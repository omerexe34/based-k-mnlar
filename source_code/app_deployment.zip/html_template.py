"""
html_template.py
================
Frontend arayüzü (HTML + CSS + JavaScript).
HTML_CODE değişkeni Flask render_template_string() tarafından kullanılır.
Jinja2 değişkenleri: {{ onesignal_app_id }}, {{ supabase_url }}, {{ supabase_key }}
"""
HTML_CODE = """
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    
    <!-- SEO Meta Tags -->
    <title>Freerider Türkiye | Türkiye'nin En Büyük Downhill & Freeride Dağ Bisikleti Topluluğu</title>
    <meta name="description" content="Türkiye'nin en büyük Downhill ve Freeride MTB dağ bisikleti topluluğu. Rotalar keşfet, ikinci el parça al-sat, etkinliklere katıl ve bisikletçilerle tanış!">
    <meta name="keywords" content="Freeride, Downhill, MTB, Dağ Bisikleti, Bisiklet Topluluğu, Enduro, İkinci El Bisiklet, Bisiklet Rotaları, Türkiye Bisiklet, Hardcore Freeride, MTB Türkiye">
    <meta name="author" content="FreeriderTR">
    <meta name="robots" content="index, follow">
    <meta name="language" content="Turkish">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://freerider.tr/">
    <meta property="og:title" content="Freerider Türkiye | Downhill & Freeride Topluluğu">
    <meta property="og:description" content="Türkiye'nin en büyük Downhill ve Freeride MTB dağ bisikleti topluluğu. Rotalar keşfet, ikinci el parça al-sat, etkinliklere katıl!">
    <meta property="og:image" content="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg">
    <meta property="og:site_name" content="FreeriderTR">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://freerider.tr/">
    <meta property="twitter:title" content="Freerider Türkiye | Downhill & Freeride Topluluğu">
    <meta property="twitter:description" content="Türkiye'nin en büyük Downhill ve Freeride MTB dağ bisikleti topluluğu. Rotalar keşfet, ikinci el parça al-sat, etkinliklere katıl!">
    <meta property="twitter:image" content="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg">

    <!-- Google / Search Engine Meta Image -->
    <meta itemprop="image" content="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg">

    <!-- Canonical URL -->
    <link rel="canonical" href="https://freerider.tr/">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#000000">
    
    <!-- Structured Data for Google Logo -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "url": "https://freerider.tr/",
      "logo": "https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg"
    }
    </script>

    <!-- iOS PWA Support -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="icon" href="data:,">
    <meta name="apple-mobile-web-app-title" content="FreeriderTR">
    <link rel="apple-touch-icon" href="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg">
    
    <!-- Onboarding System (Custom) & Canvas Confetti -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
    
    <style>
        
        /* Intro.js Customizations */
        .introjs-tooltip {
            background: rgba(15, 15, 20, 0.95) !important;
            backdrop-filter: blur(16px) saturate(180%) !important;
            -webkit-backdrop-filter: blur(16px) saturate(180%) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 20px !important;
            color: #fff !important;
            box-shadow: 0 20px 50px rgba(0,0,0,0.8) !important;
        }
        .introjs-tooltiptext { color: #d4d4d8 !important; font-size: 14px !important; }
        .introjs-tooltipbuttons { border-top: 1px solid rgba(255,255,255,0.1) !important; }
        .introjs-button { background: rgba(255,255,255,0.1) !important; color: white !important; border: none !important; text-shadow: none !important; border-radius: 8px !important; }
        .introjs-button:hover { background: #0284c7 !important; }
        .introjs-overlay { z-index: 999999 !important; }
        .introjs-helperLayer { z-index: 999998 !important; }
        </style>
    
    <!-- Tailwind CSS warning suppression -->
    <script>
        const originalWarn = console.warn;
        console.warn = function(...args) {
            if (args[0] && typeof args[0] === 'string' && args[0].includes('cdn.tailwindcss.com should not be used in production')) return;
            originalWarn.apply(console, args);
        };
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css" />
    <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
    <script src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js" defer></script>
<script>
// AI HUB LOGIC - BULLETPROOF REWRITE
(function() {
    const BUILD_STEPS = [
        { id: 'frame',      name: 'Kadro (Frame)',                    freetext: true },
        { id: 'headset',    name: 'Furç Takımı (Headset)' },
        { id: 'fork',       name: 'Maşa (Fork)' },
        { id: 'shock',      name: 'Arka Şok (Rear Shock)' },
        { id: 'bb',         name: 'Orta Göbek (Bottom Bracket)' },
        { id: 'crank',      name: 'Aynakol (Crankset)' },
        { id: 'chainguide', name: 'Zincir Gergisi (Chainguide)' },
        { id: 'derailleur', name: 'Arka Aktarıcı (Rear Derailleur)' },
        { id: 'shifter',    name: 'Vites Kolu (Shifter)' },
        { id: 'cassette',   name: 'Kaset (Cassette)' },
        { id: 'chain',      name: 'Zincir (Chain)' },
        { id: 'brakes',     name: 'Fren Seti (Brakes)' },
        { id: 'rotors',     name: 'Fren Diskleri (Rotors)' },
        { id: 'wheels',     name: 'Jant Seti (Wheelset)' },
        { id: 'tires',      name: 'Lastikler (Tires)' },
        { id: 'handlebar',  name: 'Gidon (Handlebar)' },
        { id: 'stem',       name: 'Gidon Boğazı (Stem)' },
        { id: 'grips',      name: 'Elcik (Grips)' },
        { id: 'seatpost',   name: 'Sele Borusu / Dropper (Seatpost)' },
        { id: 'saddle',     name: 'Sele (Saddle)' },
        { id: 'pedals',     name: 'Pedallar (Pedals)' },
        { id: 'extras',     name: 'Ekstralar (Örn: Çamurluk vs)',    freetext: true }
    ];

    // =========================================================
    // KAPSAMLI PARÇA VERİTABANI — Marka → Model
    // =========================================================
    const PARTS_DB = {
        frame: {
            'Santa Cruz': ['V10', 'Megatower', 'Nomad', 'Bronson', 'Hightower', 'Tallboy', 'Bullit (E-Bike)', 'Heckler (E-Bike)', 'Chameleon', 'Blur', 'Highball', 'Stigmata'],
            'Trek': ['Session', 'Slash', 'Remedy', 'Fuel EX', 'Fuel EXe', 'Top Fuel', 'Rail (E-Bike)', 'Powerfly (E-Bike)', 'Marlin', 'Roscoe', 'Procaliber', 'Supercaliber', 'Ticket'],
            'Specialized': ['Demo', 'Enduro', 'Stumpjumper EVO', 'Stumpjumper', 'Epic', 'Epic EVO', 'Chisel', 'Fuse', 'Status', 'Levo (E-Bike)', 'Levo SL (E-Bike)', 'Kenevo (E-Bike)', 'Kenevo SL (E-Bike)'],
            'Canyon': ['Sender', 'Torque', 'Strive', 'Spectral', 'Neuron', 'Lux', 'Exceed', 'Grand Canyon', 'Stoic', 'Torque:ON', 'Spectral:ON', 'Neuron:ON', 'Grand Canyon:ON'],
            'YT Industries': ['Tues', 'Capra', 'Jeffsy', 'Izzo', 'Szepter', 'Dirt Love', 'Decoy (E-Bike)'],
            'Commencal': ['Supreme DH', 'Furious', 'Clash', 'Meta AM', 'Meta SX', 'Meta TR', 'Meta HT AM', 'Absolut', 'Meta Power TR', 'Meta Power SX'],
            'Nukeproof': ['Dissent', 'Mega', 'Giga', 'Reactor', 'Scout', 'Megawatt (E-Bike)'],
            'Transition': ['TR11', 'Spire', 'Patrol', 'Sentinel', 'Scout', 'Smuggler', 'Spur', 'PBJ', 'Relay (E-Bike)', 'Repeater (E-Bike)'],
            'Evil': ['Wreckoning', 'Insurgent', 'Offering', 'Following', 'Chamois Hagar', 'Faction', 'Epocalypse (E-Bike)'],
            'Yeti': ['SB165', 'SB160', 'SB150', 'SB140', 'SB135', 'SB130', 'SB120', 'SB115', 'ARC', '160E (E-Bike)'],
            'Giant': ['Glory', 'Reign', 'Trance X', 'Trance', 'Anthem', 'XTC', 'Fathom', 'Talon', 'Stance', 'Reign E+', 'Trance X E+', 'Stance E+', 'Talon E+'],
            'Scott': ['Gambler', 'Ransom', 'Genius', 'Spark', 'Scale', 'Aspect', 'Voltage', 'Ransom eRIDE', 'Genius eRIDE', 'Strike eRIDE', 'Patron eRIDE', 'Lumen eRIDE'],
            'Propain': ['Rage', 'Spindrift', 'Tyee', 'Hugene', 'Trickshot', 'Ekano (E-Bike)'],
            'Pivot': ['Phoenix', 'Firebird', 'Mach 6', 'Switchblade', 'Trail 429', 'Mach 4 SL', 'LES SL', 'Shuttle LT', 'Shuttle AM', 'Shuttle SL'],
            'Orbea': ['Rallon', 'Occam LT', 'Occam SL', 'Oiz', 'Alma', 'Laufey', 'Onna', 'Wild', 'Rise', 'Urrun', 'Keram'],
            'Ibis': ['Ripmo', 'Ripmo AF', 'Ripley', 'Ripley AF', 'Mojo HD5', 'Mojo 4', 'Exie', 'Oso (E-Bike)'],
            'Norco': ['Aurum HSP', 'Shore', 'Range', 'Sight', 'Optic', 'Fluid FS', 'Fluid HT', 'Revolver', 'Torrent', 'Rampage', 'Range VLT', 'Sight VLT', 'Fluid VLT'],
            'Devinci': ['Wilson', 'Spartan', 'Troy', 'Marshall', 'Django', 'Kobain', 'AC (E-Bike)', 'DC (E-Bike)', 'E-Troy', 'E-Spartan'],
            'Rocky Mountain': ['Maiden', 'Slayer', 'Altitude', 'Instinct', 'Element', 'Growler', 'Soul', 'Vertex', 'Altitude Powerplay', 'Instinct Powerplay', 'Growler Powerplay'],
            'Kona': ['Operator', 'Process X', 'Process 153', 'Process 134', 'Hei Hei', 'Honzo', 'Honzo ESD', 'Big Honzo', 'Kahuna', 'Remote (E-Bike)', 'Remote 160'],
            'GT': ['Fury', 'Force', 'Sensor', 'Zaskar', 'Avalanche', 'Aggressor', 'La Bomba', 'Force AMP', 'Pantera AMP'],
            'Merida': ['One-Sixty', 'One-Forty', 'One-Twenty', 'Ninety-Six', 'Big.Nine', 'Big.Trail', 'Matts', 'eOne-Sixty', 'eOne-Forty', 'eBig.Nine'],
            'Cube': ['Two15', 'Stereo ONE77', 'Stereo ONE55', 'Stereo ONE44', 'Stereo ONE22', 'Reaction', 'Attention', 'Analog', 'Aim', 'Stereo Hybrid 160', 'Stereo Hybrid 140', 'Stereo Hybrid 120', 'Reaction Hybrid'],
            'Marin': ['Alpine Trail', 'Rift Zone', 'San Quentin', 'Bobcat Trail', 'Bolinas Ridge', 'El Roy', 'Pine Mountain', 'Alpine Trail E', 'Rift Zone E'],
            'Mondraker': ['Summum', 'Superfoxy', 'Foxy', 'Raze', 'Podium', 'Chrono', 'Level (E-Bike)', 'Crafty (E-Bike)', 'Chaser (E-Bike)', 'Dusk (E-Bike)', 'Prime (E-Bike)'],
            'Ghost': ['Riot EN', 'Riot AM', 'Riot Trail', 'Lector', 'Nirvana', 'Kato', 'E-Riot EN', 'E-Riot AM', 'E-Riot Trail', 'E-Teru'],
            'Polygon': ['Collosus DH', 'Collosus N9', 'Siskiu T', 'Siskiu D', 'Xtrada', 'Premier', 'Cascade', 'Mt Bromo (E-Bike)', 'Siskiu TE (E-Bike)']
        },
        headset: {
            'Chris King': ['InSet 1 (EC49/40)', 'InSet 2 (EC49/40)', 'InSet 3', 'InSet 7 (EC49/40)', 'InSet 8 (ZS49/EC49)', 'NoThreadSet (ZS44)', 'NoThreadSet (EC49)', 'ThreadFit 40 (ZS56)', 'GripNut', 'Dropset 1', 'Dropset 2', 'Dropset 3', 'Dropset 4', 'Dropset 5'],
            'Cane Creek': ['40 Series (ZS44/ZS56)', '40 Series (IS41/IS52)', '40 Series (EC34/EC44)', '110 Series (ZS44/ZS56)', '110 Series (IS41/IS52)', 'Hellbender 70 (ZS44/ZS56)', 'Hellbender 70 (IS41/IS52)', 'ViscoSet', 'AER', 'SlamSet'],
            'FSA': ['Orbit C-40', 'Orbit 1.5 ZS', 'Orbit Z', 'No.10', 'No.57E', 'No.42/ACB', 'No.55R', 'No.69', 'DX Pro', 'The Pig DH Pro', 'Orbit MX'],
            'Ritchey': ['WCS Logic Drop In', 'WCS Press Fit', 'WCS Zero', 'Comp Logic', 'Comp Zero', 'Classic'],
            'Hope': ['Pick n Mix (Custom)', 'Traditional', 'Integral', 'Internal (Zero Stack)', 'Integrated (IS)'],
            'Nukeproof': ['Horizon 44IETS', 'Horizon 44-56IITS', 'Neutron', 'Warhead'],
            'Wolf Tooth': ['Premium IS', 'Premium ZS', 'Premium EC', 'Performance IS', 'Performance ZS', 'Performance EC', 'GeoShift Angle Headset'],
            'Acros': ['AZX-203', 'AZX-212', 'AZX-226', 'AZX-252', 'AZX-258', 'Blocklock', 'ZS44/ZS56', 'IS41/IS52'],
            'Token': ['Omega A83', 'Omega C83', 'Ninja', 'Kudos'],
            'Brand-X': ['Sealed Integrated', 'Sealed ZS44/ZS56', 'Sealed EC34/EC44'],
            'First': ['DS-1', 'Z1', 'R1']
        },
        fork: {
            'Fox': ['32 Float Step-Cast Factory', '32 Float Step-Cast Performance', '32 Float Rhythm', '34 Float Factory', '34 Float Performance Elite', '34 Float Performance', '34 Float Rhythm', '34 Step-Cast Factory', '34 Step-Cast Performance', '36 Float Factory', '36 Float Performance Elite', '36 Float Performance', '36 Float Rhythm', '38 Float Factory', '38 Float Performance Elite', '38 Float Performance', '40 Float Factory', '40 Float Performance'],
            'RockShox': ['Judy Silver TK', 'Judy Gold RL', 'Recon Silver RL', 'Recon Gold RL', '35 Silver TK', '35 Gold RL', 'Bluto', 'Reba RL', 'SID SL Select', 'SID SL Ultimate', 'SID Select', 'SID Select+', 'SID Ultimate', 'Revelation RC', 'Pike Select', 'Pike Select+', 'Pike Ultimate', 'Lyrik Select', 'Lyrik Select+', 'Lyrik Ultimate', 'Zeb Select', 'Zeb Select+', 'Zeb Ultimate', 'Domain RC', 'Domain Select', 'BoXXer Select', 'BoXXer Ultimate'],
            'Manitou': ['Markhor', 'Machete', 'Machete JUNIT', 'Circus Sport', 'Circus Expert', 'Circus Pro', 'Mattoc Comp', 'Mattoc Expert', 'Mattoc Pro', 'Mezzer Expert', 'Mezzer Pro', 'Dorado Comp', 'Dorado Expert', 'Dorado Pro', 'Mastodon Comp', 'Mastodon Pro'],
            'Marzocchi': ['Bomber Z2', 'Bomber Z1 Air', 'Bomber Z1 Coil', 'Bomber 58', 'Bomber DJ'],
            'Öhlins': ['RXF34 m.2', 'RXF36 m.2 Air', 'RXF36 m.2 Coil', 'RXF38 m.2', 'DH38 m.1'],
            'DVO': ['Sapphire D1', 'Diamond D1', 'Diamond D2', 'Onyx SC D1', 'Onyx DC D1', 'Beryl'],
            'SR Suntour': ['XCT', 'XCM', 'XCR 32', 'XCR 34', 'Raidon 32', 'Raidon 34', 'Epixon', 'Axon 32', 'Axon 34', 'Aion 35', 'Auron 35', 'Durolux 36', 'Durolux 38', 'Rux 38'],
            'Formula': ['33', '35', 'Selva R', 'Selva S', 'Selva C', 'Nero C', 'Nero R'],
            'Cane Creek': ['Helm MKII Air', 'Helm MKII Coil'],
            'EXT': ['Era V2', 'Era V2 LT', 'Ferro'],
            'Trust Performance': ['Message', 'Shout'],
            'RST': ['Gila', 'Blaze', 'Omega', 'Aerial', 'First', 'Rogue', 'Stitch', 'Killah'],
            'Magura': ['TS6', 'TS8', 'Boltron (E-Bike)'],
            'Cannondale': ['Lefty Ocho', 'Lefty Ocho Carbon', 'Lefty Supermax', 'Lefty Oliver']
        },
        shock: {
            'Fox': ['Float DPS Performance', 'Float DPS Performance Elite', 'Float DPS Factory', 'Float SL', 'Float X Performance', 'Float X Performance Elite', 'Float X Factory', 'Float X2 Performance', 'Float X2 Factory', 'DHX Performance', 'DHX Factory', 'DHX2 Performance Elite', 'DHX2 Factory', 'Float DPX2'],
            'RockShox': ['Monarch R', 'Monarch RT3', 'Monarch Plus RC3', 'Deluxe Select', 'Deluxe Select+', 'Deluxe Ultimate', 'Super Deluxe Select', 'Super Deluxe Select+', 'Super Deluxe Ultimate', 'Super Deluxe Coil Select', 'Super Deluxe Coil Select+', 'Super Deluxe Coil Ultimate', 'Vivid Air', 'Vivid Coil', 'Kage RC'],
            'Öhlins': ['TTX1 Air', 'TTX2 Air', 'TTX22M.2 Coil', 'TTX Flow'],
            'Cane Creek': ['DB IL Air', 'DB IL Coil', 'Kitsuma Air', 'Kitsuma Coil'],
            'Marzocchi': ['Bomber Air', 'Bomber CR'],
            'DVO': ['Topaz T3 Air', 'Topaz 2', 'Topaz 3', 'Jade Coil', 'Jade X Coil'],
            'EXT': ['Storia LOK V3', 'Arma V3', 'Aria'],
            'Push': ['ElevenSix', 'SV8'],
            'Manitou': ['Mara Inline', 'Mara Pro'],
            'Formula': ['Mod'],
            'SR Suntour': ['Raidon R', 'Epixon R', 'Triair 3CR', 'Triair2 3CR', 'Voro'],
            'X-Fusion': ['O2 Pro RL', 'O2 Pro RCX', 'Vector Air HLR', 'Vector Coil HLR', 'H3C Coil'],
            'Fast Suspension': ['Fenix Evo', 'Holy Grail']
        },
        bb: {
            'Shimano': ['BB-UN101 (Square Taper)', 'BB-UN300 (Square Taper)', 'BB-MT500 (Hollowtech II)', 'BB-MT501', 'SM-BB52', 'BB-MT800', 'BB-MT801', 'SM-BB93', 'BB-MT500-PA (Press-Fit)', 'BB-MT800-PA', 'SM-BB71-41A', 'SM-BB94-41A'],
            'SRAM': ['Power Spline', 'Howitzer XR', 'Howitzer Team', 'GXP XR', 'GXP Team', 'PressFit GXP', 'DUB BSA 68/73', 'DUB BSA 83', 'DUB PressFit 89/92', 'DUB PressFit 104.5/107', 'DUB BB30', 'DUB PF30'],
            'Race Face': ['BSA 24mm', 'BSA 30mm', 'Cinch BSA 30', 'PF30 24mm', 'PF30 30mm', 'BB92 24mm', 'BB92 30mm'],
            'Hope': ['Stainless Steel BSA 24mm', 'Stainless Steel BSA 30mm', 'PressFit 41 24mm', 'PressFit 41 30mm', 'PressFit 46 24mm', 'PressFit 46 30mm'],
            'Chris King': ['ThreadFit 24', 'ThreadFit 30', 'PressFit 24', 'PressFit 30', 'ThreadFit T47'],
            'Cane Creek': ['Hellbender 70 BSA', 'Hellbender 70 PF41', 'Hellbender 70 PF30', 'Hellbender 70 BB30', 'Hellbender 70 T47', 'Hellbender Neo (Ceramic)'],
            'Wheels Manufacturing': ['BSA 24', 'BSA 30', 'BB86/92 to 24', 'BB86/92 to 30', 'PF30 Outboard', 'BB30 Outboard', 'T47 Outboard'],
            'Token': ['Ninja Lite (PF)', 'Ninja (Threaded PF)', 'Ninja Token ThreadFit', 'VGM BB'],
            'FSA': ['MegaExo', 'MegaEvo', 'BB30', 'PF30', 'BB392EVO', 'Platinum Pro (ISIS)'],
            'Praxis Works': ['M30 BSA', 'M30 BB86/92', 'M30 BB30/PF30', 'M30 T47', 'Shimano BB30/PF30 Conv']
        },
        crank: {
            'Shimano': ['Tourney FC-TY301', 'Tourney FC-TY501', 'Altus FC-M311', 'Altus FC-MT101', 'Acera FC-M361', 'Acera FC-MT210', 'Alivio FC-M4050', 'Alivio FC-M3100', 'Deore FC-M4100-2', 'Deore FC-M5100-1', 'Deore FC-M5100-2', 'Deore FC-M6100-1', 'Deore FC-M6120-1', 'Deore FC-M6130-1', 'SLX FC-M7100-1', 'SLX FC-M7120-1', 'SLX FC-M7130-1', 'XT FC-M8100-1', 'XT FC-M8120-1', 'XT FC-M8130-1', 'XTR FC-M9100-1', 'XTR FC-M9120-1', 'ZEE FC-M640', 'Saint FC-M820', 'Saint FC-M825', 'FC-MT511', 'FC-MT611'],
            'SRAM': ['SX Eagle', 'NX Eagle', 'GX Eagle', 'GX Eagle Carbon', 'X1 Carbon', 'X01 Eagle', 'X01 Eagle DUB', 'XX1 Eagle', 'XX1 Eagle DUB', 'X0 Eagle Transmission', 'XX Eagle Transmission', 'XX SL Eagle Transmission', 'Descendant 6K', 'Descendant 7K', 'Descendant Carbon', 'Stylo 6K', 'Stylo 7K', 'Stylo Carbon'],
            'Race Face': ['Ride', 'Chester', 'Aeffect', 'Aeffect R', 'Turbine', 'Turbine R', 'Atlas', 'Next R', 'Next SL', 'Era'],
            'Hope': ['Evo', 'Evo e-Bike', 'RX'],
            'e*thirteen': ['Base', 'Helix Core', 'Helix Race', 'LG1 Plus', 'LG1 Race Carbon', 'TRS Plus', 'TRS Race Carbon', 'XCX Race Carbon'],
            'Truvativ': ['Hussefelt', 'Holzfeller', 'Descendant (Alloy/Carbon)', 'Stylo (Alloy/Carbon)'],
            'FSA': ['Alpha Drive', 'Gamma Pro', 'Comet', 'V-Drive', 'Afterburner', 'Gradient', 'K-Force', 'KFX'],
            'Cane Creek': ['eeWings Mountain Titanium', 'eeWings Raven'],
            'Rotor': ['Kapic', 'Kapic Carbon', 'RHawk', 'Raptor'],
            'Praxis Works': ['Cadet M30', 'Girder Carbon', 'Lyft Carbon'],
            'Miranda': ['Delta (E-Bike)', 'Kappa (E-Bike)'],
            'Suntour': ['XCC', 'XCE', 'XCM', 'Zeron'],
            'Prowheel': ['Charm', 'Zephyr', 'Claw', 'MPX']
        },
        chainguide: {
            'MRP': ['1x CS', '1x Alloy', '1x Carbon', 'AMg CS', 'AMg Alloy', 'AMg Carbon', 'SXg Alloy', 'SXg Carbon', 'G4 Alloy', 'G4 Carbon', 'XCG V2'],
            'e*thirteen': ['Base Guide', 'TRS Plus', 'TRS Race', 'LG1 Plus', 'LG1 Race', 'Vario Top Guide', 'XCX Plus', 'XCX Race'],
            'OneUp Components': ['Chainguide - ISCG05', 'Bash Guide - ISCG05', 'Chain Guide - High Direct Mount', 'Chain Guide - Low Direct Mount'],
            'Wolf Tooth': ['GnarWolf ISCG05', 'GnarWolf High Direct Mount', 'GnarWolf Seat Tube', 'LoneWolf Aero'],
            'Funnn': ['Zippa Lite', 'Zippa DH', 'Zippa Bash'],
            'Hope': ['Slick Guide', 'Dropper Guide'],
            'Mozartt': ['HXR', 'Presto', 'Presto Steel', 'Meno Carbon', 'Piano'],
            'Reverse Components': ['X11-Evo', 'X1-B', 'Colab'],
            'Shimano': ['SM-CD50', 'SM-CD800', 'STEPS E8000 Guide'],
            'Sixpack': ['Kamikaze', 'Vertic'],
            'AbsoluteBlack': ['Oval Guide ISCG05', 'Oval Guide HDM']
        },
        derailleur: {
            'Shimano': ['Tourney TY200', 'Tourney TY300', 'Tourney TX800', 'Altus M310', 'Altus M370', 'Altus M2000', 'Acera M360', 'Acera M3000', 'Acera M3020', 'Alivio M4000', 'Alivio M3100', 'Deore M592', 'Deore M6000 (10s GS/SGS)', 'Deore M5120 (10/11s)', 'Deore M5100 (11s)', 'Deore M6100 (12s)', 'SLX M670', 'SLX M7000 (11s)', 'SLX M7100 (12s)', 'SLX M7120 (12s)', 'XT M786', 'XT M8000 (11s GS/SGS)', 'XT M8100 (12s)', 'XT M8120 (12s)', 'XTR M986', 'XTR M9000 (11s)', 'XTR M9100 (12s GS/SGS)', 'XTR M9120 (12s)', 'Saint M820', 'ZEE M640 (SS/Freeride)', 'CUES U4000 (9s)', 'CUES U6000 (10/11s)', 'CUES U8000 (11s)'],
            'SRAM': ['X3 (7/8s/9s)', 'X4 (8/9s)', 'X5 (9/10s)', 'X7 (9/10s)', 'X9 (9/10s)', 'X0 (9/10s)', 'NX (11s)', 'GX (10/11s)', 'X1 (11s)', 'X01 (11s)', 'XX1 (11s)', 'SX Eagle (12s)', 'NX Eagle (12s)', 'GX Eagle (12s)', 'GX Eagle AXS (12s)', 'X01 Eagle (12s)', 'X01 Eagle AXS (12s)', 'XX1 Eagle (12s)', 'XX1 Eagle AXS (12s)', 'GX Eagle Transmission', 'X0 Eagle Transmission', 'XX Eagle Transmission', 'XX SL Eagle Transmission'],
            'microSHIFT': ['Mezzo (8/9s)', 'Marvo LT (9s)', 'XLE (10/11s)', 'Advent (9s)', 'Advent X (10s)', 'Acolyte (8s)', 'Sword (10s)'],
            'Box Components': ['Box Four (8s)', 'Box Three (9s)', 'Box Two (11s)', 'Box One (11s)'],
            'TRP': ['TR12 (12s)', 'DH7 (7s)', 'Evo7 (7s)', 'Evo12 (12s)'],
            'SunRace': ['M40 (7/8s)', 'M50 (8/9s)', 'M90 (9s)', 'MS (10s)', 'MX (10/11s)', 'MZ (12s)']
        },
        shifter: {
            'Shimano': ['Tourney RS35 (Revoshift)', 'Tourney TX50', 'Tourney EF41', 'Altus M310', 'Altus M315', 'Altus M2000', 'Acera M360', 'Acera M3000', 'Alivio M4000', 'Alivio M3100', 'Deore M590', 'Deore M6000', 'Deore M5100', 'Deore M6100', 'SLX M670', 'SLX M7000', 'SLX M7100', 'XT M780', 'XT M8000', 'XT M8100', 'XTR M980', 'XTR M9000', 'XTR M9100', 'Saint M820', 'ZEE M640', 'CUES U4000', 'CUES U6000', 'CUES U8000'],
            'SRAM': ['X3 Trigger', 'X4 Trigger', 'X5 Trigger', 'X7 Trigger', 'X9 Trigger', 'X0 Trigger', 'NX Trigger', 'GX Trigger', 'X1 Trigger', 'X01 Trigger', 'XX1 Trigger', 'SX Eagle Trigger', 'NX Eagle Trigger', 'GX Eagle Trigger', 'GX Eagle AXS Controller', 'X01 Eagle Trigger', 'X01 Eagle AXS Controller', 'XX1 Eagle Trigger', 'XX1 Eagle AXS Controller', 'Eagle AXS Pod Controller', 'Eagle AXS Pod Ultimate', 'Grip Shift NX/GX/X01/XX1'],
            'microSHIFT': ['Mezzo Trigger', 'XLE Trigger', 'Advent Trigger', 'Advent X Trigger', 'Advent X Pro Trigger', 'Acolyte Trigger', 'Thumb Shifters'],
            'Box Components': ['Box Four Shifter', 'Box Three Shifter', 'Box Two Shifter', 'Box One Shifter'],
            'TRP': ['TR12 Shifter', 'DH7 Shifter', 'Evo7 Shifter', 'Evo12 Shifter'],
            'SunRace': ['M40 Trigger', 'M50 Trigger', 'M90 Trigger', 'DLM (Trigger)']
        },
        cassette: {
            'Shimano': ['Tourney TZ500 (6/7s)', 'Tourney HG200 (7/8/9s)', 'Altus HG31 (8s)', 'Acera HG400 (9s)', 'Alivio HG400 (9s)', 'Deore HG50 (10s)', 'Deore HG500 (10s)', 'Deore M4100 (10s)', 'Deore M5100 (11s)', 'Deore M6100 (12s)', 'SLX HG81 (10s)', 'SLX M7000 (11s)', 'SLX M7100 (12s)', 'XT M771 (10s)', 'XT M8000 (11s)', 'XT M8100 (12s)', 'XTR M980 (10s)', 'XTR M9000 (11s)', 'XTR M9100 (12s)', 'Linkglide LG300', 'Linkglide LG400', 'Linkglide LG600', 'Linkglide LG700'],
            'SRAM': ['PG-730 (7s)', 'PG-820 (8s)', 'PG-850 (8s)', 'PG-920 (9s)', 'PG-950 (9s)', 'PG-970 (9s)', 'PG-1030 (10s)', 'PG-1050 (10s)', 'PG-1070 (10s)', 'PG-1130 (11s)', 'XG-1150 (11s)', 'XG-1175 (11s)', 'XG-1195 (11s)', 'XG-1199 (11s)', 'PG-1210 (SX 12s)', 'PG-1230 (NX 12s)', 'XG-1275 (GX 12s)', 'XG-1295 (X01 12s)', 'XG-1299 (XX1 12s)', 'XS-1275 (Transmission)', 'XS-1295 (Transmission)', 'XS-1299 (Transmission)'],
            'microSHIFT': ['H081 (8s)', 'H092 (9s)', 'H100 (10s)', 'H113 (11s)', 'Advent (9s 11-42/46)', 'Advent X (10s 11-48)', 'Acolyte (8s 12-42/46)'],
            'SunRace': ['CSM90 (9s)', 'CSMS2 (10s)', 'CSMX3 (10s)', 'CSMS8 (11s)', 'CSMX8 (11s)', 'CSMZ80 (12s)', 'CSMZ90 (12s)'],
            'e*thirteen': ['TRS Plus (9-44/9-46)', 'TRS Race (9-46)', 'Helix R (9-46/9-50/9-52)', 'Helix Plus (9-50)'],
            'Garbaruk': ['10s (11-42/45)', '11s (11-46/48/50)', '12s (10-50/52)', '12s Microspline (10-52)'],
            'Box Components': ['Box Four (8s 11-42)', 'Box Three (9s 11-50)', 'Box Two (11s 11-50)', 'Box One (11s 11-50)']
        },
        chain: {
            'Shimano': ['UG51 (6/7/8s)', 'HG40 (6/7/8s)', 'HG71 (8s)', 'HG53 (9s)', 'HG93 (9s)', 'HG54 (10s)', 'HG95 (10s)', 'HG601 (11s)', 'HG701 (11s)', 'HG901 (11s)', 'M6100 (12s)', 'M7100 (12s)', 'M8100 (12s)', 'M9100 (12s)', 'E6090 (E-Bike 10s)', 'E8000 (E-Bike 11s)'],
            'SRAM': ['PC-830', 'PC-850', 'PC-870', 'PC-951', 'PC-971', 'PC-991', 'PC-1031', 'PC-1051', 'PC-1071', 'PC-1091R', 'PC-1110', 'PC-1130', 'PC-1170', 'XX1 11s', 'SX Eagle', 'NX Eagle', 'GX Eagle', 'X01 Eagle', 'XX1 Eagle', 'Flattop Transmission GX', 'Flattop Transmission X0', 'Flattop Transmission XX', 'EX1 (E-Bike)'],
            'KMC': ['Z6', 'Z7', 'Z8', 'Z9', 'X8', 'X9', 'X10', 'X10EL', 'X10SL', 'X11', 'X11EL', 'X11SL', 'X12', 'X12 Ti-N', 'X12 DLC', 'e8 (E-Bike)', 'e9 (E-Bike)', 'e10 (E-Bike)', 'e11 (E-Bike)', 'e12 (E-Bike)'],
            'Connex': ['800', '804', '808', '900', '904', '908', '10s0', '10sB', '10sG', '11s0', '11sB', '11sX', '12s0', '12sX', '10sE (E-Bike)'],
            'YBN': ['S8', 'S9', 'S10', 'S11', 'S12', 'SLA10', 'SLA11', 'SLA12', 'SLA211 (Titanium)', 'SLA212 (Titanium)'],
            'Campagnolo': ['Record 9s', 'Record 10s', 'Record 11s', 'Record 12s', 'Super Record 12s']
        },
        brakes: {
            'Shimano': ['Tourney TX805 (Mech)', 'MT200', 'MT400', 'MT500', 'MT420 (4-Pot)', 'MT520 (4-Pot)', 'Deore M6000', 'Deore M6100', 'Deore M6120 (4-Pot)', 'SLX M7000', 'SLX M7100', 'SLX M7120 (4-Pot)', 'XT M8000', 'XT M8100', 'XT M8120 (4-Pot)', 'XTR M9000', 'XTR M9020', 'XTR M9100', 'XTR M9120 (4-Pot)', 'ZEE M640 (4-Pot)', 'Saint M820 (4-Pot)'],
            'SRAM': ['Level', 'Level T', 'Level TL', 'Level TLM', 'Level Ultimate', 'Level Bronze Stealth', 'Level Silver Stealth', 'Level Ultimate Stealth', 'Guide T', 'Guide R', 'Guide RS', 'Guide RSC', 'Guide Ultimate', 'Guide RE', 'G2 R', 'G2 RS', 'G2 RSC', 'G2 Ultimate', 'Code R', 'Code RS', 'Code RSC', 'Code Bronze Stealth', 'Code Silver Stealth', 'Code Ultimate Stealth', 'Maven Bronze', 'Maven Silver', 'Maven Ultimate'],
            'Magura': ['MT Sport', 'MT2', 'MT4', 'MT5', 'MT5 FABIO WIBMER', 'MT7 Pro', 'MT7 Raceline', 'MT8 Pro', 'MT8 SL', 'MT Trail Sport', 'MT Trail SL'],
            'Hope': ['Tech 3 X2', 'Tech 3 E4', 'Tech 3 V4', 'Tech 4 X2', 'Tech 4 E4', 'Tech 4 V4'],
            'TRP': ['Slate T4', 'Slate EVO', 'Quadiem', 'G-Spec Quadiem', 'Trail EVO', 'DH-R EVO', 'DH-R EVO Gold'],
            'Hayes': ['Radar', 'Prime Sport', 'Prime Pro', 'Dominion A2', 'Dominion A4', 'Dominion T2', 'Dominion T4'],
            'Formula': ['RX', 'The One', 'RO Racing', 'Cura', 'Cura 4', 'Cura X'],
            'Clarks': ['Clout 1', 'M2', 'M3', 'M4'],
            'Tektro': ['Aries (Mech)', 'Aquila (Mech)', 'HD-M275', 'HD-M285', 'Gemini', 'Auriga', 'Orion 4P'],
            'Promax': ['Solve', 'F1', 'Decipher']
        },
        rotors: {
            'Shimano': ['SM-RT10', 'SM-RT26', 'SM-RT30', 'SM-RT54', 'SM-RT56', 'SM-RT64', 'SM-RT66', 'SM-RT70 (Ice-Tech)', 'SM-RT76', 'SM-RT86 (Ice-Tech)', 'RT-MT800 (Ice-Tech Freeza)', 'RT-MT900 (Ice-Tech Freeza)', 'SM-RT99'],
            'SRAM': ['Centerline', 'Centerline 2-Piece', 'Centerline Rounded', 'HS2', 'Paceline', 'G2 CleanSweep'],
            'Hope': ['Standard 6-Bolt', 'Floating 6-Bolt', 'Vented V4', 'Centerlock Floating'],
            'Magura': ['Storm', 'Storm HC', 'Storm SL.2', 'MDR-C', 'MDR-P'],
            'TRP': ['TR-16', 'TR-25', 'TR-29', 'TR-33', 'R1', 'RS01E', 'RS02M'],
            'Galfer': ['Wave Fixed', 'Wave Floating', 'Disc Shark'],
            'Hayes': ['D-Series', 'V-Series'],
            'Formula': ['1-Piece Solid', '1-Piece Lightweight', '2-Piece Floating'],
            'Clarks': ['Wavy', 'Floating'],
            'SwissStop': ['Catalyst One', 'Catalyst Pro', 'Catalyst Race'],
            'AbsoluteBlack': ['Raven']
        },
        wheels: {
            'DT Swiss': ['E 1900 Spline', 'M 1900 Spline', 'X 1900 Spline', 'E 1700 Spline', 'M 1700 Spline', 'X 1700 Spline', 'EX 1700 Spline', 'XM 1700 Spline', 'XR 1700 Spline', 'EX 1501 Spline One', 'XM 1501 Spline One', 'XR 1501 Spline One', 'EXC 1501 Carbon', 'XMC 1501 Carbon', 'XRC 1501 Carbon', 'EXC 1200 Carbon', 'XMC 1200 Carbon', 'XRC 1200 Carbon', 'FR 1950 Classic', 'FR 541', 'HX 1700 (E-Bike)'],
            'Stan\\\'s NoTubes': ['Crest S1', 'Arch S1', 'Flow S1', 'Crest MK3', 'Arch MK3', 'Flow MK3', 'Crest MK4', 'Arch MK4', 'Flow MK4', 'Flow EX3', 'Crest CB7 Carbon', 'Arch CB7 Carbon', 'Flow CB7 Carbon', 'Podium SRD Carbon'],
            'Industry Nine': ['1/1 Trail S', '1/1 Enduro S', 'Hydra Trail S', 'Hydra Enduro S', 'Hydra Trail 270', 'Hydra Enduro 305', 'Hydra Grade 300', 'Ultralite 235', 'Pillar Carbon Trail', 'Pillar Carbon Enduro'],
            'Crankbrothers': ['Cobalt 1', 'Cobalt 2', 'Cobalt 3', 'Cobalt 11 Carbon', 'Iodine 2', 'Iodine 3', 'Opium 3', 'Synthesis Alloy XCT', 'Synthesis Alloy Enduro', 'Synthesis Alloy DH', 'Synthesis Carbon XCT', 'Synthesis Carbon Enduro', 'Synthesis Carbon DH'],
            'Mavic': ['Crossmax', 'Crossmax SL', 'Crossmax XL', 'Crossmax SL R Carbon', 'Crossmax XL R Carbon', 'Deemax', 'Deemax Park', 'Deemax Pro', 'E-Deemax'],
            'Enve': ['M525', 'M630', 'M635', 'M640', 'M730', 'M735', 'M930', 'Foundation AM30'],
            'Hope': ['Fortus 23', 'Fortus 26', 'Fortus 30', 'Fortus 30 SC', 'Hope Tech 35W'],
            'Race Face': ['Aeffect R', 'Turbine R', 'Atlas', 'Next R Carbon', 'Next SL Carbon'],
            'Hunt': ['Trail Wide', 'Enduro Wide', 'All-Mountain Carbon H_Impact', 'Enduro Carbon H_Impact', 'Proven Race XC', 'Proven Race Enduro'],
            'Spank': ['Spoon 32', 'Spike Race 33', 'Oozy Trail 395+', 'Oozy Trail 345', 'Hex Drive', 'Vibrocore 350'],
            'Reynolds': ['TR 309', 'TR 309 S', 'TR 367', 'TR 367 S', 'Blacklabel XC', 'Blacklabel Trail', 'Blacklabel Enduro'],
            'e*thirteen': ['LG1 Base', 'LG1 Plus', 'LG1 Race Carbon', 'TRS Base', 'TRS Plus', 'TRS Race Carbon', 'XCX Race Carbon'],
            'Roval': ['Traverse Alloy', 'Traverse SL Carbon', 'Control Alloy', 'Control Carbon', 'Control SL Carbon'],
            'Santa Cruz / Reserve': ['Reserve 25', 'Reserve 27', 'Reserve 30', 'Reserve 30|SL', 'Reserve 30|HD', 'Reserve 31|DH', 'Reserve 28|XC'],
            'Bontrager': ['Kovee Comp', 'Kovee Elite', 'Kovee Pro', 'Kovee RSL', 'Line Comp', 'Line Elite', 'Line Pro Carbon', 'Line DH']
        },
        tires: {
            'Maxxis': ['Minion DHF', 'Minion DHR II', 'Assegai', 'High Roller II', 'Shorty', 'Wetscream', 'Aggressor', 'Dissector', 'Forekaster', 'Ardent', 'Ardent Race', 'Ikon', 'Rekon', 'Rekon Race', 'Crossmark II', 'Aspen', 'Severe', 'Tomahawk', 'Griffin', 'Pace', 'Larsen TT', 'Ignitor', 'Minion SS', 'Agressor', 'MaxxLite'],
            'Continental': ['Kryptotal-F', 'Kryptotal-R', 'Argotal', 'Hydrotal', 'Xynotal', 'Der Kaiser', 'Der Baron', 'Mud King', 'Trail King', 'Mountain King', 'Cross King', 'Race King', 'Speed King', 'Ruban', 'Terra Trail'],
            'Schwalbe': ['Magic Mary', 'Big Betty', 'Hans Dampf', 'Nobby Nic', 'Wicked Will', 'Racing Ray', 'Racing Ralph', 'Thunder Burt', 'Rocket Ron', 'Smart Sam', 'Dirty Dan', 'Ice Spiker Pro', 'Eddy Current Front', 'Eddy Current Rear', 'Fat Albert'],
            'Vittoria': ['Mazza', 'Martello', 'Mota', 'Morsa', 'Agarro', 'Barzo', 'Mezcal', 'Gato', 'Synergic', 'E-Mazza', 'E-Martello', 'E-Barzo'],
            'WTB': ['Verdict', 'Verdict Wet', 'Judge', 'Vigilante', 'Trail Boss', 'Ranger', 'Riddler', 'Nano', 'Vulpine', 'Convict', 'Wolverine', 'Breakout'],
            'Michelin': ['Wild Enduro Front', 'Wild Enduro Rear', 'Wild AM', 'Wild AM2', 'Force AM', 'Force AM2', 'Force XC', 'Jet XC2', 'DH22', 'DH34', 'DH Mud', 'E-Wild'],
            'Pirelli': ['Scorpion Race DH M', 'Scorpion Race DH T', 'Scorpion Race DH S', 'Scorpion Race Enduro M', 'Scorpion Race Enduro T', 'Scorpion Race Enduro S', 'Scorpion Enduro S', 'Scorpion Enduro M', 'Scorpion Enduro R', 'Scorpion Trail S', 'Scorpion Trail M', 'Scorpion Trail R', 'Scorpion XC S', 'Scorpion XC M', 'Scorpion XC R', 'Scorpion XC RC'],
            'Specialized': ['Butcher', 'Eliminator', 'Hillbilly', 'Purgatory', 'Ground Control', 'Fast Trak', 'Renegade', 'Slaughter', 'Cannibal'],
            'Bontrager': ['SE6 Team Issue', 'SE5 Team Issue', 'SE4 Team Issue', 'XR4 Team Issue', 'XR3 Team Issue', 'XR2 Team Issue', 'XR1 Team Issue', 'G5 Team Issue', 'G-Mud'],
            'Hutchinson': ['Griffus', 'Toro', 'Kraken', 'Skeleton', 'Taipan', 'Gila', 'Cougar', 'Python 2', 'Skeleton Racing Lab'],
            'Kenda': ['Hellkat Pro', 'Nevegal 2', 'Pinner Pro', 'Regolith Pro', 'Booster Pro', 'Honey Badger', 'Karma 2', 'El Moco', 'Small Block Eight', 'Slant Six'],
            'Onza': ['Aquila', 'Porcupine', 'Porcupine RC', 'Ibex', 'Canis', 'Citius', 'Greina'],
            'Goodyear': ['Newton MTF', 'Newton MTR', 'Escape', 'Peak', 'Connector', 'Wrangler MTF']
        },
        handlebar: {
            'Renthal': ['Fatbar 35', 'Fatbar Carbon 35', 'Fatbar Lite 35', 'Fatbar Lite Carbon 35', 'Fatbar 31.8', 'Fatbar Carbon 31.8', 'Fatbar Lite 31.8', 'Fatbar V2'],
            'Race Face': ['Next 35 Carbon', 'Next R 35 Carbon', 'SixC 35 Carbon', 'Turbine R 35', 'Atlas 35', 'Aeffect R 35', 'Chester 35', 'Respond', 'Evolve'],
            'Deity': ['Skywire 35 Carbon', 'Speedway 35 Carbon', 'Ridgeline 35', 'Racepoint 35', 'Topside 35', 'Blacklabel 31.8', 'Hole Shot 31.8', 'Highside 760', 'Highside 50mm'],
            'Chromag': ['BZA 35 Carbon', 'Cutlass 31.8 Carbon', 'OSX 35', 'OSX 31.8', 'OSX LTD', 'FU40', 'FU50', 'Acute'],
            'OneUp Components': ['Carbon Handlebar 35', 'Aluminum Handlebar 35'],
            'Burgtec': ['Ride Wide Enduro Carbon 35', 'Ride Wide Enduro Alloy 35', 'Ride Wide DH Alloy 35', 'Ride Wide DH Alloy 31.8', 'Josh Bryceland Signature'],
            'Spank': ['Spike 800 Vibrocore', 'Spike 35 Vibrocore', 'Oozy 780 Trail', 'Oozy 35', 'Spoon 800', 'Spoon 785'],
            'e*thirteen': ['Race Carbon 35', 'Plus Alloy 35', 'Base Alloy 35'],
            'Truvativ': ['Descendant Carbon 35', 'Descendant Alloy 35', 'Descendant DH', 'Stylo Carbon', 'Stylo Alloy', 'Jerome Clementz Signature', 'Danny Hart Signature'],
            'Pro (Shimano)': ['Tharsis 35 Carbon', 'Tharsis 31.8 Carbon', 'Koryak Di2', 'Koryak 35', 'LT', 'FRS'],
            'ENVE': ['M5', 'M6', 'M7', 'M9', 'Sweep', 'Riser'],
            'Hope': ['Carbon 35', 'Carbon 31.8'],
            'PNW Components': ['Range Handlebar Gen 3', 'Loam Carbon'],
            'Thomson': ['Elite Carbon', 'Elite Titanium', 'Elite Alloy Trail'],
            'Nukeproof': ['Horizon V2 Carbon', 'Horizon V2 Alloy', 'Sam Hill Signature'],
            'Title': ['AH1 35', 'AH1 31.8', 'Form Carbon']
        },
        stem: {
            'Renthal': ['Apex 35', 'Apex 31.8', 'Integra 35 (Direct Mount)', 'Integra 31.8 (Direct Mount)', 'Strata (Direct Mount)'],
            'Race Face': ['Turbine R 35', 'Atlas 35', 'Atlas 31.8', 'Atlas Direct Mount', 'Aeffect R 35', 'Aeffect 31.8', 'Chester 35', 'Chester Direct Mount', 'Respond'],
            'Deity': ['Copperhead 35', 'Copperhead 31.8', 'Cavity 31.8', 'Micro DM', 'Intake 31.8 DM', 'Intake 35 DM', 'Crosshair'],
            'Hope': ['AM/Freeride 31.8', 'Gravity 35', 'Direct Mount 31.8', 'Direct Mount 35', 'XC 31.8'],
            'Chromag': ['Ranger V2 31.8', 'BZA 35', 'Hifi V2 31.8', 'Hifi 35', 'Director Direct Mount', 'Rift Direct Mount'],
            'Burgtec': ['Enduro MK3 35', 'Enduro MK3 31.8', 'Direct Mount MK3 35', 'Direct Mount MK3 31.8'],
            'Industry Nine': ['A35', 'A318', 'A35 Direct Mount'],
            'OneUp Components': ['Stem 35'],
            'Spank': ['Split 35', 'Split 31.8', 'Spike Race 2', 'Oozy Trail', 'Spike Direct Mount'],
            'Truvativ': ['Descendant 35', 'Descendant 31.8', 'Descendant Direct Mount', 'Stylo', 'Holzfeller', 'Hussefelt'],
            'Thomson': ['Elite X4 31.8', 'Elite 35', 'Direct Mount'],
            'e*thirteen': ['Plus 35', 'Base 35'],
            'Pro (Shimano)': ['Tharsis 35', 'Koryak 35', 'Koryak 31.8', 'LT', 'FRS Direct Mount'],
            'Title': ['ST1 35', 'ST1 31.8', 'DM1 Direct Mount'],
            'PNW Components': ['Range Stem Gen 3'],
            'Nukeproof': ['Horizon', 'Neutron', 'Sam Hill Signature']
        },
        grips: {
            'ODI': ['Ruffian Lock-On', 'Ruffian Mini', 'Elite Pro Lock-On', 'Elite Motion Lock-On', 'Elite Flow Lock-On', 'Rogue Lock-On', 'Oury Lock-On', 'AG-1 Aaron Gwin', 'AG-2 Aaron Gwin', 'Troy Lee Designs Lock-On', 'Vans Lock-On', 'F-1 Float', 'Dreadlocks'],
            'Ergon': ['GE1 Evo', 'GE1 Evo Factory', 'GA2', 'GA2 Fat', 'GA3', 'GD1 Evo', 'GD1 Factory', 'GFR1', 'GFR1 Factory', 'GS1', 'GP1'],
            'DMR': ['Deathgrip', 'Deathgrip Flangeless', 'Deathgrip Thick', 'Brendog', 'Sect'],
            'Race Face': ['Half Nelson', 'Getta Grip', 'Love Handle', 'Grippler', 'Chester'],
            'PNW Components': ['Loam Grip', 'Loam Grip XL'],
            'Deity': ['Knuckleduster', 'Supracush', 'Lockjaw', 'Slimfit', 'Waypoint'],
            'Renthal': ['Lock-On Traction', 'Lock-On Kevlar', 'Lock-On Ultra Tacky', 'Push-On Kevlar', 'Push-On Ultra Tacky'],
            'Chromag': ['Format', 'Squarewaves', 'Basis', 'Wax', 'Clutch', 'Palmskin'],
            'ESI': ['Chunky', 'Extra Chunky', 'Fit SG', 'Fit CR', 'Racer\\\'s Edge', 'Plush'],
            'Sensus': ['Swayze', 'Lite', 'Meaty Paw', 'Emil Johansson Signature', 'Bite', 'Disisdaboss'],
            'Wolf Tooth': ['Fat Paw', 'Fat Paw Cam', 'Karat', 'Mega Fat Paw', 'Razer', 'Echo Lock-On'],
            'Lizard Skins': ['MacAskill', 'Peaty', 'Northshore', 'Machine', 'Charger', 'Moab', 'DSP 30.3', 'DSP 32.3'],
            'Burgtec': ['Bartender', 'Bartender Pro (Greg Minnaar)'],
            'Spank': ['Spike 30', 'Spike 33', 'Oozy Trail'],
            'OneUp Components': ['Lock-On Grips'],
            'WTB': ['Trail', 'Wafel', 'Commander', 'Koda'],
            'Syncros': ['Pro Lock-On', 'Comfort Lock-On', 'XR Silicon']
        },
        seatpost: {
            'Fox': ['Transfer Factory', 'Transfer Performance Elite', 'Transfer Performance', 'Transfer SL Factory', 'Transfer SL Performance Elite', 'Transfer SL Performance'],
            'RockShox': ['Reverb AXS', 'Reverb Stealth', 'Reverb XPLR AXS'],
            'OneUp Components': ['Dropper Post V2', 'Dropper Post V3'],
            'BikeYoke': ['Revive', 'Revive Max', 'Divine', 'Divine SL', 'Divine SL Rascal'],
            'PNW Components': ['Loam Dropper', 'Ridge Dropper', 'Cascade Dropper', 'Rainier Gen 3', 'Pine Dropper', 'Coast Suspension Dropper'],
            'KS (Kind Shock)': ['LEV Integra', 'LEV Ci', 'LEV Si', 'Rage-i', 'Dropzone', 'Supernatural', 'Crux-i', 'Eten', 'Eten-i'],
            'Crankbrothers': ['Highline 3', 'Highline 7', 'Highline 11 Carbon', 'Highline XC/Gravel'],
            'Race Face': ['Turbine R Dropper', 'Aeffect R Dropper', 'Chester Rigid', 'Next Carbon Rigid'],
            'Thomson': ['Elite Dropper', 'Covert Dropper', 'Elite Rigid', 'Masterpiece Rigid', 'Masterpiece Carbon'],
            'TranzX': ['Kitsuma Air', 'Kitsuma Coil', 'Skyline', 'Jump Seat'],
            'e*thirteen': ['Vario Infinite'],
            'SDG': ['Tellis V2', 'Tellis'],
            'Specialized': ['Command Post IRcc', 'Command Post BlackLite', 'Command Post SRL'],
            'Bontrager': ['Line Elite Dropper', 'Line Dropper', 'Drop Line'],
            'Syncros': ['Duncan Dropper 1.5', 'Duncan Dropper 2.0', 'Duncan Aero'],
            'Hope': ['Carbon Seatpost', 'Eternity']
        },
        saddle: {
            'Ergon': ['SM Pro', 'SM Comp', 'SM Sport', 'SM Enduro Pro', 'SM Enduro Comp', 'SMC Core', 'SR Allroad', 'SR Pro', 'SM E-Mountain'],
            'WTB': ['Volt', 'Silverado', 'Koda', 'Pure', 'Rocket', 'Hightail', 'Devo', 'Gravelier'],
            'Specialized': ['Power Pro', 'Power Expert', 'Power Comp', 'Phenom Pro', 'Phenom Expert', 'Bridge Comp', 'Bridge Sport', 'Romin EVO', 'Henge', 'Avatar'],
            'Fizik': ['Terra Alpaca X5', 'Gravita Alpaca X5', 'Taiga', 'Tundra M3', 'Gobi M3', 'Antares', 'Aliante', 'Vento Argo', 'Tempo Argo'],
            'Selle Italia': ['SLR Boost', 'Flite Boost', 'Model X', 'X-Bow', 'Novus Boost Evo', 'SLR TM Superflow', 'Max Flite'],
            'SDG': ['Bel-Air V3', 'Radar', 'Duster', 'Circuit', 'Fly', 'Apollo', 'Patriot'],
            'Chromag': ['Trailmaster', 'Trailmaster DT', 'Trailmaster LTD', 'Lynx DT', 'Moon', 'Overture', 'Mood'],
            'Fabric': ['Scoop Shallow', 'Scoop Radius', 'Scoop Flat', 'Line Shallow', 'Line Pro', 'Cell', 'Magic', 'Alm'],
            'Prologo': ['Dimension NDR', 'Dimension Space', 'Scratch M5', 'Scratch X8', 'Nago X10', 'Proxim W450', 'Proxim W650 (E-Bike)'],
            'SQLab': ['611 Ergowave', '611 Ergowave Active', '612 Ergowave', '60X Ergowave', '6OX Infinergy'],
            'Bontrager': ['Arvada', 'Verse', 'Aeolus', 'Kovee', 'Montrose', 'Ajna', 'Evoke'],
            'Syncros': ['Tofino', 'Savona', 'Belcarra', 'Comox', 'Capilano'],
            'Tioga': ['Spyder Outland', 'Spyder Stratum', 'Undercover Stratum', 'D-Spyder'],
            'Selle San Marco': ['Ground', 'Allroad', 'Shortfit', 'Aspide', 'Mantra'],
            'Deity': ['Speedtrap', 'Sidetrack', 'Frisco']
        },
        pedals: {
            'Shimano': ['PD-M9120 (XTR Trail)', 'PD-M9100 (XTR XC)', 'PD-M8120 (XT Trail)', 'PD-M8100 (XT XC)', 'PD-M8140 (XT Flat)', 'PD-M828 (Saint Flat)', 'PD-M820 (Saint Clipless)', 'PD-M821 (Saint Clipless)', 'PD-M647 (DX)', 'PD-M642 (ZEE Flat)', 'PD-M540', 'PD-M530', 'PD-M520', 'PD-M424', 'PD-M324', 'PD-GR500 (Flat)', 'PD-GR400 (Flat)', 'PD-EF202 (Flat)', 'PD-EH500 (Hybrid)'],
            'Crankbrothers': ['Mallet E', 'Mallet E LS', 'Mallet DH', 'Mallet 2', 'Mallet 3', 'Eggbeater 11', 'Eggbeater 3', 'Eggbeater 2', 'Eggbeater 1', 'Candy 11', 'Candy 7', 'Candy 3', 'Candy 2', 'Candy 1', 'Stamp 1 (Flat)', 'Stamp 2 (Flat)', 'Stamp 3 (Flat)', 'Stamp 7 (Flat)', 'Stamp 11 (Flat)', 'Double Shot 1', 'Double Shot 2', 'Double Shot 3'],
            'Race Face': ['Atlas', 'Aeffect', 'Chester', 'Ride'],
            'Deity': ['TMAC', 'Bladerunner', 'Black Kat', 'Deftrap', 'Compound'],
            'HT Components': ['X2 (DH Clipless)', 'X2T (Titanium)', 'T1 (Enduro Clipless)', 'T2', 'ME03 (Magnesium Flat)', 'AE03 (Evo Flat)', 'AE05', 'ANS10 Supreme', 'PA03A (Composite Flat)', 'Leopard M4'],
            'Hope': ['F20', 'F22', 'Union TC', 'Union GC', 'Union RC'],
            'Burgtec': ['Penthouse Flat MK5', 'Penthouse Flat MK5 Composite', 'MK4'],
            'OneUp Components': ['Aluminum Pedals', 'Composite Pedals'],
            'DMR': ['Vault', 'Vault Midi', 'Vault Mag', 'V12', 'V12 Mag', 'V11 (Composite)', 'V8', 'V6'],
            'Nukeproof': ['Horizon Pro', 'Horizon Comp', 'Horizon CS Trail', 'Horizon CL DH', 'Neutron Evo'],
            'Look': ['X-Track Race Carbon Ti', 'X-Track Race Carbon', 'X-Track Race', 'X-Track En-Rage', 'X-Track En-Rage Plus', 'Trail Roc (Flat)', 'Trail Grip'],
            'Spank': ['Oozy Trail', 'Spike Reboot', 'Spoon 110', 'Spoon 100', 'Spoon 90'],
            'Time': ['Speciale 12', 'Speciale 8', 'ATAC XC 12', 'ATAC XC 8', 'ATAC XC 6', 'ATAC MX 6', 'ATAC MX 4'],
            'Chromag': ['Scarab', 'Dagga', 'Contact', 'Synth'],
            'Yoshimura': ['Chilao'],
            'Bontrager': ['Line Pro', 'Line Elite', 'Elite MTB Clipless', 'Comp MTB Clipless']
        }
    };


    // Hangi adımda dropdown yok → serbest metin
    const FREETEXT_STEPS = new Set(['extras']);

    // =========================================================
    // DROPDOWN UI OLUŞTURUCUSU (CUSTOM BUILD)
    // =========================================================
    window.renderBuildInputUI = function() {
        const step = BUILD_STEPS[currentBuildStepIndex];
        if (!step) return;
        const isFree = FREETEXT_STEPS.has(step.id) || !PARTS_DB[step.id];
        const area = document.getElementById('ai-build-input-area');
        if (!area) return;

        if (isFree) {
            area.innerHTML = `
                <input type="text" id="ai-inp-build" class="ai-input mb-3" placeholder="Marka ve model girin...">
                <div class="flex gap-2 mb-4">
                    <button class="flex-[2] ai-btn bg-purple-600 hover:bg-purple-500 text-white !border-none" onclick="runAI('build')" style="pointer-events:auto;">Ekle &amp; Kontrol Et</button>
                    <button class="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-all" onclick="window.aiSkipBuildStep()" style="pointer-events:auto;">Geç ⏭</button>
                    <button class="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-all" onclick="window.aiUndoBuildStep()" style="pointer-events:auto;">← Geri Al</button>
                </div>
            `;
        } else {
            const brands = Object.keys(PARTS_DB[step.id]).sort();
            const brandOptions = brands.map(b => `<option value="${b}">${b}</option>`).join('');
            area.innerHTML = `
                <div class="flex flex-col gap-2 mb-3">
                    <select id="ai-build-brand" onchange="window.onBuildBrandChange()" class="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl px-3 py-2.5 text-sm font-semibold focus:outline-none focus:border-purple-500 transition-colors">
                        <option value="">— Marka Seç —</option>
                        ${brandOptions}
                    </select>
                    <select id="ai-build-model" class="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-purple-500 transition-colors" disabled>
                        <option value="">— Önce marka seçin —</option>
                    </select>
                    <div id="ai-build-selected-preview" class="hidden text-xs text-purple-300 font-bold bg-purple-900/20 border border-purple-700/40 rounded-lg px-3 py-2"></div>
                    <div class="text-center text-zinc-500 text-xs font-bold my-1">— VEYA —</div>
                    <input type="text" id="ai-inp-build" class="ai-input mt-1" placeholder="Listede yoksa direkt yazın..." oninput="window.onBuildManualInput()">
                </div>
                <div class="flex gap-2 mb-4">
                    <button class="flex-[2] ai-btn bg-purple-600 hover:bg-purple-500 text-white !border-none" onclick="runAI('build')" style="pointer-events:auto;">Ekle &amp; Kontrol Et</button>
                    <button class="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-all" onclick="window.aiSkipBuildStep()" style="pointer-events:auto;">Geç ⏭</button>
                    <button class="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-all" onclick="window.aiUndoBuildStep()" style="pointer-events:auto;">← Geri Al</button>
                </div>
            `;
        }
    };

    window.onBuildBrandChange = function() {
        const step = BUILD_STEPS[currentBuildStepIndex];
        const brand = document.getElementById('ai-build-brand').value;
        const modelSel = document.getElementById('ai-build-model');
        const preview = document.getElementById('ai-build-selected-preview');
        const inp = document.getElementById('ai-inp-build');
        if (!brand) { modelSel.disabled = true; modelSel.innerHTML = '<option>— Önce marka seçin —</option>'; preview.classList.add('hidden'); inp.value = ''; return; }
        const models = PARTS_DB[step.id][brand] || [];
        modelSel.disabled = false;
        modelSel.innerHTML = '<option value="">— Model Seç —</option>' + models.map(m => `<option value="${m}">${m}</option>`).join('');
        modelSel.onchange = function() {
            const model = modelSel.value;
            if (model) {
                inp.value = brand + ' ' + model;
                preview.textContent = '✅ Seçilen: ' + brand + ' ' + model;
                preview.classList.remove('hidden');
            } else {
                inp.value = '';
                preview.classList.add('hidden');
            }
        };
        inp.value = ''; preview.classList.add('hidden');
    };

    window.onBuildManualInput = function() {
        const inp = document.getElementById('ai-inp-build').value;
        const preview = document.getElementById('ai-build-selected-preview');
        const brandSel = document.getElementById('ai-build-brand');
        const modelSel = document.getElementById('ai-build-model');
        if (inp) {
            if (preview) { preview.textContent = '✏️ Manuel giriş: ' + inp; preview.classList.remove('hidden'); }
            if (brandSel) { brandSel.value = ''; }
            if (modelSel) { modelSel.innerHTML = '<option>— Önce marka seçin —</option>'; modelSel.disabled = true; }
        } else {
            if (preview) preview.classList.add('hidden');
        }
    };

    // =========================================================
    // DROPDOWN UI OLUŞTURUCUSU (PARÇA İNCELEME)
    // =========================================================
    window.renderPartInputUI = function() {
        const categories = Object.keys(PARTS_DB);
        const catMap = {
            frame: 'Kadro', headset: 'Furç Takımı', fork: 'Maşa', shock: 'Arka Şok', bb: 'Orta Göbek', crank: 'Aynakol',
            chainguide: 'Zincir Gergisi', derailleur: 'Arka Aktarıcı', shifter: 'Vites Kolu', cassette: 'Kaset',
            chain: 'Zincir', brakes: 'Fren Seti', rotors: 'Fren Diskleri', wheels: 'Jant Seti', tires: 'Lastikler',
            handlebar: 'Gidon', stem: 'Gidon Boğazı', grips: 'Elcik', seatpost: 'Sele Borusu', saddle: 'Sele', pedals: 'Pedallar'
        };
        const catOptions = categories.map(c => `<option value="${c}">${catMap[c] || c}</option>`).join('');

        const html = `
            <div class="flex flex-col gap-2 mb-4">
                <select id="ai-part-cat" onchange="window.onPartCatChange()" class="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl px-3 py-2.5 text-sm font-semibold focus:outline-none focus:border-blue-500 transition-colors">
                    <option value="">— Parça Türü Seç —</option>
                    ${catOptions}
                </select>
                <select id="ai-part-brand" onchange="window.onPartBrandChange()" class="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl px-3 py-2.5 text-sm font-semibold focus:outline-none focus:border-blue-500 transition-colors" disabled>
                    <option value="">— Önce tür seçin —</option>
                </select>
                <select id="ai-part-model" class="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-500 transition-colors" disabled>
                    <option value="">— Önce marka seçin —</option>
                </select>
                <div id="ai-part-selected-preview" class="hidden text-xs text-blue-300 font-bold bg-blue-900/20 border border-blue-700/40 rounded-lg px-3 py-2"></div>
                
                <div class="text-center text-zinc-500 text-xs font-bold my-1">— VEYA —</div>
                <input type="text" id="ai-inp-part" class="ai-input" placeholder="Listede yoksa manuel girin (Örn: Fox 40 Factory)" oninput="window.onPartManualInput()">
            </div>
            <button class="ai-btn bg-blue-600 hover:bg-blue-500 text-white w-full py-3 rounded-xl font-bold transition-all !border-none" onclick="runAI('part')" style="pointer-events: auto;">Skorla & İncele</button>
        `;
        
        const container = document.getElementById('ai-part-input-container');
        if (container) container.innerHTML = html;
    };

    window.onPartCatChange = function() {
        const cat = document.getElementById('ai-part-cat').value;
        const brandSel = document.getElementById('ai-part-brand');
        const modelSel = document.getElementById('ai-part-model');
        const preview = document.getElementById('ai-part-selected-preview');
        const inp = document.getElementById('ai-inp-part');

        if (!cat) {
            brandSel.disabled = true; brandSel.innerHTML = '<option>— Önce tür seçin —</option>';
            modelSel.disabled = true; modelSel.innerHTML = '<option>— Önce marka seçin —</option>';
            preview.classList.add('hidden'); inp.value = ''; return;
        }

        const brands = Object.keys(PARTS_DB[cat]).sort();
        brandSel.disabled = false;
        brandSel.innerHTML = '<option value="">— Marka Seç —</option>' + brands.map(b => `<option value="${b}">${b}</option>`).join('');
        modelSel.disabled = true; modelSel.innerHTML = '<option value="">— Önce marka seçin —</option>';
        inp.value = ''; preview.classList.add('hidden');
    };

    window.onPartBrandChange = function() {
        const cat = document.getElementById('ai-part-cat').value;
        const brand = document.getElementById('ai-part-brand').value;
        const modelSel = document.getElementById('ai-part-model');
        const preview = document.getElementById('ai-part-selected-preview');
        const inp = document.getElementById('ai-inp-part');

        if (!brand) { modelSel.disabled = true; modelSel.innerHTML = '<option>— Önce marka seçin —</option>'; preview.classList.add('hidden'); inp.value = ''; return; }

        const models = PARTS_DB[cat][brand] || [];
        modelSel.disabled = false;
        modelSel.innerHTML = '<option value="">— Model Seç —</option>' + models.map(m => `<option value="${m}">${m}</option>`).join('');
        modelSel.onchange = function() {
            const model = modelSel.value;
            if (model) {
                inp.value = brand + ' ' + model;
                preview.textContent = '✅ Seçilen: ' + brand + ' ' + model;
                preview.classList.remove('hidden');
            } else {
                inp.value = '';
                preview.classList.add('hidden');
            }
        };
        inp.value = ''; preview.classList.add('hidden');
    };

    window.onPartManualInput = function() {
        const inp = document.getElementById('ai-inp-part').value;
        const preview = document.getElementById('ai-part-selected-preview');
        const catSel = document.getElementById('ai-part-cat');
        const brandSel = document.getElementById('ai-part-brand');
        const modelSel = document.getElementById('ai-part-model');

        if (inp) {
            if (preview) { preview.textContent = '✏️ Manuel giriş: ' + inp; preview.classList.remove('hidden'); }
            if (catSel) catSel.value = '';
            if (brandSel) { brandSel.innerHTML = '<option>— Önce tür seçin —</option>'; brandSel.disabled = true; }
            if (modelSel) { modelSel.innerHTML = '<option>— Önce marka seçin —</option>'; modelSel.disabled = true; }
        } else {
            if (preview) preview.classList.add('hidden');
        }
    };

    let currentBuildStepIndex = 0;
    let aiBuildMemory = {};

    window.openAIHub = function() {
        try {
            if(typeof showToast==='function') showToast("AI Hub Açılıyor...", "info", 1500);
            const overlay = document.getElementById('ai-hub-overlay');
            if(!overlay) return;
            document.body.appendChild(overlay);
            overlay.style.setProperty('display', 'flex', 'important');
            overlay.style.setProperty('opacity', '1', 'important');
            overlay.style.setProperty('visibility', 'visible', 'important');
            overlay.style.setProperty('z-index', '9999999', 'important');
            overlay.style.setProperty('pointer-events', 'auto', 'important');
            overlay.style.setProperty('position', 'fixed', 'important');
            overlay.style.setProperty('top', '0', 'important');
            overlay.style.setProperty('left', '0', 'important');
            overlay.style.setProperty('width', '100%', 'important');
            overlay.style.setProperty('height', '100%', 'important');
            overlay.classList.add('show');
            if(typeof window.backToAIMenu === 'function') window.backToAIMenu();
            window.updateBuildProgress(0); // Initialize build UI
        } catch(e) {}
    };

    window.closeAIHub = function() {
        try {
            const overlay = document.getElementById('ai-hub-overlay');
            if(overlay) {
                overlay.classList.remove('show');
                overlay.style.display = 'none';
            }
        } catch(e) {}
    };

    window.backToAIMenu = function() {
        try {
            document.getElementById('ai-main-menu').style.display = 'block';
            document.querySelectorAll('.ai-screen').forEach(el => el.style.display = 'none');
            document.getElementById('ai-hub-title').innerText = 'AI Merkezi';
        } catch(e) {}
    };

    window.openAIScreen = function(type) {
        document.getElementById('ai-main-menu').style.display = 'none';
        document.querySelectorAll('.ai-screen').forEach(el => el.style.display = 'none');
        document.getElementById(`ai-screen-${type}`).style.display = 'flex';
        const titles = { 'analysis': 'Bisiklet Analizi', 'recommend': 'Akıllı Öneri', 'build': 'Custom Build', 'part': 'Parça İnceleme' };
        document.getElementById('ai-hub-title').innerText = titles[type];
        
        // Eğer Custom Build açılıyorsa, UI'ı güncelle
        if (type === 'build') {
            window.updateBuildProgress();
        }
        // Eğer Parça İnceleme açılıyorsa ve dropdown div'i henüz oluşturulmadıysa doldur
        if (type === 'part') {
            const container = document.getElementById('ai-part-input-container');
            // Check if it already has the select elements, if not render it
            if (container && !container.querySelector('select')) {
                window.renderPartInputUI();
            }
        }
    };

    window.updateBuildProgress = function(forceStepIndex = -1) {
        if(forceStepIndex !== -1) currentBuildStepIndex = forceStepIndex;
        
        const isDone = currentBuildStepIndex >= BUILD_STEPS.length;
        
        const progContainer = document.getElementById('ai-build-progress');
        if(progContainer) {
            let dots = '';
            for(let i=0; i<BUILD_STEPS.length; i++) {
                const stepId = BUILD_STEPS[i].id;
                const isInstalled = (i < currentBuildStepIndex);
                
                const svgs = [
                    document.getElementById(`svg-part-${stepId}`),
                    document.getElementById(`svg-part-${stepId}-r`)
                ];
                svgs.forEach(svgEl => {
                    if (svgEl) {
                        if (isInstalled) svgEl.classList.add('svg-installed');
                        else svgEl.classList.remove('svg-installed');
                    }
                });

                if(i < currentBuildStepIndex) dots += '<div class="w-3 h-3 rounded-full bg-green-500 shrink-0"></div>';
                else if(i === currentBuildStepIndex) dots += '<div class="w-3 h-3 rounded-full bg-purple-500 shrink-0 border-2 border-white "></div>';
                else dots += '<div class="w-3 h-3 rounded-full bg-zinc-800 shrink-0"></div>';
            }
            progContainer.innerHTML = dots;
        }

        if(currentBuildStepIndex >= BUILD_STEPS.length) {
            document.getElementById('ai-build-input-area').style.display = 'none';
            document.getElementById('ai-build-complete-area').style.display = 'block';
            document.getElementById('ai-build-step-title').innerText = `${BUILD_STEPS.length} Parça Seçildi`;
            document.getElementById('ai-build-step-counter').innerText = 'Tebrikler';
            document.getElementById('ai-build-summary-text').innerText = 'Tüm donanımlar hazır. Şimdi analiz et veya kopyala.';
        } else {
            document.getElementById('ai-build-input-area').style.display = 'block';
            const step = BUILD_STEPS[currentBuildStepIndex];
            document.getElementById('ai-build-step-counter').innerText = `Adım ${currentBuildStepIndex + 1} / ${BUILD_STEPS.length}`;
            document.getElementById('ai-build-step-title').innerText = step.name;
            const hasDB = PARTS_DB[step.id];
            document.getElementById('ai-build-summary-text').innerText = hasDB ? '⬇️ Listeden seçin veya direkt yazın.' : 'Marka ve model girin.';
            document.getElementById('ai-build-input-area').classList.remove('hidden');
            document.getElementById('ai-build-complete-area').classList.add('hidden');
            window.renderBuildInputUI();
        }
    };

    window.aiUndoBuildStep = function() {
        if(currentBuildStepIndex > 0) {
            currentBuildStepIndex--;
            const stepId = BUILD_STEPS[currentBuildStepIndex].id;
            delete aiBuildMemory[stepId];
            window.updateBuildProgress();
            document.getElementById('ai-res-build').innerHTML = '';
        }
    };

    window.aiSkipBuildStep = function() {
        if(currentBuildStepIndex < BUILD_STEPS.length) {
            const stepId = BUILD_STEPS[currentBuildStepIndex].id;
            aiBuildMemory[stepId] = 'Atlandı / Kullanılmıyor';
            currentBuildStepIndex++;
            window.updateBuildProgress();
            document.getElementById('ai-res-build').innerHTML = `<div class="p-2 bg-zinc-800/80 rounded-lg text-center text-xs text-zinc-400 font-bold border border-zinc-700/50">⏭ Adım atlandı.</div>`;
            document.getElementById('ai-inp-build').value = '';
        }
    };

    window.aiResetBuild = function() {
        aiBuildMemory = {};
        currentBuildStepIndex = 0;
        document.getElementById('ai-res-build').innerHTML = '';
        window.updateBuildProgress();
    };

    window.aiCopyBuild = function() {
        let text = "🚲 Benim Custom Build Projem:\\n";
        for(let i=0; i<BUILD_STEPS.length; i++) {
            const step = BUILD_STEPS[i];
            const part = aiBuildMemory[step.id] || '-';
            text += `✅ ${step.name}: ${part}\\n`;
        }
        navigator.clipboard.writeText(text).then(() => {
            if(typeof showToast==='function') showToast("Tasarım kopyalandı!", "success");
        });
    };

    window.aiAnalyzeFullBuild = async function() {
        const loader = document.getElementById(`ai-loader-build`);
        const resBox = document.getElementById(`ai-res-build`);
        loader.style.display = 'block';
        resBox.innerHTML = '';
        
        try {
            const r = await fetch('/api/data', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ action: 'ai_bike_build_final', data: { build_data: aiBuildMemory } })
            });
            const data = await r.json();
            loader.style.display = 'none';
            if (data.status === 'error') {
                resBox.innerHTML = `<div class="ai-result-box" style="border-color: #ef4444;"><div class="text-red-400 font-bold">${data.message}</div></div>`;
                return;
            }
            const d = data.data;
            resBox.innerHTML = `<div class="ai-result-box">
                <div class="ai-score-ring">${d.score || 0}</div>
                <div class="text-center text-xs text-zinc-400 mb-6 font-bold tracking-widest uppercase">Genel Uyum Skoru</div>
                <div class="ai-stat-row"><span class="ai-stat-label">Uygun Kategori</span> <span class="ai-stat-val text-purple-400">${d.category || '-'}</span></div>
                
                <div class="mt-4 mb-2 font-bold text-sm text-green-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Genel Değerlendirme</div>
                <div class="text-sm text-zinc-200 leading-relaxed mb-4">${d.overall_review || '-'}</div>
                
                <div class="mt-4 mb-2 font-bold text-sm text-red-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Zayıf Halka / Eksikler</div>
                <ul class="text-zinc-300 text-sm list-disc pl-4 space-y-1">${(d.weaknesses||[]).map(s => `<li>${s}</li>`).join('')}</ul>
                
                <div class="mt-4 mb-2 font-bold text-sm text-yellow-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Tavsiyeler</div>
                <ul class="text-zinc-300 text-sm list-disc pl-4 space-y-1">${(d.recommendations||[]).map(s => `<li>${s}</li>`).join('')}</ul>
            </div>`;
        } catch(e) {
            loader.style.display = 'none';
            resBox.innerHTML = `<div class="ai-result-box" style="border-color: #ef4444;"><div class="text-red-400 font-bold">Analiz hatası oluştu.</div></div>`;
        }
    };

    window.runAI = async function(type) {
        const loader = document.getElementById(`ai-loader-${type}`);
        const resBox = document.getElementById(`ai-res-${type}`);
        loader.style.display = 'block';
        resBox.innerHTML = '';
        
        let payload = { action: '' };
        
        if (type === 'analysis') {
            const val = document.getElementById('ai-inp-analysis').value;
            if(!val) return loader.style.display = 'none';
            payload = { action: 'ai_bike_analysis', data: { bike_info: val } };
        } 
        else if (type === 'recommend') {
            const b = document.getElementById('ai-inp-rec-budget').value;
            const s = document.getElementById('ai-inp-rec-style').value;
            const t = document.getElementById('ai-inp-rec-terrain').value;
            const l = document.getElementById('ai-inp-rec-level').value;
            if(!b || !s) return loader.style.display = 'none';
            payload = { action: 'ai_bike_recommendation', data: { budget: b, style: s, terrain: t, level: l } };
        }
        else if (type === 'build') {
            const req = document.getElementById('ai-inp-build').value;
            if(!req) return loader.style.display = 'none';
            
            const currentStepDef = BUILD_STEPS[currentBuildStepIndex];
            payload = { 
                action: 'ai_bike_build', 
                data: { 
                    history: aiBuildMemory, 
                    new_request: req,
                    current_step: currentStepDef.name,
                    next_step: (currentBuildStepIndex + 1 < BUILD_STEPS.length) ? BUILD_STEPS[currentBuildStepIndex + 1].name : "Tamamlandı"
                } 
            };
        }
        else if (type === 'part') {
            const p = document.getElementById('ai-inp-part').value;
            if(!p) return loader.style.display = 'none';
            payload = { action: 'ai_part_analysis', data: { part_name: p } };
        }
        
        try {
            const r = await fetch('/api/data', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            });
            const data = await r.json();
            loader.style.display = 'none';
            
            if (data.status === 'error') {
                resBox.innerHTML = `<div class="ai-result-box" style="border-color: #ef4444;"><div class="text-red-400 font-bold">${data.message}</div></div>`;
                return;
            }
            
            const d = data.data;
            let html = '';
            
            if (d.status === 'needs_info') {
                html += `<div class="ai-result-box" style="border-color: #eab308; box-shadow: 0 0 15px rgba(234,179,8,0.2);">
                    <div class="text-yellow-400 font-bold mb-2 uppercase tracking-widest text-sm">Eksik Bilgi Tespit Edildi</div>
                    <div class="text-zinc-200 text-sm leading-relaxed">${d.question || 'Lütfen daha detaylı bilgi verin.'}</div>
                </div>`;
                resBox.innerHTML = html;
                return;
            }
            
            if (type === 'analysis') {
                html += `<div class="ai-result-box">
                    <div class="ai-score-ring">${d.performance_score || 0}</div>
                    <div class="text-center text-xs text-zinc-400 mb-6 font-bold tracking-widest uppercase">Performans Skoru</div>
                    
                    <div class="ai-stat-row"><span class="ai-stat-label">Kategori</span> <span class="ai-stat-val text-purple-400">${d.category || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Sürüş Tarzı</span> <span class="ai-stat-val">${d.riding_style || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Geometri</span> <span class="ai-stat-val">${d.geometry || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Süspansiyon</span> <span class="ai-stat-val">${d.suspension || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Lastikler</span> <span class="ai-stat-val">${d.tires || '-'}</span></div>
                    
                    <div class="mt-4 mb-2 font-bold text-sm text-green-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Güçlü Yönler</div>
                    <div>${(d.strengths||[]).map(s => `<span class="ai-tag green">${s}</span>`).join('')}</div>
                    
                    <div class="mt-4 mb-2 font-bold text-sm text-red-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Zayıf Yönler</div>
                    <div>${(d.weaknesses||[]).map(s => `<span class="ai-tag red">${s}</span>`).join('')}</div>
                    
                    <div class="mt-4 mb-2 font-bold text-sm text-yellow-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Yükseltme Önerileri</div>
                    <ul class="text-zinc-300 text-sm list-disc pl-4 space-y-1">${(d.upgrades||[]).map(s => `<li>${s}</li>`).join('')}</ul>
                </div>`;
            }
            else if (type === 'recommend') {
                html += `<div class="ai-result-box">
                    <div class="text-center mb-6">
                        <div class="text-3xl mb-2">🚲</div>
                        <div class="font-black text-xl text-purple-400 uppercase tracking-wider">${d.bike_type || '-'}</div>
                        <div class="text-sm font-bold text-green-400 mt-1">${d.estimated_price || 'Bütçe Analizi Yapılmadı'}</div>
                        <div class="text-xs text-zinc-400 mt-2">${d.level_advice || ''}</div>
                    </div>
                    
                    <div class="ai-stat-row"><span class="ai-stat-label">Geometri</span> <span class="ai-stat-val text-blue-300">${d.geometry || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Travel Önerisi</span> <span class="ai-stat-val text-yellow-400">${d.suspension_travel || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Teker Önerisi</span> <span class="ai-stat-val">${d.wheel_size || '-'}</span></div>
                    
                    <div class="mt-6 mb-2 font-bold text-sm text-white uppercase tracking-widest border-b border-zinc-800 pb-1">Örnek Modeller</div>
                    <div class="flex flex-col gap-2 mt-3">
                        ${(d.models||[]).map(s => `<div class="bg-black/50 border border-zinc-700/50 p-3 rounded-lg font-bold text-sm text-zinc-200 border-l-4 border-l-purple-500">${s}</div>`).join('')}
                    </div>
                </div>`;
            }
            else if (type === 'build') {
                // Save the approved part
                const currentStepDef = BUILD_STEPS[currentBuildStepIndex];
                aiBuildMemory[currentStepDef.id] = document.getElementById('ai-inp-build').value;
                document.getElementById('ai-inp-build').value = '';
                
                // Advance step
                currentBuildStepIndex++;
                window.updateBuildProgress();
                
                let warnHtml = '';
                if (d.compatibility_warning && d.compatibility_warning.length > 5) {
                    warnHtml = `<div class="bg-red-900/30 border-l-4 border-l-red-500 text-red-200 p-2 rounded-r-lg mb-2 text-xs font-medium">⚠️ ${d.compatibility_warning}</div>`;
                }
                
                html += `<div class="bg-black/60 border border-zinc-700/50 rounded-xl p-3  ">
                    ${warnHtml}
                    <div class="flex items-start gap-2">
                        <div class="text-green-500 mt-0.5 text-sm">✅</div>
                        <div class="flex-1">
                            <div class="text-xs text-zinc-300 leading-tight mb-2">${d.compatibility || '-'}</div>
                            <div class="text-[10px] text-purple-400 font-black uppercase tracking-widest mb-1">Sıradaki Adım Önerileri:</div>
                            <ul class="text-[11px] text-zinc-400 list-disc pl-4 space-y-0.5">
                                ${(d.suggestions||[]).map(s => `<li>${s}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                </div>`;
            }
            else if (type === 'part') {
                html += `<div class="ai-result-box">
                    <div class="ai-score-ring" style="border-color:#38bdf8; box-shadow:0 0 20px rgba(56,189,248,0.5)">${d.performance_score || 0}</div>
                    <div class="text-center text-xs text-zinc-400 mb-6 font-bold tracking-widest uppercase">Parça Skoru</div>
                    
                    <div class="ai-stat-row"><span class="ai-stat-label">Kategori</span> <span class="ai-stat-val text-blue-400">${d.category || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Seviye</span> <span class="ai-stat-val">${d.level || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Sertlik</span> <span class="ai-stat-val">${d.stiffness || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Dayanıklılık</span> <span class="ai-stat-val">${d.durability || '-'}</span></div>
                    <div class="ai-stat-row"><span class="ai-stat-label">Fiyat/Performans</span> <span class="ai-stat-val text-green-400">${d.price_performance || '-'}</span></div>
                    
                    <div class="mt-4 mb-2 font-bold text-sm text-green-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Güçlü Yönler</div>
                    <div>${(d.strengths||[]).map(s => `<span class="ai-tag green">${s}</span>`).join('')}</div>
                    
                    <div class="mt-4 mb-2 font-bold text-sm text-red-400 uppercase tracking-widest border-b border-zinc-800 pb-1">Zayıf Yönler</div>
                    <div>${(d.weaknesses||[]).map(s => `<span class="ai-tag red">${s}</span>`).join('')}</div>
                    
                    <div class="mt-4 p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg text-sm text-blue-200 leading-relaxed">
                        <b>💡 Tavsiye:</b> ${d.usage_advice || '-'}
                    </div>
                </div>`;
            }
            
            resBox.innerHTML = html;
            
        } catch(e) {
            loader.style.display = 'none';
            resBox.innerHTML = `<div class="ai-result-box" style="border-color: #ef4444;"><div class="text-red-400 font-bold">Bağlantı hatası oluştu.</div></div>`;
        }
    };

    console.log("AI HUB IIFE loaded successfully.");
})();
</script>
        <script>
      window.OneSignalDeferred = window.OneSignalDeferred || [];
      window._oneSignalInstance = null;
      OneSignalDeferred.push(async function(OneSignal) {
        await OneSignal.init({
          appId: "{{ onesignal_app_id }}",
          serviceWorkerParam: { scope: "/" },
          serviceWorkerPath: "/OneSignalSDKWorker.js",
          notifyButton: { enable: false },
          allowLocalhostAsSecureOrigin: true,
          notificationClickHandlerMatch: "origin",
          notificationClickHandlerAction: "focus",
        });
        window._oneSignalInstance = OneSignal;
        console.log('✅ OneSignal SDK başarıyla başlatıldı');

        // Subscription değiştiğinde otomatik kaydet
        OneSignal.User.PushSubscription.addEventListener('change', async function(event) {
          console.log('🔔 OneSignal subscription değişti:', event);
          if (event.current && event.current.id) {
            if (typeof saveOneSignalPlayerId === 'function') {
              await saveOneSignalPlayerId(OneSignal);
            }
          }
        });

        // SDK init olduktan sonra currentUser varsa hemen login yap + player_id HERZAMAN tazele
        if (window.currentUser && window.currentUser.username) {
          try {
            await OneSignal.login(window.currentUser.username);
            console.log('✅ OneSignal otomatik login (init sonrası):', window.currentUser.username);

            // Her zaman optIn çağır — eski/geçersiz subscription ID'yi yeniler
            try {
              await OneSignal.User.PushSubscription.optIn();
              console.log('🔔 OneSignal optIn çağırıldı');
            } catch(optErr) {
              console.warn('OptIn zaten aktif veya hata:', optErr);
            }

            // Kısa bekleme — subscription aktif olana kadar
            await new Promise(r => setTimeout(r, 2000));

            // İzin durumunu kontrol et
            let permission = OneSignal.Notifications.permission;
            console.log('🔔 Mevcut bildirim izni:', permission);

            if (!permission) {
              try {
                await OneSignal.Notifications.requestPermission();
                permission = OneSignal.Notifications.permission;
                console.log('🔔 İzin sonucu:', permission);
              } catch(permErr) {
                console.warn('Bildirim izni isteği başarısız:', permErr);
              }
            }

            // İzin var ya da yok — her durumda subscription ID kaydetmeye çalış
            if (typeof saveOneSignalPlayerId === 'function') {
              await saveOneSignalPlayerId(OneSignal);
            }
          } catch(e) {
            console.error('OneSignal init-login hatası:', e);
          }
        }
      });
    </script>
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;800;900&family=Teko:wght@500;700&display=swap');
        body { font-family: 'Outfit', sans-serif; background-color: #020b19; margin: 0; padding: 0; overscroll-behavior: none; color: #e4e4e7; touch-action: manipulation; }
        .teko-font { font-family: 'Teko', sans-serif; text-transform: uppercase; }
        #map { height: 100% !important; width: 100% !important; z-index: 10; touch-action: none; }
        ::-webkit-scrollbar { width: 0px; background: transparent; }
        .bg-glass { background: rgba(24, 24, 27, 0.7); border: 1px solid rgba(255, 255, 255, 0.05); }
        .bg-darker { background-color: #030a16; }
        
        .leaflet-control-layers { margin-top: 70px !important; background: rgba(24, 24, 27, 0.7) !important; color: white !important; border: 1px solid rgba(255, 255, 255, 0.1) !important; border-radius: 8px !important;  font-size: 10px !important; padding: 2px !important; }
        .leaflet-control-layers-toggle { width: 30px !important; height: 30px !important; background-size: 18px 18px !important; }
        .leaflet-control-layers-base label { margin-bottom: 2px !important; padding: 2px !important; cursor: pointer; }
        .leaflet-control-geocoder { margin-top: 15px !important; }
        
        /* Premium Animasyonlar & Efektler */
        @keyframes slideUpFade { 0% { opacity: 0; transform: translateY(40px) scale(0.97); } 60% { opacity: 1; } 100% { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes confettiFall { 0% { transform: translateY(-20px) rotate(0deg); opacity:1; } 100% { transform: translateY(110vh) rotate(720deg); opacity:0; } }
        @keyframes slideDownFade { 0% { opacity: 0; transform: translateY(-20px); } 100% { opacity: 1; transform: translateY(0); } }
        @keyframes scaleInFade { 0% { opacity: 0; transform: scale(0.90); } 70% { transform: scale(1.02); } 100% { opacity: 1; transform: scale(1); } }
        @keyframes fadeIn { 0% { opacity: 0; } 100% { opacity: 1; } }
        @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
        @keyframes pulseGlow { 0%, 100% { box-shadow: 0 0 8px rgba(14,165,233,0.5); } 50% { box-shadow: 0 0 22px rgba(14,165,233,0.9); } }
        @keyframes onlinePulse { 0%, 100% { box-shadow: 0 0 0 0 rgba(34,197,94,0.7); transform: scale(1); } 50% { box-shadow: 0 0 0 6px rgba(34,197,94,0); transform: scale(1.1); } }
        @keyframes slideInRight { 0% { opacity: 0; transform: translateX(60px); } 100% { opacity: 1; transform: translateX(0); } }
        @keyframes slideInLeft { 0% { opacity: 0; transform: translateX(-60px); } 100% { opacity: 1; transform: translateX(0); } }
        @keyframes tabSwitch { 0% { opacity: 0; transform: translateY(12px); } 100% { opacity: 1; transform: translateY(0); } }
        @keyframes notifBounce { 0%,100%{transform:scale(1)} 30%{transform:scale(1.25)} 60%{transform:scale(0.9)} }
        @keyframes ripple { 0% { transform: scale(0); opacity: 0.6; } 100% { transform: scale(4); opacity: 0; } }

        /* ── AI Moderatör & Moderation UI ── */
        @keyframes shake { 0%,100%{transform:translateX(0)} 10%,30%,50%,70%,90%{transform:translateX(-4px)} 20%,40%,60%,80%{transform:translateX(4px)} }
        @keyframes fadeInUp { 0%{opacity:0;transform:translateY(16px)} 100%{opacity:1;transform:translateY(0)} }
        @keyframes slideUp { 0%{opacity:0;transform:translateY(40px)} 100%{opacity:1;transform:translateY(0)} }
        @keyframes glowPulseRed { 0%,100%{box-shadow:0 0 12px rgba(239,68,68,0.3)} 50%{box-shadow:0 0 24px rgba(239,68,68,0.6)} }
        @keyframes toastSlideIn { 0%{opacity:0;transform:translateX(-50%) translateY(20px)} 100%{opacity:1;transform:translateX(-50%) translateY(0)} }
        @keyframes toastSlideOut { 0%{opacity:1;transform:translateX(-50%) translateY(0)} 100%{opacity:0;transform:translateX(-50%) translateY(20px)} }
        @keyframes skeletonPulse { 0%{opacity:0.4} 50%{opacity:0.8} 100%{opacity:0.4} }
        @keyframes premiumGlow { 0%,100%{box-shadow:0 0 20px rgba(234,179,8,0.3)} 50%{box-shadow:0 0 40px rgba(234,179,8,0.6)} }

        .ai-moderator-msg {
            background: linear-gradient(135deg, #dc2626, #991b1b) !important;
            border-left: 4px solid #ef4444 !important;
            border-color: #ef4444 !important;
            box-shadow: 0 0 20px rgba(239,68,68,0.3);
            animation: shake 0.5s ease-in-out, fadeInUp 0.4s ease-out, glowPulseRed 2s ease-in-out infinite;
            color: #fef2f2 !important;
        }
        /* Flagged mesaj: blur + overlay (flag_count < 2) */
        .msg-flagged {
            filter: blur(5px);
            opacity: 0.6;
            position: relative;
            transition: filter 0.3s, opacity 0.3s;
        }
        .msg-flagged-overlay {
            display: block; width: 100%; margin-bottom: 4px;
        }
        .msg-flagged-overlay span {
            font-size: 9px; font-weight: 800; color: #fca5a5;
            text-transform: uppercase; letter-spacing: 1px;
            padding: 4px 8px; border-radius: 6px;
            background: rgba(127,29,29,0.8); border: 1px solid rgba(239,68,68,0.4);
            display: inline-block;
        }
        /* Collapsed mesaj: flag_count >= 2, tıklanabilir */
        .msg-collapsed-wrap { cursor: pointer; }
        .msg-collapsed-bar {
            display: flex; align-items: center; gap: 8px;
            padding: 8px 14px; border-radius: 12px;
            background: linear-gradient(135deg, rgba(127,29,29,0.4), rgba(0,0,0,0.6));
            border: 1px solid rgba(239,68,68,0.3);
            font-size: 11px; font-weight: 700; color: #fca5a5;
            letter-spacing: 0.5px;
        }
        .msg-collapsed-bar:hover { background: rgba(127,29,29,0.6); }
        .msg-collapsed-content { display: none; margin-top: 6px; }
        .msg-collapsed-content.show { display: block; filter: blur(2px); opacity: 0.5; }
        /* Notification popup */
        .notif-popup-overlay {
            position: fixed; inset: 0; z-index: 99999;
            background: rgba(0,0,0,0.6); 
            display: flex; align-items: center; justify-content: center;
            animation: fadeIn 0.3s ease-out;
        }
        .notif-popup-card {
            background: linear-gradient(145deg, rgba(20,20,20,0.95), rgba(10,10,10,0.98));
            border: 1px solid rgba(59,130,246,0.3);
            border-radius: 20px; padding: 28px 24px;
            max-width: 340px; width: 90%; position: relative;
            box-shadow: 0 20px 60px rgba(0,0,0,0.8), 0 0 40px rgba(59,130,246,0.15);
            animation: slideUp 0.4s cubic-bezier(0.16,1,0.3,1);
        }
        @keyframes slideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .skeleton-loader {
            background: linear-gradient(90deg, #27272a 0%, #3f3f46 50%, #27272a 100%);
            background-size: 200% 100%;
            animation: skeletonPulse 1.5s ease-in-out infinite;
            border-radius: 12px;
        }
        .premium-popup-overlay {
            position: fixed; inset: 0; z-index: 999999;
            background: rgba(0,0,0,0.7); 
            display: flex; align-items: center; justify-content: center;
            padding: 16px;
        }
        .premium-popup-card {
            background: linear-gradient(145deg, #18181b, #27272a);
            border: 1px solid rgba(234,179,8,0.3);
            border-radius: 20px; max-width: 400px; width: 100%;
            padding: 32px 24px; text-align: center;
            animation: slideUp 0.5s cubic-bezier(0.16,1,0.3,1) both;
            box-shadow: 0 20px 60px rgba(0,0,0,0.6);
        }

        /* .slide-up-anim ve .scale-in-anim — alt satırlardaki (683-684) tanımlar tarafından override edilir */
        .slide-down-anim { animation: slideDownFade 0.35s cubic-bezier(0.16, 1, 0.3, 1) both; }
        .fade-in-anim { animation: fadeIn 0.3s ease both; }
        .slide-in-right { animation: slideInRight 0.4s cubic-bezier(0.16, 1, 0.3, 1) both; }
        .slide-in-left { animation: slideInLeft 0.4s cubic-bezier(0.16, 1, 0.3, 1) both; }
        .tab-switch-anim { animation: tabSwitch 0.3s cubic-bezier(0.16, 1, 0.3, 1) both; }

        /* .btn-premium-hover tanımı — alttaki (687) enhanced versiyon override eder */
        /* .glass-panel tanımı — alttaki (559) enhanced versiyon override eder */
        
        /* Admin Panel Tab Styles */
        .admin-tab-btn { color: #71717a; }
        .active-admin-tab { background: rgba(12,74,110,0.4); color: #bae6fd; border: 1px solid rgba(12,74,110,0.6); }
        .ua-tab-btn { color: #71717a; }
        .ua-active-tab { background: rgba(39,39,42,0.8); color: #e4e4e7; border: 1px solid rgba(255,255,255,0.08); }

        /* Enhanced animations */
        @keyframes adminPulse { 0%,100%{box-shadow:0 0 15px rgba(14,165,233,0.3)} 50%{box-shadow:0 0 30px rgba(14,165,233,0.7)} }
        @keyframes logEntry { 0%{opacity:0;transform:translateX(-12px)} 100%{opacity:1;transform:translateX(0)} }
        @keyframes countUp { 0%{opacity:0;transform:translateY(8px)scale(0.9)} 100%{opacity:1;transform:translateY(0)scale(1)} }
        .admin-card-enter { animation: logEntry 0.3s ease both; }
        .count-up-anim { animation: countUp 0.4s cubic-bezier(0.34,1.56,0.64,1) both; }

        /* Scrollbar for admin panel */
        #admin-panel ::-webkit-scrollbar { width: 3px; }
        #admin-panel ::-webkit-scrollbar-track { background: transparent; }
        #admin-panel ::-webkit-scrollbar-thumb { background: rgba(12,74,110,0.6); border-radius: 4px; }

        /* Ban badge */
        .ban-reason-badge { background: rgba(12,74,110,0.25); border: 1px solid rgba(12,74,110,0.5); color: #bae6fd; font-size: 9px; font-weight: 800; padding: 2px 8px; border-radius: 6px; text-transform: uppercase; letter-spacing: 0.05em; }

        /* Log action colors */
        .log-ban { border-left: 3px solid #38bdf8; }
        .log-delete { border-left: 3px solid #f97316; }
        .log-assign { border-left: 3px solid #22c55e; }
        .log-revoke { border-left: 3px solid #eab308; }
        .log-notify { border-left: 3px solid #3b82f6; }
        .log-default { border-left: 3px solid #71717a; }

        /* Çevrim içi göstergesi */
        .online-dot { width: 10px; height: 10px; background: #22c55e; border-radius: 50%; border: 2px solid #09090b; animation: onlinePulse 2s infinite; display: inline-block; flex-shrink: 0; }
        .online-dot-sm { width: 8px; height: 8px; background: #22c55e; border-radius: 50%; border: 1.5px solid #09090b; animation: onlinePulse 2s infinite; display: inline-block; flex-shrink: 0; }
        .recent-dot { width: 8px; height: 8px; background: #eab308; border-radius: 50%; border: 1.5px solid #09090b; display: inline-block; flex-shrink: 0; }
        .offline-dot { width: 8px; height: 8px; background: #52525b; border-radius: 50%; border: 1.5px solid #09090b; display: inline-block; flex-shrink: 0; }
        .online-label { color: #22c55e; font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; }
        .recent-label { color: #eab308; font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
        
        @keyframes rainbow-text { 0% { background-position: 0% 50%; } 100% { background-position: 200% 50%; } }
        /* ── Rainbow border: sadece border-color degistir, box-shadow yok ── */
        @keyframes rainbow-shadow {
            0%   { border-color: #ff4466; }
            20%  { border-color: #ff8800; }
            40%  { border-color: #eab308; }
            60%  { border-color: #22c55e; }
            80%  { border-color: #38bdf8; }
            100% { border-color: #ff4466; }
        }
        /* Alev efekti — sadece border-color + hafif brightness */
        @keyframes fire-border {
            0%,100% { border-color: #c03900; }
            50%     { border-color: #f06000; }
        }
        @keyframes ice-border {
            0%,100% { border-color: #4488bb; }
            50%     { border-color: #66aadd; }
        }
        @keyframes fire-flicker { 0%,100%{opacity:1} 50%{opacity:0.88} }
        @keyframes ice-shimmer  { 0%,100%{opacity:1} 50%{opacity:0.9} }
        @keyframes particle-rise { 0%{transform:translateY(0) translateX(0) scale(1);opacity:0.9} 100%{transform:translateY(-60px) translateX(var(--tx)) scale(0);opacity:0} }
        @keyframes particle-float { 0%{transform:translateY(0) translateX(0) scale(0.8);opacity:0.7} 100%{transform:translateY(40px) translateX(var(--tx)) scale(0.2);opacity:0} }

        .effect-fire {
            animation: fire-border 2s ease-in-out infinite, fire-flicker 2.5s ease-in-out infinite !important;
            border-width: 3px !important;
        }
        .effect-ice {
            animation: ice-border 2.5s ease-in-out infinite, ice-shimmer 3s ease-in-out infinite !important;
            border-width: 3px !important;
        }

        /* Parcacik container */
        .avatar-particle-wrap { position: relative; display: inline-block; }
        .particle-canvas { position: absolute; top: -30px; left: 50%; transform: translateX(-50%); width: 120px; height: 80px; pointer-events: none; z-index: 50; }

        /* ── Premium metin renkleri — text-shadow kaldirildi ── */
        .text-prem-rainbow { background: linear-gradient(90deg, #ff0055, #ffaa00, #55ff00, #00eeff, #aa00ff, #ff0055); background-size: 200% auto; color: transparent; -webkit-background-clip: text; background-clip: text; animation: rainbow-text 3s linear infinite; font-weight: 900 !important; }
        .text-prem-gold  { color: #fbbf24 !important; font-weight: 900 !important; }
        .text-prem-blue  { color: #3b82f6 !important; font-weight: 900 !important; }
        .text-prem-green { color: #22c55e !important; font-weight: 900 !important; }
        .text-prem-pink  { color: #ec4899 !important; font-weight: 900 !important; }

        /* ── Premium avatar border — box-shadow kaldirildi, outline kullanildi ── */
        .border-prem-rainbow { animation: rainbow-shadow 2.5s linear infinite; border-width: 3px; border-style: solid; }
        .border-prem-gold  { border: 3px solid #fbbf24; outline: 1px solid rgba(251,191,36,0.3); }
        .border-prem-blue  { border: 3px solid #3b82f6; outline: 1px solid rgba(59,130,246,0.3); }
        .border-prem-green { border: 3px solid #22c55e; outline: 1px solid rgba(34,197,94,0.3); }
        .border-prem-pink  { border: 3px solid #ec4899; outline: 1px solid rgba(236,72,153,0.3); }

        /* ── Deluxe metin renkleri — text-shadow kaldirildi ── */
        .text-dlx-blue   { background: linear-gradient(45deg, #60a5fa, #bfdbfe, #3b82f6); -webkit-background-clip: text; background-clip: text; color: transparent; font-weight: 800 !important; }
        .text-dlx-yellow { background: linear-gradient(45deg, #fde047, #fef08a, #eab308); -webkit-background-clip: text; background-clip: text; color: transparent; font-weight: 800 !important; }
        .text-dlx-pink   { background: linear-gradient(45deg, #f472b6, #fbcfe8, #ec4899); -webkit-background-clip: text; background-clip: text; color: transparent; font-weight: 800 !important; }
        .text-dlx-green  { background: linear-gradient(45deg, #4ade80, #bbf7d0, #22c55e); -webkit-background-clip: text; background-clip: text; color: transparent; font-weight: 800 !important; }

        /* ── Deluxe border — box-shadow yerine outline ── */
        .border-dlx-blue   { border: 2px solid #3b82f6; outline: 1px solid rgba(59,130,246,0.25); }
        .border-dlx-yellow { border: 2px solid #eab308; outline: 1px solid rgba(234,179,8,0.25); }
        .border-dlx-pink   { border: 2px solid #ec4899; outline: 1px solid rgba(236,72,153,0.25); }
        .border-dlx-green  { border: 2px solid #22c55e; outline: 1px solid rgba(34,197,94,0.25); }
        
        .tab-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .market-img-scroll { display: flex; overflow-x: auto; scroll-snap-type: x mandatory; gap: 10px; }
        .market-img-scroll img { scroll-snap-align: center; max-width: 100%; border-radius: 8px; }
        .horizontal-scroll-container { display: flex; overflow-x: auto; scroll-behavior: smooth; -ms-overflow-style: none; scrollbar-width: none; }
        .horizontal-scroll-container::-webkit-scrollbar { display: none; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #3f3f46; border-radius: 4px; }
        .map-add-mode { cursor: crosshair !important; }
        .progress-bar-bg { background-color: #27272a; border-radius: 9999px; height: 8px; width: 100%; overflow: hidden; margin-top: 8px; }
        .progress-bar-fill { background: linear-gradient(90deg, #0ea5e9, #0284c7); height: 100%; transition: width 0.5s ease; }
        
        /* Safe area padding for bottom nav */
        .pb-safe { padding-bottom: env(safe-area-inset-bottom, 8px); }
        #bottom-nav { padding-bottom: max(8px, env(safe-area-inset-bottom)); }
        
        /* Mobile tap highlight fix */
        * { -webkit-tap-highlight-color: transparent; }
        
        /* Premium input focus */
        input:focus, textarea:focus, select:focus { outline: none; }
        
        /* Smooth modal backdrop */
        .modal-backdrop { background: rgba(0,0,0,0.75); backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); }
        
        /* Seviye atlaması kutlama */
        @keyframes levelUpPulse {
            0%   { transform: scale(0.5) rotate(-5deg); opacity: 0; }
            40%  { transform: scale(1.15) rotate(3deg); opacity: 1; }
            70%  { transform: scale(0.95) rotate(-1deg); }
            100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        @keyframes levelUpFloat {
            0%   { transform: translateY(0) scale(1); opacity: 1; }
            100% { transform: translateY(-80px) scale(0.5); opacity: 0; }
        }
        @keyframes storyRing {
            0%   { box-shadow: 0 0 0 3px #0ea5e9, 0 0 0 5px #0ea5e940; }
            50%  { box-shadow: 0 0 0 3px #f59e0b, 0 0 0 6px #f59e0b50; }
            100% { box-shadow: 0 0 0 3px #0ea5e9, 0 0 0 5px #0ea5e940; }
        }
        @keyframes igStoryRingSpin {
            0%   { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .level-up-anim { animation: levelUpPulse 0.7s cubic-bezier(0.34,1.56,0.64,1) both; }
        /* Instagram gradient story ring */
        .story-ring {
            border-radius: 50%;
            position: relative;
            background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888) border-box;
            border: 2.5px solid transparent;
            background-clip: padding-box;
            box-shadow: 0 0 0 2.5px #f09433, 0 0 12px rgba(220,39,67,0.5);
            animation: storyRing 2.5s ease-in-out infinite;
        }
        .story-seen { opacity: 0.5; filter: grayscale(60%); }

        /* ── REELS GRID VIEW ── */
        #reels-feed.grid-mode {
            display: grid !important;
            grid-template-columns: repeat(4, 1fr);
            gap: 2px;
            overflow-y: auto;
            scroll-snap-type: none;
            height: 100%;
            align-content: start;
        }
        #reels-feed.grid-mode > div {
            height: 160px !important;
            cursor: pointer;
            scroll-snap-align: unset !important;
            position: relative;
        }
        #reels-feed.grid-mode > div > video,
        #reels-feed.grid-mode > div > img {
            object-fit: cover !important;
            width: 100% !important;
            height: 100% !important;
        }
        #reels-feed.grid-mode > div > .absolute { display: none !important; }
        #reels-feed.grid-mode > div > video { pointer-events: none; }
        .reel-fullscreen-overlay {
            position: fixed;
            inset: 0;
            z-index: 100;
            background: #000;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* Play/Pause flash icon */
        .reel-play-flash {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            pointer-events: none;
            z-index: 20;
            opacity: 0;
            transition: opacity 0.15s;
        }
        .reel-play-flash.show {
            opacity: 1;
            animation: flashFade 0.5s ease-out forwards;
        }
        @keyframes flashFade {
            0%   { opacity: 1; transform: translate(-50%,-50%) scale(1); }
            60%  { opacity: 0.7; transform: translate(-50%,-50%) scale(1.15); }
            100% { opacity: 0; transform: translate(-50%,-50%) scale(0.9); }
        }

        /* Özel tema rengi */
        .theme-red    { --accent: #dc2626; --accent-light: #ef4444; }
        .theme-blue   { --accent: #2563eb; --accent-light: #3b82f6; }
        .theme-green  { --accent: #16a34a; --accent-light: #22c55e; }
        .theme-purple { --accent: #7c3aed; --accent-light: #8b5cf6; }
        .theme-orange { --accent: #ea580c; --accent-light: #f97316; }
        .theme-pink   { --accent: #db2777; --accent-light: #ec4899; }
        body { --accent: #0088ff; --accent-light: #00ccff; }

        @keyframes confettiFall {
            0%   { transform: translateY(0) rotate(0deg) scale(1); opacity: 1; }
            100% { transform: translateY(60vh) rotate(720deg) scale(0.3); opacity: 0; }
        }
        @keyframes scaleIn {
            0%   { opacity: 0; transform: scale(0.7); }
            70%  { transform: scale(1.04); }
            100% { opacity: 1; transform: scale(1); }
        }
        @keyframes bounce {
            0%   { transform: translateY(0px) scale(1); }
            100% { transform: translateY(-14px) scale(1.08); }
        }
        @keyframes wheelSpinGlow {
            0%,100% { box-shadow: 0 0 35px rgba(14,165,233,0.5), 0 0 60px rgba(234,179,8,0.2); }
            50%      { box-shadow: 0 0 55px rgba(234,179,8,0.9), 0 0 100px rgba(14,165,233,0.6), 0 0 8px rgba(255,255,255,0.4); }
        }
        @keyframes confettiRect {
            0%   { transform: translateY(0) rotate(0deg); opacity: 1; }
            100% { transform: translateY(70vh) rotate(900deg); opacity: 0; }
        }
        .wheel-spinning-canvas {
            animation: wheelSpinGlow 0.35s ease-in-out infinite !important;
        }
        @keyframes trialBanner {
            0%   { transform: translateY(-100%); opacity: 0; }
            15%  { transform: translateY(0); opacity: 1; }
            85%  { transform: translateY(0); opacity: 1; }
            100% { transform: translateY(-100%); opacity: 0; }
        }
        .trial-banner { animation: trialBanner 5s ease-in-out forwards; }
        .wheel-slice {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 50%;
            height: 20px;
            transform-origin: 0% 50%;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding-right: 15px;
            box-sizing: border-box;
            color: white;
            font-weight: 900;
            font-size: 10px;
            text-shadow: 1px 1px 3px black;
            text-transform: uppercase;
        }

        /* ═══════════════════════════════════════════════════════
           FREERIDER TR — BUZ CAM MAVİSİ PREMIUM TEMA v3
           Ice Glass Blue Ultra Premium Edition
           ═══════════════════════════════════════════════════════ */

        /* ── Buz kristal doku efektleri ── */
        @keyframes iceShimmer {
            0%   { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        @keyframes frostPulse {
            0%,100% { 
                box-shadow: 0 0 12px rgba(14,165,233,0.35), 0 0 24px rgba(56,189,248,0.12),
                            inset 0 0 20px rgba(56,189,248,0.04);
            }
            50% { 
                box-shadow: 0 0 24px rgba(14,165,233,0.55), 0 0 48px rgba(56,189,248,0.18),
                            inset 0 0 30px rgba(56,189,248,0.06);
            }
        }
        @keyframes iceGlow {
            0%,100% { filter: drop-shadow(0 0 4px rgba(56,189,248,0.6)); }
            50%      { filter: drop-shadow(0 0 10px rgba(56,189,248,0.9)); }
        }
        @keyframes crystalFloat {
            0%,100% { transform: translateY(0px) rotate(0deg); }
            33%     { transform: translateY(-4px) rotate(1deg); }
            66%     { transform: translateY(-2px) rotate(-1deg); }
        }
        @keyframes auroraShift {
            0%   { background-position: 0% 50%; }
            50%  { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        @keyframes frostLine {
            0%   { opacity: 0; transform: scaleX(0); }
            50%  { opacity: 1; transform: scaleX(1); }
            100% { opacity: 0; transform: scaleX(0); }
        }
        @keyframes iceRipple {
            0%   { transform: scale(0); opacity: 0.7; }
            100% { transform: scale(4); opacity: 0; }
        }
        @keyframes glacierPulse {
            0%,100% { opacity: 0.06; }
            50%     { opacity: 0.12; }
        }

        .ice-glow  { animation: iceGlow 2s ease-in-out infinite; }
        .frost-pulse { animation: frostPulse 3s ease-in-out infinite; }
        .crystal-float { animation: crystalFloat 4s ease-in-out infinite; }

        /* ── Buz cam ultra glass panel (kaldırıldı — line 559'daki son tanım aktif) ── */

        /* ── Buz shimmer efekti (özel kartlar için) ── */
        .ice-shimmer-bg {
            background: linear-gradient(
                90deg,
                rgba(14,165,233,0.03) 0%,
                rgba(56,189,248,0.08) 30%,
                rgba(125,211,252,0.12) 50%,
                rgba(56,189,248,0.08) 70%,
                rgba(14,165,233,0.03) 100%
            );
            background-size: 200% 100%;
            animation: iceShimmer 4s linear infinite;
        }

        /* ── Aurora arkaplan efekti ── */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background: 
                radial-gradient(ellipse 60% 40% at 20% 80%, rgba(14,165,233,0.04) 0%, transparent 60%),
                radial-gradient(ellipse 40% 30% at 80% 20%, rgba(56,189,248,0.03) 0%, transparent 60%);
            pointer-events: none;
            z-index: 0;
            animation: glacierPulse 6s ease-in-out infinite;
        }

        /* ── Arka Plan Dokusu ── */
        body {
            background:
                radial-gradient(ellipse 80% 50% at 50% -10%, rgba(2,132,199,0.18) 0%, transparent 60%),
                radial-gradient(ellipse 50% 30% at 85% 90%, rgba(120,0,0,0.12) 0%, transparent 50%),
                #000;
        }

        /* ── Gelişmiş Glass Panel ── */
        .glass-panel { background: rgba(18,18,22,0.98); border: 1px solid rgba(255,255,255,0.06); }

        /* ── App Header Gradient Border ── */
        #main-app > div:first-child {
            background: linear-gradient(180deg, rgba(3,12,24,0.95) 0%, rgba(15,15,20,0.88) 100%);
            
            border-bottom: 1px solid transparent;
            background-clip: padding-box;
            box-shadow: 0 1px 0 rgba(14,165,233,0.35), 0 4px 20px rgba(0,0,0,0.5);
        }

        /* ── FREERIDER markası parlar ── */
        @keyframes brandPulse {
            0%,100% { text-shadow: 0 0 8px rgba(14,165,233,0.4); }
            50%      { text-shadow: 0 0 20px rgba(14,165,233,0.9), 0 0 40px rgba(14,165,233,0.3); }
        }
        #main-app .teko-font.text-2xl { animation: brandPulse 4s ease-in-out infinite; }

        /* ── Gelişmiş Bottom Nav (Floating Pill) ── */
        #bottom-nav {
            background: linear-gradient(180deg, rgba(8,8,12,0.0) 0%, rgba(0,0,0,0.98) 100%) !important;
            border-top: none !important;
            box-shadow: none !important;
            padding-top: 4px;
            padding-bottom: max(12px, env(safe-area-inset-bottom));
        }
        #bottom-nav::before {
            content: '';
            position: absolute;
            inset: 0;
            border-top: 1px solid rgba(14,165,233,0.2);
            pointer-events: none;
        }
        #bottom-nav button {
            position: relative;
            border-radius: 14px;
            padding: 8px 10px 6px;
            transition: all 0.3s cubic-bezier(0.34,1.56,0.64,1);
        }
        #bottom-nav button.text-white {
            background: linear-gradient(135deg, rgba(2,132,199,0.35), rgba(120,0,0,0.2)) !important;
            box-shadow: 0 0 16px rgba(14,165,233,0.35), inset 0 1px 0 rgba(255,255,255,0.07);
        }
        #bottom-nav button.text-white span:first-child {
            filter: drop-shadow(0 0 6px rgba(14,165,233,0.8));
            transform: scale(1.15);
            display: inline-block;
        }
        #bottom-nav button span:first-child {
            transition: transform 0.3s cubic-bezier(0.34,1.56,0.64,1), filter 0.3s ease;
        }
        #bottom-nav button:active { transform: scale(0.88) !important; }

        /* ── Gelişmiş Yükleme Ekranı ── */
        #app-loading-screen {
            background: radial-gradient(ellipse 70% 60% at 50% 40%, rgba(3,105,161,0.4) 0%, #000 70%);
        }

        /* ── Animasyonlar ── */
        @keyframes floatUp {
            0%,100% { transform: translateY(0px); }
            50%      { transform: translateY(-6px); }
        }
        @keyframes glowPulse {
            0%,100% { opacity: 0.7; }
            50%      { opacity: 1; }
        }
        @keyframes morphBorder {
            0%,100% { border-radius: 24px; }
            50%      { border-radius: 32px; }
        }
        @keyframes slideUpSpring {
            0%   { opacity:0; transform: translateY(32px) scale(0.95); }
            60%  { opacity:1; transform: translateY(-4px) scale(1.01); }
            100% { opacity:1; transform: translateY(0) scale(1); }
        }
        @keyframes fadeSlideLeft {
            0%   { opacity:0; transform: translateX(24px); }
            100% { opacity:1; transform: translateX(0); }
        }
        @keyframes fadeSlideRight {
            0%   { opacity:0; transform: translateX(-24px); }
            100% { opacity:1; transform: translateX(0); }
        }
        @keyframes cardEnter {
            0%   { opacity:0; transform: translateY(20px) scale(0.96); }
            70%  { opacity:1; transform: translateY(-2px) scale(1.01); }
            100% { opacity:1; transform: translateY(0) scale(1); }
        }
        @keyframes shimmerSweep {
            0%   { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        @keyframes neonBlink {
            0%,95%,100% { opacity:1; }
            97%          { opacity:0.6; }
        }
        @keyframes iconBounce {
            0%,100% { transform: translateY(0) rotate(0deg); }
            25%     { transform: translateY(-5px) rotate(-8deg); }
            75%     { transform: translateY(-3px) rotate(6deg); }
        }
        @keyframes scanline {
            0%   { transform: translateY(-100%); }
            100% { transform: translateY(100vh); }
        }
        @keyframes gradientShift {
            0%   { background-position: 0% 50%; }
            50%  { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .float-anim   { animation: floatUp 3s ease-in-out infinite; }
        .glow-pulse   { animation: glowPulse 2.5s ease-in-out infinite; }
        .card-enter   { animation: cardEnter 0.45s cubic-bezier(0.34,1.56,0.64,1) both; }
        .slide-up-anim { animation: slideUpSpring 0.5s cubic-bezier(0.34,1.3,0.64,1) both; }
        .scale-in-anim { animation: slideUpSpring 0.4s cubic-bezier(0.34,1.56,0.64,1) both; }

        @keyframes slideUpFade {
            from { opacity: 0; transform: translateY(40px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ── Gelişmiş Buton Hover ── */
        .btn-premium-hover {
            transition: all 0.25s cubic-bezier(0.34,1.2,0.64,1);
            position: relative;
            overflow: hidden;
        }
        .btn-premium-hover::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.06) 0%, transparent 50%, rgba(255,255,255,0.02) 100%);
            opacity: 0;
            transition: opacity 0.2s;
            pointer-events: none;
            border-radius: inherit;
        }
        .btn-premium-hover:hover::before { opacity: 1; }
        .btn-premium-hover:hover {
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 8px 24px rgba(14,165,233,0.4), 0 2px 8px rgba(0,0,0,0.4);
        }
        .btn-premium-hover:active {
            transform: translateY(1px) scale(0.97);
            box-shadow: 0 2px 8px rgba(14,165,233,0.2);
        }
        .btn-premium-hover::after {
            content: '';
            position: absolute;
            top: 50%; left: 50%;
            width: 4px; height: 4px;
            background: rgba(255,255,255,0.6);
            border-radius: 50%;
            transform: scale(0); opacity: 0;
            pointer-events: none;
        }
        .btn-premium-hover:active::after { animation: ripple 0.5s ease-out forwards; }

        /* ── Shimmer Loading Skeleton ── */
        .skeleton {
            background: linear-gradient(90deg, #0a1525 25%, #0d1e36 50%, #0a1525 75%);
            background-size: 200% 100%;
            animation: shimmerSweep 1.5s infinite;
            border-radius: 8px;
        }

        /* ── Gradient Progress Bar ── */
        .progress-bar-fill {
            background: linear-gradient(90deg, #0ea5e9, #f97316, #eab308) !important;
            background-size: 200% 100%;
            animation: gradientShift 2s ease infinite;
            box-shadow: 0 0 8px rgba(14,165,233,0.5);
        }

        /* ── Kart Hover Efekti ── */
        .hover-card {
            transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
        }
        .hover-card:hover {
            transform: translateY(-3px) scale(1.01);
            box-shadow: 0 16px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.06);
        }

        /* ── Modal Backdrop Gelişmiş ── */
        .modal-backdrop {
            background: rgba(0,0,0,0.82);
            backdrop-filter: blur(8px) saturate(150%);
            -webkit-backdrop-filter: blur(8px) saturate(150%);
        }

        /* ── Özel Scrollbar ── */
        .custom-scrollbar::-webkit-scrollbar { width: 3px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: rgba(0,0,0,0.2); }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #0ea5e9, #0c4a6e);
            border-radius: 3px;
        }

        /* ── Input Glow Focus ── */
        input:focus, textarea:focus, select:focus {
            box-shadow: 0 0 0 2px rgba(14,165,233,0.3), 0 0 12px rgba(14,165,233,0.15) !important;
            border-color: rgba(14,165,233,0.7) !important;
        }

        /* ── Sidebar Gelişmiş ── */
        #sidebar {
            background: linear-gradient(180deg, rgba(2,6,16,0.98) 0%, rgba(5,5,8,0.99) 100%) !important;
            border-right: 1px solid rgba(14,165,233,0.2) !important;
            box-shadow: 4px 0 40px rgba(0,0,0,0.8) !important;
        }
        #sidebar button.tab-btn {
            transition: all 0.25s cubic-bezier(0.4,0,0.2,1);
            border-left: 2px solid transparent;
        }
        #sidebar button.tab-btn:hover {
            background: rgba(14,165,233,0.08) !important;
            border-left-color: rgba(14,165,233,0.5);
            transform: translateX(3px);
        }
        #sidebar button.bg-zinc-900 {
            background: linear-gradient(135deg, rgba(2,132,199,0.25), rgba(3,105,161,0.15)) !important;
            border-left: 2px solid rgba(14,165,233,0.7);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
        }

        /* ── Profil Kartı Efekti ── */
        #screen-profile .glass-panel { background: rgba(18,18,22,0.98); border: 1px solid rgba(255,255,255,0.06); }
        #screen-profile .glass-panel:hover {
            border-color: rgba(14,165,233,0.2);
        }

        /* ── Leaderboard Row ── */
        @keyframes goldShine {
            0%,100% { box-shadow: 0 0 10px rgba(251,191,36,0.3); }
            50%      { box-shadow: 0 0 20px rgba(251,191,36,0.7), 0 0 40px rgba(251,191,36,0.2); }
        }

        /* ── Toast Bildirimleri ── */
        @keyframes toastSlide {
            0%   { opacity:0; transform: translateX(-50%) translateY(-20px) scale(0.9); }
            60%  { opacity:1; transform: translateX(-50%) translateY(4px) scale(1.02); }
            100% { opacity:1; transform: translateX(-50%) translateY(0) scale(1); }
        }

        /* ── Reel Kart Overlay Gradient ── */
        #reels-feed .absolute.inset-0 {
            background: linear-gradient(
                to top,
                rgba(0,0,0,0.88) 0%,
                rgba(0,0,0,0.3) 40%,
                transparent 70%
            ) !important;
        }

        /* ── Story Ring Gelişmiş ── */
        .story-ring {
            animation: storyRing 2.5s ease-in-out infinite;
            box-shadow: 0 0 12px rgba(14,165,233,0.4);
        }

        /* ── bg-glass Gelişmiş ── */
        .bg-glass {
            background: rgba(4, 10, 24, 0.88) !important;
            backdrop-filter: blur(16px) saturate(180%) !important;
            -webkit-backdrop-filter: blur(16px) saturate(180%) !important;
            border-color: rgba(255,255,255,0.06) !important;
        }

        /* ── bg-darker ── */
        .bg-darker {
            background: linear-gradient(180deg, #03080f 0%, #020609 100%) !important;
        }

        /* ── Dalgalı Separator ── */
        .wave-sep {
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(14,165,233,0.5), rgba(251,191,36,0.3), rgba(14,165,233,0.5), transparent);
            margin: 16px 0;
        }

        /* ── Yükleme Animasyonu Gelişmiş ── */
        @keyframes loadRing {
            0%   { transform: rotate(0deg) scale(1); }
            50%  { transform: rotate(180deg) scale(1.05); }
            100% { transform: rotate(360deg) scale(1); }
        }
        #app-loading-screen .animate-spin {
            animation: spin 1s linear infinite !important;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to   { transform: rotate(360deg); }
        }

        /* ── Harita Overlay Gradient ── */
        #screen-map::after {
            content: '';
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 60px;
            background: linear-gradient(to top, rgba(2,8,22,0.4), transparent);
            pointer-events: none;
            z-index: 5;
        }

        /* ── Harita Beyaz Flash Düzeltmesi ── */
        /* Tile'lar yüklenirken beyaz zemin görünmesin */
        .leaflet-container {
            background: #0a0a0a !important;
        }
        .leaflet-tile-pane {
            will-change: transform;
        }
        .leaflet-tile {
            will-change: transform;
        }
        #map {
            background: #0a0a0a !important;
            will-change: transform;
        }

        /* ════════════════════════════════════════════════════════
           OVERFLOW & TAŞMA DÜZELTMELERİ
           ════════════════════════════════════════════════════════ */

        /* Global overflow kontrol */
        *, *::before, *::after {
            box-sizing: border-box;
        }

        /* Flex child taşma engelleyici */
        .flex > * { min-width: 0; }
        .flex-1   { min-width: 0; }

        /* Text taşma önleme */
        .truncate-safe {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            min-width: 0;
        }

        /* İçerik taşma engel */
        #screen-chat, #screen-leaderboard, #screen-profile,
        #screen-news, #screen-missions,
        #screen-reels, #screen-plus, #screen-invite {
            overflow-x: hidden !important;
            overflow-y: auto !important;
        }

        /* Pazar özel kaydırma düzeltmesi */
        #screen-market {
            overflow-x: hidden !important;
            overflow-y: auto !important;
            display: flex !important;
            flex-direction: column !important;
        }
        #market-list {
            flex: 1 1 auto;
            overflow-y: auto !important;
            -webkit-overflow-scrolling: touch !important;
        }

        /* Mesaj balonları taşma engeli */
        .chat-bubble-wrap {
            max-width: calc(100% - 60px) !important;
            overflow-wrap: break-word !important;
            word-break: break-word !important;
        }

        /* Resim taşma engeli */
        img {
            max-width: 100%;
            height: auto;
        }

        /* Modal içi overflow */
        /* .glass-panel burada tekrar tanımlanmasına gerek yok (satır 1013'te tanımlı) */

        /* Kullanıcı adı taşma */
        [id$="-username"], .username-text {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 100%;
        }

        /* Yatay scroll container'lar */
        .horizontal-scroll-container {
            overflow-x: auto !important;
            overflow-y: hidden !important;
            max-width: 100% !important;
        }

        /* Grid ve flex taşma */
        .grid { overflow: hidden; }

        /* Bottom nav güvenli alan */
        #bottom-nav {
            width: 100% !important;
            max-width: 100% !important;
            overflow: hidden !important;
        }

        /* Ana konteyner taşma engeli */
        .max-w-md {
            overflow-x: hidden !important;
        }

        /* Toast overflow fix */
        #toast-notification {
            max-width: calc(100vw - 32px) !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
        }
    </style>
</head>
<body class="fixed inset-0 w-full overflow-hidden bg-black">
    <!-- Premium Yükleme Ekranı v2 -->
    <div id="app-loading-screen" class="fixed inset-0 z-[9999] flex flex-col items-center justify-center" style="position:fixed;top:0;left:0;right:0;bottom:0;z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(ellipse 70% 60% at 50% 40%,rgba(0,136,255,0.3) 0%,#000 70%);transition:opacity 0.5s ease;background-color:#000;">
        <!-- Tek arka halka -->
        <div class="absolute w-64 h-64 rounded-full border border-sky-700/20" style="animation:ping 3s ease-in-out infinite;"></div>
        <!-- Tek dönen halka -->
        <div class="relative mb-8 z-10">
            <div class="w-24 h-24 rounded-full" style="background:conic-gradient(from 0deg,#0088ff,#00ccff,#0055ff,#0088ff);padding:3px;border-radius:50%;">
                <div class="w-full h-full rounded-full bg-black flex items-center justify-center overflow-hidden">
                    <img src="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg" alt="FreeriderTR Logo" class="w-full h-full object-cover">
                </div>
            </div>
            <!-- Tek dönen halka -->
            <div class="absolute inset-0 animate-spin" style="animation-duration:1.4s;">
                <div class="w-24 h-24 rounded-full border-t-2 border-r-2 border-[#00ccff]/60 border-b-transparent border-l-transparent"></div>
            </div>
        </div>
        <!-- Brand -->
        <div class="z-10 text-center">
            <div class="teko-font text-white text-5xl tracking-[0.15em]">FREERIDER<span style="color:#0088ff;text-shadow:0 0 10px #0088ff;">TR</span></div>
            <div class="flex items-center justify-center gap-2 mt-3">
                <div class="h-px w-12 bg-gradient-to-r from-transparent to-[#0088ff]/60"></div>
                <div class="text-[#0088ff] text-[10px] uppercase tracking-[0.3em] font-bold animate-pulse">Yükleniyor</div>
                <div class="h-px w-12 bg-gradient-to-l from-transparent to-[#0088ff]/60"></div>
            </div>
            <!-- 3 bounce yerine tek bir pulse nokta -->
            <div class="flex justify-center gap-1 mt-3">
                <div class="w-1.5 h-1.5 bg-[#0055ff] rounded-full animate-pulse"></div>
                <div class="w-1.5 h-1.5 bg-[#0088ff] rounded-full animate-pulse" style="animation-delay:0.2s"></div>
                <div class="w-1.5 h-1.5 bg-[#00ccff] rounded-full animate-pulse" style="animation-delay:0.4s"></div>
            </div>
        </div>
    </div>
    <audio id="notif-sound" src="https://cdn.freesound.org/previews/256/256113_3263906-lq.mp3" preload="auto"></audio>
    <input type="file" id="chat-photo-upload" accept="image/*" class="hidden" onchange="handleChatPhotoUpload(this)">

    <div id="sidebar-overlay" class="hidden fixed inset-0 modal-backdrop z-[1000]  transition-opacity duration-300" onclick="toggleSidebar()"></div>
    <div id="sidebar" class="fixed inset-y-0 left-0 w-64 bg-zinc-950 border-r border-zinc-800 z-[1001] transform -translate-x-full transition-transform duration-500 cubic-bezier(0.16, 1, 0.3, 1) flex flex-col  glass-panel">
        <div class="p-5 border-b border-zinc-800 flex items-center gap-3 shrink-0">
            <span class="text-3xl ">🏔️</span>
            <span class="teko-font text-white text-3xl tracking-widest font-bold mt-1">MENÜ</span>
          <button onclick="toggleSidebar()" class="bg-zinc-800/80 hover:bg-zinc-700 transition px-3 py-1 rounded-xl text-white text-2xl mr-2 border border-zinc-700 focus:outline-none ">☰</button>
        </div>
        <div class="flex-1 overflow-y-auto py-4 flex flex-col gap-2 px-3 custom-scrollbar">
            <button id="tab-btn-0" onclick="switchTab(0)" class="w-full py-3 px-4 flex items-center gap-4 text-white bg-zinc-900 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🗺️</span> Harita</button>
            <button id="tab-btn-1" onclick="switchTab(1)" class="w-full py-3 px-4 flex items-center gap-4 text-zinc-500 hover:bg-zinc-900/50 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">💬</span> Chat</button>
            <button id="tab-btn-2" onclick="switchTab(2)" class="w-full py-3 px-4 flex items-center gap-4 text-zinc-500 hover:bg-zinc-900/50 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🛒</span> Pazar</button>
            <button id="tab-btn-3" onclick="switchTab(3)" class="w-full py-3 px-4 flex items-center gap-4 text-zinc-500 hover:bg-zinc-900/50 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🏆</span> Lider Tablosu</button>
            <button id="tab-btn-4" onclick="switchTab(4)" class="w-full py-3 px-4 flex items-center gap-4 text-zinc-500 hover:bg-zinc-900/50 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">📰</span> Haberler</button>
            <button id="tab-btn-5" onclick="switchTab(5)" class="w-full py-3 px-4 flex items-center gap-4 text-zinc-500 hover:bg-zinc-900/50 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🎯</span> Görevler ve Çark</button>
            <button id="tab-btn-9" onclick="switchTab(9)" class="w-full py-3 px-4 flex items-center gap-4 text-pink-400 hover:bg-pink-900/20 border border-transparent hover:border-pink-500/30 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🎬</span> Reels</button>
            <button id="tab-btn-10" onclick="switchTab(10)" class="w-full py-3 px-4 flex items-center gap-4 text-orange-400 hover:bg-orange-900/20 border border-transparent hover:border-orange-500/30 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🏁</span> Bisiklet Yarışması</button>
            <button id="tab-btn-11" onclick="switchTab(11)" class="w-full py-3 px-4 flex items-center gap-4 text-emerald-400 hover:bg-emerald-900/30 border border-transparent hover:border-emerald-500/30 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">🎁</span> Çekilişler</button>
            <button id="tab-btn-8" onclick="switchTab(8)" class="w-full py-3 px-4 flex items-center gap-4 text-purple-400 hover:bg-purple-900/30 border border-transparent hover:border-purple-500/30 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center ">🤝</span> Davet Et Kazan</button>
            <button id="tab-btn-6" onclick="switchTab(6)" class="w-full py-3 px-4 flex items-center gap-4 text-yellow-500 hover:bg-yellow-900/30 border border-transparent hover:border-yellow-500/30 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center ">🌟</span> Freerider Plus</button>
            <button id="tab-btn-7" onclick="switchTab(7)" class="w-full py-3 px-4 flex items-center gap-4 text-zinc-500 hover:bg-zinc-900/50 rounded-xl tab-btn font-bold transition-all"><span class="text-xl w-6 text-center">👤</span> Profilim</button>
        </div>

        <div class="p-4 border-t border-zinc-800 flex flex-col gap-2">
                <button onclick="document.getElementById('social-modal').classList.remove('hidden'); toggleSidebar();" class="w-full bg-zinc-900 border border-pink-700/40 hover:bg-pink-900/20 transition text-pink-400 py-3 rounded-xl font-bold text-xs tracking-widest flex items-center justify-center gap-2">
                    <span>📸</span> Hesaplarımızı Takip Et
                </button>
                <button onclick="window.open('https://whatsapp.com/channel/0029VbCTLFCJUM2kLBD7TC1Z', '_blank')" class="w-full bg-zinc-900 border border-green-700/40 hover:bg-green-900/20 transition text-green-400 py-3 rounded-xl font-bold text-xs tracking-widest flex items-center justify-center gap-2">
                    <span>💬</span> WP Kanalı
                </button>
                <button onclick="openAISupportPanel(); toggleSidebar();" class="w-full bg-zinc-900 border border-blue-700/40 hover:bg-blue-900/20 transition text-blue-400 py-3 rounded-xl font-bold text-xs tracking-widest flex items-center justify-center gap-2">
                    <span>🎧</span> Destek Hattı
                </button>

            </div>
    </div>

    <div class="max-w-md mx-auto h-[100dvh] flex flex-col  bg-darker border-x border-zinc-900/50 relative overflow-x-hidden">
        <div id="login-screen" class="flex-1 flex flex-col overflow-y-auto z-50 relative slide-up-anim">
            <video autoplay loop muted playsinline class="absolute inset-0 w-full h-full object-cover z-0 opacity-40">
                <source src="https://cdn.freeridertr.com.tr/video%20ana/istockphoto-2221026101-640_adpp_is.mp4">
            </video>
            
            <div class="absolute inset-0 bg-gradient-to-b from-black/90 via-black/60 to-[#020b19] z-0"></div>

            <div class="flex flex-col items-center justify-center pt-16 pb-8 relative z-10 shrink-0">
                <a href="https://instagram.com/om3r_10fr" target="_blank" class="absolute top-4 right-4 bg-sky-900/80 text-white text-[11px] font-bold py-2 px-4 rounded-full flex items-center gap-2 z-20 border border-sky-400/50  btn-premium-hover">
                    <span class="text-white">📸</span> Takip Et
                </a>
                
                <div class="text-center flex flex-col items-center scale-in-anim">
                    <div class="w-24 h-24 mx-auto rounded-full overflow-hidden border-4 border-blue-500  relative mb-4 bg-black flex justify-center items-center shadow-[0_0_15px_rgba(0,136,255,0.6)]">
                        <img src="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg" class="w-full h-full object-cover">
                    </div>
                    <h1 class="teko-font text-6xl text-white tracking-widest ">FREERIDER<span style="color:#0088ff;text-shadow:0 0 10px #0088ff;">TR</span></h1>
                    <p class="text-zinc-300 text-xs uppercase tracking-widest mt-2 font-black ">HARDCORE DOWNHILL TOPLULUĞU</p>
                </div>
            </div>
            
            <!-- Kullanıcı İstatistikleri Çubuğu -->
            <div class="relative z-10 px-6 mb-3">
                <div class="flex items-center justify-center gap-4 bg-black/60 border border-zinc-800 rounded-2xl px-5 py-3 ">
                    <div class="flex items-center gap-2">
                        <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse "></div>
                        <div class="text-center">
                            <div id="login-active-users" class="text-green-400 font-black text-lg teko-font leading-none">--</div>
                            <div class="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Aktif</div>
                        </div>
                    </div>
                    <div class="w-px h-8 bg-zinc-700"></div>
                    <div class="flex items-center gap-2">
                        <span class="text-lg">👥</span>
                        <div class="text-center">
                            <div id="login-total-users" class="text-white font-black text-lg teko-font leading-none">--</div>
                            <div class="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Toplam Üye</div>
                        </div>
                    </div>
                    <div class="w-px h-8 bg-zinc-700"></div>
                    <div class="flex items-center gap-2">
                        <span class="text-lg">🏔️</span>
                        <div class="text-center">
                            <div class="text-sky-300 font-black text-lg teko-font leading-none">TR#1</div>
                            <div class="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Platform</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="p-6 flex-1 relative z-10 flex flex-col justify-end pb-12">
                <div class="glass-panel p-6 rounded-3xl">
                    <div class="flex bg-zinc-900/80 rounded-xl p-1 mb-8  border border-zinc-800">
                        <button onclick="showLoginTab()" id="login-tab-btn" class="flex-1 py-3 bg-gradient-to-r from-sky-700 to-sky-500 text-white rounded-lg font-black text-sm  tracking-widest uppercase transition-all">GİRİŞ YAP</button>
                        <button onclick="showRegisterTab()" id="register-tab-btn" class="flex-1 py-3 bg-transparent text-zinc-400 rounded-lg font-bold text-sm tracking-widest uppercase transition-all hover:text-white">KAYIT OL</button>
                    </div>
                    
                    <div id="login-form" class="scale-in-anim">
                        <input id="login-username" type="text" placeholder="Kullanıcı Adı" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 focus:bg-black/80 transition-all font-bold" autocomplete="username" autocapitalize="none" autocorrect="off">
                        <input id="login-password" type="password" placeholder="Şifre" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-4 outline-none text-white focus:border-sky-500 focus:bg-black/80 transition-all font-bold" autocomplete="current-password" autocapitalize="none" autocorrect="off">
                        
                        <div class="flex justify-end items-center mb-8 px-1">
                            <a href="javascript:void(0)" onclick="openForgotPasswordModal()" class="text-xs text-blue-400 hover:text-blue-300 transition hover:underline">Şifremi Unuttum?</a>
                        </div>
                        <!-- E-posta ile kayıt olmayan kullanıcılar için AI Destek yönlendirmesi -->
                        <div id="no-email-hint" style="display:none; margin-bottom:20px; margin-top:-15px; text-align:center;">
                          <p style="font-size:12px; color:#aaa; margin:0 0 6px;">
                            📧 E-posta ile kayıt olmadıysanız şifre sıfırlama linki gönderilemez.
                          </p>
                          <button onclick="openAISupportPanel()" style="
                            background:linear-gradient(135deg,#1a73e8,#6c3fe8);
                            color:#fff; border:none; border-radius:20px;
                            padding:8px 18px; font-size:13px; cursor:pointer;
                            font-family:inherit; transition:opacity 0.2s;
                          " onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
                            🤖 AI Destek ile Hesabımı Kurtarmak İstiyorum
                          </button>
                        </div>
                        
                        <button onclick="handleLogin()" class="w-full bg-gradient-to-r from-sky-700 to-sky-500 btn-premium-hover text-white py-4 rounded-xl font-black  text-lg tracking-widest">SİSTEME DAL</button>
                        
                        <div class="my-4 flex items-center">
                            <div class="flex-grow border-t border-zinc-700"></div>
                            <span class="px-3 text-zinc-500 text-xs font-bold uppercase tracking-widest">veya</span>
                            <div class="flex-grow border-t border-zinc-700"></div>
                        </div>
                        
                        <button onclick="handleGoogleLogin()" class="w-full bg-white text-black py-3.5 rounded-xl font-bold flex items-center justify-center gap-3 transition hover:bg-gray-200">
                            <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" /><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" /><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" /><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" /></svg>
                            Google ile Giriş Yap
                        </button>
                        
                        <div class="mt-6 text-center">
                            <button onclick="openAISupportPanel()" class="text-xs text-blue-400 hover:text-blue-300 font-bold uppercase tracking-widest transition">
                                🎧 Destek Hattı
                            </button>
                        </div>
                    </div>
                    
                    <div id="register-form" class="hidden scale-in-anim">
                        <input id="reg-name" type="text" placeholder="Ad Soyad" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold">
                        <input id="reg-username" type="text" placeholder="Kullanıcı Adı" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold" autocapitalize="none" autocorrect="off">
                        <input id="reg-city" type="text" placeholder="Şehir" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold">
                        <input id="reg-password" type="password" placeholder="Şifre" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold" autocapitalize="none" autocorrect="off">
                        
                        <input id="reg-email" type="email" placeholder="E-posta (@gmail.com — İsteğe Bağlı)" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-1 outline-none text-white focus:border-sky-500 transition-all font-bold">
                        <div class="mb-3 px-1 space-y-1">
                            <p class="text-[10px] text-yellow-400/80 leading-tight">⚠️ <b>Gmail girmezsen şifreni sıfırlayamazsın.</b> Daha sonra profil ayarlarından ekleyebilirsin.</p>
                            <p class="text-[10px] text-zinc-500 leading-tight">Referans kodu kullanmak için @gmail.com zorunludur.</p>
                        </div>

                        <input id="reg-ref-code" type="text" placeholder="Referans Kodu (İsteğe Bağlı)" class="w-full bg-black/50 border border-purple-500/50 rounded-xl px-5 py-4 mb-3 outline-none text-purple-100 focus:border-purple-400 focus: transition-all font-bold" oninput="checkRefCodeInput()">
                        
                        <div id="reg-ref-reward-container" class="hidden mb-3 p-4 bg-purple-900/30 border border-purple-500/50 rounded-xl ">
                            <p class="text-[10px] text-purple-300 font-bold uppercase tracking-widest mb-2 flex items-center gap-2"><span class="animate-pulse">🎁</span> Referans Ödülünü Seç</p>
                            <select id="reg-ref-reward" class="w-full bg-black/80 border border-purple-700 rounded-lg px-3 py-3 text-white text-sm outline-none focus:border-purple-400 transition cursor-pointer">
                                <option value="xp_500">🌟 500 Başlangıç XP'si</option>
                                <option value="prem_dlx_2">🔥 2 Gün Deluxe Premium</option>
                                <option value="prem_ult_1">👑 1 Gün Ultra+ Premium</option>
                                <option value="prem_std_7">⭐ 1 Hafta Standart Premium</option>
                            </select>
                        </div>
                        
                        <div class="flex items-start gap-2 mb-3 px-1">
                            <input type="checkbox" id="reg-marketing" class="w-4 h-4 mt-0.5 accent-sky-500 rounded cursor-pointer">
                            <label for="reg-marketing" class="text-xs text-zinc-400 font-medium cursor-pointer hover:text-white transition">
                                Haberlerden ve güncellemelerden haberdar olmak istiyorum.
                            </label>
                        </div>
                        
                        <div class="flex items-start gap-2 mb-3 px-1 border-t border-zinc-800 pt-3">
                            <input type="checkbox" id="reg-kvkk" class="w-4 h-4 mt-0.5 accent-sky-500 rounded cursor-pointer">
                            <label for="reg-kvkk" class="text-xs text-zinc-400 font-medium cursor-pointer hover:text-white transition">
                                <a onclick="openKvkkModal()" class="text-sky-400 hover:text-sky-300 underline font-bold transition">Kullanıcı Sözleşmesi ve KVKK</a> metnini okudum, kabul ediyorum.
                            </label>
                        </div>
                        <div class="flex items-start gap-2 mb-6 px-1">
                            <input type="checkbox" id="reg-privacy" class="w-4 h-4 mt-0.5 accent-sky-500 rounded cursor-pointer">
                            <label for="reg-privacy" class="text-xs text-zinc-400 font-medium cursor-pointer hover:text-white transition">
                                <a href="/privacy-policy" target="_blank" class="text-blue-400 hover:text-blue-300 underline font-bold transition">Gizlilik Sözleşmesi</a> ve <a href="/terms" target="_blank" class="text-blue-400 hover:text-blue-300 underline font-bold transition">Kullanım Şartları</a>'nı okudum, kabul ediyorum.
                            </label>
                        </div>
                        
                        <button onclick="handleRegister()" class="w-full bg-gradient-to-r from-sky-700 to-sky-500 btn-premium-hover text-white py-4 rounded-xl font-black  text-lg tracking-widest">ARAMIZA KATIL</button>
                    </div>


                    
                </div>
            </div>
        </div>

        <div id="main-app" class="hidden absolute inset-0 flex flex-col w-full slide-up-anim">
            <div class="px-4 py-2 flex items-center justify-between z-[100] shrink-0 gap-2" style="background:linear-gradient(180deg,rgba(2,8,18,0.98) 0%,rgba(8,8,12,0.96) 100%);box-shadow:0 1px 0 rgba(14,165,233,0.15),0 3px 16px rgba(0,0,0,0.6);">
                <!-- Sol: Logo -->
                <div class="flex items-center gap-1.5 min-w-0 flex-1">
                    <img src="https://cdn.freeridertr.com.tr/bildirim%20resmi/photo_5825636358775573905_y%20(1).jpg" class="w-7 h-7 rounded-full border border-blue-500/50 object-cover" style="box-shadow: 0 0 10px rgba(0,136,255,0.7);">
                    <span class="teko-font text-white tracking-widest font-black truncate" style="font-size:22px;letter-spacing:0.10em;text-shadow:0 0 18px rgba(0,136,255,0.5)">FREERIDER<span style="color:#00ccff;text-shadow:0 0 12px #00ccff">TR</span></span>
                </div>
                <!-- Sağ: Kullanıcı Adı + Avatar -->
                <div onclick="switchTab(7)" class="flex items-center gap-2 cursor-pointer group shrink-0" style="transition:all 0.2s">
                    <div class="text-right group-hover:opacity-80 transition-opacity">
                        <div id="top-username" class="font-black text-sm text-white transition-all leading-tight truncate max-w-[90px]"></div>
                        <div id="top-title" class="text-[9px] font-black uppercase text-sky-400/80 tracking-widest leading-tight"></div>
                    </div>
                    <div class="relative shrink-0">
                        <div class="w-10 h-10 rounded-full overflow-hidden transition-all group-hover:scale-110" style="border:2px solid rgba(56,189,248,0.7);box-shadow:0 0 14px rgba(56,189,248,0.4);">
                            <img id="top-avatar" src="" class="w-full h-full object-cover" onerror="this.src='https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg'">
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex-1 relative overflow-hidden bg-zinc-950 z-0">
                <div id="screen-map" class="absolute inset-0 flex flex-col z-10 slide-up-anim">
                    <div class="absolute top-4 left-4 flex flex-col gap-2 z-[999]">
                        <button onclick="showNearbyRoutes()" title="Yakın Rotalar"
                            class="bg-glass rounded-full border border-zinc-700/50   hover:bg-zinc-800 btn-premium-hover flex items-center gap-1.5 px-3 py-2 mb-2"><span class="text-lg">📍</span><span class="text-[9px] text-white font-bold uppercase tracking-widest">Yakın Rotalar</span></button>
                        
                        <!-- Map Filter UI Kaldırıldı (Kullanıcı talebi) -->
                    </div>

                    <!-- Hava durumu tamamen kaldırıldı -->
                    <div id="weather-widget" style="display:none!important;" class="hidden">
                        <div id="weather-icon"></div>
                        <div>
                            <div id="weather-temp"></div>
                            <div id="weather-desc"></div>
                            <div id="weather-advice"></div>
                        </div>
                    </div>
                    
                    <div id="radar-info" class="hidden absolute top-16 left-4 right-4 bg-green-900/90 border border-green-500/70 p-3 rounded-2xl z-[999] flex items-center justify-between   slide-up-anim">
                        <div class="flex items-center gap-2">
                            <span class="text-green-400 animate-pulse text-xl ">📡</span>
                            <div>
                                <div class="text-white text-xs font-bold tracking-wide">Sürüş Modu Aktif</div>
                                <div class="text-green-300 text-[9px] uppercase tracking-widest font-bold">Konumun diğerlerine gözüküyor</div>
                            </div>
                        </div>
                        <button onclick="toggleRidingMode()" class="bg-green-700 hover:bg-green-600 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold btn-premium-hover">BİTİR</button>
                    </div>
                    
                    <div id="map" class="flex-1 w-full h-full relative"></div>
                    
                    <!-- EKRAN ORTASI HEDEF (CROSSHAIR) - Tıklama Sorunu Çözümü -->
                    <div id="map-crosshair" class="hidden absolute inset-0 pointer-events-none z-[800] flex items-center justify-center">
                        <div class="relative flex items-center justify-center">
                            <div class="absolute w-8 h-8 rounded-full border-2 border-red-500/50 animate-ping"></div>
                            <div class="absolute w-0.5 h-3 bg-red-500"></div>
                            <div class="absolute w-3 h-0.5 bg-red-500"></div>
                            <div class="absolute mt-10 text-red-400 font-bold text-[9px] bg-black/80 px-2 py-0.5 rounded-full border border-red-500/30 uppercase tracking-widest ">Hedefi Ayarla</div>
                        </div>
                    </div>
                    
                    <!-- İŞARETLE BUTONU -->
                    <div id="map-confirm-btn-container" class="hidden absolute bottom-24 left-1/2 -translate-x-1/2 z-[900]">
                        <button onclick="confirmMapSelection()" class="bg-red-600 hover:bg-red-500 transition text-white font-bold px-5 py-2 rounded-full  animate-bounce border border-white/30 tracking-widest text-xs flex items-center gap-2"><span>📍</span> BURAYI SEÇ</button>
                    </div>
                    
                    <div class="absolute bottom-6 right-4 flex flex-col gap-2 z-[999] items-end pointer-events-none">
                        <button onclick="autoZoomToUserLocation()" class="bg-glass w-10 h-10 rounded-full text-lg border border-zinc-700/50  flex items-center justify-center pointer-events-auto mb-1 btn-premium-hover">🎯</button>
                        <button onclick="toggleRidingMode()" id="btn-riding-mode" class="bg-green-600/90  hover:bg-green-500 btn-premium-hover px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-green-400/50 pointer-events-auto">📡 RADAR (SÜRÜŞTEYİM)</button>
                        <button onclick="toggleAddEventMode()" id="btn-add-event-mode" class="bg-blue-600/90  hover:bg-blue-500 btn-premium-hover px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-blue-400/50 pointer-events-auto">📅 BULUŞMA EKLE</button>
                        <button onclick="openCategorySelectModal()" id="btn-add-marker-mode" class="bg-sky-600/90  hover:bg-red-500 btn-premium-hover px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-red-400/50 pointer-events-auto">📍 YER EKLE</button>
                        <button onclick="quickAddMarkerCurrentLocation()" id="btn-add-marker-current" class="bg-orange-600/90  hover:bg-orange-500 btn-premium-hover px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-orange-400/50 pointer-events-auto">🎯 KENDİ KONUMUMU EKLE</button>
                    </div>
                </div>

                <div id="screen-chat" class="hidden absolute inset-0 flex flex-col z-20 bg-darker slide-up-anim">
                    <div class="bg-zinc-900/50 p-2 flex justify-between items-center border-b border-zinc-800 shrink-0 z-10">
                        <div class="flex w-full bg-zinc-950 rounded-lg p-1">
                            <button onclick="switchChatTab('group')" id="chat-tab-group" class="flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition-all ">GRUP SOHBETİ</button>
                            <button onclick="switchChatTab('dm')" id="chat-tab-dm" class="flex-1 py-2 text-zinc-500 rounded font-bold text-xs transition-all hover:text-white">ÖZEL (DM)</button>
                        </div>
                    </div>
                    
                    <!-- Story Bar -->
                    <div id="story-bar" class="flex gap-3 overflow-x-auto px-4 py-3 shrink-0 border-b border-zinc-800/50 bg-black/20" style="scrollbar-width:none;-ms-overflow-style:none;">
                        <!-- Add story button -->
                        <div onclick="openAddStoryModal()" class="flex flex-col items-center gap-1 shrink-0 cursor-pointer">
                            <div class="w-14 h-14 rounded-full bg-zinc-900 border-2 border-dashed border-zinc-600 flex items-center justify-center text-2xl hover:border-sky-400 transition-colors">+</div>
                            <span class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">Story</span>
                        </div>
                        <div id="story-items" class="flex gap-3 items-center"></div>
                    </div>

                    <div id="chat-group-area" class="flex-1 flex flex-col overflow-hidden relative">
                        <div id="pinned-message-area" class="hidden bg-gradient-to-r from-yellow-600 to-yellow-500 text-black px-4 py-2 font-bold text-xs flex justify-between items-center z-20  border-b border-yellow-400">
                            <div class="flex items-center gap-2 truncate">
                                <span class="animate-bounce">📌</span> <span id="pinned-message-text" class="truncate "></span>
                            </div>
                        </div>

                        <div id="chat-messages" class="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar scroll-smooth"></div>
                        
                        <div class="bg-glass p-2 flex items-center gap-1 border-t border-zinc-800 shrink-0 pb-safe">
                            <button onclick="askAIGroup()" title="AI'ya Sor" class="bg-gradient-to-br from-violet-600 to-cyan-500 hover:opacity-90 active:scale-95 transition w-10 h-10 md:w-12 md:h-12 rounded-xl text-lg flex items-center justify-center border border-violet-500/50 btn-premium-hover shrink-0 ">🤖</button>
                            <button onclick="openPhotoUpload('group')" title="Fotoğraf Gönder" class="bg-zinc-800/80 hover:bg-zinc-700 transition w-10 h-10 md:w-12 md:h-12 rounded-xl text-lg flex items-center justify-center border border-zinc-700 btn-premium-hover shrink-0">📸</button>
                            <button onclick="toggleVoiceRecord('group')" id="voice-btn" title="Sesli Mesaj" class="bg-zinc-800/80 hover:bg-zinc-700 transition w-10 h-10 md:w-12 md:h-12 rounded-xl text-lg flex items-center justify-center border border-zinc-700 btn-premium-hover shrink-0">🎤</button>
                            <input id="chat-input" type="text" placeholder="Mesaj veya AI'a soru yaz..." class="flex-1 bg-zinc-950/80  border border-zinc-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-zinc-400 transition min-w-[80px] ">
                            <button onclick="sendChatMessage()" class="bg-white hover:bg-gray-100 active:scale-95 transition text-black px-4 py-3 rounded-xl font-bold text-xs  btn-premium-hover shrink-0">✈️ GÖNDER</button>
                        </div>

                    </div>

                    <div id="chat-dm-list-area" class="hidden flex-1 overflow-y-auto p-4 custom-scrollbar slide-up-anim">
                        <div class="text-[10px] text-zinc-500 mb-4 font-bold uppercase tracking-widest border-b border-zinc-800 pb-2">Mesaj Kutun</div>
                        <div id="dm-users-list" class="space-y-2"></div>
                    </div>
                    
                    <div id="chat-dm-thread-area" class="hidden flex-1 flex flex-col overflow-hidden bg-darker absolute inset-0 z-30 slide-up-anim">
                        <div class="glass-panel p-3 flex items-center gap-3 border-b border-zinc-800 shrink-0 z-10">
                            <button onclick="closeDmThread()" class="text-zinc-400 bg-zinc-900 w-8 h-8 rounded-full flex items-center justify-center hover:text-white transition hover:scale-110">←</button>
                            <div class="font-bold text-white flex-1 text-sm tracking-wide " id="dm-thread-name"></div>
                        </div>
                        
                        <div id="dm-messages" class="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar scroll-smooth"></div>
                        
                        <div class="glass-panel p-2 flex items-center gap-1 border-t border-zinc-800 shrink-0 pb-safe">
                            <button onclick="openPhotoUpload('dm')" class="bg-zinc-800/80 hover:bg-zinc-700 transition w-12 h-12 rounded-xl text-xl flex items-center justify-center border border-zinc-700 btn-premium-hover">📸</button>
                            <input id="dm-input" type="text" placeholder="Özel mesaj yaz..." class="flex-1 w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-zinc-400 transition ">
                            <button onclick="sendDmMessage()" class="bg-white hover:bg-gray-200 transition text-black px-5 py-3 rounded-xl font-bold text-sm btn-premium-hover ">GÖNDER</button>
                        </div>
                    </div>
                </div>

                <div id="screen-market" class="hidden absolute inset-0 bg-darker overflow-y-auto p-4 z-20 custom-scrollbar slide-up-anim" style="max-width:100%;box-sizing:border-box;-webkit-overflow-scrolling:touch;">
                    <div class="flex justify-between items-center mb-6 border-b border-zinc-800 pb-3">
                        <h2 class="text-3xl teko-font tracking-wide text-white ">EKİPMAN PAZARI</h2>
                        <button onclick="openMarketModal()" class="bg-white hover:bg-gray-200 transition text-black text-xs px-4 py-2 rounded-lg font-bold  btn-premium-hover">+ İLAN VER</button>
                    </div>
                    <div id="market-list" class="grid grid-cols-2 gap-3 pb-32"></div>
                </div>

                <div id="screen-rank" class="hidden absolute inset-0 bg-darker overflow-y-auto p-4 z-20 custom-scrollbar slide-up-anim">
                    <!-- Kullanıcı Sayacı Bandı -->
                    <div class="flex gap-3 mb-4">
                        <div class="flex-1 bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 flex items-center gap-2">
                            <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <div>
                                <div id="rank-active-users" class="text-green-400 font-black text-base teko-font leading-none">--</div>
                                <div class="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Aktif Kullanıcı</div>
                            </div>
                        </div>
                        <div class="flex-1 bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 flex items-center gap-2">
                            <span class="text-base">👥</span>
                            <div>
                                <div id="rank-total-users" class="text-white font-black text-base teko-font leading-none">--</div>
                                <div class="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Toplam Üye</div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-3xl teko-font tracking-wide text-white ">🏆 LİDER TABLOSU</h2>
                        <button onclick="document.getElementById('rewards-modal').classList.remove('hidden')" class="bg-gradient-to-r from-yellow-600 to-orange-500 hover:opacity-90 transition text-white px-4 py-2 rounded-xl text-[10px] font-black tracking-widest uppercase  btn-premium-hover flex items-center gap-1">
                            <span class="text-sm">🎁</span> ÖDÜLLER
                        </button>
                    </div>
                    <div class="flex w-full bg-zinc-950 rounded-lg p-1 mb-6 border border-zinc-800 ">
                        <button onclick="switchLeaderboard('weekly')" id="rank-tab-weekly" class="flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition-all ">HAFTALIK</button>
                        <button onclick="switchLeaderboard('month')" id="rank-tab-month" class="flex-1 py-2 text-zinc-500 rounded font-bold text-xs transition-all hover:text-white">AYLIK</button>
                        <button onclick="switchLeaderboard('all')" id="rank-tab-all" class="flex-1 py-2 text-zinc-500 rounded font-bold text-xs transition-all hover:text-white">TÜM ZAMANLAR</button>
                    </div>
                    <div id="leaderboard" class="space-y-3 pb-10"></div>
                </div>
                
                <div id="screen-news" class="hidden absolute inset-0 bg-darker overflow-y-auto p-4 z-20 custom-scrollbar slide-up-anim">
                    <h2 class="text-3xl mb-6 text-white teko-font tracking-wide border-b border-zinc-800 pb-3 ">📰 HABERLER & DUYURULAR</h2>
                    <div id="news-list" class="space-y-4 pb-10"></div>
                </div>

                <div id="screen-missions" class="hidden absolute inset-0 bg-darker overflow-y-auto z-20 custom-scrollbar slide-up-anim" style="max-width:100%;box-sizing:border-box;">

                    <!-- INLINE ŞANS ÇARKI — sabit üst bölge, kaydırmaz -->
                    <div class="glass-panel rounded-3xl p-5 border border-yellow-700/40 mx-4 mt-4 mb-4">
                        <div class="flex items-center justify-between mb-3">
                            <h2 class="text-2xl text-yellow-400 teko-font tracking-wide ">🎡 ŞANS ÇARKI</h2>
                            <p id="spin-inline-info" class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest text-right"></p>
                        </div>
                        <div class="flex flex-col items-center">
                            <div class="relative mb-4" style="perspective:800px;">
                                <canvas id="wheel-canvas-3d" width="260" height="260" style="border-radius:50%;box-shadow:0 0 35px rgba(14,165,233,0.5),0 0 60px rgba(234,179,8,0.2);cursor:pointer;" onclick="spinWheelAction()"></canvas>
                                <!-- Pointer (ibre) -->
                                <div class="absolute top-0 left-1/2 z-20" style="transform:translateX(-50%) translateY(-4px);width:0;height:0;border-left:13px solid transparent;border-right:13px solid transparent;border-top:28px solid #ffffff;filter:drop-shadow(0 3px 8px rgba(0,0,0,1)) drop-shadow(0 0 6px rgba(234,179,8,0.8));"></div>
                                <!-- Center cap -->
                                <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                                    <div class="w-12 h-12 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-900 border-4 border-zinc-600  z-30 flex items-center justify-center text-xl">🎯</div>
                                </div>
                            </div>
                            <!-- Sesler: base64 data URI yerine güvenilir CDN -->
                            <audio id="spin-tick-sound" preload="auto">
                                <source src="https://cdn.freesound.org/previews/220/220173_4100837-lq.mp3" type="audio/mpeg">
                            </audio>
                            <audio id="spin-win-sound" preload="auto">
                                <source src="https://cdn.freesound.org/previews/270/270404_5123851-lq.mp3" type="audio/mpeg">
                            </audio>
                            <button id="spin-btn" onclick="spinWheelAction()" class="w-full bg-gradient-to-r from-yellow-600 to-sky-500 hover:opacity-90 transition-all text-white py-4 rounded-xl font-black  text-lg tracking-widest btn-premium-hover">ÇARKI ÇEVİR</button>
                            <p class="text-[10px] text-zinc-600 font-bold uppercase tracking-widest text-center mt-2">Tüm hesaplamalar sunucuda güvenli yapılır.</p>
                        </div>
                    </div>  <!-- glass-panel çark sonu -->

                    <!-- Kaydırılabilir görev listesi -->
                    <div class="px-4 pt-2 pb-32">
                        <div class="bg-gradient-to-r from-sky-700 to-sky-500 rounded-3xl p-6 mb-6 relative overflow-hidden ">
                            <div class="absolute -right-4 -bottom-4 text-8xl opacity-20">🎯</div>
                            <h2 class="text-3xl text-white teko-font tracking-wide mb-1 relative z-10 ">GÖREVLER VE ÖDÜLLER</h2>
                            <p class="text-xs text-white/90 relative z-10 font-medium">Aktivite yap, görevleri tamamla ve XP kazan!</p>
                        </div>
                        <div id="missions-list" class="space-y-3"></div>
                    </div>
                </div>
                
                <!-- BISIKLET YARIŞMASI EKRANI -->
                <div id="screen-giveaway" class="hidden absolute inset-0 bg-darker overflow-y-auto z-20 custom-scrollbar slide-up-anim" style="max-width:100%;box-sizing:border-box;">
                    <div style="padding:16px 16px 8px;display:flex;align-items:center;justify-content:space-between;">
                        <h2 style="font-size:24px;font-weight:900;color:#fff;letter-spacing:0.03em;">🎁 Çekilişler</h2>
                        <button id="btn-admin-gw-add" onclick="showCreateGiveawayModal()" class="hidden bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition">YENİ ÇEKİLİŞ</button>
                    </div>
                    <div id="giveaway-list" style="display:flex;flex-direction:column;gap:12px;padding:8px 16px 80px;"></div>
                </div>

                <div id="screen-competition" class="hidden absolute inset-0 bg-darker overflow-y-auto z-20 custom-scrollbar slide-up-anim" style="max-width:100%;box-sizing:border-box;">
                    <!-- Header -->
                    <div class="sticky top-0 z-30 bg-darker/95  border-b border-zinc-800 px-4 pt-4 pb-3">
                        <div class="flex items-center justify-between mb-2">
                            <div>
                                <h1 class="text-3xl text-white teko-font tracking-wide">🏁 BİSİKLET YARIŞMASI</h1>
                                <p id="comp-week-label" class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest"></p>
                            </div>
                            <button onclick="openSubmitBikeModal()" class="bg-gradient-to-r from-orange-500 to-red-500 hover:opacity-90 text-white px-4 py-2 rounded-xl font-black text-xs uppercase tracking-widest transition  btn-premium-hover">+ Bisiklet Ekle</button>
                        </div>
                        <div class="mb-3">
                            <div class="bg-black/60 border border-zinc-700/50 rounded-xl px-3 py-2 flex items-center justify-between">
                                <span class="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">⏳ Kalan Süre</span>
                                <span id="comp-countdown" class="text-xs text-orange-400 font-black tracking-wider font-mono">Hesaplanıyor...</span>
                            </div>
                        </div>
                        <!-- Category tabs -->
                        <div class="flex gap-2 overflow-x-auto pb-1 custom-scrollbar" style="scrollbar-width:none;">
                            <button id="ctab-Tümü" onclick="setCompetitionCategory('Tümü')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-orange-500 text-white transition">Tümü</button>
                            <button id="ctab-DH" onclick="setCompetitionCategory('DH')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition">DH</button>
                            <button id="ctab-Enduro" onclick="setCompetitionCategory('Enduro')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition">Enduro</button>
                            <button id="ctab-XC" onclick="setCompetitionCategory('XC')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition">XC</button>
                            <button id="ctab-Hardtail" onclick="setCompetitionCategory('Hardtail')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition">Hardtail</button>
                            <button id="ctab-Trail" onclick="setCompetitionCategory('Trail')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition">Trail</button>
                            <button id="ctab-BMX" onclick="setCompetitionCategory('BMX')" class="comp-cat-btn shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition">BMX</button>
                        </div>
                    </div>

                    <div class="p-4">
                        <!-- Compact Rewards Banner -->
                        <div class="glass-panel p-3 rounded-xl border border-yellow-900/50  mb-5 bg-gradient-to-r from-yellow-950/20 to-orange-950/20 flex flex-col md:flex-row items-center justify-between gap-3">
                            <div class="flex-1">
                                <h3 class="text-xs text-yellow-500 font-black uppercase tracking-widest mb-1 flex items-center gap-2"><span class="animate-bounce">🎁</span> Ödüller & Rozetler</h3>
                                <p class="text-[9px] text-zinc-300 font-medium leading-relaxed">Pazar gece yarısı süre dolduğunda, <b class="text-white">her kategoride (DH, Enduro, vs.) ayrı ayrı</b> en çok puan alan ilk 3 kişiye XP ve o aya özel <b>kalıcı rozet</b> otomatik verilir! (🥇3000 XP, 🥈2000 XP, 🥉1000 XP)</p>
                            </div>
                            <div class="flex gap-2 shrink-0">
                                <div class="bg-black/40 px-2 py-1.5 rounded-lg border border-yellow-500/20 flex flex-col items-center">
                                    <span class="text-sm">🥇</span>
                                    <span class="text-[8px] text-zinc-400 font-bold">1. SIRA</span>
                                </div>
                                <div class="bg-black/40 px-2 py-1.5 rounded-lg border border-zinc-500/20 flex flex-col items-center">
                                    <span class="text-sm">🥈</span>
                                    <span class="text-[8px] text-zinc-400 font-bold">2. SIRA</span>
                                </div>
                                <div class="bg-black/40 px-2 py-1.5 rounded-lg border border-orange-500/20 flex flex-col items-center">
                                    <span class="text-sm">🥉</span>
                                    <span class="text-[8px] text-zinc-400 font-bold">3. SIRA</span>
                                </div>
                            </div>
                        </div>

                        <!-- Previous week winners -->
                        <div id="comp-winners-section" class="hidden mb-6">
                            <h2 class="text-sm font-black uppercase tracking-widest text-yellow-400 mb-3 flex items-center gap-2"><span class="animate-pulse">🏆</span> Geçen Hafta Kazananları</h2>
                            <div id="comp-winners-list" class="space-y-2"></div>
                        </div>

                        <!-- This week entries -->
                        <div class="mb-3 flex items-center justify-between">
                            <h2 class="text-sm font-black uppercase tracking-widest text-white flex items-center gap-2">⚡ Bu Haftanın Bisikletleri</h2>
                            <span id="comp-entry-count" class="text-[10px] text-zinc-500 font-bold"></span>
                        </div>
                        <div id="comp-entries-list" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="text-center text-zinc-600 text-xs py-10 animate-pulse col-span-full">Yükleniyor...</div>
                        </div>
                    </div>
                </div>

                <!-- Yarışma Bisiklet Detay Modal -->
                <div id="comp-bike-detail-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 " onclick="if(event.target === this) this.classList.add('hidden')">
                    <div class="glass-panel w-full max-w-md rounded-3xl overflow-hidden border border-zinc-700  scale-in-anim max-h-[90dvh] flex flex-col">
                        <div class="relative shrink-0">
                            <img id="cbd-image" src="" class="w-full h-56 object-cover bg-zinc-900">
                            <button onclick="document.getElementById('comp-bike-detail-modal').classList.add('hidden')" class="absolute top-[70px] right-4 bg-black/80  border border-zinc-500 text-white w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition " style="z-index:9999;">✕</button>
                            <div class="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-black/90 to-transparent"></div>
                            <div class="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                                <div>
                                    <div id="cbd-model" class="text-2xl font-black text-white teko-font tracking-wide "></div>
                                    <div id="cbd-brand" class="text-xs font-bold text-zinc-300 uppercase tracking-widest "></div>
                                </div>
                                <div class="text-right">
                                    <div id="cbd-stars" class="text-2xl font-black "></div>
                                    <div id="cbd-rating-count" class="text-[9px] text-zinc-400 font-bold uppercase tracking-widest"></div>
                                </div>
                            </div>
                        </div>
                        <div class="p-5 overflow-y-auto custom-scrollbar flex-1 bg-black/60">
                            <div class="flex items-center justify-between mb-4 border-b border-zinc-800 pb-3">
                                <div class="text-xs text-zinc-400 font-bold cursor-pointer hover:text-white transition" id="cbd-owner"></div>
                                <div class="text-xs font-bold px-2 py-1 bg-zinc-800 rounded-lg text-zinc-300" id="cbd-category"></div>
                            </div>
                            <div id="cbd-specs" class="space-y-2"></div>
                            
                            <div id="cbd-actions" class="mt-5 pt-4 border-t border-zinc-800"></div>
                        </div>
                    </div>
                </div>

                <!-- Bisiklet Katılım Modal -->
                <div id="submit-bike-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
                    <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  scale-in-anim max-h-[90dvh] overflow-y-auto custom-scrollbar">
                        <h2 class="text-3xl text-white mb-1 teko-font tracking-wide ">🏁 YARIŞMAYA KATIL</h2>
                        <p class="text-zinc-400 text-xs mb-5 font-bold">Garajından bir bisiklet seç ve yarışmaya ekle. Her kategoride haftada 1 bisiklet.</p>
                        <div class="mb-4">
                            <label class="block text-[10px] text-zinc-400 mb-2 uppercase font-bold tracking-widest">Kategori Seç</label>
                            <select id="submit-bike-category" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white font-bold text-sm outline-none focus:border-orange-400 transition ">
                                <option value="DH">DH (Downhill)</option>
                                <option value="Enduro">Enduro</option>
                                <option value="XC">XC (Cross Country)</option>
                                <option value="Hardtail">Hardtail</option>
                                <option value="Trail">Trail</option>
                                <option value="BMX">BMX</option>
                            </select>
                        </div>
                        <div class="mb-5">
                            <label class="block text-[10px] text-zinc-400 mb-2 uppercase font-bold tracking-widest">Bisikletini Seç</label>
                            <div id="submit-bike-garage" class="grid grid-cols-2 gap-3"></div>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <button onclick="document.getElementById('submit-bike-modal').classList.add('hidden')" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">İPTAL</button>
                            <button onclick="submitBikeToCompetition()" class="py-4 bg-gradient-to-r from-orange-500 to-red-500 hover:opacity-90 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">KATIL!</button>
                        </div>
                    </div>
                </div>

                <!-- Puanlama Modal -->
                <div id="rate-bike-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
                    <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-zinc-700  scale-in-anim">
                        <h2 class="text-3xl text-white mb-1 teko-font tracking-wide">⭐ PUANLA</h2>
                        <div id="rate-bike-info" class="mb-5"></div>
                        <label class="block text-[10px] text-zinc-400 mb-3 uppercase font-bold tracking-widest">Puan: <span id="rate-score-display" class="text-orange-400 text-lg">5</span> / 10</label>
                        <input id="rate-score-slider" type="range" min="1" max="10" step="0.5" value="5"
                            oninput="document.getElementById('rate-score-display').textContent = this.value"
                            class="w-full h-3 rounded-full bg-zinc-700 appearance-none cursor-pointer mb-6"
                            style="accent-color: #f97316;">
                        <div class="grid grid-cols-2 gap-3">
                            <button onclick="document.getElementById('rate-bike-modal').classList.add('hidden')" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm ">İPTAL</button>
                            <button onclick="submitBikeRating()" class="py-4 bg-gradient-to-r from-yellow-500 to-orange-500 hover:opacity-90 transition rounded-xl font-bold text-black text-sm ">PUAN VER</button>
                        </div>
                    </div>
                </div>

                <div id="screen-referral" class="hidden absolute inset-0 bg-darker overflow-y-auto p-4 z-20 custom-scrollbar slide-up-anim" style="max-width:100%;box-sizing:border-box;">
                    <div class="bg-gradient-to-r from-purple-800 to-indigo-900 rounded-3xl p-6 mb-6 relative overflow-hidden  border border-purple-500/50">
                        <div class="absolute -right-4 -bottom-4 text-8xl opacity-20">🤝</div>
                        <h2 class="text-4xl text-white teko-font tracking-wide mb-1 relative z-10 ">DAVET ET, KAZAN!</h2>
                        <p class="text-xs text-zinc-200 relative z-10 font-medium leading-relaxed">Arkadaşlarını FreeriderTR'ye davet et, ikiniz de <b class="text-yellow-400 font-bold">XP veya Premium ödül</b> kazanın! <br><br><span class="bg-black/40 px-2 py-1 rounded border border-purple-500/30 text-[10px] uppercase tracking-wider inline-block">Spam Koruması: Kayıt olan kişi @gmail.com kullanmalıdır.</span></p>
                    </div>
                    
                    <div class="glass-panel p-5 rounded-2xl border border-zinc-800  mb-6">
                        <h3 class="text-sm text-purple-400 font-bold uppercase tracking-widest mb-3 flex items-center gap-2"><span class="animate-pulse">📌</span> Senin Referans Kodun</h3>
                        <div class="flex items-center gap-3">
                            <input type="text" id="my-ref-code" readonly class="flex-1 min-w-0 bg-black/60 border border-purple-900/50 rounded-xl px-4 py-3 text-white text-lg font-black tracking-widest text-center  overflow-hidden" value="">
                            <button onclick="copyRefCode()" class="bg-white hover:bg-gray-200 text-black px-5 py-3 rounded-xl font-bold transition-all  btn-premium-hover">KOPYALA</button>
                        </div>
                        <div class="mt-4 bg-zinc-900/50 rounded-lg p-3 border border-zinc-800/50">
                            <p id="ref-monthly-limit" class="text-xs text-zinc-400 text-center uppercase tracking-widest font-bold"></p>
                            <div class="w-full bg-zinc-800 h-1.5 rounded-full mt-2 overflow-hidden">
                                <div id="ref-monthly-bar" class="bg-gradient-to-r from-purple-600 to-indigo-500 h-full transition-all duration-500" style="width: 0%;"></div>
                            </div>
                        </div>
                    </div>

                    <div class="glass-panel p-5 rounded-2xl border border-yellow-900/50 ">
                        <h3 class="text-sm text-yellow-500 font-bold uppercase tracking-widest mb-3 flex justify-between items-center">
                            <span>🎁 Alınabilir Ödüllerin</span>
                            <span id="claimable-ref-count" class="bg-gradient-to-r from-yellow-500 to-yellow-600 text-black px-3 py-1 rounded-lg text-xs font-black ">0</span>
                        </h3>
                        
                        <div id="ref-claim-area" class="mt-4 transition-all duration-300">
                            <select id="ref-reward-select" class="w-full bg-black/80 border border-yellow-900/50 rounded-xl px-4 py-4 mb-4 text-white text-sm outline-none focus:border-yellow-500 transition  cursor-pointer font-medium">
                                <option value="xp_500">🌟 500 XP (Anında Hesabına Yüklenir)</option>
                                <option value="prem_dlx_2">🔥 2 Gün Deluxe Premium Üyelik</option>
                                <option value="prem_ult_1">👑 1 Gün Ultra+ Premium Üyelik</option>
                                <option value="prem_std_7">⭐ 1 Hafta Standart Premium Üyelik</option>
                            </select>
                            <button onclick="claimRefReward()" class="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 hover:opacity-90 transition-all text-black py-4 rounded-xl font-black text-sm  tracking-widest btn-premium-hover flex items-center justify-center gap-2">
                                <span>ÖDÜLÜ AL</span> <span class="text-lg">🎯</span>
                            </button>
                        </div>
                    </div>
                </div>

                <div id="screen-premium" class="hidden absolute inset-0 bg-darker overflow-y-auto z-20 custom-scrollbar slide-up-anim">
                    <!-- HEADER -->
                    <div class="relative overflow-hidden px-4 pt-8 pb-6 text-center" style="background:linear-gradient(160deg,#0a0a1a 0%,#0d1b2a 40%,#0a0a1a 100%);">
                        <div class="absolute inset-0 pointer-events-none" style="background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(56,189,248,0.12) 0%,transparent 70%);"></div>
                        <div class="text-5xl mb-2 animate-bounce">🌟</div>
                        <h2 class="text-4xl text-prem-rainbow teko-font tracking-widest mb-1">FREERIDER PLUS</h2>
                        <p class="text-[11px] text-zinc-400 mb-4 px-4 leading-relaxed">Reklamsız deneyim, özel özellikler ve topluluk ayrıcalıkları seni bekliyor.</p>
                        <!-- Lansman bandı -->
                        <div class="inline-flex items-center gap-2 bg-red-900/50 border border-red-500/40 rounded-full px-4 py-1.5 text-[10px] font-black text-red-300 uppercase tracking-widest animate-pulse">
                            <span>🔥</span> Özel Lansman İndirimi %80 — Sınırlı Süre!
                        </div>
                    </div>

                    <div class="px-4 pb-6">

                        <!-- PAKET KARTLARI — 2 sütun grid -->
                        <div class="grid grid-cols-2 gap-3 mb-4">

                            <!-- STANDART -->
                            <div id="card-std" class="relative rounded-2xl border border-blue-700/40 overflow-hidden cursor-pointer select-none transition-all duration-300"
                                 style="background:linear-gradient(145deg,#0a1628 0%,#0d1f3c 100%);"
                                 onclick="togglePremCard('std')">
                                <div class="p-4">
                                    <div class="text-2xl mb-1">⭐</div>
                                    <div class="text-blue-300 font-black text-sm tracking-wide uppercase">Standart</div>
                                    <div class="flex items-end gap-1 mt-2">
                                        <span class="text-white font-black text-xl leading-none">10 ₺</span>
                                        <span class="text-zinc-500 text-[10px] mb-0.5">/Ay</span>
                                    </div>
                                    <div class="text-zinc-500 text-[9px] line-through mt-0.5">50 ₺ /Ay</div>
                                    <div class="mt-3 text-[9px] text-blue-400 font-bold flex items-center gap-1">
                                        <span>Detaylar</span>
                                        <span id="card-std-arrow">▼</span>
                                    </div>
                                </div>
                                <div class="absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 pointer-events-none" id="card-std-glow" style="box-shadow:inset 0 0 0 2px rgba(56,189,248,0.7);"></div>
                            </div>

                            <!-- DELUXE -->
                            <div id="card-dlx" class="relative rounded-2xl border border-purple-700/40 overflow-hidden cursor-pointer select-none transition-all duration-300"
                                 style="background:linear-gradient(145deg,#150a28 0%,#1e0d3c 100%);"
                                 onclick="togglePremCard('dlx')">
                                <div class="p-4">
                                    <div class="text-2xl mb-1">🌟</div>
                                    <div class="text-purple-300 font-black text-sm tracking-wide uppercase">Deluxe</div>
                                    <div class="flex items-end gap-1 mt-2">
                                        <span class="text-white font-black text-xl leading-none">20 ₺</span>
                                        <span class="text-zinc-500 text-[10px] mb-0.5">/Ay</span>
                                    </div>
                                    <div class="text-zinc-500 text-[9px] line-through mt-0.5">100 ₺ /Ay</div>
                                    <div class="mt-3 text-[9px] text-purple-400 font-bold flex items-center gap-1">
                                        <span>Detaylar</span>
                                        <span id="card-dlx-arrow">▼</span>
                                    </div>
                                </div>
                                <div class="absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 pointer-events-none" id="card-dlx-glow" style="box-shadow:inset 0 0 0 2px rgba(168,85,247,0.7);"></div>
                            </div>

                            <!-- ULTRA — tam genişlik -->
                            <div id="card-ult" class="relative col-span-2 rounded-2xl border border-yellow-600/50 overflow-hidden cursor-pointer select-none transition-all duration-300"
                                 style="background:linear-gradient(145deg,#1a1000 0%,#2a1d00 60%,#1a1000 100%);"
                                 onclick="togglePremCard('ult')">
                                <div class="absolute -right-4 top-3 bg-yellow-500 text-black font-black text-[8px] py-1 px-8 rotate-45 tracking-widest uppercase">V.I.P</div>
                                <div class="p-4 flex items-start gap-4">
                                    <div>
                                        <div class="text-2xl mb-1">👑</div>
                                        <div class="text-yellow-400 font-black text-sm tracking-wide uppercase">Ultra+</div>
                                        <div class="flex items-end gap-1 mt-2">
                                            <span class="text-white font-black text-xl leading-none">30 ₺</span>
                                            <span class="text-zinc-500 text-[10px] mb-0.5">/Ay</span>
                                        </div>
                                        <div class="text-zinc-500 text-[9px] line-through mt-0.5">150 ₺ /Ay</div>
                                    </div>
                                    <div class="flex-1 mt-1">
                                        <div class="text-[9px] text-yellow-400/80 leading-relaxed space-y-0.5">
                                            <div>⚡ Sistem Efsanesi unvanı</div>
                                            <div>🔥 Canlı alev/buz avatar efekti</div>
                                            <div>🌈 HEX renk özgürlüğü</div>
                                            <div>✅ Mavi onay tiki</div>
                                            <div>🚲 4 bisiklet garaja ekleme</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="px-4 pb-3 text-[9px] text-yellow-500 font-bold flex items-center gap-1">
                                    <span>Tüm Detaylar</span>
                                    <span id="card-ult-arrow">▼</span>
                                </div>
                                <div class="absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 pointer-events-none" id="card-ult-glow" style="box-shadow:inset 0 0 0 2px rgba(234,179,8,0.8);"></div>
                            </div>
                        </div>

                        <!-- AÇILAN DETAY PANELİ (dinamik) -->
                        <div id="prem-detail-panel" class="hidden mb-4 rounded-2xl border p-4 transition-all duration-300 scale-in-anim">
                            <div id="prem-detail-content" class="text-xs text-zinc-300 space-y-2 leading-relaxed"></div>
                            <button id="prem-buy-btn" onclick="requestPremium()" class="w-full mt-4 py-3.5 rounded-xl font-black text-sm tracking-widest btn-premium-hover flex items-center justify-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style="width:18px;height:18px;"><path d="M3.18 23.76c.3.17.64.24.99.2l12.45-12.45L12.6 7.5 3.18 23.76zm17.01-10.7-3.45-1.99-3.62 3.62 3.62 3.62 3.44-1.98c.98-.57.98-2.1.01-2.67zM3.54.32C3.22.13 2.84.08 2.51.25L14.98 12.7l-3.62 3.62 3.45-1.99.01-.01z"/></svg>
                                SATIN AL
                            </button>
                        </div>

                        <!-- AKTİF ÜYELİK BÖLÜMÜ -->
                        <div id="premium-settings-section" class="hidden scale-in-anim mb-4">
                            <div id="current-plan-card" class="glass-panel p-5 rounded-2xl border border-zinc-700 mb-4">
                                <div class="flex items-center justify-between mb-1">
                                    <span class="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Aktif Paketiniz</span>
                                    <span id="current-plan-badge" class="text-xs font-black px-3 py-1 rounded-lg"></span>
                                </div>
                                <div id="current-plan-name" class="text-xl font-black text-white mb-1"></div>
                                <div id="current-plan-expiry" class="text-[11px] text-zinc-400 font-medium"></div>
                            </div>
                            <div id="upgrade-plan-section" class="hidden mb-4">
                                <div class="bg-gradient-to-r from-yellow-900/40 to-amber-900/30 border border-yellow-700/50 rounded-2xl p-4 mb-3 flex items-center gap-3">
                                    <span class="text-2xl">⬆️</span>
                                    <div>
                                        <div class="text-yellow-400 font-black text-sm">Üyeliğini Yükselt!</div>
                                        <div id="upgrade-hint-text" class="text-[11px] text-zinc-400 mt-0.5"></div>
                                    </div>
                                </div>
                                <select id="upgrade-tier-select" class="w-full bg-black border border-yellow-700/60 rounded-xl px-5 py-4 mb-3 outline-none text-white text-sm focus:border-yellow-500 transition font-bold cursor-pointer"></select>
                                <button onclick="requestUpgrade()" class="w-full bg-gradient-to-r from-yellow-600 to-amber-500 hover:opacity-90 transition py-4 rounded-xl font-black text-black text-sm tracking-widest btn-premium-hover flex items-center justify-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style="width:18px;height:18px;"><path d="M3.18 23.76c.3.17.64.24.99.2l12.45-12.45L12.6 7.5 3.18 23.76zm17.01-10.7-3.45-1.99-3.62 3.62 3.62 3.62 3.44-1.98c.98-.57.98-2.1.01-2.67zM3.54.32C3.22.13 2.84.08 2.51.25L14.98 12.7l-3.62 3.62 3.45-1.99.01-.01z"/></svg>
                                    ÜYELİĞİ YÜKSELT
                                </button>
                            </div>
                            <div class="glass-panel p-5 rounded-2xl border border-zinc-700 text-left">
                                <h3 class="text-white font-bold mb-3 text-sm flex items-center gap-2"><span class="animate-pulse">🎨</span> Plus Profil Ayarları</h3>
                                <div id="color-options" class="flex flex-wrap gap-2"></div>
                            </div>
                        </div>

                        <!-- SATIN ALMA BÖLÜMÜ (üyelik yoksa) -->
                        <div id="premium-buy-section">
                            <select id="premium-tier-select" class="w-full bg-black border border-zinc-700 rounded-xl px-5 py-4 mb-4 outline-none text-white text-sm focus:border-zinc-400 transition font-bold cursor-pointer">
                                <option value="freeridertr_standard_pack_monthly">⭐ Standart Paket — 10 ₺/Ay (İndirimli)</option>
                                <option value="freeridertr_deluxe_pack_monthly">🌟 Deluxe Paket — 20 ₺/Ay (İndirimli)</option>
                                <option value="freeridertr_ultra_pack_monthly">👑 Ultra+ Paket — 30 ₺/Ay (İndirimli)</option>
                            </select>
                            <button onclick="requestPremium()" class="w-full bg-gradient-to-r from-green-700 to-emerald-500 hover:opacity-90 transition py-4 rounded-xl font-bold text-white text-lg tracking-wide btn-premium-hover flex items-center justify-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style="width:22px;height:22px;"><path d="M3.18 23.76c.3.17.64.24.99.2l12.45-12.45L12.6 7.5 3.18 23.76zm17.01-10.7-3.45-1.99-3.62 3.62 3.62 3.62 3.44-1.98c.98-.57.98-2.1.01-2.67zM3.54.32C3.22.13 2.84.08 2.51.25L14.98 12.7l-3.62 3.62 3.45-1.99.01-.01z"/></svg>
                                SATIN AL
                            </button>
                            <p class="text-[10px] text-zinc-500 mt-3 text-center font-medium">Satın alım mobil uygulama üzerinden gerçekleştirilir ve otomatik aktive edilir.</p>
                        </div>

                        <!-- ══════════════════════════════════ -->
                        <!-- AKTİVASYON KODU GİRİŞ BÖLÜMÜ    -->
                        <!-- ══════════════════════════════════ -->
                        <div class="mt-4 relative rounded-2xl overflow-hidden" style="background:linear-gradient(135deg,#0f1a2e 0%,#151f35 50%,#0f1a2e 100%);border:1px solid rgba(56,189,248,0.25);">
                            <!-- Dekoratif ışık çizgisi -->
                            <div class="absolute top-0 left-0 right-0 h-px" style="background:linear-gradient(90deg,transparent,rgba(56,189,248,0.6),transparent);"></div>
                            <div class="p-4">
                                <div class="flex items-center gap-2 mb-3">
                                    <div class="w-8 h-8 rounded-xl flex items-center justify-center text-lg" style="background:linear-gradient(135deg,rgba(56,189,248,0.2),rgba(56,189,248,0.1));border:1px solid rgba(56,189,248,0.3);">🔑</div>
                                    <div>
                                        <div class="text-white font-black text-sm tracking-wide">Aktivasyon Kodu</div>
                                        <div class="text-zinc-500 text-[10px]">Kodunu gir, üyeliğin anında aktive edilsin</div>
                                    </div>
                                </div>
                                <div class="flex gap-2">
                                    <input id="activation-code-input"
                                           type="text"
                                           maxlength="12"
                                           placeholder="FRK-XXXXXXXX"
                                           oninput="this.value=this.value.toUpperCase()"
                                           class="flex-1 bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm font-mono font-bold placeholder-zinc-600 outline-none focus:border-sky-500 transition tracking-widest uppercase"
                                    >
                                    <button id="activation-code-btn" onclick="redeemActivationCode()"
                                            class="bg-gradient-to-r from-sky-600 to-blue-600 hover:opacity-90 active:scale-95 transition px-4 py-3 rounded-xl font-black text-white text-xs tracking-widest btn-premium-hover flex items-center gap-1.5 whitespace-nowrap">
                                        ⚡ AKTİVE ET
                                    </button>
                                </div>
                                <div id="activation-code-result" class="hidden mt-3 text-center text-sm font-bold rounded-xl py-2.5 px-4"></div>
                            </div>
                            <!-- Alt dekoratif ışık -->
                            <div class="absolute bottom-0 left-0 right-0 h-px" style="background:linear-gradient(90deg,transparent,rgba(56,189,248,0.3),transparent);"></div>
                        </div>

                    </div><!-- /px-4 pb-6 -->
                </div>

                <!-- ============================================================ -->
                <!-- REELS EKRANI (TikTok/Instagram tarzı) -->
                <!-- ============================================================ -->
                <div id="screen-reels" class="hidden fixed inset-0 bg-black z-[9990] flex flex-col">
                    <!-- Tam ekran feed -->
                    <div id="reels-feed" class="w-full h-full overflow-y-auto snap-y snap-mandatory custom-scrollbar" style="scroll-snap-type:y mandatory;">
                        <div id="reels-loading" class="flex items-center justify-center h-full">
                            <div class="text-center">
                                <div class="w-10 h-10 rounded-full border-4 border-pink-900/40 border-t-pink-500 animate-spin mx-auto mb-3"></div>
                                <p class="text-zinc-400 text-sm font-bold">Reels yükleniyor...</p>
                            </div>
                        </div>
                    </div>
                    <!-- Overlay butonlar — position:absolute (screen-reels zaten inset-0) -->
                    <!-- ✕ Kapat — çentikten 20px daha aşağı (72px) -->
                    <button onclick="closeReels()" style="position:absolute;top:calc(env(safe-area-inset-top, 0px) + 72px);right:16px;z-index:9999;width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,0.65);color:#fff;font-size:18px;font-weight:bold;border:1px solid rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 12px rgba(0,0,0,0.5);cursor:pointer;">✕</button>
                    <!-- 🔊 Ses -->
                    <button id="reel-sound-btn" onclick="toggleReelSound()" style="position:absolute;top:calc(env(safe-area-inset-top, 0px) + 72px);right:68px;z-index:9999;width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,0.65);font-size:22px;border:1px solid rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 12px rgba(0,0,0,0.5);cursor:pointer;">🔊</button>
                    <!-- 📷+ Reels Paylaş — ses butonunun hemen yanında, belirgin kamera ikonu -->
                    <button id="reels-upload-top-btn" onclick="openReelUploadModal()" title="Reels Paylaş"
                        style="position:absolute;top:calc(env(safe-area-inset-top, 0px) + 72px);right:120px;z-index:9999;width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,0.5);border:1.5px solid rgba(236,72,153,0.6);display:flex;align-items:center;justify-content:center;box-shadow:0 0 12px rgba(236,72,153,0.4),0 2px 8px rgba(0,0,0,0.5);cursor:pointer;font-size:18px;">
                        📷<span style="position:absolute;top:-3px;right:-3px;width:15px;height:15px;background:#e91e8c;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;color:#fff;border:1.5px solid #000;line-height:1;">+</span>
                    </button>
                    <!-- ⊞ Grid/Feed geçiş butonu -->
                    <button id="grid-view-btn" onclick="window.toggleReelsGridView()" style="position:absolute;top:calc(env(safe-area-inset-top, 0px) + 72px);right:172px;z-index:9999;width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,0.65);border:1px solid rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 12px rgba(0,0,0,0.5);cursor:pointer;" title="Izgara Görünümü">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px;"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    </button>
                    <!-- Reels FAB: sol alt köşe, navigasyonun hemen üstü -->
                    <button onclick="openReelUploadModal()" id="reels-fab-btn"
                        class="fixed z-[9999] btn-premium-hover"
                        title="Reel Paylaş"
                        style="bottom:calc(70px + env(safe-area-inset-bottom, 0px));left:16px;width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#be185d,#0ea5e9);display:flex;align-items:center;justify-content:center;box-shadow:0 0 20px rgba(236,72,153,0.65),0 4px 14px rgba(0,0,0,0.5);border:1.5px solid rgba(255,255,255,0.18);">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:22px;height:22px;">
                            <path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
                        </svg>
                    </button>
                    <!-- Boş durum -->
                    <div id="reels-empty" class="hidden fixed inset-0 flex flex-col items-center justify-center gap-4 z-[9991]">
                        <div class="text-6xl">🎬</div>
                        <p class="text-white font-black teko-font text-2xl tracking-widest">İlk Reels'i Sen Paylaş!</p>
                        <p class="text-zinc-400 text-sm text-center px-8">Bisiklet videolarını ve fotoğraflarını toplulukla paylaş!</p>
                        <button onclick="openReelUploadModal()" class="bg-gradient-to-r from-pink-700 to-sky-500 text-white px-6 py-3 rounded-xl font-black text-sm tracking-widest btn-premium-hover">+ REEL PAYLAŞ</button>
                    </div>
                </div>

                <div id="screen-profile" class="hidden absolute inset-0 bg-darker overflow-y-auto z-20 custom-scrollbar slide-up-anim">
                    <div class="p-6 text-center pb-20">
                        <div class="relative inline-block mt-4 group">
                            <div id="profile-avatar-wrap" class="avatar-particle-wrap relative inline-block">
                            <img id="profile-avatar" src="" class="w-32 h-32 mx-auto rounded-full object-cover cursor-pointer bg-zinc-900 transition-all duration-300 group-hover:opacity-80 group-hover:scale-105 " onclick="openProfilePicUpload()">
                            </div>
                            <div class="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-300">
                                <span class="text-2xl text-white ">📸</span>
                            </div>
                            <input id="pic-upload" type="file" accept="image/*" class="hidden" onchange="uploadProfilePic(this)">
                        </div>

                        <!-- Avatar seçim butonları -->
                        <div class="flex gap-2 justify-center mt-3">
                            <button onclick="openRpmModal()" class="bg-gradient-to-r from-purple-700 to-indigo-700 hover:opacity-90 text-white text-[10px] font-black px-4 py-2 rounded-xl  btn-premium-hover flex items-center gap-2 tracking-widest">
                                <span>🎭</span> 3D AVATAR OLUŞTUR
                            </button>
                            <button onclick="openProfilePicUpload()" class="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-bold px-4 py-2 rounded-xl border border-zinc-700 btn-premium-hover flex items-center gap-2 tracking-widest">
                                <span>📸</span> FOTOĞRAF
                            </button>
                        </div>
                        <p class="text-[9px] text-zinc-600 mt-1 font-bold uppercase tracking-widest">Ücretsiz · Hesap gerekmez</p>
                        
                        <div id="profile-name-container" class="flex justify-center items-center gap-2 mt-5">
                            <div id="profile-name" class="text-4xl font-bold text-white teko-font tracking-wide  transition-all"></div>
                            <div id="profile-verified-badge" class="hidden"></div>
                        </div>
                        
                        <div id="profile-bio" class="text-zinc-300 mt-2 text-sm font-medium px-4 leading-relaxed"></div>
                        
                        <div class="flex flex-wrap justify-center gap-3 mt-8 px-2">
                            <div class="glass-panel p-4 rounded-2xl border border-zinc-800/50 flex-1 min-w-[120px] max-w-[160px]  hover:border-zinc-600 transition-all duration-300">
                                <div id="profile-xp" class="text-4xl teko-font text-white tracking-wide  leading-tight">0</div>
                                <div class="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mt-1">Toplanan XP</div>
                            </div>
                            <div class="glass-panel p-4 rounded-2xl border border-zinc-800/50 flex-1 min-w-[120px] max-w-[160px]  hover:border-zinc-600 transition-all duration-300">
                                <div id="profile-title" class="text-base font-bold mt-1  transition-colors leading-snug break-words">Çaylak</div>
                            <div id="profile-xp-progress" class="w-full mt-1"></div>
                                <div class="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mt-1.5">Mevcut Ünvan</div>
                            </div>
                        </div>

                                
                        <div class="mt-4 text-left glass-panel p-4 rounded-2xl border border-zinc-800/50">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2"><span>🚲</span> Garajım</h3>
                                <button onclick="openAddBikeModal()" class="bg-zinc-800 hover:bg-zinc-700 transition text-white text-[10px] px-3 py-1.5 rounded-lg font-bold  btn-premium-hover">+ Yeni Ekle</button>
                            </div>
                            <div id="garage-list" class="grid grid-cols-2 gap-3"></div>
                        </div>

                        <div class="mt-3 text-left glass-panel p-4 rounded-2xl border border-zinc-800/50">
                            <h3 class="text-xs font-bold text-zinc-400 mb-4 uppercase tracking-widest flex items-center gap-2"><span>🏅</span> Kazanılan Rozetler</h3>
                            <div id="profile-badges" class="flex flex-wrap gap-2"></div>
                        </div>

                        <div class="mt-4 space-y-2">
                            
                            <button onclick="openSettingsModal()" class="w-full bg-zinc-900 hover:bg-zinc-800 transition py-4 rounded-xl font-bold text-white text-sm border border-zinc-700  btn-premium-hover">⚙️ PROFİLİ DÜZENLE</button>

                            
                            <button onclick="logout()" class="w-full bg-black hover:bg-red-950/40 transition text-sky-400 py-4 rounded-xl font-bold text-sm border border-sky-900/50  btn-premium-hover mt-4">SİSTEMDEN ÇIKIŞ YAP</button>
                            <button onclick="forgetMe()" class="w-full bg-red-950/20 hover:bg-red-950/50 transition text-red-500 py-4 rounded-xl font-bold text-sm border border-red-900/50 btn-premium-hover mt-2 flex items-center justify-center gap-2"><span>🗑️</span> BENİ UNUT (Tüm Çerezleri Temizle)</button>

                                                        <button id="notif-perm-btn" onclick="handleNotifPermission()" class="w-full bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-300 py-4 rounded-xl font-bold text-sm mt-4 btn-premium-hover flex items-center justify-center gap-2">
                                <span id="notif-btn-icon">🔔</span>
                                <span id="notif-btn-text">Bildirimleri Aç</span>
                            </button>

                            <div id="streak-freeze-badge" class="hidden mt-3 bg-blue-950/50 border border-blue-700/50 rounded-xl px-4 py-3 flex items-center gap-3">
                                <span class="text-2xl">🛡️</span>
                                <div><div class="text-blue-300 font-black text-sm">Seri Koruma Kalkani</div><div id="streak-freeze-count" class="text-[10px] text-zinc-400 font-bold">0 adet</div></div>
                            </div>
                            <button id="admin-btn" onclick="showAdminPanel()" class="hidden w-full bg-gradient-to-r from-sky-800 to-zinc-900 hover:opacity-90 transition text-white py-4 rounded-xl font-bold text-sm  mt-6 btn-premium-hover border border-sky-800/60">👑 YÖNETİCİ PANELİ</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div id="social-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-zinc-700 relative text-center scale-in-anim">
                <button onclick="document.getElementById('social-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50  border border-zinc-700 hover:bg-zinc-700 transition w-8 h-8 rounded-full flex items-center justify-center text-zinc-300 hover:text-white z-10 hover:scale-110">✕</button>
                <h3 class="text-3xl text-white mb-6 teko-font tracking-wide">📸 INSTAGRAM HESAPLARIMIZ</h3>
                <div class="space-y-3">
                    <button onclick="window.open('https://instagram.com/om3r_10fr', '_blank')" class="w-full bg-gradient-to-r from-pink-600 to-orange-500 py-4 rounded-xl font-bold text-white  btn-premium-hover">@om3r_10fr</button>
                    <button onclick="window.open('https://instagram.com/om3r.em1n', '_blank')" class="w-full bg-gradient-to-r from-pink-600 to-orange-500 py-4 rounded-xl font-bold text-white  btn-premium-hover">@om3r.em1n</button>
                    <button onclick="window.open('https://instagram.com/liorae.a', '_blank')" class="w-full bg-gradient-to-r from-pink-600 to-orange-500 py-4 rounded-xl font-bold text-white  btn-premium-hover">@liorae.a</button>
                    <button onclick="window.open('https://instagram.com/freeridertr1', '_blank')" class="w-full bg-gradient-to-r from-pink-600 to-orange-500 py-4 rounded-xl font-bold text-white  btn-premium-hover">@freeridertr1</button>
                </div>
            </div>
        </div>

        <div id="rewards-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-zinc-700 relative text-center scale-in-anim">
                <button onclick="document.getElementById('rewards-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50  border border-zinc-700 hover:bg-zinc-700 transition w-8 h-8 rounded-full flex items-center justify-center text-zinc-300 hover:text-white z-10 hover:scale-110">✕</button>
                <h3 class="text-4xl text-white mb-2 teko-font tracking-wide text-yellow-500 ">🎁 SIRALAMA ÖDÜLLERİ</h3>
                <p class="text-xs text-zinc-300 mb-6 font-medium">Sıralamada ilk 3'e giren pedalşörler yöneticiler tarafından ödüllendirilir.</p>
                
                <div class="bg-black/50 border border-zinc-700 rounded-2xl p-4 mb-4 text-left ">
                    <h4 class="text-sm font-bold text-blue-400 mb-2 uppercase tracking-widest border-b border-zinc-800 pb-2">📅 Haftalık Yarış</h4>
                    <div class="space-y-2 text-xs text-white">
                        <p class="flex justify-between items-center"><span>🥇 1. Olan:</span> <span class="bg-yellow-500 text-black px-2 py-0.5 rounded font-bold ">1 Hafta Ultra+</span></p>
                        <p class="flex justify-between items-center"><span>🥈 2. Olan:</span> <span class="bg-purple-600 text-white px-2 py-0.5 rounded font-bold ">1 Hafta Deluxe</span></p>
                        <p class="flex justify-between items-center"><span>🥉 3. Olan:</span> <span class="bg-purple-600 text-white px-2 py-0.5 rounded font-bold ">1 Hafta Deluxe</span></p>
                    </div>
                </div>
                
                <div class="bg-black/50 border border-zinc-700 rounded-2xl p-4 text-left ">
                    <h4 class="text-sm font-bold text-orange-400 mb-2 uppercase tracking-widest border-b border-zinc-800 pb-2">🏆 Aylık Yarış</h4>
                    <div class="space-y-2 text-xs text-white">
                        <p class="flex justify-between items-center"><span>🥇 1. Olan:</span> <span class="bg-purple-600 text-white px-2 py-0.5 rounded font-bold ">1 Ay Deluxe</span></p>
                        <p class="flex justify-between items-center"><span>🥈 2. Olan:</span> <span class="bg-purple-600 text-white px-2 py-0.5 rounded font-bold ">1 Ay Deluxe</span></p>
                        <p class="flex justify-between items-center"><span>🥉 3. Olan:</span> <span class="bg-purple-600 text-white px-2 py-0.5 rounded font-bold ">1 Ay Deluxe</span></p>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="onboarding-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4  transition-opacity">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  relative text-center scale-in-anim overflow-y-auto max-h-[92dvh]">
                <div class="text-6xl mb-3  animate-bounce">👋</div>
                <h2 class="text-4xl text-white mb-2 teko-font tracking-wide ">FREERIDER<span class="text-sky-500">TR</span>'YE HOŞ GELDİN!</h2>
                <p class="text-xs text-zinc-300 mb-4 font-medium">Türkiye'nin en büyük Hardcore Downhill & Freeride topluluğundasın.</p>

                <div class="bg-gradient-to-r from-yellow-600/20 to-amber-500/20 border border-yellow-500/50 rounded-2xl p-4 mb-4 text-left">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="text-2xl">🎁</span>
                        <span class="text-yellow-400 font-black text-sm uppercase tracking-widest">3 Günlük Ücretsiz Ultra+ Aktif!</span>
                    </div>
                    <p class="text-xs text-zinc-300 leading-relaxed">Sınırsız AI, özel isim rengi, alev efekti, şans çarkı ve tüm premium özellikler <b class="text-yellow-300">3 gün boyunca tamamen ücretsiz</b>. Denemen bitince Plus sayfasından devam edebilirsin.</p>
                    <div id="onboarding-trial-date" class="mt-2 text-[10px] text-yellow-500 font-bold uppercase tracking-widest"></div>
                </div>

                <div class="space-y-2 text-left mb-5">
                    <div class="bg-zinc-950/80 p-3 rounded-xl border border-zinc-800 flex items-start gap-3">
                        <span class="text-xl mt-0.5 shrink-0">🗺️</span>
                        <div><div class="text-white font-bold text-xs teko-font tracking-widest mb-0.5">HARİTA & RADAR</div><p class="text-[10px] text-zinc-400 leading-relaxed">Çevrendeki rampaları keşfet! Radar modunu açarsan seni canlı haritada görürler.</p></div>
                    </div>
                    <div class="bg-zinc-950/80 p-3 rounded-xl border border-zinc-800 flex items-start gap-3">
                        <span class="text-xl mt-0.5 shrink-0">💬</span>
                        <div><div class="text-white font-bold text-xs teko-font tracking-widest mb-0.5">SOHBET & AI</div><p class="text-[10px] text-zinc-400 leading-relaxed">Toplulukla kaynaş, DM at, Freerider AI'a bisiklet soruları sor.</p></div>
                    </div>
                    <div class="bg-zinc-950/80 p-3 rounded-xl border border-zinc-800 flex items-start gap-3">
                        <span class="text-xl mt-0.5 shrink-0">🎯</span>
                        <div><div class="text-white font-bold text-xs teko-font tracking-widest mb-0.5">GÖREVLER & ŞANS ÇARKI</div><p class="text-[10px] text-zinc-400 leading-relaxed">Her gün görev tamamla, çarkı çevir ve XP ile ödüller kazan!</p></div>
                    </div>
                </div>

                <button onclick="completeOnboarding()" class="w-full bg-gradient-to-r from-yellow-600 to-sky-500 btn-premium-hover text-white py-4 rounded-xl font-black  text-lg tracking-widest">🚴 DENEMEYİ BAŞLAT!</button>
                <p class="text-[10px] text-zinc-600 mt-2">Kredi kartı gerekmez · Otomatik ücretlendirme yok</p>
            </div>
        </div>

        <div id="email-verify-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[10000] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  text-center scale-in-anim">
                <h3 class="text-4xl text-white mb-2 teko-font tracking-wide ">📧 E-POSTA DOĞRULAMA</h3>
                <p class="text-xs text-zinc-300 mb-6 font-medium">E-posta adresinize 6 haneli bir doğrulama kodu gönderdik. Lütfen kodu aşağıya girin.</p>
                <input id="verify-code-input" type="text" placeholder="6 Haneli Kod" class="w-full bg-black/60 border border-zinc-600 rounded-xl px-5 py-4 mb-6 text-white text-center text-2xl tracking-widest outline-none focus:border-white transition  font-bold" maxlength="6">
                <div class="grid grid-cols-2 gap-3">
                    <button onclick="skipVerification()" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">SONRA YAP</button>
                    <button onclick="submitVerificationCode()" class="py-4 bg-sky-700 hover:bg-sky-600 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">DOĞRULA</button>
                </div>
            </div>
        </div>

        <div id="forgot-password-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[10000] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  scale-in-anim">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-4xl text-white teko-font tracking-wide ">🔐 ŞİFREMİ UNUTTUM</h3>
                    <button onclick="closeForgotPasswordModal()" class="text-zinc-400 hover:text-white w-8 h-8 flex items-center justify-center bg-zinc-800 rounded-full transition hover:scale-110">✕</button>
                </div>
                
                <div id="fp-step-1" class="slide-up-anim">
                    <p class="text-xs text-zinc-300 mb-5 leading-relaxed font-medium">Sisteme kayıtlı ve doğrulanmış e-posta adresinizi girin. Size bir sıfırlama kodu göndereceğiz.</p>
                    <input id="fp-email" type="email" placeholder="E-posta Adresiniz" class="w-full bg-black/60 border border-zinc-600 rounded-xl px-5 py-4 mb-5 text-white text-sm outline-none focus:border-white transition  font-bold">
                    <button onclick="requestPasswordReset()" class="w-full bg-white hover:bg-gray-200 transition text-black py-4 rounded-xl font-bold  text-sm tracking-wide btn-premium-hover">KOD GÖNDER</button>
                </div>
                
                <div id="fp-step-2" class="hidden slide-up-anim">
                    <p class="text-xs text-zinc-300 mb-4 font-medium">E-postanıza gelen 6 haneli kodu ve yeni şifrenizi girin.</p>
                    <input id="fp-code" type="text" placeholder="6 Haneli Kod" class="w-full bg-black/60 border border-zinc-600 rounded-xl px-5 py-4 mb-3 text-white text-center tracking-widest text-lg outline-none focus:border-white transition font-bold " maxlength="6">
                    <input id="fp-new-password" type="password" placeholder="Yeni Şifreniz" class="w-full bg-black/60 border border-zinc-600 rounded-xl px-5 py-4 mb-6 text-white text-sm outline-none focus:border-white transition font-bold " autocapitalize="none" autocorrect="off">
                    <button onclick="submitNewPassword()" class="w-full bg-sky-700 hover:bg-sky-600 transition text-white py-4 rounded-xl font-bold  text-sm tracking-wide btn-premium-hover">ŞİFREYİ GÜNCELLE</button>
                </div>
            </div>
        </div>

        <div id="add-bike-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl border border-zinc-700  scale-in-anim max-h-[92vh] flex flex-col">
                <div class="p-5 border-b border-zinc-800 shrink-0 flex items-center justify-between">
                    <h3 class="text-3xl text-white teko-font tracking-wide">🚲 BİSİKLET EKLE</h3>
                    <button onclick="document.getElementById('add-bike-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
                </div>
                <div class="overflow-y-auto p-5 flex-1 custom-scrollbar space-y-3">
                    <!-- Temel bilgiler -->
                    <div class="text-[10px] text-sky-300 font-bold uppercase tracking-widest mb-1">Temel Bilgiler *</div>
                    <input id="bike-model" type="text" placeholder="Marka ve Model (Örn: Trek Session 8)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-sky-400 transition font-bold">
                    <select id="bike-type" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition font-bold cursor-pointer">
                        <option value="Downhill">Downhill</option>
                        <option value="Freeride">Freeride</option>
                        <option value="Enduro">Enduro</option>
                        <option value="Dirt Jump">Dirt Jump</option>
                        <option value="Trail">Trail / XC</option>
                        <option value="Diger">Diğer</option>
                    </select>

                    <!-- Süspansiyon -->
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pt-2 border-t border-zinc-800">Süspansiyon</div>
                    <input id="bike-fork" type="text" placeholder="Maşa (Örn: Fox 40 Performance)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-shock" type="text" placeholder="Arka Şok (Örn: Fox Float X2)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">

                    <!-- Fren sistemi -->
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pt-2 border-t border-zinc-800">Fren Sistemi</div>
                    <input id="bike-brakes" type="text" placeholder="Frenler (Örn: Shimano Saint 4-Piston)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-rotor" type="text" placeholder="Disk Çapı (Örn: 200mm/200mm)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">

                    <!-- Aktarma -->
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pt-2 border-t border-zinc-800">Aktarma Sistemi</div>
                    <input id="bike-drivetrain" type="text" placeholder="Vites Sistemi (Örn: Shimano Deore 12V)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-chain" type="text" placeholder="Zincir (Örn: KMC e12 Turbo)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-crankset" type="text" placeholder="Krank / BB (Örn: Race Face Next R 170mm)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-cassette" type="text" placeholder="Kasnak (Örn: Shimano CS-M7100 10-51T)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">

                    <!-- Tekerlek -->
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pt-2 border-t border-zinc-800">Tekerlek</div>
                    <input id="bike-wheelset" type="text" placeholder="Jantlar (Örn: Stan's Flow MK4 27.5)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-tires" type="text" placeholder="Lastikler (Örn: Maxxis Assegai 27.5x2.5 WT)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-tire-size" type="text" placeholder="Lastik Boyutu / Hava Basıncı" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">

                    <!-- Cockpit -->
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pt-2 border-t border-zinc-800">Kokpit</div>
                    <input id="bike-handlebar" type="text" placeholder="Gidon (Örn: Race Face Atlas 800mm 20mm rise)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-stem" type="text" placeholder="Stem (Örn: Race Face Ride 50mm)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-grips" type="text" placeholder="Gidon Tutuş (Örn: ODI Ruffian Slim)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-seatpost" type="text" placeholder="Seatpost / Tele (Örn: BikeYoke Revive 160mm)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-saddle" type="text" placeholder="Sele (Örn: SDG Bel-Air 3.0)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <input id="bike-pedals" type="text" placeholder="Pedallar (Örn: Crankbrothers Stamp 7)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">

                    <!-- Ekstra -->
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pt-2 border-t border-zinc-800">Ağırlık & Notlar</div>
                    <input id="bike-weight" type="text" placeholder="Bisiklet Ağırlığı (Örn: 15.2 kg)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-zinc-400 transition">
                    <textarea id="bike-desc" placeholder="Özel notlar, modifikasyonlar..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 h-20 text-white text-sm outline-none focus:border-zinc-400 transition custom-scrollbar"></textarea>

                    <!-- Gizli premium icon -->
                    <select id="new-marker-icon" class="hidden w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none font-bold"></select>

                    <!-- Fotoğraf -->
                    <div id="bike-photo-label" class="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mt-2">Bisiklet Fotoğrafları</div>
                    <input id="bike-photo" type="file" accept="image/*" multiple class="w-full bg-black/60 border border-zinc-700 rounded-xl px-3 py-3 text-xs text-zinc-300 cursor-pointer">
                    <div class="grid grid-cols-2 gap-3 pb-4">
                        <button onclick="document.getElementById('add-bike-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-300 py-3 rounded-xl font-bold text-sm btn-premium-hover">İptal</button>
                        <button onclick="saveBike()" class="bg-gradient-to-r from-sky-700 to-sky-500 hover:opacity-90 transition text-white py-3 rounded-xl font-bold text-sm  btn-premium-hover">KAYDET</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="bike-detail-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[10000] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  relative max-h-[90dvh] overflow-y-auto custom-scrollbar scale-in-anim">
                <button onclick="document.getElementById('bike-detail-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50  border border-zinc-700 hover:bg-zinc-700 transition w-8 h-8 rounded-full flex items-center justify-center text-zinc-300 hover:text-white z-10 hover:scale-110">✕</button>
                
                <div id="bd-image-container" class="market-img-scroll mb-4 shrink-0 h-48 bg-black/80 rounded-xl items-center custom-scrollbar border border-zinc-700 "></div>
                
                <h3 id="bd-model" class="text-4xl text-white mb-1 teko-font tracking-wide "></h3>
                <div id="bd-type" class="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-6 bg-zinc-800/50 inline-block px-3 py-1 rounded-lg border border-zinc-700"></div>
                
                <div class="space-y-3 bg-black/50 p-5 rounded-2xl border border-zinc-700 ">
                    <div>
                        <div class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest mb-1">Maşa / Süspansiyon</div>
                        <div id="bd-fork" class="text-sm text-white font-medium ">Belirtilmemiş</div>
                    </div>
                    <div class="border-t border-zinc-800 pt-3 mt-1">
                        <div class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest mb-1">Arka Şok</div>
                        <div id="bd-shock" class="text-sm text-white font-medium ">Belirtilmemiş</div>
                    </div>
                    <div class="border-t border-zinc-800 pt-3 mt-1">
                        <div class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest mb-1">Fren Sistemi</div>
                        <div id="bd-brakes" class="text-sm text-white font-medium ">Belirtilmemiş</div>
                    </div>
                    <div class="border-t border-zinc-800 pt-3 mt-1">
                        <div class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest mb-1">Açıklama / Notlar</div>
                        <div id="bd-desc" class="text-sm text-zinc-300 italic leading-relaxed">Belirtilmemiş</div>
                    </div>
                    <div class="border-t border-zinc-800 pt-3 mt-1">
                        <div class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest mb-2">Tum Parcalar</div>
                        <div id="bd-extra-specs" class="space-y-0"></div>
                    </div>
                </div>
                
                <div id="bd-actions-area" class="mt-5 flex gap-3"></div>
                
            </div>
        </div>

            <!-- Yönetici Paneli Çekiliş Ekleme Modalı -->
            <div id="gw-create-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 overflow-y-auto py-10">
                <div class="glass-panel w-full max-w-md rounded-2xl p-5 border border-emerald-900/50 scale-in-anim relative bg-zinc-900 mt-auto mb-auto">
                    <button onclick="document.getElementById('gw-create-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50 border border-zinc-700 hover:bg-zinc-700 transition w-8 h-8 rounded-full flex items-center justify-center text-zinc-300 hover:text-white z-10">✕</button>
                    <h2 class="text-2xl text-white font-black mb-4">🎁 Yeni Çekiliş</h2>
                    
                    <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Başlık</label>
                    <input type="text" id="gw-title" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm mb-3 outline-none focus:border-emerald-500" placeholder="Örn: 1 Aylık Premium Çekilişi">

                    <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Ödül</label>
                    <input type="text" id="gw-prize" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm mb-3 outline-none focus:border-emerald-500" placeholder="Örn: 1 Aylık Standart">

                    <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Açıklama</label>
                    <textarea id="gw-desc" rows="3" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm mb-3 outline-none focus:border-emerald-500 custom-scrollbar" placeholder="Şartlar ve detaylar..."></textarea>
                    
                    <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Bitiş Tarihi</label>
                    <input type="date" id="gw-date" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm mb-3 outline-none focus:border-emerald-500">

                    <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Kazanan Sayısı</label>
                    <input type="number" id="gw-winner-count" min="1" value="1" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm mb-3 outline-none focus:border-emerald-500">

                    <div class="flex items-center justify-between mb-2 p-3 bg-zinc-800/60 rounded-xl border border-zinc-700">
                      <span class="text-xs text-zinc-300 font-bold">📁 Admin Kazanıları Önceden Seçsin</span>
                      <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="gw-admin-pick" class="sr-only peer" onchange="document.getElementById('gw-picked-users-row').classList.toggle('hidden', !this.checked)">
                        <div class="w-10 h-5 bg-zinc-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                      </label>
                    </div>
                    <div id="gw-picked-users-row" class="hidden mb-3">
                      <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Kazanıcı Kullanıcı Adları (virgülle ayır)</label>
                      <input type="text" id="gw-picked-usernames" placeholder="ali,veli,ayse" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-amber-500">
                      <p class="text-[10px] text-zinc-500 mt-1">Çekiliş bitince bu kişiler otomatik kazanıcı olur.</p>
                    </div>

                    <label class="block text-[10px] text-zinc-400 font-bold uppercase mb-1">Resim (Opsiyonel)</label>
                    <label for="gw-img-input" class="w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl border border-dashed border-zinc-600 mb-2 transition block text-center cursor-pointer">📸 Resim Seç</label>
                    <input type="file" id="gw-img-input" accept="image/*" class="opacity-0 absolute w-0 h-0" onchange="window.handleGwImage(event)">
                    <img id="gw-img-preview" src="" class="hidden w-full h-32 object-cover rounded-xl mb-4 border border-zinc-700">

                    <button id="gw-save-btn" onclick="submitCreateGiveaway()" class="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition shadow-lg shadow-emerald-900/30">KAYDET</button>
                </div>
            </div>

            <!-- Çekilişe Katıl Modalı -->
            <!-- Çekiliş Detay Modalı -->
            <div id="gw-detail-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9990] px-4" onclick="if(event.target===this) closeGiveawayDetail()">
                <div class="gw-detail-panel glass-panel w-full max-w-lg rounded-3xl border border-zinc-700 bg-zinc-900 overflow-y-auto custom-scrollbar" style="max-height:88vh;will-change:transform,opacity;">
                    <div class="flex justify-between items-center px-5 pt-4 pb-3 sticky top-0 bg-zinc-900/95 backdrop-blur-md z-10 border-b border-zinc-800">
                        <div class="text-xs text-zinc-500 font-bold uppercase tracking-widest">🎁 Çekiliş Detayı</div>
                        <button onclick="closeGiveawayDetail()" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-red-900/60 text-zinc-400 hover:text-red-400 font-bold text-sm transition-all border border-zinc-700 hover:border-red-700/50">
                            <span class="text-base leading-none">✕</span>
                            <span>Çık</span>
                        </button>
                    </div>
                    <div id="gw-detail-body" class="p-5"></div>
                </div>
            </div>

            <div id="gw-join-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4">
                <div class="glass-panel w-full max-w-sm rounded-2xl p-6 border border-zinc-700 scale-in-anim text-center bg-zinc-900">
                    <div class="text-4xl mb-3">📸</div>
                    <h2 class="text-xl text-white font-black mb-2">Çekilişe Katıl</h2>
                    <p class="text-xs text-zinc-400 mb-4">Sana ulaşabilmemiz için Instagram kullanıcı adını girmelisin.</p>
                    <div class="relative mb-5">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-bold">@</span>
                        <input type="text" id="gw-ig-input" placeholder="kullanici_adi" class="w-full bg-black/50 border border-zinc-700 focus:border-emerald-500 text-white pl-8 pr-4 py-3 rounded-xl outline-none transition">
                    </div>
                    <div class="flex gap-2">
                        <button onclick="document.getElementById('gw-join-modal').classList.add('hidden')" class="flex-1 py-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl transition">İPTAL</button>
                        <button id="gw-confirm-btn" onclick="submitJoinGiveaway()" class="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition shadow-lg">KATIL</button>
                    </div>
                </div>
            </div>

            <!-- Kazanan Seç Modalı (Sadece Admin - Gizli) -->
            <div id="gw-winner-picker-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4">
                <div class="glass-panel w-full max-w-md rounded-2xl border border-zinc-700 bg-zinc-900 overflow-hidden" style="max-height:85vh;display:flex;flex-direction:column;">
                    <div class="flex justify-between items-center px-5 py-4 border-b border-zinc-800 shrink-0">
                        <div class="text-sm text-white font-black">👑 Kazanan Seç</div>
                        <button onclick="document.getElementById('gw-winner-picker-modal').classList.add('hidden')" class="w-7 h-7 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center text-sm transition">✕</button>
                    </div>
                    <div class="px-5 py-3 bg-zinc-800/40 shrink-0">
                        <p class="text-[11px] text-zinc-500">Seçtiğin kişiler kazanan olarak kaydedilir. Kullanıcılara rastgele seçilmiş gibi gösterilir.</p>
                    </div>
                    <div id="gw-winner-picker-list" class="overflow-y-auto custom-scrollbar flex-1 px-4 py-3 flex flex-col gap-2"></div>
                    <div class="px-5 py-4 border-t border-zinc-800 shrink-0 flex gap-2">
                        <button onclick="document.getElementById('gw-winner-picker-modal').classList.add('hidden')" class="flex-1 py-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl transition text-sm">İPTAL</button>
                        <button id="gw-winner-picker-confirm" onclick="submitWinnerPicker()" class="flex-1 py-3 bg-amber-600 hover:bg-amber-500 text-white font-black rounded-xl transition text-sm shadow-lg">✅ ONAYLA</button>
                    </div>
                </div>
            </div>

        <!-- Premium Alt Navigasyon Çubuğu -->
        <!-- ── PREMIUM FLOATING BOTTOM NAV ── -->
        <div id="bottom-nav" class="relative shrink-0 z-[200]" style="display:none;background:linear-gradient(180deg,rgba(0,0,0,0) 0%,rgba(0,0,0,0.98) 100%);padding:6px 8px max(14px,env(safe-area-inset-bottom)) 8px;">
            <!-- Gradient separator line -->
            <div style="position:absolute;top:0;left:16px;right:16px;height:1px;background:linear-gradient(90deg,transparent,rgba(14,165,233,0.4),rgba(251,191,36,0.2),rgba(14,165,233,0.4),transparent);"></div>
            <div class="flex justify-around items-center">
                <button onclick="switchTab(0)" id="bnav-0" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-zinc-500" style="min-width:48px">
                    <span class="text-[22px] leading-none" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">🗺️</span>
                    <span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">Harita</span>
                </button>
                <button onclick="switchTab(1)" id="bnav-1" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-zinc-500 relative" style="min-width:48px">
                    <span class="text-[22px] leading-none" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">💬</span>
                    <span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">Chat</span>
                </button>
                <!-- Reels - Merkez Özel Buton -->
                <button onclick="switchTab(9)" id="bnav-9" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-zinc-500 relative" style="min-width:52px">
                    <div class="relative">
                        <span class="text-[24px] leading-none block" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">🎬</span>
                    </div>
                    <span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">Reels</span>
                </button>
                <button onclick="if(window.openAIHub) { window.openAIHub(); } else { window.location.reload(); }" id="bnav-ai" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-purple-400" style="min-width:48px; pointer-events: auto !important; position: relative; z-index: 9999999 !important;">
<span class="text-[22px] leading-none" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">🤖</span>
<span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">AI Hub</span>
</button>
<button onclick="switchTab(3)" id="bnav-3" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-zinc-500" style="min-width:48px">
                    <span class="text-[22px] leading-none" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">🏆</span>
                    <span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">Sıra</span>
                </button>
                <button onclick="switchTab(7)" id="bnav-7" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-zinc-500" style="min-width:48px">
                    <span class="text-[22px] leading-none" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">👤</span>
                    <span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">Profil</span>
                </button>
                <button onclick="toggleSidebar()" id="bnav-menu" class="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all duration-300 text-zinc-500" style="min-width:48px">
                    <span class="text-[22px] leading-none" style="transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s ease">☰</span>
                    <span class="text-[9px] font-black uppercase tracking-widest mt-0.5" style="transition:all 0.2s">Menü</span>
                </button>
            </div>
        </div>

        <div id="settings-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  max-h-[90vh] overflow-y-auto custom-scrollbar relative scale-in-anim">
                <h3 class="text-4xl text-white mb-5 teko-font tracking-wide ">⚙️ PROFİLİ DÜZENLE</h3>
                <input id="edit-name" type="text" placeholder="İsim" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                <input id="edit-bio" type="text" placeholder="Kısa Bio..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                <input id="edit-password" type="password" autocomplete="new-password" placeholder="Yeni şifre (Değişmeyecekse boş bırak)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 text-white text-sm outline-none focus:border-white transition font-bold " autocapitalize="none" autocorrect="off">
                
                <div class="mt-5 border-t border-zinc-700 pt-5 mb-5">
                    <h4 class="text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-3">E-Posta & Güvenlik</h4>
                    <div id="profile-email-status" class="mb-3"></div>
                   <input id="edit-email" type="email" placeholder="E-posta Adresi" oninput="checkEmailChange()" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                    <div class="flex items-start gap-2 mb-4 px-1">
                        <input type="checkbox" id="edit-marketing" class="w-4 h-4 mt-0.5 accent-sky-500 rounded cursor-pointer">
                        <label for="edit-marketing" class="text-[10px] text-zinc-400 font-medium cursor-pointer hover:text-white transition">Haberlerden ve güncellemelerden haberdar olmak istiyorum.</label>
                    </div>
                    <button onclick="requestProfileEmailVerify()" id="btn-verify-email" class="w-full bg-zinc-800 hover:bg-zinc-700 transition py-4 rounded-xl font-bold text-white text-xs border border-zinc-600 hidden uppercase tracking-widest  btn-premium-hover">DOĞRULAMA KODU GÖNDER</button>
                </div>

                <div class="grid grid-cols-2 gap-3 mt-2">
                    <button onclick="closeSettingsModal()" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">İPTAL</button>
                    <button onclick="saveSettings()" class="py-4 bg-white hover:bg-gray-200 transition rounded-xl font-bold text-black text-sm  btn-premium-hover">KAYDET</button>
                </div>

                <div class="mt-6 pt-5 border-t border-zinc-800">
                    <p class="text-[10px] text-zinc-500 mb-3 uppercase tracking-widest font-bold">Uygulama Turu</p>
                    <button onclick="startAppTourFromSettings()" class="w-full bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-300 py-3 rounded-xl font-bold text-xs uppercase tracking-widest ">🚀 Uygulama Turunu Yeniden Başlat</button>
                </div>

                <div class="mt-6 pt-5 border-t border-zinc-800">
                    <p class="text-[10px] text-zinc-500 mb-3 uppercase tracking-widest font-bold">Tehlikeli Bölge</p>
                    <button onclick="openDeleteAccountModal()" class="w-full bg-black border border-sky-900/60 hover:bg-red-950/40 transition text-sky-400 py-3 rounded-xl font-bold text-xs uppercase tracking-widest btn-premium-hover">🗑️ Hesabımı Kalıcı Olarak Sil</button>
                </div>
            </div>
        </div>

        <!-- HESAP SİLME ONAY MODALI -->
        <div id="delete-account-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[99999] px-4 ">
            <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-sky-900/50  scale-in-anim">
                <div class="text-center mb-5">
                    <div class="text-5xl mb-3">⚠️</div>
                    <h3 class="text-2xl text-sky-300 teko-font tracking-wide">HESABI SİL</h3>
                    <p class="text-xs text-zinc-400 mt-2 leading-relaxed">Bu işlem <b class="text-sky-300">geri alınamaz.</b> Profilin, gönderilerin, ilanların ve tüm verilen kalıcı olarak silinir.</p>
                </div>
                <input id="delete-account-password" type="password" placeholder="Onaylamak için şifreni gir" class="w-full bg-black/60 border border-sky-800/60 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-sky-400 transition font-bold mb-4" autocapitalize="none" autocorrect="off">
                <div class="grid grid-cols-2 gap-3">
                    <button onclick="document.getElementById('delete-account-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm">Vazgeç</button>
                    <button onclick="confirmDeleteAccount()" class="bg-sky-800 hover:bg-sky-700 text-white py-3 rounded-xl font-bold text-sm btn-premium-hover uppercase tracking-widest">HESABI SİL</button>
                </div>
            </div>
        </div>

        <div id="other-profile-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-zinc-700 relative text-center overflow-y-auto max-h-[90dvh] custom-scrollbar  scale-in-anim">
                <button onclick="document.getElementById('other-profile-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50  border border-zinc-700 hover:bg-zinc-700 transition text-zinc-300 hover:text-white w-8 h-8 rounded-full flex items-center justify-center hover:scale-110 z-10">✕</button>
                
                <img id="op-avatar" src="" class="w-28 h-28 mx-auto rounded-full object-cover mt-6 bg-zinc-950  border-4 transition-all duration-300">
                <div id="op-premium-badge" class="hidden mt-3 text-xs font-bold uppercase tracking-widest"></div>
                            <div id="op-online-status" class="hidden flex items-center gap-2 justify-center mt-2"></div>
                
                <div id="op-username-container" class="flex justify-center items-center gap-1 mt-3">
                    <div id="op-username" class="text-4xl font-bold text-white break-all teko-font tracking-wide  transition-all"></div>
                    <div id="op-verified-badge" class="hidden"></div>
                </div>
                
                <div id="op-bio" class="text-zinc-300 mt-2 text-sm font-medium px-2 leading-relaxed"></div>
                
                <div class="flex justify-center gap-4 mt-8">
                    <div class="bg-black/50 p-4 rounded-2xl w-28 border border-zinc-700 ">
                        <div id="op-xp" class="text-3xl text-white teko-font tracking-wide "></div>
                        <div class="text-[9px] text-zinc-500 mt-1 font-bold uppercase tracking-widest">XP</div>
                    </div>
                    <div class="bg-black/50 p-4 rounded-2xl w-28 border border-zinc-700 ">
                        <div id="op-title" class="text-sm font-bold text-zinc-300 truncate uppercase mt-1 "></div>
                        <div class="text-[9px] text-zinc-500 mt-2 font-bold uppercase tracking-widest">ÜNVAN</div>
                    </div>
                </div>
                                
                <div class="mt-8 text-left pb-4 bg-black/40 p-5 rounded-2xl border border-zinc-700/50 ">
                    <h3 class="text-[10px] font-bold text-zinc-400 mb-4 uppercase tracking-widest flex items-center gap-2"><span>🚲</span> Garajı</h3>
                    <div id="op-garage" class="grid grid-cols-2 gap-3"></div>
                </div>
                
                <div class="mt-6 text-left pb-4 bg-black/40 p-5 rounded-2xl border border-zinc-700/50 ">
                    <h3 class="text-[10px] font-bold text-zinc-400 mb-4 uppercase tracking-widest flex items-center gap-2"><span>🏅</span> Kazanılan Rozetler</h3>
                    <div id="op-badges" class="flex flex-wrap gap-2"></div>
                </div>
                
                <div id="op-actions" class="border-t border-zinc-700/50 pt-6 mt-6 space-y-3"></div>
            </div>
        </div>

        <div id="google-onboarding-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 py-10 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  scale-in-anim">
                <h2 class="text-4xl text-white mb-2 teko-font tracking-wide ">KAYDI TAMAMLA</h2>
                <p class="text-sm text-zinc-400 mb-6 font-medium">Google hesabınla giriş yaptın, şimdi profilini tamamla.</p>
                
                <input type="hidden" id="go-email">
                <input type="hidden" id="go-avatar">
                
                <input id="go-username" type="text" placeholder="Kullanıcı Adı (Benzersiz)" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold">
                <input id="go-name" type="text" placeholder="Ad Soyad" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold">
                <input id="go-password" type="password" placeholder="Şifre Belirle (En az 4 karakter)" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold" autocapitalize="none" autocorrect="off">
                <input id="go-city" type="text" placeholder="Şehir" class="w-full bg-black/50 border border-zinc-700 rounded-xl px-5 py-4 mb-3 outline-none text-white focus:border-sky-500 transition-all font-bold">
                <input id="go-ref-code" type="text" placeholder="Referans Kodu (İsteğe Bağlı)" class="w-full bg-black/50 border border-purple-500/50 rounded-xl px-5 py-4 mb-6 outline-none text-purple-100 focus:border-purple-400 transition-all font-bold">
                
                <div class="flex flex-col gap-3">
                    <button onclick="submitGoogleOnboarding(event)" class="w-full bg-gradient-to-r from-sky-700 to-sky-500 hover:from-sky-600 hover:to-sky-400 text-white py-4 rounded-xl font-bold text-sm  tracking-widest uppercase btn-premium-hover">KAYDINI TAMAMLA</button>
                    <button onclick="document.getElementById('google-onboarding-modal').classList.add('hidden')" class="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-4 rounded-xl font-bold text-sm  btn-premium-hover">İPTAL</button>
                </div>
            </div>
        </div>

        <div id="chat-rules-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 py-10 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700 flex flex-col  scale-in-anim">
                <h2 class="text-4xl text-white mb-4 teko-font tracking-wide ">📜 TOPLULUK KURALLARI</h2>
                <div class="overflow-y-auto flex-1 text-sm text-zinc-300 space-y-4 mb-5 custom-scrollbar pr-2 bg-black/50 p-5 rounded-2xl border border-zinc-700  leading-relaxed font-medium">
                    <ul class="list-disc pl-5 space-y-3">
                        <li><b>+18 ve Cinsel İçerik Kesinlikle Yasaktır:</b> Gruba gönderilen her türlü cinsel içerik kalıcı olarak engellenir.</li>
                        <li><b>Taciz ve Zorbalık Yasaktır:</b> Diğer üyeleri özelden veya gruptan rahatsız etmek affedilmez.</li>
                        <li><b>Ayrımcılık ve Nefret Söylemi:</b> Din, dil, ırk, mezhep ayrımcılığı yapmak yasaktır. Bizi birleştiren şey bisiklet tutkusudur.</li>
                        <li><b>Spam ve Reklam Yasaktır:</b> İzin alınmadan yapılan ticari reklamlar yasaktır. Pazar sekmesini kullanın.</li>
                    </ul>
                    <p class="text-xs text-sky-300 font-bold mt-5 border-t border-zinc-800 pt-4">ÖNEMLİ: Kuralları ihlal eden üyeler uyarısız olarak sistemden KALICI olarak uzaklaştırılır.</p>
                </div>
                <div class="flex flex-col gap-3 shrink-0">
                    <button onclick="acceptChatRules()" class="w-full bg-white hover:bg-gray-200 transition text-black py-4 rounded-xl font-bold text-sm  btn-premium-hover">OKUDUM, KABUL EDİYORUM</button>
                    <button onclick="switchTab(0)" class="w-full bg-zinc-800 hover:bg-zinc-700 transition py-4 rounded-xl font-bold text-zinc-300 text-sm  btn-premium-hover">Vazgeç ve Geri Dön</button>
                </div>
            </div>
        </div>

        <div id="market-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 overflow-y-auto py-10 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700 my-auto  scale-in-anim">
                <h2 class="text-4xl text-white mb-6 teko-font tracking-wide ">🛒 YENİ İLAN</h2>
                <input id="mk-title" type="text" placeholder="Ürün Adı" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                <input id="mk-price" type="number" placeholder="Fiyat (TL)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                <input id="mk-contact" type="text" placeholder="İletişim Bilgisi (Tel/Insta)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                <textarea id="mk-desc" placeholder="Açıklama..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 h-24 mb-5 text-white text-sm outline-none focus:border-white transition custom-scrollbar font-bold "></textarea>
                
                <label id="mk-photo-label" class="block text-[10px] text-zinc-400 mb-2 uppercase font-bold tracking-widest">Fotoğraf Ekle</label>
                <input id="mk-photos" type="file" accept="image/*" multiple class="w-full bg-black/60 border border-zinc-700 rounded-xl px-3 py-3 mb-5 text-xs text-zinc-300 focus:border-white transition cursor-pointer">
                
                <div class="grid grid-cols-2 gap-3 mt-2">
                    <button onclick="document.getElementById('market-modal').classList.add('hidden')" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">İPTAL</button>
                    <button onclick="saveMarketItem()" class="py-4 bg-white hover:bg-gray-200 transition rounded-xl font-bold text-black text-sm  btn-premium-hover">İLANI YAYINLA</button>
                </div>
            </div>
        </div>
        
        <div id="market-detail-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700 relative flex flex-col max-h-[90dvh]  scale-in-anim">
                <button onclick="document.getElementById('market-detail-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50  border border-zinc-700 hover:bg-zinc-700 transition w-8 h-8 rounded-full flex items-center justify-center text-zinc-300 hover:text-white z-10 hover:scale-110">✕</button>
                
                <div id="md-photos" class="market-img-scroll mb-5 shrink-0 h-48 bg-black/80 rounded-xl items-center custom-scrollbar border border-zinc-700 "></div>
                
                <div class="overflow-y-auto flex-1 pr-2 custom-scrollbar">
                    <h3 id="md-title" class="text-4xl text-white mb-2 teko-font tracking-wide "></h3>
                    <div id="md-price" class="text-2xl font-black text-green-400 mb-3 bg-green-950/40 inline-block px-4 py-1.5 rounded-xl border border-green-800/50 "></div>
                    <div id="md-views-badge" class="hidden text-xs font-bold text-yellow-400 mb-6 bg-yellow-900/30 inline-block px-3 py-1.5 rounded-xl border border-yellow-700/50 ml-2 "></div>
                    
                    <div class="flex items-center gap-4 mb-6 bg-black/50 p-4 rounded-2xl cursor-pointer hover:bg-zinc-800 transition-colors border border-zinc-700  group" onclick="if(window.currentOwner) showOtherProfile(window.currentOwner)">
                        <img id="md-owner-avatar" class="w-14 h-14 rounded-full object-cover border-2 border-zinc-600 group-hover:border-zinc-400 transition-colors ">
                        <div>
                            <div class="text-[10px] text-zinc-400 uppercase font-bold tracking-widest mb-1">Satıcı</div>
                            <div id="md-owner" class="text-base font-bold text-white tracking-wide group-hover:text-blue-300 transition-colors"></div>
                        </div>
                    </div>
                    
                    <p id="md-desc" class="text-sm text-zinc-300 mb-6 whitespace-pre-wrap break-all leading-relaxed font-medium bg-black/30 p-4 rounded-xl border border-zinc-800/50"></p>
                    
                    <div class="bg-blue-950/30 border border-blue-800/50 p-5 rounded-2xl mb-4 text-center ">
                        <div class="text-[10px] text-blue-300 mb-2 uppercase font-bold tracking-widest flex justify-center items-center gap-2"><span class="animate-pulse">📞</span> İletişim Bilgisi</div>
                        <div id="md-contact" class="font-black text-white text-xl break-all "></div>
                    </div>
                </div>
                
                <div id="md-actions-area" class="mt-5 shrink-0 space-y-3"></div>
            </div>
        </div>

        <!-- CATEGORY SELECT MODAL -->
        <div id="category-select-modal" class="hidden fixed inset-0 modal-backdrop flex items-end justify-center z-[9999] px-0">
            <div class="glass-panel w-full max-w-lg rounded-t-3xl p-5 border border-zinc-700 scale-in-anim" style="max-height:85vh;overflow-y:auto">
                <div class="w-12 h-1 bg-zinc-600 rounded-full mx-auto mb-4"></div>
                <h2 class="text-2xl text-white mb-1 teko-font tracking-wide text-center">📍 TÜR SEÇ</h2>
                <p class="text-zinc-500 text-[10px] text-center mb-4 font-bold uppercase tracking-widest">Haritaya eklmek istediğin noktanın türünü seç</p>
                <!-- Temel Lokasyonlar -->
                <div class="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-2 px-1">📌 Temel Noktalar</div>
                <div class="grid grid-cols-4 gap-2 mb-4">
                    <button onclick="selectMarkerCategory('Rampa')" class="bg-sky-900/30 border border-sky-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-sky-800/40 active:scale-95 transition">
                        <span class="text-2xl">🏔️</span>
                        <span class="text-white text-[9px] font-black">Rampa</span>
                    </button>
                    <button onclick="selectMarkerCategory('Trail')" class="bg-emerald-900/30 border border-emerald-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-emerald-800/40 active:scale-95 transition">
                        <span class="text-2xl">🗺️</span>
                        <span class="text-white text-[9px] font-black">Trail</span>
                    </button>
                    <button onclick="selectMarkerCategory('Downhill')" class="bg-red-900/30 border border-red-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-red-800/40 active:scale-95 transition">
                        <span class="text-2xl">🚵</span>
                        <span class="text-white text-[9px] font-black">Downhill</span>
                    </button>
                    <button onclick="selectMarkerCategory('Freeride')" class="bg-orange-900/30 border border-orange-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-orange-800/40 active:scale-95 transition">
                        <span class="text-2xl">🤟</span>
                        <span class="text-white text-[9px] font-black">Freeride</span>
                    </button>
                </div>
                <!-- Atlama Türleri -->
                <div class="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-2 px-1">🚀 Atlama Teknikleri</div>
                <div class="grid grid-cols-4 gap-2 mb-4">
                    <button onclick="selectMarkerCategory('Drop')" class="bg-purple-900/30 border border-purple-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-purple-800/40 active:scale-95 transition">
                        <span class="text-2xl">⬇️</span>
                        <span class="text-white text-[9px] font-black">Drop</span>
                    </button>
                    <button onclick="selectMarkerCategory('Transfer')" class="bg-indigo-900/30 border border-indigo-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-indigo-800/40 active:scale-95 transition">
                        <span class="text-2xl">🪜</span>
                        <span class="text-white text-[9px] font-black">Transfer</span>
                    </button>
                    <button onclick="selectMarkerCategory('Step-Up')" class="bg-lime-900/30 border border-lime-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-lime-800/40 active:scale-95 transition">
                        <span class="text-2xl">⬆️</span>
                        <span class="text-white text-[9px] font-black">Step-Up</span>
                    </button>
                    <button onclick="selectMarkerCategory('Step-Down')" class="bg-pink-900/30 border border-pink-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-pink-800/40 active:scale-95 transition">
                        <span class="text-2xl">📉</span>
                        <span class="text-white text-[9px] font-black">Step-Down</span>
                    </button>
                    <button onclick="selectMarkerCategory('Gap')" class="bg-yellow-900/30 border border-yellow-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-yellow-800/40 active:scale-95 transition">
                        <span class="text-2xl">🌉</span>
                        <span class="text-white text-[9px] font-black">Gap</span>
                    </button>
                    <button onclick="selectMarkerCategory('Tabletop')" class="bg-teal-900/30 border border-teal-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-teal-800/40 active:scale-95 transition">
                        <span class="text-2xl">🏗️</span>
                        <span class="text-white text-[9px] font-black">Tabletop</span>
                    </button>
                    <button onclick="selectMarkerCategory('Double')" class="bg-violet-900/30 border border-violet-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-violet-800/40 active:scale-95 transition">
                        <span class="text-2xl">✌️</span>
                        <span class="text-white text-[9px] font-black">Double</span>
                    </button>
                    <button onclick="selectMarkerCategory('Triple')" class="bg-rose-900/30 border border-rose-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-rose-800/40 active:scale-95 transition">
                        <span class="text-2xl">3️⃣</span>
                        <span class="text-white text-[9px] font-black">Triple</span>
                    </button>
                    <button onclick="selectMarkerCategory('Hip Jump')" class="bg-amber-900/30 border border-amber-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-amber-800/40 active:scale-95 transition">
                        <span class="text-2xl">🔀</span>
                        <span class="text-white text-[9px] font-black">Hip Jump</span>
                    </button>
                    <button onclick="selectMarkerCategory('Bunny')" class="bg-green-900/30 border border-green-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-green-800/40 active:scale-95 transition">
                        <span class="text-2xl">🐇</span>
                        <span class="text-white text-[9px] font-black">Bunny Hop</span>
                    </button>
                    <button onclick="selectMarkerCategory('Dirt Jump')" class="bg-yellow-900/30 border border-yellow-600/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-yellow-800/40 active:scale-95 transition">
                        <span class="text-2xl">⚡</span>
                        <span class="text-white text-[9px] font-black">Dirt Jump</span>
                    </button>
                </div>
                <!-- Arazi Özellikleri -->
                <div class="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-2 px-1">🪨 Arazi Özellikleri</div>
                <div class="grid grid-cols-4 gap-2 mb-4">
                    <button onclick="selectMarkerCategory('Rock Garden')" class="bg-stone-900/40 border border-stone-600/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-stone-800/40 active:scale-95 transition">
                        <span class="text-2xl">🪨</span>
                        <span class="text-white text-[9px] font-black">Rock Garden</span>
                    </button>
                    <button onclick="selectMarkerCategory('Root Section')" class="bg-lime-900/30 border border-lime-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-lime-800/40 active:scale-95 transition">
                        <span class="text-2xl">🌿</span>
                        <span class="text-white text-[9px] font-black">Root Section</span>
                    </button>
                    <button onclick="selectMarkerCategory('Chute')" class="bg-cyan-900/30 border border-cyan-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-cyan-800/40 active:scale-95 transition">
                        <span class="text-2xl">🎿</span>
                        <span class="text-white text-[9px] font-black">Chute</span>
                    </button>
                    <button onclick="selectMarkerCategory('Slab')" class="bg-slate-900/40 border border-slate-600/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-slate-800/40 active:scale-95 transition">
                        <span class="text-2xl">🗿</span>
                        <span class="text-white text-[9px] font-black">Slab</span>
                    </button>
                    <button onclick="selectMarkerCategory('Wallride')" class="bg-fuchsia-900/30 border border-fuchsia-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-fuchsia-800/40 active:scale-95 transition">
                        <span class="text-2xl">🧱</span>
                        <span class="text-white text-[9px] font-black">Wallride</span>
                    </button>
                    <button onclick="selectMarkerCategory('Skinny')" class="bg-zinc-800/60 border border-zinc-600/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-zinc-700/40 active:scale-95 transition">
                        <span class="text-2xl">🪵</span>
                        <span class="text-white text-[9px] font-black">Skinny</span>
                    </button>
                    <button onclick="selectMarkerCategory('Shark Fin')" class="bg-blue-900/30 border border-blue-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-blue-800/40 active:scale-95 transition">
                        <span class="text-2xl">🦈</span>
                        <span class="text-white text-[9px] font-black">Shark Fin</span>
                    </button>
                    <button onclick="selectMarkerCategory('Berm')" class="bg-orange-900/30 border border-orange-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-orange-800/40 active:scale-95 transition">
                        <span class="text-2xl">🌀</span>
                        <span class="text-white text-[9px] font-black">Berm</span>
                    </button>
                    <button onclick="selectMarkerCategory('Switchback')" class="bg-teal-900/30 border border-teal-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-teal-800/40 active:scale-95 transition">
                        <span class="text-2xl">🔁</span>
                        <span class="text-white text-[9px] font-black">Switchback</span>
                    </button>
                    <button onclick="selectMarkerCategory('Roller')" class="bg-green-900/30 border border-green-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-green-800/40 active:scale-95 transition">
                        <span class="text-2xl">🎢</span>
                        <span class="text-white text-[9px] font-black">Roller</span>
                    </button>
                </div>
                <!-- Hizmet Noktaları -->
                <div class="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-2 px-1">🔧 Hizmet & Sosyal</div>
                <div class="grid grid-cols-4 gap-2 mb-5">
                    <button onclick="selectMarkerCategory('Bisikletçi')" class="bg-orange-900/30 border border-orange-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-orange-800/40 active:scale-95 transition">
                        <span class="text-2xl">🔧</span>
                        <span class="text-white text-[9px] font-black">Bisikletçi</span>
                    </button>
                    <button onclick="selectMarkerCategory('Tamir Noktası')" class="bg-blue-900/30 border border-blue-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-blue-800/40 active:scale-95 transition">
                        <span class="text-2xl">🔨</span>
                        <span class="text-white text-[9px] font-black">Tamir Noktası</span>
                    </button>
                    <button onclick="selectMarkerCategory('Su Kaynağı')" class="bg-cyan-900/30 border border-cyan-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-cyan-800/40 active:scale-95 transition">
                        <span class="text-2xl">💧</span>
                        <span class="text-white text-[9px] font-black">Su Kaynağı</span>
                    </button>
                    <button onclick="selectMarkerCategory('Toplanma Noktası')" class="bg-pink-900/30 border border-pink-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-pink-800/40 active:scale-95 transition">
                        <span class="text-2xl">🤝</span>
                        <span class="text-white text-[9px] font-black">Toplanma</span>
                    </button>
                    <button onclick="selectMarkerCategory('Market')" class="bg-green-900/30 border border-green-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-green-800/40 active:scale-95 transition">
                        <span class="text-2xl">🛒</span>
                        <span class="text-white text-[9px] font-black">Market</span>
                    </button>
                    <button onclick="selectMarkerCategory('Tehlikeli Bölge')" class="bg-red-900/30 border border-red-700/50 rounded-2xl p-3 flex flex-col items-center gap-1.5 hover:bg-red-800/40 active:scale-95 transition">
                        <span class="text-2xl">⚠️</span>
                        <span class="text-white text-[9px] font-black">Tehlikeli</span>
                    </button>
                </div>
                <button onclick="document.getElementById('category-select-modal').classList.add('hidden'); tempLat = null; tempLng = null;" class="w-full py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-2xl font-bold text-white text-sm btn-premium-hover">İPTAL</button>
            </div>
        </div>

        <div id="add-marker-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  scale-in-anim">
                <h2 id="modal-marker-title" class="text-4xl text-white mb-2 teko-font tracking-wide ">📍 NOKTA EKLE</h2>
                <p id="modal-marker-category-label" class="text-sky-400 text-xs mb-5 font-bold uppercase tracking-wider"></p>
                <input id="new-marker-name" type="text" placeholder="Başlık" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                
                <div class="flex gap-3 mb-3">
                    <select id="new-marker-difficulty" class="flex-1 bg-black/60 border border-zinc-700 rounded-xl px-4 py-4 text-white font-bold text-xs outline-none focus:border-white transition  cursor-pointer">
                        <option value="Kolay">🟢 Kolay Seviye</option>
                        <option value="Orta" selected>🟡 Orta Seviye</option>
                        <option value="Zor">🔴 Zor Seviye</option>
                        <option value="Tehlike">💀 Çok Tehlikeli</option>
                    </select>
                </div>
                
                <textarea id="new-marker-desc" placeholder="Açıklama / Nasıl Gidilir?" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-3 h-20 mb-3 text-white text-sm outline-none focus:border-white transition custom-scrollbar font-bold "></textarea>
                <textarea id="new-marker-extranote" placeholder="Ekstra Not / Uyarılar..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-3 h-16 mb-4 text-white text-sm outline-none focus:border-white transition custom-scrollbar font-bold "></textarea>
                
                <label class="block text-[10px] text-zinc-400 mb-2 uppercase font-bold tracking-widest">Fotoğraf (İsteğe Bağlı)</label>
                <input id="new-marker-photo" type="file" accept="image/*" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-3 py-3 mb-6 text-xs text-zinc-300 focus:border-white transition cursor-pointer">
                
                <div class="grid grid-cols-2 gap-3">
                    <button onclick="closeMarkerModal(); tempLat = null; tempLng = null;" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">İPTAL</button>
                    <button onclick="saveNewMarker()" class="py-4 bg-white hover:bg-gray-200 transition rounded-xl font-bold text-black text-sm  btn-premium-hover">KAYDET</button>
                </div>
            </div>
        </div>

        <div id="add-event-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  scale-in-anim">
                <h2 class="text-4xl text-white mb-5 teko-font tracking-wide ">📅 BULUŞMA EKLE</h2>
                <input id="ev-title" type="text" placeholder="Başlık (Örn: Sabah Antrenmanı)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                
                <div class="flex gap-3 mb-3">
                    <input id="ev-date" type="date" class="flex-1 bg-black/60 border border-zinc-700 rounded-xl px-4 py-4 outline-none text-sm text-white font-bold focus:border-white transition ">
                    <input id="ev-time" type="time" class="w-28 bg-black/60 border border-zinc-700 rounded-xl px-3 py-4 outline-none text-sm text-white font-bold focus:border-white transition ">
                </div>
                
                <input id="ev-max" type="number" placeholder="Kişi Sınırı (Opsiyonel)" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 mb-3 text-white text-sm outline-none focus:border-white transition font-bold ">
                <textarea id="ev-desc" placeholder="Açıklama..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-5 py-4 h-24 mb-6 text-white text-sm outline-none focus:border-white transition custom-scrollbar font-bold "></textarea>
                
                <div class="grid grid-cols-2 gap-3">
                    <button onclick="document.getElementById('add-event-modal').classList.add('hidden')" class="py-4 bg-zinc-800 hover:bg-zinc-700 transition rounded-xl font-bold text-white text-sm  btn-premium-hover">İPTAL</button>
                    <button onclick="saveEvent()" class="py-4 bg-white hover:bg-gray-200 transition rounded-xl font-bold text-black text-sm  btn-premium-hover">OLUŞTUR</button>
                </div>
            </div>
        </div>
        
        <div id="marker-sheet" class="hidden fixed glass-panel border-t border-zinc-700 rounded-t-3xl  p-5 z-[9999] max-h-[88vh] flex flex-col slide-up-anim overflow-hidden" style="bottom:0;left:0;right:0;width:100%;max-width:100%;margin-left:auto;margin-right:auto;box-sizing:border-box;transform:none;">
            <div id="ms-danger-banner" class="hidden bg-red-950/70 border border-sky-700/50 text-red-300 text-xs font-bold px-4 py-2 rounded-xl mb-3 flex items-center gap-2 shrink-0"></div>
            <div class="flex justify-between items-start mb-5 border-b border-zinc-700 pb-4 shrink-0">
                <div class="flex-1 pr-4">
                    <h3 id="ms-title" class="text-4xl text-white teko-font tracking-wide break-words "></h3>
                    <div class="flex gap-2 flex-wrap mt-2">
                        <span id="ms-category" class="text-[10px] bg-sky-600/30 text-sky-300 border border-sky-500/30 px-3 py-1.5 rounded-lg inline-block uppercase tracking-widest font-bold "></span>
                        <span id="ms-difficulty" class="text-[10px] bg-zinc-800 text-zinc-300 border border-zinc-700 px-3 py-1.5 rounded-lg inline-block uppercase tracking-widest font-bold "></span>
                    </div>
                </div>
                <button onclick="closeMarkerSheet()" class="bg-black/50 hover:bg-zinc-700 transition w-10 h-10 rounded-full flex items-center justify-center text-zinc-300 hover:text-white shrink-0 border border-zinc-700 hover:scale-110 ">✕</button>
            </div>
            <!-- Kim ekledi bilgisi -->
            <div id="ms-addedby-container" class="hidden flex items-center gap-2 px-1 mb-3 shrink-0">
                <span class="text-[9px] text-zinc-600 font-bold uppercase tracking-widest">Ekleyen:</span>
                <button id="ms-addedby-btn" onclick="" class="text-[10px] text-sky-400 font-bold hover:text-sky-300 transition"></button>
            </div>
            
            <div class="overflow-y-auto custom-scrollbar flex-1 pb-4">
                <div id="ms-image-container" class="mb-5"></div>
                <p id="ms-desc" class="text-sm text-zinc-300 bg-black/40 p-5 rounded-2xl border border-zinc-700 mb-5 whitespace-pre-wrap break-words font-medium leading-relaxed "></p>
                <div id="ms-extranote-container" class="hidden text-sm text-sky-200 bg-sky-900/20 p-4 rounded-xl border border-sky-800/50 mb-5 whitespace-pre-wrap break-words font-medium leading-relaxed ">
                    <div class="text-[10px] text-sky-400 font-bold uppercase tracking-widest mb-1">Ekstra Not</div>
                    <span id="ms-extranote"></span>
                </div>
                
                <div class="flex justify-between gap-3 mb-5">
                    <button id="ms-btn-like" onclick="toggleMarkerInteraction('like')" class="flex-1 bg-black/50 border border-zinc-700 hover:bg-zinc-800 transition py-4 rounded-xl flex items-center justify-center gap-2 font-bold text-base text-white  btn-premium-hover">
                        <span class="text-xl">👍</span> <span id="ms-likes-count">0</span>
                    </button>
                    <button id="ms-btn-dislike" onclick="toggleMarkerInteraction('dislike')" class="flex-1 bg-black/50 border border-zinc-700 hover:bg-zinc-800 transition py-4 rounded-xl flex items-center justify-center gap-2 font-bold text-base text-white  btn-premium-hover">
                        <span class="text-xl">👎</span> <span id="ms-dislikes-count">0</span>
                    </button>
                </div>

                <a id="ms-btn-directions" href="#" target="_blank" class="w-full flex items-center justify-center gap-2 bg-blue-600/20 hover:bg-blue-600/40 border border-blue-500/50 transition text-blue-300 py-4 rounded-xl font-bold text-sm  mb-3 uppercase tracking-widest btn-premium-hover"><span class="text-lg">🗺️</span> YOL TARİFİ AL</a>
                
                <!-- Puan verme -->
                <div id="ms-rating" class="mt-3 mb-2">
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mb-2">Rampayı Puan Ver</div>
                    <div class="flex items-center gap-2">
                        <div id="ms-stars" class="flex gap-1">
                            <span onclick="rateMarker(1)" class="text-2xl cursor-pointer hover:scale-125 transition-transform">⭐</span>
                            <span onclick="rateMarker(2)" class="text-2xl cursor-pointer hover:scale-125 transition-transform">⭐</span>
                            <span onclick="rateMarker(3)" class="text-2xl cursor-pointer hover:scale-125 transition-transform">⭐</span>
                            <span onclick="rateMarker(4)" class="text-2xl cursor-pointer hover:scale-125 transition-transform">⭐</span>
                            <span onclick="rateMarker(5)" class="text-2xl cursor-pointer hover:scale-125 transition-transform">⭐</span>
                        </div>
                        <span id="ms-avg-rating" class="text-xs text-zinc-400 font-bold"></span>
                    </div>
                </div>
                <button onclick="openDangerReport()" class="w-full bg-red-950/40 border border-sky-800/50 hover:bg-sky-900/30 transition text-sky-300 py-2.5 rounded-xl font-bold text-xs mb-2 btn-premium-hover flex items-center justify-center gap-2">
                    <span>⚠️</span> Tehlike Bildir
                </button>
                <button onclick="openComments('marker', currentMarkerId)" class="w-full bg-zinc-900/80 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-300 py-3 rounded-xl font-bold text-sm mb-3 btn-premium-hover flex items-center justify-center gap-2 mt-1">
                    <span>💬</span> Yorumlar
                </button>
                <div id="ms-admin-controls" class="hidden flex gap-3 mt-5 pt-5 border-t border-zinc-700">
                    <button id="ms-btn-edit" class="flex-1 bg-blue-950/50 hover:bg-blue-900/80 transition text-blue-400 py-3.5 rounded-xl text-xs font-bold border border-blue-800/50  btn-premium-hover">DÜZENLE</button>
                    <button id="ms-btn-delete" class="flex-1 bg-red-950/50 hover:bg-sky-900/80 transition text-sky-400 py-3.5 rounded-xl text-xs font-bold border border-sky-800/50  btn-premium-hover">SİL</button>
                </div>
            </div>
        </div>

        <div id="event-sheet" class="hidden fixed bottom-0 inset-x-0 glass-panel border-t border-zinc-700 rounded-t-3xl  p-5 z-[9999] overflow-y-auto max-h-[88vh] slide-up-anim">
            <div class="flex justify-between items-start mb-5 border-b border-zinc-700 pb-4">
                <div>
                    <h3 id="es-title" class="text-4xl text-white teko-font tracking-wide "></h3>
                    <p id="es-time" class="text-[11px] text-blue-400 font-bold mt-2 uppercase tracking-widest bg-blue-950/30 inline-block px-2 py-1 rounded border border-blue-900/50"></p>
                </div>
                <button onclick="document.getElementById('event-sheet').classList.add('hidden')" class="bg-black/50 hover:bg-zinc-700 transition w-10 h-10 rounded-full flex items-center justify-center text-zinc-300 hover:text-white border border-zinc-700  hover:scale-110">✕</button>
            </div>
            
            <p id="es-desc" class="text-sm text-zinc-300 mb-6 bg-black/40 p-5 rounded-2xl border border-zinc-700 font-medium leading-relaxed "></p>
            
            <div class="mb-6 bg-zinc-900/30 p-4 rounded-2xl border border-zinc-800/50">
                <h4 class="text-[10px] font-bold text-zinc-400 mb-3 uppercase tracking-widest flex items-center gap-2"><span>👥</span> Katılacaklar</h4>
                <div id="es-attendees" class="flex flex-wrap gap-2"></div>
            </div>
            
            <button id="btn-join" onclick="toggleJoinEvent()" class="w-full bg-zinc-800 hover:bg-zinc-700 transition text-white py-4 rounded-xl font-bold text-sm  mb-3 btn-premium-hover"></button>
            <a id="btn-directions" href="#" target="_blank" class="w-full flex items-center justify-center gap-2 bg-black hover:bg-zinc-900 border border-zinc-700 transition text-white py-4 rounded-xl font-bold text-sm  mb-3 uppercase tracking-widest btn-premium-hover"><span class="text-lg">🗺️</span> YOL TARİFİ AL</a>
            <button onclick="openComments('event', currentEventId)" class="w-full bg-zinc-900/80 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-300 py-3 rounded-xl font-bold text-xs mb-2 btn-premium-hover flex items-center justify-center gap-2">
                <span>💬</span> Yorumlar
            </button>
            <button id="btn-del-event" onclick="deleteEvent()" class="hidden w-full bg-red-950/50 hover:bg-sky-900/80 transition text-sky-400 py-3.5 rounded-xl text-xs font-bold mt-2 border border-sky-800/50  btn-premium-hover">ETKİNLİĞİ SİL</button>
        </div>

        <div id="nearby-routes-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700 relative max-h-[80dvh] flex flex-col  scale-in-anim">
                <button onclick="document.getElementById('nearby-routes-modal').classList.add('hidden')" class="absolute top-4 right-4 bg-black/50  border border-zinc-700 hover:bg-zinc-700 transition w-8 h-8 rounded-full flex items-center justify-center text-zinc-300 hover:text-white z-10 hover:scale-110">✕</button>
                <h2 class="text-4xl text-white mb-5 teko-font tracking-wide border-b border-zinc-700 pb-3 ">📍 YAKIN ROTALAR</h2>
                <div id="nr-list" class="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar"></div>
            </div>
        </div>

        <div id="kvkk-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 py-10 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-sky-900/50 flex flex-col  scale-in-anim">
                <h2 class="text-3xl text-white mb-4 teko-font tracking-wide text-sky-400  flex items-center gap-2"><span class="animate-pulse">⚠️</span> KULLANICI SÖZLEŞMESİ</h2>
                <div class="overflow-y-auto flex-1 text-xs text-zinc-300 space-y-5 mb-5 custom-scrollbar pr-3 bg-black/50 p-5 rounded-2xl border border-zinc-700  leading-relaxed">
                    <p><b class="text-white text-sm">1. GÜVENLİK VE SORUMLULUK REDDİ (WAIVER)</b><br>
                    Downhill ve Freeride dağ bisikleti, doğası gereği yüksek ölüm ve ağır yaralanma riski taşıyan ekstrem bir spordur. FreeriderTR platformunda (haritada) paylaşılan rampalar, atlayış noktaları ve rotalar tamamen kullanıcılar tarafından eklenmektedir. 
                    <br><br>Bu noktalarda sürüş yaparken oluşabilecek <b>hiçbir kazadan, fiziksel yaralanmadan, ekipman hasarından veya ölümden FreeriderTR yönetimi sorumlu tutulamaz.</b> Sürüş esnasında <i>Tam kapalı kask (Full-face), boyunluk (Neck brace), göğüs/sırt zırhı ve dizlik</i> kullanmak tamamen sizin bireysel sorumluluğunuzdadır.</p>
                    
                    <p><b class="text-white text-sm">2. KİŞİSEL VERİLER (KVKK)</b><br>
                    6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında; uygulamaya kayıt olurken verdiğiniz isim, şehir bilgileri, yüklediğiniz fotoğraflar, pazar ilanlarınız ve mesajlarınız sunucularımızda saklanmaktadır. <b>"Radar (Sürüşteyim)"</b> modunu açtığınızda anlık GPS konumunuz diğer kullanıcılara açık hale gelir. Verileriniz ticari amaçla 3. şahıslara satılmaz, sadece topluluk içi etkileşim için kullanılır.</p>
                    
                    <p><b class="text-white text-sm">3. TOPLULUK KURALLARI</b><br>
                    Uygulama içi sohbetlerde, pazar ilanlarında ve profil sayfalarında küfür, hakaret, yasa dışı madde ticareti ve müstehcen (+18) içerik paylaşımı kesinlikle yasaktır. İhlal durumunda hesabınız kalıcı olarak (IP ve Cihaz banı ile) sistemden uzaklaştırılır.</p>
                </div>
                <div class="shrink-0 mt-2">
                    <button onclick="closeKvkkModal()" class="w-full bg-sky-700 hover:bg-sky-600 transition text-white py-4 rounded-xl font-black text-sm  tracking-widest btn-premium-hover">OKUDUM VE ANLADIM</button>
                </div>
            </div>
        </div>

        <!-- ============================================================ -->
        <!-- GELİŞMİŞ YÖNETİCİ PANELİ -->
        <!-- ============================================================ -->
        <div id="admin-panel" class="hidden fixed inset-0 z-[9999] flex items-center justify-center px-3" style="background:rgba(0,0,0,0.85);">
            <div class="w-full max-w-lg h-[92dvh] rounded-3xl flex flex-col overflow-hidden  border border-sky-900/40 scale-in-anim" style="background:linear-gradient(160deg,#0f0f12 0%,#130d0d 60%,#0a0a0f 100%)">

                <!-- Header -->
                <div class="shrink-0 px-5 pt-5 pb-4 border-b border-sky-900/30" style="background:linear-gradient(90deg,rgba(12,74,110,0.25),rgba(0,0,0,0))">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl flex items-center justify-center text-xl " style="background:linear-gradient(135deg,#0c4a6e,#0369a1)">👑</div>
                            <div>
                                <h2 class="text-2xl text-white teko-font tracking-widest leading-none">YÖNETİM MERKEZİ</h2>
                                <div id="admin-panel-role-tag" class="text-[10px] font-black uppercase tracking-widest text-sky-300 mt-0.5">Ana Yönetici</div>
                            </div>
                        </div>
                        <button onclick="document.getElementById('admin-panel').classList.add('hidden')" class="w-9 h-9 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white border border-zinc-700 hover:border-sky-600 transition-all hover:scale-105" style="background:rgba(0,0,0,0.5)">✕</button>
                    </div>

                    <!-- Tab Navigation -->
                    <div class="flex gap-1 mt-4 p-1 rounded-xl" style="background:rgba(0,0,0,0.4)">
                        <button onclick="adminSwitchTab('overview')" id="atab-overview" class="admin-tab-btn flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all active-admin-tab">📊 Genel</button>
                        <button onclick="adminSwitchTab('users')" id="atab-users" class="admin-tab-btn flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all">👥 Kullanıcı</button>
                        <button onclick="adminSwitchTab('reels')" id="atab-reels" class="admin-tab-btn flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all">🎬 Reels</button>
                        <button onclick="adminSwitchTab('commands')" id="atab-commands" class="admin-tab-btn flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all">🚀 İşlemler</button>
                        <button onclick="adminSwitchTab('reports')" id="atab-reports" class="admin-tab-btn flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all">🛡️ Raporlar</button>
                        <button onclick="adminSwitchTab('logs')" id="atab-logs" class="admin-tab-btn flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all">📋 Kayıt</button>
                        <button onclick="adminSwitchTab('admins')" id="atab-admins" class="admin-tab-btn admin-main-only flex-1 py-2 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all">🛡️ Ekip</button>
                    </div>
                </div>

                <!-- Content Area -->
                <div class="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">

                    <!-- ===== GENEL TAB ===== -->
                    <div id="admin-tab-overview" class="space-y-4">
                        <!-- Stats Cards -->
                        <div class="grid grid-cols-3 gap-2">
                            <div class="rounded-2xl p-3 text-center border border-zinc-800/80" style="background:rgba(0,0,0,0.5)">
                                <div id="astat-users" class="text-2xl font-black text-white teko-font">—</div>
                                <div class="text-[9px] text-zinc-500 uppercase font-bold tracking-wider mt-1">Kullanıcı</div>
                            </div>
                            <div class="rounded-2xl p-3 text-center border border-zinc-800/80" style="background:rgba(0,0,0,0.5)">
                                <div id="astat-banned" class="text-2xl font-black text-sky-300 teko-font">—</div>
                                <div class="text-[9px] text-zinc-500 uppercase font-bold tracking-wider mt-1">Banlı</div>
                            </div>
                            <div class="rounded-2xl p-3 text-center border border-zinc-800/80" style="background:rgba(0,0,0,0.5)">
                                <div id="astat-admins" class="text-2xl font-black text-amber-400 teko-font">—</div>
                                <div class="text-[9px] text-zinc-500 uppercase font-bold tracking-wider mt-1">Yrd. Admin</div>
                            </div>
                        </div>

                        <!-- Google Play IAP Doğrulamaları -->
                        <div class="rounded-2xl border border-zinc-800/80 overflow-hidden admin-main-only">
                            <div class="px-4 py-3 flex items-center gap-2 border-b border-zinc-800/50" style="background:rgba(0,0,0,0.4)">
                                <span class="animate-pulse text-sm">📱</span>
                                <span class="text-white font-black text-xs uppercase tracking-widest">Google Play IAP — Bekleyen Onaylar</span>
                            </div>
                            <div id="admin-iap-requests" class="p-3 space-y-2 text-zinc-500 text-xs italic font-medium">Yükleniyor...</div>
                        </div>

                        <!-- Koordinat ile Nokta Ekle -->
                        <div class="rounded-2xl border border-sky-900/40 overflow-hidden" style="background:rgba(0,0,0,0.4)">
                            <div class="px-4 py-3 border-b border-sky-900/30">
                                <span class="text-sky-300 font-black text-xs uppercase tracking-widest">📍 KOORDİNAT İLE NOKTA EKLE</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <input type="text" id="admin-manual-coords" placeholder="Örn: 39.5035, 26.9557" class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-sky-500 transition font-medium" style="background:rgba(0,0,0,0.5)">
                                <button onclick="addMarkerFromAdminCoords()" class="w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-sky-700/60 text-sky-300 hover:bg-sky-900/30 transition-all btn-premium-hover">➕ Ekleme Modalını Aç</button>
                            </div>
                        </div>

                        <!-- Maintenance + News: Main Admin only -->
                        <div class="rounded-2xl border border-zinc-800/80 overflow-hidden admin-main-only">
                            <div class="px-4 py-3 flex items-center justify-between border-b border-zinc-800/50" style="background:rgba(0,0,0,0.4)">
                                <span class="text-white font-black text-xs uppercase tracking-widest">⚙️ Sistem Ayarları</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <div class="flex items-center justify-between">
                                    <span class="text-zinc-300 text-sm font-bold">🔧 Bakım Modu</span>
                                    <input type="checkbox" id="admin-maintenance" onchange="toggleMaintenance()" class="w-6 h-6 accent-sky-500 cursor-pointer">
                                </div>
                                <button onclick="openNewsAdminModal()" class="w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-zinc-700 hover:border-white text-zinc-300 hover:text-white transition-all btn-premium-hover" style="background:rgba(0,0,0,0.4)">📰 Haber / Duyuru Ekle</button>
                            </div>
                        </div>

                        <!-- Sub-admin notify main -->
                        <div class="rounded-2xl border border-amber-900/40 overflow-hidden admin-sub-only" style="display:none">
                            <div class="px-4 py-3 border-b border-amber-900/30" style="background:rgba(120,53,15,0.15)">
                                <span class="text-amber-300 font-black text-xs uppercase tracking-widest">📢 Ana Admine Bildirim Gönder</span>
                            </div>
                            <div class="p-4">
                                <textarea id="admin-notify-msg" placeholder="Ana admine iletmek istediğin mesajı yaz..." class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-amber-500 transition resize-none h-20 font-medium" style="background:rgba(0,0,0,0.5)"></textarea>
                                <button onclick="adminNotifyMain()" class="mt-2 w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-amber-700/60 text-amber-300 hover:bg-amber-900/30 transition-all btn-premium-hover">📨 Gönder</button>
                            </div>
                        </div>
                    </div>

                    <!-- ===== KULLANICI TAB ===== -->
                    <div id="admin-tab-users" class="hidden space-y-3">
                        <div class="relative">
                            <input id="admin-user-search" type="text" placeholder="Kullanıcı ara..." oninput="adminSearchUsers()" class="w-full rounded-2xl px-5 py-3.5 text-sm text-white border border-zinc-700 outline-none focus:border-sky-500 transition font-medium" style="background:rgba(0,0,0,0.6)">
                            <span class="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500">🔍</span>
                        </div>
                        <div id="admin-user-list" class="space-y-2">
                            <!-- Doldurulacak -->
                        </div>
                    </div>

                    <!-- ===== KOMUTLAR TAB ===== -->
                    <div id="admin-tab-commands" class="hidden space-y-4">
                        <!-- ===== SIRALAMA YÖNETİMİ ===== -->
                        <div class="rounded-2xl border border-purple-900/50 overflow-hidden admin-main-only" style="background:rgba(0,0,0,0.6)">
                            <div class="px-4 py-3 border-b border-purple-900/40 flex items-center gap-2" style="background:rgba(88,28,135,0.15)">
                                <span class="text-purple-300 font-black text-xs uppercase tracking-widest">🏆 Sıralama Tablosu Yönetimi</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <div class="text-[10px] text-zinc-400 font-medium leading-relaxed">Tabloyu erken sonlandır: ilk 3 kişiye ödül verilir ve XP'ler sıfırlanır. Bu işlem geri alınamaz.</div>
                                <div id="leaderboard-preview" class="rounded-xl border border-zinc-800/60 p-3 space-y-1 text-[11px]" style="background:rgba(0,0,0,0.4)">
                                    <div class="text-zinc-500 italic text-center">Önizleme için yükle...</div>
                                </div>
                                <button onclick="loadLeaderboardPreview()" class="w-full py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-zinc-700 text-zinc-300 hover:bg-zinc-800/50 transition-all">🔄 Mevcut Sıralamayı Önizle</button>
                                <div class="grid grid-cols-2 gap-2 mt-1">
                                    <button onclick="adminForceEndLeaderboard('weekly')" class="py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border border-purple-700/60 text-purple-300 hover:bg-purple-900/30 transition-all">⚡ Haftalığı Sonlandır</button>
                                    <button onclick="adminForceEndLeaderboard('monthly')" class="py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border border-indigo-700/60 text-indigo-300 hover:bg-indigo-900/30 transition-all">📅 Aylığı Sonlandır</button>
                                </div>
                                <div id="leaderboard-end-result" class="hidden text-[11px] font-bold p-3 rounded-xl border"></div>
                            </div>
                        </div>
                        <!-- ===== KULLANICI SORGULAMA ===== -->
                        <div class="rounded-2xl border border-zinc-800/80 overflow-hidden" style="background:rgba(0,0,0,0.6)">
                            <div class="px-4 py-3 border-b border-zinc-800/50 flex justify-between items-center" style="background:rgba(0,0,0,0.4)">
                                <span class="text-white font-black text-xs uppercase tracking-widest">🔍 Kullanıcı Sorgulama</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <div class="relative">
                                    <input id="admin-action-username" type="text" placeholder="Kullanıcı adı girin..." onkeyup="if(event.key==='Enter') adminCheckUserDetails()" class="w-full rounded-xl pl-10 pr-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-sky-500 transition font-medium" style="background:rgba(0,0,0,0.5)">
                                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500">👤</span>
                                </div>
                                <button onclick="adminCheckUserDetails()" class="w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest bg-sky-900/30 border border-sky-800/50 text-sky-300 hover:bg-sky-800/50 transition-all  btn-premium-hover">Kullanıcıyı Bul</button>
                            </div>
                        </div>

                        <div id="admin-action-result" class="hidden space-y-4 slide-down-anim">
                            <!-- Kullanıcı Detay Kartı -->
                            <div class="rounded-2xl border border-zinc-700 overflow-hidden" style="background:rgba(15,15,20,0.8)">
                                <div class="px-4 py-3 border-b border-zinc-800/50">
                                    <span class="text-zinc-400 font-black text-[10px] uppercase tracking-widest">📋 Kullanıcı Bilgileri</span>
                                </div>
                                <div class="p-4 text-xs text-white space-y-2 font-medium">
                                    <div class="flex justify-between"><span class="text-zinc-500">Kullanıcı Adı:</span> <span id="aa-username" class="font-bold text-sky-400"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">E-posta:</span> <span id="aa-email"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">Kayıt Tarihi:</span> <span id="aa-date"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">Şehir / XP:</span> <span id="aa-cityxp"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">Mevcut Rol:</span> <span id="aa-role" class="font-bold"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">Durum:</span> <span id="aa-banned" class="font-bold"></span></div>
                                </div>
                            </div>

                            <!-- Premium Bilgileri Kartı -->
                            <div class="rounded-2xl border border-amber-900/40 overflow-hidden" style="background:rgba(120,53,15,0.1)">
                                <div class="px-4 py-3 border-b border-amber-900/30">
                                    <span class="text-amber-500 font-black text-[10px] uppercase tracking-widest">👑 Üyelik Durumu</span>
                                </div>
                                <div class="p-4 text-xs text-white space-y-2 font-medium">
                                    <div class="flex justify-between"><span class="text-zinc-500">Paket:</span> <span id="aa-tier" class="font-bold text-yellow-400"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">Bitiş Tarihi:</span> <span id="aa-expire"></span></div>
                                    <div class="flex justify-between"><span class="text-zinc-500">Edinme Yolu:</span> <span id="aa-source"></span></div>
                                </div>
                            </div>

                            <!-- Aksiyon Butonları -->
                            <div class="space-y-2">
                                <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest px-1">💎 Premium Ver / Uzat</div>
                                <div class="grid grid-cols-3 gap-2">
                                    <button onclick="adminActionExec('standart gönder')" class="py-3 bg-blue-900/30 border border-blue-800/50 text-blue-300 text-[10px] font-black rounded-xl hover:bg-blue-800/50 transition">Std Ver</button>
                                    <button onclick="adminActionExec('deluxe gönder')" class="py-3 bg-purple-900/30 border border-purple-800/50 text-purple-300 text-[10px] font-black rounded-xl hover:bg-purple-800/50 transition">Dlx Ver</button>
                                    <button onclick="adminActionExec('ultra gönder')" class="py-3 bg-yellow-900/30 border border-yellow-800/50 text-yellow-300 text-[10px] font-black rounded-xl hover:bg-yellow-800/50 transition">Ult+ Ver</button>
                                </div>
                                <div class="grid grid-cols-3 gap-2 mt-2">
                                    <button onclick="adminActionExec('standart geri çek')" class="py-3 bg-zinc-800/50 border border-zinc-700 text-zinc-400 text-[10px] font-black rounded-xl hover:bg-zinc-700 transition">Std Düşür</button>
                                    <button onclick="adminActionExec('deluxe geri çek')" class="py-3 bg-zinc-800/50 border border-zinc-700 text-zinc-400 text-[10px] font-black rounded-xl hover:bg-zinc-700 transition">Dlx Düşür</button>
                                    <button onclick="adminActionExec('ultra geri çek')" class="py-3 bg-red-900/30 border border-red-800/50 text-red-300 text-[10px] font-black rounded-xl hover:bg-red-800/50 transition">Üyeliği Sil</button>
                                </div>
                            </div>

                            <!-- Diğer İşlemler -->
                            <div class="space-y-2 mt-4 mb-8">
                                <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest px-1">⚠️ Hesap İşlemleri</div>
                                <div class="grid grid-cols-2 gap-2">
                                    <button onclick="adminResetPassword(document.getElementById('aa-username').textContent)" class="py-3 bg-zinc-800 border border-zinc-700 text-zinc-300 text-[10px] font-black rounded-xl hover:bg-zinc-700 transition">🔑 Şifre Sıfırla</button>
                                    <button onclick="adminChangeUsername(document.getElementById('aa-username').textContent); adminCheckUserDetails();" class="py-3 bg-zinc-800 border border-zinc-700 text-zinc-300 text-[10px] font-black rounded-xl hover:bg-zinc-700 transition">✏️ İsim Değiş</button>
                                    <button id="aa-btn-ban" onclick="adminActionBanToggle()" class="py-3 bg-orange-950/40 border border-orange-900/50 text-orange-400 text-[10px] font-black rounded-xl hover:bg-orange-900/40 transition">🚫 Banla</button>
                                    <button onclick="adminDeleteUser(document.getElementById('aa-username').textContent)" class="py-3 bg-red-950/50 border border-red-900/50 text-red-400 text-[10px] font-black rounded-xl hover:bg-red-900/50 transition">🗑️ Hesabı Sil</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ===== RAPORLAR TAB ===== -->
                    <div id="admin-tab-reports" class="hidden space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-zinc-400 text-xs font-bold uppercase tracking-widest">🛡️ Bekleyen Raporlar</span>
                            <button onclick="loadAdminReports()" class="text-[10px] text-sky-300 font-bold border border-sky-900/40 px-3 py-1.5 rounded-lg hover:bg-sky-900/20 transition">🔄 Yenile</button>
                        </div>
                        <div class="flex gap-2 mb-2">
                            <select id="admin-report-status" onchange="loadAdminReports()" class="bg-black/60 border border-zinc-700 rounded-lg px-2 py-2 text-white text-[10px] font-bold outline-none">
                                <option value="pending">⏳ Bekleyen</option>
                                <option value="all">📋 Tümü</option>
                                <option value="reviewed">✅ İncelendi</option>
                                <option value="dismissed">❌ Reddedildi</option>
                            </select>
                            <select id="admin-report-severity" onchange="loadAdminReports()" class="bg-black/60 border border-zinc-700 rounded-lg px-2 py-2 text-white text-[10px] font-bold outline-none">
                                <option value="all">Tüm Şiddetler</option>
                                <option value="high">🔴 Yüksek</option>
                                <option value="medium">🟠 Orta</option>
                                <option value="low">🟡 Düşük</option>
                            </select>
                        </div>
                        <div id="admin-reports-list" class="space-y-2">
                            <div class="text-zinc-600 text-xs italic font-medium text-center py-4">Yükleniyor...</div>
                        </div>
                        <div id="admin-reports-pagination" class="flex justify-center gap-2 mt-2"></div>
                    </div>

                    <!-- ===== REELS TAB ===== -->
                    <div id="admin-tab-reels" class="hidden space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-zinc-400 text-xs font-bold uppercase tracking-widest">Son 50 Reel</span>
                            <button onclick="loadAdminReels()" class="text-[10px] text-sky-300 font-bold border border-sky-900/40 px-3 py-1.5 rounded-lg hover:bg-sky-900/20 transition">🔄 Yenile</button>
                        </div>
                        <div id="admin-reels-list" class="space-y-2">
                            <div class="text-zinc-600 text-xs italic font-medium text-center py-4">Yükleniyor...</div>
                        </div>
                    </div>

                    <!-- ===== LOGLAR TAB ===== -->
                    <div id="admin-tab-logs" class="hidden space-y-3">
                        <!-- Bildirim Test Aracı -->
                        <!-- Özel Bildirim Gönderici -->
                        <div class="rounded-2xl border border-emerald-900/50 overflow-hidden mb-3">
                            <div class="px-4 py-3 border-b border-emerald-900/30" style="background:rgba(6,78,59,0.2)">
                                <span class="text-emerald-300 font-black text-xs uppercase tracking-widest">🔔 Özel Bildirim Gönder</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <select id="push-target-type" onchange="togglePushTargetInput()" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-emerald-500 transition font-bold">
                                    <option value="specific">Belirli Kişilere</option>
                                    <option value="all">Tüm Kullanıcılara (Herkes)</option>
                                </select>
                                <input id="push-usernames" type="text" placeholder="Kullanıcı adları (virgülle ayırın, örn: ali,ayşe)..." class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-emerald-500 transition font-medium" style="background:rgba(0,0,0,0.5)">
                                <input id="push-title" type="text" placeholder="Bildirim Başlığı..." class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-emerald-500 transition font-medium" style="background:rgba(0,0,0,0.5)">
                                <textarea id="push-message" placeholder="Bildirim Mesajı..." class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-emerald-500 transition font-medium h-20 custom-scrollbar" style="background:rgba(0,0,0,0.5)"></textarea>
                                <button onclick="sendCustomPushNotification()" class="w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-emerald-700/60 text-emerald-300 hover:bg-emerald-900/30 transition-all btn-premium-hover">🚀 Bildirimi Gönder</button>
                                <div id="test-push-result" class="hidden text-[11px] font-bold p-3 rounded-xl border"></div>
                            </div>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-zinc-400 text-xs font-bold uppercase tracking-widest">Admin Eylem Kayıtları</span>
                            <button onclick="loadAdminLogs()" class="text-[10px] text-blue-400 font-bold border border-blue-900/40 px-3 py-1.5 rounded-lg hover:bg-blue-900/20 transition">🔄 Yenile</button>
                        </div>
                        <div id="admin-logs-list" class="space-y-2">
                            <div class="text-zinc-600 text-xs italic font-medium text-center py-4">Yükleniyor...</div>
                        </div>
                    </div>

                    <!-- ===== EKIP (ADMİNLER) TAB ===== -->
                    <div id="admin-tab-admins" class="hidden space-y-4 admin-main-only">
                        <div class="rounded-2xl border border-zinc-800/80 overflow-hidden">
                            <div class="px-4 py-3 border-b border-zinc-800/50" style="background:rgba(0,0,0,0.4)">
                                <span class="text-white font-black text-xs uppercase tracking-widest">➕ Yardımcı Admin Ata</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <input id="assign-admin-username" type="text" placeholder="Kullanıcı adı gir..." class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-amber-500 transition font-medium" style="background:rgba(0,0,0,0.5)">
                                <button onclick="assignSubAdmin()" class="w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-amber-700/60 text-amber-300 hover:bg-amber-900/30 transition-all btn-premium-hover">👑 Yardımcı Admin Yap</button>
                            </div>
                        </div>

                        <div class="rounded-2xl border border-zinc-800/80 overflow-hidden">
                            <div class="px-4 py-3 flex items-center justify-between border-b border-zinc-800/50" style="background:rgba(0,0,0,0.4)">
                                <span class="text-white font-black text-xs uppercase tracking-widest">🛡️ Mevcut Yardımcı Adminler</span>
                                <button onclick="loadSubAdmins()" class="text-[10px] text-zinc-400 font-bold hover:text-white transition">🔄</button>
                            </div>
                            <div id="sub-admin-list" class="p-3 space-y-2">
                                <div class="text-zinc-600 text-xs italic font-medium text-center py-3">Yükleniyor...</div>
                            </div>
                        </div>

                        <div class="rounded-2xl border border-sky-900/30 overflow-hidden">
                            <div class="px-4 py-3 border-b border-sky-900/25" style="background:rgba(12,74,110,0.1)">
                                <span class="text-sky-300 font-black text-xs uppercase tracking-widest">🚫 Yetki Al</span>
                            </div>
                            <div class="p-4 space-y-3">
                                <input id="revoke-admin-username" type="text" placeholder="Admin kullanıcı adı..." class="w-full rounded-xl px-4 py-3 text-sm text-white border border-zinc-700 outline-none focus:border-sky-500 transition font-medium" style="background:rgba(0,0,0,0.5)">
                                <button onclick="revokeSubAdmin()" class="w-full py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-sky-800/60 text-sky-300 hover:bg-sky-900/20 transition-all btn-premium-hover">❌ Adminliği Geri Al</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Kullanıcı Aktivite Modalı -->
        <div id="user-activity-modal" class="hidden fixed inset-0 z-[99999] flex items-center justify-center px-3" style="background:rgba(0,0,0,0.9);">
            <div class="w-full max-w-md h-[88dvh] rounded-3xl flex flex-col overflow-hidden border border-zinc-700  scale-in-anim" style="background:#0c0c10">
                <div class="shrink-0 px-5 py-4 border-b border-zinc-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-xl text-white teko-font tracking-wide">🔍 Kullanıcı Aktivitesi</h3>
                        <div id="ua-username-label" class="text-xs text-zinc-500 font-bold mt-0.5"></div>
                    </div>
                    <button onclick="document.getElementById('user-activity-modal').classList.add('hidden')" class="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center transition">✕</button>
                </div>
                <div class="flex gap-1 p-3 border-b border-zinc-800" style="background:rgba(0,0,0,0.3)">
                    <button onclick="uaTab('messages')" id="uatab-messages" class="ua-tab-btn flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ua-active-tab">💬 Mesajlar</button>
                    <button onclick="uaTab('dms')" id="uatab-dms" class="ua-tab-btn flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all">📩 DM</button>
                    <button onclick="uaTab('reels')" id="uatab-reels" class="ua-tab-btn flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all">🎬 Reels</button>
                    <button onclick="uaTab('markers')" id="uatab-markers" class="ua-tab-btn flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all">📍 Yerler</button>
                    <button onclick="uaTab('manage')" id="uatab-manage" class="ua-tab-btn flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all admin-main-only text-sky-400">⚙️ Yönet</button>
                </div>
                <div class="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2" id="ua-content">
                    <div class="text-zinc-600 text-xs italic text-center py-6">Yükleniyor...</div>
                </div>
                <div class="shrink-0 p-3 border-t border-zinc-800 grid grid-cols-2 gap-2">
                    <button id="ua-ban-btn" onclick="adminBanFromActivity()" class="py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-sky-800/60 text-sky-300 hover:bg-sky-900/20 transition">🚨 Banla</button>
                    <button onclick="document.getElementById('user-activity-modal').classList.add('hidden')" class="py-3 rounded-xl text-xs font-black uppercase tracking-widest border border-zinc-700 text-zinc-400 hover:bg-zinc-800 transition">Kapat</button>
                </div>
            </div>
        </div>
        
        <div id="news-admin-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4 ">
            <div class="glass-panel w-full max-w-md rounded-3xl p-6 border border-zinc-700  scale-in-anim">
                <h2 class="text-4xl text-white mb-6 teko-font tracking-wide ">📰 YENİ HABER</h2>
                <input id="news-title" type="text" placeholder="Haber Başlığı" class="w-full bg-black/60 p-4 rounded-xl mb-4 text-white font-bold border border-zinc-700 outline-none focus:border-white transition ">
                <textarea id="news-content" placeholder="Haber İçeriği..." class="w-full bg-black/60 p-4 rounded-xl h-28 mb-4 text-white font-medium border border-zinc-700 outline-none focus:border-white transition custom-scrollbar "></textarea>
                
                <label class="block text-[10px] text-zinc-400 mb-2 uppercase font-bold tracking-widest">Haber Görseli (İsteğe Bağlı)</label>
                <input id="news-photo" type="file" accept="image/*" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-3 py-3 mb-6 text-xs text-zinc-300 focus:border-white transition cursor-pointer ">
                
                <div class="flex gap-3">
                    <button onclick="document.getElementById('news-admin-modal').classList.add('hidden')" class="flex-1 bg-zinc-800 hover:bg-zinc-700 transition py-4 rounded-xl text-white font-bold  btn-premium-hover">İptal</button>
                    <button onclick="saveNews()" class="flex-1 bg-white hover:bg-gray-200 transition py-4 rounded-xl text-black font-bold  btn-premium-hover">YAYINLA</button>
                </div>
            </div>
        </div>

        <!-- spin sesleri missions screen'de inline -->

    <script>
        // Global Değişkenler
        // window.currentUser olarak tanımla — OneSignal init callback'i erişebilsin
        window.currentUser = null;
        let currentUser = null; 
        let map; 
        let selectedMarkerCategory = "Rampa";
        let activeMarkerFilter = "Tümü";
        let isFetchingMarkers = false;
        let markerCache = new Map();
        
        let userLat = 39.0; 
        let userLng = 35.0; 
        let tempLat; 
        let tempLng;
        let db = { 
            users: [], 
            markers: [], 
            messages: [], 
            market: [], 
            events: [], 
            news: [], 
            reports: [], 
            banned: [], 
            dms: [], 
            maintenance: false, 
            pinned_message: {},
            total_users: 300,
            active_users: 0
        };
        // Reels global state
        let reelsData = [];
        let currentReelId = null;
        let reelFileData = null;
        let reelFileType = null;
        let _prevTab = 0; // Reels'ten önce hangi tab'daydık

        // ── Toast Bildirim Sistemi (Geliştirilmiş) ──────────────────────────────
        // showToast(message, type?, duration?)  →  ekranın altında kısa süreli bildirim
        // type: 'success' | 'error' | 'warning' | 'info'
        let _toastTimer = null;
        function showToast(message, typeOrDuration = 'info', duration = 1500) {
            // Geriye dönük uyumluluk: eski çağrılar showToast(msg, 3000) şeklinde
            let type = 'info';
            if (typeof typeOrDuration === 'number') {
                duration = typeOrDuration;
            } else if (typeof typeOrDuration === 'string') {
                type = typeOrDuration;
            }

            const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
            const colors = {
                success: 'border-color:rgba(34,197,94,0.6);background:linear-gradient(135deg,rgba(20,83,45,0.95),rgba(24,24,27,0.97))',
                error:   'border-color:rgba(239,68,68,0.6);background:linear-gradient(135deg,rgba(127,29,29,0.95),rgba(24,24,27,0.97))',
                warning: 'border-color:rgba(234,179,8,0.6);background:linear-gradient(135deg,rgba(113,63,18,0.95),rgba(24,24,27,0.97))',
                info:    'border-color:rgba(59,130,246,0.6);background:linear-gradient(135deg,rgba(30,58,138,0.95),rgba(24,24,27,0.97))'
            };

            let toast = document.getElementById('__freerider_toast__');
            if (!toast) {
                toast = document.createElement('div');
                toast.id = '__freerider_toast__';
                document.body.appendChild(toast);
            }
            toast.innerHTML = `<span style="margin-right:8px;font-size:16px">${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
            toast.style.cssText = [
                'position:fixed', 'top:20px', 'left:50%',
                'transform:translateX(-50%)', 'z-index:9999999',
                'color:#f4f4f5',
                'padding:8px 16px', 'border-radius:24px',
                'font-size:13px', 'font-weight:700',
                'box-shadow:0 8px 32px rgba(0,0,0,0.5)',
                'border:1px solid rgba(255,255,255,0.1)',
                'max-width:88vw', 'text-align:center',
                'pointer-events:none',
                'display:flex', 'align-items:center', 'justify-content:center',
                'gap:6px',
                colors[type] || colors.info,
                'animation:toastSlideIn 0.35s cubic-bezier(0.16,1,0.3,1) both'
            ].join(';');
            if (_toastTimer) clearTimeout(_toastTimer);
            _toastTimer = setTimeout(() => {
                toast.style.animation = 'toastSlideOut 0.3s ease-in forwards';
                setTimeout(() => { toast.style.display = 'none'; }, 300);
            }, duration);
        }
        let markerLayers = []; 
        let markerCluster = null;
        let currentMessageCount = 0;
        let _heartbeatInterval = null;
        let _locationInterval = null;
        let currentEventId = null; 
        let currentMarketId = null; 
        let currentDmUser = null; 
        let currentMarkerId = null; 
        let mediaRecorder; 
        let audioChunks = [];
        let _voiceStopping = false; // Ses gönderim aşamasında tekrar tıklamayı engeller
        window.currentOwner = null; 
        let isAddingMarkerMode = false; 
        let isAddingEventMode = false; 
        let currentPhotoContext = 'group';
        let editingBikeIndex = null;

        let editingMarkerId = null;
        let editingMarkerLat = null;
        let editingMarkerLng = null;

        let currentLeaderboardTab = 'weekly'; 
        let verificationUsername = null;

        function checkFileSize(file, maxMB = 10) {
            if(!file) return true; 
            const fileSizeMB = file.size / (1024 * 1024);
            if (fileSizeMB > maxMB) {
                alert(`⚠️ Dosya çok büyük (${fileSizeMB.toFixed(2)} MB). Lütfen sistemi yormamak için ${maxMB}MB'dan küçük bir görsel seçin.`);
                return false;
            }
            return true;
        }
        
        // =====================================================
        // ŞANS ÇARKI - SABİT ÖDÜL LİSTESİ (backend ile eşleşir)
        // =====================================================
        window.WHEEL_PRIZES = [
            {id: "xp_100",      name: "100 XP",          color: "#38bdf8"},
            {id: "prem_dlx_1",  name: "1G Deluxe",        color: "#8b5cf6"},
            {id: "xp_200",      name: "200 XP",           color: "#f59e0b"},
            {id: "prem_ult_1",  name: "1G Ultra+",        color: "#eab308"},
            {id: "xp_300",      name: "300 XP",           color: "#10b981"},
            {id: "prem_std_7",  name: "7G Standart",      color: "#3b82f6"},
            {id: "xp_500",      name: "500 XP",           color: "#38bdf8"},
            {id: "prem_dlx_7",  name: "7G Deluxe",        color: "#8b5cf6"},
            {id: "xp_1000",     name: "1000 XP",          color: "#f59e0b"},
            {id: "prem_ult_7",  name: "7G Ultra+",        color: "#eab308"},
            {id: "xp_10000",    name: "10.000 XP",        color: "#10b981"},
            {id: "prem_std_30", name: "1Ay Standart",     color: "#3b82f6"},
            {id: "xp_100000",   name: "100.000 XP",       color: "#38bdf8"},
            {id: "prem_dlx_30", name: "1Ay Deluxe",       color: "#8b5cf6"},
            {id: "prem_ult_30", name: "1Ay Ultra+",       color: "#eab308"},
            {id: "prem_std_365",name: "1Yil Standart",    color: "#3b82f6"},
            {id: "prem_ult_365",name: "1Yil Ultra+",      color: "#eab308"},
            {id: "xp_200",      name: "200 XP",           color: "#f59e0b"},
        ];


        function checkRefCodeInput() {
            const val = document.getElementById("reg-ref-code").value.trim();
            const container = document.getElementById("reg-ref-reward-container");
            if(val.length > 0) {
                container.classList.remove("hidden");
                container.classList.add("scale-in-anim");
            } else {
                container.classList.add("hidden");
            }
        }

        // =========================================================
        // GİRİŞ VE KAYIT İŞLEMLERİ
        // =========================================================
        async function handleLogin() {
            const u = document.getElementById("login-username").value.trim();
            const p = document.getElementById("login-password").value;
            
            if(!u || !p) return alert("Kullanıcı adı ve şifre zorunludur!");
            
            try {
                const res = await sendAction('login', { username: u, password: p });
                if (res.status === 'needs_password') {
                    alert(res.message);
                    const newPw = prompt("Lütfen hesabınız için yeni şifrenizi girin (en az 4 karakter):");
                    if (newPw && newPw.length >= 4) {
                        const setRes = await sendAction('set_new_password', { username: res.username, new_password: newPw });
                        if (setRes.status === 'ok') {
                            alert(setRes.message);
                            document.getElementById("login-password").value = newPw;
                            return handleLogin(); // Tekrar giriş yapmayı dene
                        } else {
                            alert(setRes.message || "Şifre ayarlanamadı.");
                        }
                    } else if (newPw) {
                        alert("Şifre en az 4 karakter olmalıdır!");
                    }
                    return;
                }
                
                if(res.status === 'ok') {
                    currentUser = res.user;
                    window.currentUser = currentUser; // OneSignal callback için global'e de yaz
                    localStorage.setItem("fr_user", JSON.stringify(currentUser));
                    const meIdx = db.users.findIndex(u => u.username === currentUser.username);
                    if (meIdx !== -1) { db.users[meIdx] = currentUser; } else { db.users.push(currentUser); }
                    
                    // Beni hatırla kapatıldı, eski kayıtları temizle
                    localStorage.removeItem("fr_remembered_username");
                    localStorage.removeItem("fr_remembered_password");
                    
                    if (res.user.session_token) {
                        localStorage.setItem("fr_session_token", res.user.session_token);
                        localStorage.setItem("fr_session_username", currentUser.username);
                    }
                    
                    if(res.user.just_got_daily) {
                        alert("🎉 Harika! Günlük giriş ödülü olarak +" + res.user.just_got_daily + " XP kazandın.");
                    }
                    
                    loginSuccess();
                }
            } catch(e) { }
        }

        async function handleRegister() {
            const name = document.getElementById("reg-name").value.trim();
            const username = document.getElementById("reg-username").value.trim();
            const city = document.getElementById("reg-city").value.trim();
            const password = document.getElementById("reg-password").value;
            const email = document.getElementById("reg-email").value.trim();
            const marketing = document.getElementById("reg-marketing").checked;
            const kvkk = document.getElementById("reg-kvkk").checked;
            const privacy = document.getElementById("reg-privacy").checked;
            const refCode = document.getElementById("reg-ref-code").value.trim();
            const refReward = document.getElementById("reg-ref-reward").value;
            
            if(!name || !username || !city || !password) return alert("Lütfen Ad Soyad, Kullanıcı Adı, Şehir ve Şifre alanlarını doldurun!");
            
            // Gmail zorunlu değil, ama girilmişse geçerli olmalı
            if(email && !email.toLowerCase().endsWith('@gmail.com')) return alert("Girdiğiniz e-posta @gmail.com uzantılı değil. Lütfen Gmail adresinizi girin ya da alanı boş bırakın.");
            
            // Referans kodu varsa Gmail zorunlu
            if(refCode && !email) return alert("Referans kodu kullanabilmek için @gmail.com adresinizi girmeniz zorunludur! (Spam koruması)");
            if(refCode && !email.toLowerCase().endsWith('@gmail.com')) return alert("Referans kodu kullanabilmek için @gmail.com uzantılı e-posta girmeniz zorunludur! (Spam koruması)");
            
            if(password.length < 4) return alert("Şifre en az 4 karakter olmalıdır!");
            if(!kvkk) return alert("Kayıt olmak için Kullanıcı Sözleşmesi ve KVKK metnini onaylamanız gerekmektedir!");
            if(!privacy) return alert("Kayıt olmak için Gizlilik Sözleşmesi ve Kullanım Şartları'nı onaylamanız gerekmektedir!");
            
            try {
                const payload = {
                    name: name,
                    username: username,
                    city: city,
                    password: password,
                    email: email,
                    marketing: marketing
                };
                
                if (refCode) {
                    payload.ref_code = refCode;
                    payload.ref_reward = refReward;
                }
                
                const res = await sendAction('register', payload);
                
                if(res.status === 'ok') {
                    alert("Kayıt başarılı! Aramıza hoş geldin. Şimdi giriş yapabilirsin.");
                    showLoginTab();
                    document.getElementById("login-username").value = username;
                } else if (res.status === 'needs_verification') {
                    verificationUsername = res.username;
                    document.getElementById("verify-code-input").value = "";
                    document.getElementById("email-verify-modal").classList.remove("hidden");
                    alert("Kayıt başarılı! E-posta adresinize bir doğrulama kodu gönderdik.");
                }
            } catch(e) { 
                console.error(e);
            }
        }

        function openKvkkModal() {
            document.getElementById("kvkk-modal").classList.remove("hidden");
        }

        function closeKvkkModal() {
            document.getElementById("kvkk-modal").classList.add("hidden");
            document.getElementById("reg-kvkk").checked = true;
        }

        function showLoginTab() {
            document.getElementById("login-form").classList.remove("hidden");
            document.getElementById("register-form").classList.add("hidden");
            document.getElementById("login-tab-btn").className = "flex-1 py-3 bg-gradient-to-r from-sky-700 to-sky-500 text-white rounded-lg font-black text-sm  tracking-widest uppercase transition-all scale-in-anim";
            document.getElementById("register-tab-btn").className = "flex-1 py-3 bg-transparent text-zinc-400 rounded-lg font-bold text-sm tracking-widest uppercase transition-all hover:text-white";
        }

        function showRegisterTab() {
            document.getElementById("login-form").classList.add("hidden");
            document.getElementById("register-form").classList.remove("hidden");
            document.getElementById("register-tab-btn").className = "flex-1 py-3 bg-gradient-to-r from-sky-700 to-sky-500 text-white rounded-lg font-black text-sm  tracking-widest uppercase transition-all scale-in-anim";
            document.getElementById("login-tab-btn").className = "flex-1 py-3 bg-transparent text-zinc-400 rounded-lg font-bold text-sm tracking-widest uppercase transition-all hover:text-white";
        }



        const TITLES = [
            {min:0,     max: 99,    name: "Acemi",        color: "text-zinc-500",  icon: "🌱", next: 100},
            {min:100,   max: 499,   name: "Çaylak",       color: "text-zinc-400",  icon: "🚲", next: 500},
            {min:500,   max: 999,   name: "Sürücü",       color: "text-sky-400",   icon: "🏔️", next: 1000},
            {min:1000,  max: 1999,  name: "Deneyimli",    color: "text-blue-400",  icon: "⚡", next: 2000},
            {min:2000,  max: 3999,  name: "Rampa Savaşçısı", color: "text-indigo-400",icon: "🛡️", next: 4000},
            {min:4000,  max: 6999,  name: "Usta",         color: "text-orange-400",icon: "🔥", next: 7000},
            {min:7000,  max: 9999,  name: "Elite",        color: "text-rose-400",  icon: "💥", next: 10000},
            {min:10000, max: 19999, name: "Şampiyon",     color: "text-yellow-400",icon: "🏆", next: 20000},
            {min:20000, max: 49999, name: "Efsane",       color: "text-sky-400",   icon: "👑", next: 50000},
            {min:50000, max: 999999,name: "Downhill Efsanesi", color: "text-prem-rainbow", icon: "🌟", next: null}
        ];

        function getTitle(xp) {
            return TITLES.find(t => xp >= t.min && xp <= t.max) || TITLES[TITLES.length - 1];
        }
        
        function getTitleProgress(xp) {
            const t = getTitle(xp);
            if (!t.next) return {percent: 100, xpLeft: 0, nextName: null};
            const range = t.next - t.min;
            const prog = xp - t.min;
            return {
                percent: Math.min(Math.round((prog / range) * 100), 100),
                xpLeft: t.next - xp,
                nextName: TITLES.find(tt => tt.min === t.next)?.name || null,
                nextIcon: TITLES.find(tt => tt.min === t.next)?.icon || ''
            };
        }
        
        const verifiedTick = `<svg class="w-4 h-4 inline-block text-blue-500 " fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"></path></svg>`;

        // === KALICI GÖREVLER (bir kere tamamlanır) ===
        const MISSIONS = [
            { id: "m1",  title: "İlk Adım",      desc: "Uygulamaya ilk kez giriş yap.",          target: 1,   type: "login_streak",   xp: 50,   icon: "👋", badge: null },
            { id: "m2",  title: "Bağımlı",        desc: "7 gün üst üste giriş yap.",              target: 7,   type: "login_streak",   xp: 200,  icon: "🔥", badge: "Seri Girişçi" },
            { id: "m3",  title: "Sadık Üye",      desc: "30 gün üst üste giriş yap.",             target: 30,  type: "login_streak",   xp: 2000, icon: "💎", badge: "Demir Üye" },
            { id: "m4",  title: "Çılgın",         desc: "100 gün üst üste giriş yap.",            target: 100, type: "login_streak",   xp: 10000,icon: "⚡", badge: "100 Gün Ustası" },
            { id: "m5",  title: "Sohbete Katıl",  desc: "Gruba 1 mesaj gönder.",                  target: 1,   type: "total_messages", xp: 20,   icon: "💬", badge: null },
            { id: "m6",  title: "Geveze",         desc: "Gruba 50 mesaj gönder.",                 target: 50,  type: "total_messages", xp: 300,  icon: "🗣️", badge: "Sohbet Tutkunu" },
            { id: "m7",  title: "Chat Efsanesi",  desc: "Gruba 200 mesaj gönder.",                target: 200, type: "total_messages", xp: 1000, icon: "👑", badge: "Chat Efsanesi" },
            { id: "m8",  title: "Kâşif",          desc: "Haritaya 1 rampa ekle.",                 target: 1,   type: "markers",        xp: 50,   icon: "📍", badge: "Harita Kâşifi" },
            { id: "m9",  title: "Haritacı",       desc: "Haritaya 10 rampa ekle.",                target: 10,  type: "markers",        xp: 500,  icon: "🗺️", badge: "Haritacı" },
            { id: "m10", title: "İlk Satış",      desc: "Pazara 1 ilan ekle.",                    target: 1,   type: "market",         xp: 50,   icon: "🛒", badge: "Esnaf" },
            { id: "m11", title: "Pazar Ustası",   desc: "Pazara 5 ilan ekle.",                    target: 5,   type: "market",         xp: 300,  icon: "💰", badge: "Pazar Ustası" },
            { id: "m12", title: "Organizatör",    desc: "1 sürüş buluşması oluştur.",             target: 1,   type: "events",         xp: 100,  icon: "🤝", badge: "Organizatör" },
            { id: "m13", title: "Topluluk Lideri",desc: "5 sürüş buluşması oluştur.",             target: 5,   type: "events",         xp: 500,  icon: "🏆", badge: "Topluluk Lideri" },
        ];

        // === GÜNLÜK GÖREVLER (her gün sıfırlanır) ===
        function getDailyMissions() {
            // Güne göre deterministik görev seti (aynı gün herkes aynı görevi görür)
            const dayNum = Math.floor(Date.now() / 86400000);
            const todayKey = new Date().toISOString().split('T')[0];
            const sets = [
                [{ id: "d1", title: "Günlük Giriş",    desc: "Bugün giriş yap.",           target: 1,  type: "daily_login",   xp: 30,  icon: "☀️" },
                 { id: "d2", title: "Sohbet Et",        desc: "Bugün 3 mesaj gönder.",       target: 3,  type: "daily_msg",     xp: 50,  icon: "💬" },
                 { id: "d3", title: "Haritayı Keşfet",  desc: "Haritada 1 nokta ekle.",      target: 1,  type: "daily_marker",  xp: 80,  icon: "📍" }],
                [{ id: "d1", title: "Günlük Giriş",    desc: "Bugün giriş yap.",           target: 1,  type: "daily_login",   xp: 30,  icon: "☀️" },
                 { id: "d4", title: "AI Sor",           desc: "AI'a 1 soru sor.",            target: 1,  type: "daily_ai",      xp: 40,  icon: "🤖" },
                 { id: "d5", title: "Pazar Gez",        desc: "Bir ilana bak.",              target: 1,  type: "daily_market",  xp: 20,  icon: "🛒" }],
                [{ id: "d1", title: "Günlük Giriş",    desc: "Bugün giriş yap.",           target: 1,  type: "daily_login",   xp: 30,  icon: "☀️" },
                 { id: "d6", title: "Aktif Ol",         desc: "Bugün 5 mesaj gönder.",       target: 5,  type: "daily_msg",     xp: 70,  icon: "🔥" },
                 { id: "d7", title: "Sürüşe Çık",       desc: "Radar modunu aç.",            target: 1,  type: "daily_radar",   xp: 60,  icon: "📡" }],
            ];
            const todaySet = sets[dayNum % sets.length];
            return { missions: todaySet, key: todayKey };
        }

        // === HAFTALIK GÖREVLER (her Pazartesi sıfırlanır) ===
        function getWeeklyMissions() {
            const weekNum = Math.floor(Date.now() / (86400000 * 7));
            const now = new Date();
            const monday = new Date(now);
            monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
            const weekKey = monday.toISOString().split('T')[0];
            const sets = [
                [{ id: "w1", title: "Haftalık Konuşmacı", desc: "Bu hafta 20 mesaj gönder.",  target: 20, type: "weekly_msg",    xp: 200, icon: "💬" },
                 { id: "w2", title: "Harita Gezgini",     desc: "Bu hafta 2 rampa ekle.",      target: 2,  type: "weekly_marker", xp: 150, icon: "🗺️" }],
                [{ id: "w3", title: "Topluluk Üyesi",     desc: "Bu hafta 1 etkinlik oluştur.",target: 1,  type: "weekly_event",  xp: 250, icon: "📅" },
                 { id: "w4", title: "Aktif Tüccar",       desc: "Bu hafta 1 ilan ver.",        target: 1,  type: "weekly_market", xp: 150, icon: "🛒" }],
                [{ id: "w5", title: "Sürüş Ustası",       desc: "Bu hafta 3 kez radar aç.",    target: 3,  type: "weekly_radar",  xp: 200, icon: "🚴" },
                 { id: "w6", title: "Soru Sorular",        desc: "Bu hafta 5 AI sorusu sor.",   target: 5,  type: "weekly_ai",     xp: 180, icon: "🤖" }],
            ];
            return { missions: sets[weekNum % sets.length], key: weekKey };
        }

        function resizeImage(file, maxSize) {
            return new Promise((resolve) => {
                if(!file) { resolve(null); return; }
                const reader = new FileReader();
                reader.onload = (e) => {
                    const img = new Image();
                    img.onload = () => {
                        let w = img.width, h = img.height;
                        if(w > maxSize || h > maxSize) {
                            if(w > h) { h = Math.round(h * maxSize / w); w = maxSize; }
                            else      { w = Math.round(w * maxSize / h); h = maxSize; }
                        }
                        const canvas = document.createElement('canvas');
                        canvas.width = w; canvas.height = h;
                        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                        resolve(canvas.toDataURL('image/jpeg', 0.82));
                    };
                    img.onerror = () => resolve(null);
                    img.src = e.target.result;
                };
                reader.onerror = () => resolve(null);
                reader.readAsDataURL(file);
            });
        }

        const supaUrl = '{{ supabase_url }}';
        const supaKey = '{{ supabase_key }}';
        // DUZELTME #4: window.supabase CDN'den gecikmeli yuklenebilir.
        // Direkt createClient() cagrisi "window.supabase is not defined" hatasi verir
        // ve bu, sonraki TUM JS kodunun calismasini durdurur (butonlar donuyor).
        let supaClient = null;
        if(window.supabase) {
            supaClient = window.supabase.createClient(supaUrl, supaKey);
        } else {
            console.error("[FreeriderTR] Supabase JS SDK yuklenemedi. Realtime ozellikler calismiyor.");
            // Script hatasi tum sayfayi kilitlememesi icin devam et
        }

        // ==============================================================
        // ÇEVRİM İÇİ DURUM YARDIMCI FONKSİYONLARI
        // ==============================================================
        function getOnlineStatus(user) {
            if (!user || !user.stats) return { status: 'offline', label: '' };
            const ts = user.stats.last_seen_ts;
            if (!ts) return { status: 'offline', label: '' };
            const nowSec = Math.floor(Date.now() / 1000);
            const diff = nowSec - ts;
            if (diff < 300) return { status: 'online', label: 'Şu an aktif' };
            if (diff < 3600) {
                const mins = Math.floor(diff / 60);
                return { status: 'recent', label: `${mins} dk önce aktifti` };
            }
            if (diff < 86400) {
                const hrs = Math.floor(diff / 3600);
                return { status: 'today', label: `${hrs} saat önce` };
            }
            return { status: 'offline', label: '' };
        }

        function getOnlineHTML(user, showLabel = true) {
            const s = getOnlineStatus(user);
            if (s.status === 'online') {
                return showLabel
                    ? `<span class="online-dot-sm"></span><span class="online-label">${s.label}</span>`
                    : `<span class="online-dot-sm"></span>`;
            }
            if (s.status === 'recent') {
                return showLabel
                    ? `<span class="recent-dot"></span><span class="recent-label">${s.label}</span>`
                    : `<span class="recent-dot"></span>`;
            }
            return '';
        }

        // ==============================================================
        // GERÇEK ALEV & BUZ PARTİKÜL SİSTEMİ (Ultra+)
        // ==============================================================
        const _particleTimers = {};

        function startParticles(canvasId, type) {
            const canvas = document.getElementById(canvasId);
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            // Canvas wraps around the circular avatar
            const SIZE = canvas.width = canvas.height = 160;
            const CX = SIZE / 2, CY = SIZE / 2;
            const R = 68; // avatar radius
            let particles = [];
            let running = true;
            const isIce = type === 'ice';

            function mkFireParticle() {
                // Spawn along bottom arc of circle
                const angle = (Math.random() * Math.PI) + Math.PI; // bottom half: pi to 2pi
                const spawnR = R + 2;
                return {
                    x: CX + Math.cos(angle) * spawnR,
                    y: CY + Math.sin(angle) * spawnR,
                    vx: Math.cos(angle) * -(0.3 + Math.random()*0.5) + (Math.random()-0.5)*0.6,
                    vy: -(0.8 + Math.random()*1.4),
                    size: 4 + Math.random()*5,
                    life: 1,
                    decay: 0.022 + Math.random()*0.02,
                    phase: Math.random() * Math.PI * 2  // wobble phase
                };
            }

            function mkIceParticle() {
                // Spawn around full circle border
                const angle = Math.random() * Math.PI * 2;
                const spawnR = R + 1;
                return {
                    x: CX + Math.cos(angle) * spawnR,
                    y: CY + Math.sin(angle) * spawnR,
                    angle: angle,
                    vr: (Math.random()-0.5)*0.01,  // angular drift
                    r: spawnR + Math.random()*8,
                    size: 2 + Math.random()*3.5,
                    life: 1,
                    decay: 0.012 + Math.random()*0.015,
                    points: Math.floor(5 + Math.random()*3),
                    rotation: Math.random()*Math.PI
                };
            }

            function drawFireParticle(p) {
                const wobble = Math.sin(p.phase + performance.now()*0.004) * 1.2;
                p.x += p.vx + wobble * 0.15;
                p.y += p.vy;
                p.size *= 0.978;
                p.life -= p.decay;
                if(p.life <= 0) return false;
                const a = Math.max(0, p.life);
                const t = 1 - p.life;
                // fire color: deep red -> orange -> yellow at tip
                const h = 15 + t * 35;  // 15=red-orange, 50=yellow
                const l = 35 + t * 25;
                const grad = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.size);
                grad.addColorStop(0, `hsla(${h},100%,${l+20}%,${a*0.9})`);
                grad.addColorStop(0.4, `hsla(${h},100%,${l}%,${a*0.6})`);
                grad.addColorStop(1, `hsla(${h-5},90%,${l-10}%,0)`);
                ctx.beginPath();
                ctx.arc(p.x, p.y, Math.max(0.1,p.size), 0, Math.PI*2);
                ctx.fillStyle = grad;
                ctx.globalAlpha = a;
                ctx.fill();
                return true;
            }

            function drawIceParticle(p) {
                p.angle += p.vr;
                p.x = CX + Math.cos(p.angle) * p.r;
                p.y = CY + Math.sin(p.angle) * p.r;
                p.life -= p.decay;
                if(p.life <= 0) return false;
                const a = Math.max(0, p.life) * 0.85;
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotation + performance.now()*0.0008);
                ctx.globalAlpha = a;
                // Draw snowflake/crystal shape
                const n = p.points;
                const s = Math.max(0.5, p.size);
                ctx.beginPath();
                for(let i=0;i<n*2;i++){
                    const r2 = i%2===0 ? s : s*0.4;
                    const ang2 = (i/n)*Math.PI;
                    i===0 ? ctx.moveTo(Math.cos(ang2)*r2,Math.sin(ang2)*r2)
                           : ctx.lineTo(Math.cos(ang2)*r2,Math.sin(ang2)*r2);
                }
                ctx.closePath();
                ctx.fillStyle = `rgba(180,230,255,${a*0.7})`;
                ctx.strokeStyle = `rgba(200,245,255,${a})`;
                ctx.lineWidth = 0.5;
                ctx.fill(); ctx.stroke();
                ctx.restore();
                return true;
            }

            function frame() {
                if (!running) return;
                ctx.clearRect(0, 0, SIZE, SIZE);
                // Spawn
                const spawnRate = isIce ? 0.35 : 0.6;
                if(Math.random() < spawnRate) particles.push(isIce ? mkIceParticle() : mkFireParticle());
                if(Math.random() < spawnRate*0.5) particles.push(isIce ? mkIceParticle() : mkFireParticle());
                // Draw & filter
                particles = particles.filter(p => isIce ? drawIceParticle(p) : drawFireParticle(p));
                ctx.globalAlpha = 1;
                requestAnimationFrame(frame);
            }
            frame();
            return () => { running = false; };
        }

        function attachParticles(wrapId, canvasId, type) {
            // stop previous if exists
            if (_particleTimers[canvasId]) { _particleTimers[canvasId](); delete _particleTimers[canvasId]; }
            const stop = startParticles(canvasId, type);
            if (stop) _particleTimers[canvasId] = stop;
        }

        // Profil avatarına parçacık ekle/kaldır
        function applyAvatarEffect(effect) {
            const wrap = document.getElementById('profile-avatar-wrap');
            let canvas = document.getElementById('profile-particle-canvas');
            if (!wrap) return;
            if (effect === 'fire' || effect === 'ice') {
                if (!canvas) {
                    canvas = document.createElement('canvas');
                    canvas.id = 'profile-particle-canvas';
                    // Centered overlay, slightly larger than avatar (128px = w-32)
                    canvas.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:160px;height:160px;pointer-events:none;z-index:50;';
                    canvas.width = 160; canvas.height = 160;
                    wrap.appendChild(canvas);
                }
                attachParticles('profile-avatar-wrap','profile-particle-canvas', effect);
            } else {
                if (canvas) { canvas.remove(); }
                if (_particleTimers['profile-particle-canvas']) { _particleTimers['profile-particle-canvas'](); }
            }
        }

        // Leaderboard/Chat avatarlarına da mini parçacık ekle
        function maybeAddMiniParticles(imgEl, username) {
            const u = db.users.find(x => x.username === username);
            if (!u || !u.stats) return;
            const effect = u.stats.avatar_effect || 'none';
            if (effect !== 'fire' && effect !== 'ice') return;
            const pid = 'pcanv-' + username.replace(/[^a-zA-Z0-9]/g,'');
            if (document.getElementById(pid)) return; // already added
            const wrap = imgEl.parentElement;
            if (!wrap) return;
            const origPos = wrap.style.position;
            wrap.style.position = 'relative';
            wrap.style.overflow = 'visible';
            const canvas = document.createElement('canvas');
            canvas.id = pid;
            canvas.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:80px;height:80px;pointer-events:none;z-index:50;';
            canvas.width = 80; canvas.height = 80;
            wrap.appendChild(canvas);
            attachParticles(wrap.id || '', pid, effect);
        }

        // ==============================================================
        // Heartbeat — her dakikada sunucuya "burdayım" gönder + lokal güncelle
        async function sendHeartbeat() {
            if (!currentUser) return;
            const nowSec = Math.floor(Date.now() / 1000);
            // Lokal güncelle - anında yansısın
            if (currentUser.stats) currentUser.stats.last_seen_ts = nowSec;
            const me = db.users.find(u => u.username === currentUser.username);
            if (me && me.stats) me.stats.last_seen_ts = nowSec;
            // Sunucuya da gönder; üyelik süresi dolmuşsa UI'ı güncelle
            try {
                const hbRes = await fetch('/api/heartbeat', { method: 'POST' });
                if (hbRes.ok) {
                    const hbData = await hbRes.json();
                    if (hbData.premium_revoked) {
                        // Üyelik sona erdi – lokal state sıfırla
                        if (currentUser.stats) {
                            currentUser.stats.premium_tier = 0;
                            currentUser.stats.premium_color = '';
                            delete currentUser.stats.premium_expire_date;
                            delete currentUser.stats.expiry_ts;
                        }
                        if (me && me.stats) {
                            me.stats.premium_tier = 0;
                            me.stats.premium_color = '';
                            delete me.stats.premium_expire_date;
                            delete me.stats.expiry_ts;
                        }
                        showToast('⚠️ Üyeliğin sona erdi. Devam etmek için yenile!');
                    }
                }
            } catch(e) {}
        }

        // ==============================================================
        // ONESIGNAL PUSH BİLDİRİM
        // ==============================================================
        async function requestPushPermission() {
            try {
                // İzin zaten verilmişse tekrar sormadan login yap
                const alreadyGranted = Notification.permission === 'granted';
                let permission = alreadyGranted;
                if (!alreadyGranted) {
                    permission = await OneSignal.Notifications.requestPermission();
                    console.log('OneSignal bildirim izni:', permission);
                }
                if (permission) {
                    if (currentUser) {
                        window.OneSignalDeferred = window.OneSignalDeferred || [];
                        window.OneSignalDeferred.push(async function(OneSignal) {
                            try {
                                await OneSignal.login(currentUser.username);
                                console.log('✅ OneSignal login (izin sonrası):', currentUser.username);
                                // İzin verildi → subscription ID'yi hemen kaydet
                                await saveOneSignalPlayerId(OneSignal);
                            } catch(e) { console.error('OneSignal login hatası:', e); }
                        });
                    }
                }
                updateNotifBtnState();
            } catch(e) { console.error('OneSignal izin hatası:', e); }
        }

        // OneSignal subscription ID'sini backend'e kaydeder
        async function saveOneSignalPlayerId(OneSignal) {
            try {
                // Kisa bir bekleme — subscription aktif olana kadar
                await new Promise(r => setTimeout(r, 800));
                const subId = OneSignal.User.PushSubscription.id;
                if (!subId) {
                    console.warn('⚠️ OneSignal subscription ID henüz hazır değil');
                    return;
                }
                const resp = await fetch('/api/save_push_id', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ player_id: subId })
                });
                const result = await resp.json();
                if (result.status === 'ok') {
                    console.log('✅ OneSignal player_id kaydedildi:', subId.slice(0,20) + '...');
                } else {
                    console.warn('⚠️ player_id kaydedilemedi:', result);
                }
            } catch(e) {
                console.error('❌ saveOneSignalPlayerId hatası:', e);
            }
        }

        async function setOneSignalUser() {
            if(!currentUser) return;
            
            // Android Native App'e HEMEN kullanıcı kimliğini bildir
            // Bu çağrı OneSignal web SDK'dan BAĞIMSIZ olmalı — WebView'da web SDK başarısız olsa bile bu çalışsın
            try {
                if (typeof window.Android !== 'undefined' && window.Android !== null && typeof window.Android.setUserId === 'function') {
                    window.Android.setUserId(currentUser.username);
                    console.log('Android Native setUserId called:', currentUser.username);
                }
            } catch(e) {
                console.error('Android setUserId error:', e);
            }
            
            // OneSignal Web SDK login — ayrı try/catch ile, hata olsa Android çağrısını etkilemez
            window.OneSignalDeferred = window.OneSignalDeferred || [];
            window.OneSignalDeferred.push(async function(OneSignal) {
                try {
                    await OneSignal.login(currentUser.username);
                    console.log('OneSignal web login OK:', currentUser.username);
                    
                    const permission = OneSignal.Notifications.permission;
                    if (permission) {
                        await saveOneSignalPlayerId(OneSignal);
                    }
                } catch(e) {
                    // WebView'da OneSignal web SDK başarısız olabilir — bu normaldir, Android native yeterli
                    console.warn('OneSignal web SDK login failed (expected in WebView):', e.message || e);
                }
            });
        }

        function getUserPremiumTier(username) { 
            const u = db.users.find(x => x.username === username); 
            if (!u || !u.stats) return 0; 
            return parseInt(u.stats.premium_tier) || 0; 
        }
        
        function getUserPremiumColor(username) { 
            const u = db.users.find(x => x.username === username); 
            if (!u || !u.stats || !u.stats.premium_tier) return null; 
            return u.stats.premium_color || 'std-blue'; 
        }
        
        function getPremiumTextClass(color) { 
            if(!color) return ''; 
            if(color.startsWith('#')) return ''; 
            
            const map = {
                'std-blue': 'text-blue-500 ', 'std-yellow': 'text-yellow-500 ', 'std-pink': 'text-pink-500 ', 'std-green': 'text-green-500 ',
                'dlx-blue': 'text-dlx-blue', 'dlx-yellow': 'text-dlx-yellow', 'dlx-pink': 'text-dlx-pink', 'dlx-green': 'text-dlx-green',
                'ult-gold': 'text-prem-gold', 'ult-rainbow': 'text-prem-rainbow',
                'ult-blue': 'text-prem-blue', 'ult-green': 'text-prem-green', 'ult-pink': 'text-prem-pink',
                'rainbow': 'text-prem-rainbow'
            };
            return map[color] || ''; 
        }

        function getPremiumInlineStyle(color) {
            if(color && color.startsWith('#')) {
                return `color: ${color} !important; text-shadow: 0 0 10px ${color}; font-weight: 800;`;
            }
            return '';
        }
        
        function getPremiumBorderClass(username) { 
            const u = db.users.find(x => x.username === username);
            if(!u || !u.stats) return 'border-zinc-700';
            
            let classes = "";
            let color = u.stats.premium_color || 'std-blue';
            let effect = u.stats.avatar_effect || 'none';

            if(effect === 'fire') classes += " effect-fire";
            if(effect === 'ice') classes += " effect-ice";

            if(!color.startsWith('#')) {
                const map = {
                    'std-blue': 'border-blue-500 ', 'std-yellow': 'border-yellow-500 ', 'std-pink': 'border-pink-500 ', 'std-green': 'border-green-500 ',
                    'dlx-blue': 'border-dlx-blue', 'dlx-yellow': 'border-dlx-yellow', 'dlx-pink': 'border-dlx-pink', 'dlx-green': 'border-dlx-green',
                    'ult-gold': 'border-prem-gold', 'ult-rainbow': 'border-prem-rainbow',
                    'ult-blue': 'border-prem-blue', 'ult-green': 'border-prem-green', 'ult-pink': 'border-prem-pink',
                    'rainbow': 'border-prem-rainbow'
                };
                classes += " " + (map[color] || 'border-zinc-700');
            }
            return classes.trim() || 'border-zinc-700'; 
        }

        function createColorBtn(id, label, current) {
            const isActive = id === current;
            return `<button onclick="changeColor('${id}')" class="px-3 py-1.5 rounded-lg text-[10px] uppercase tracking-widest font-bold ${isActive ? 'bg-white text-black ' : 'bg-zinc-800 text-zinc-300'} border border-zinc-700 hover:bg-zinc-700 transition">${label}</button>`;
        }

        function createEffectBtn(id, label, current) {
            const isActive = id === current;
            return `<button onclick="changeEffect('${id}')" class="px-3 py-1.5 rounded-lg text-[10px] uppercase tracking-widest font-bold ${isActive ? 'bg-white text-black ' : 'bg-zinc-800 text-zinc-300'} border border-zinc-700 hover:bg-zinc-700 transition">${label}</button>`;
        }

        async function changeColor(colorId) {
            await sendAction('update_premium_color', { color: colorId, effect: currentUser.stats.avatar_effect || 'none' });
            if(currentUser && currentUser.stats) {
                currentUser.stats.premium_color = colorId;
            }
            updateProfileUI();
        }

        async function applyCustomHex() {
            const hex = document.getElementById("custom-hex-color").value;
            await changeColor(hex);
            alert("Yeni renginiz uygulandı!");
        }

        async function changeEffect(effectId) {
            await sendAction('update_premium_color', { color: currentUser.stats.premium_color || 'std-blue', effect: effectId });
            if(currentUser && currentUser.stats) {
                currentUser.stats.avatar_effect = effectId;
            }
            updateProfileUI();
            alert("Profil efektiniz uygulandı!");
        }

        let _myLastRank = null;

        function checkLeaderboardPosition(oldRank) {
            if(!currentUser || !db.users) return;
            const sorted = [...db.users].sort((a,b) => (b.xp||0)-(a.xp||0));
            const newRank = sorted.findIndex(u => u.username === currentUser.username) + 1;
            if(newRank > 0) {
                if(oldRank && newRank < oldRank) {
                    showRankToast(newRank, oldRank, 'up');
                } else if(oldRank && newRank > oldRank) {
                    showRankToast(newRank, oldRank, 'down');
                }
                _myLastRank = newRank;
            }
        }

        function showRankToast(newRank, oldRank, dir) {
            const isUp = dir === 'up';
            const toast = document.createElement('div');
            toast.className = 'fixed top-10 left-1/2 -translate-x-1/2 z-[99999] px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2 scale-in-anim pointer-events-none opacity-90';
            toast.style.background = isUp ? 'linear-gradient(135deg,#16a34a,#15803d)' : 'linear-gradient(135deg,#0ea5e9,#0284c7)';
            toast.style.color = '#fff';
            toast.innerHTML = (isUp ? '📈' : '📉') +
                `<div><div class="text-[10px] uppercase tracking-widest opacity-80">${isUp ? 'Sıralama Yükseldi!' : 'Sıralama Düştü!'}</div>` +
                `<div>${oldRank}. sira -> ${newRank}. sıra</div></div>`;
            document.body.appendChild(toast);
            haptic(isUp ? [30,20,30,20,50] : [100,50,100]);
            setTimeout(() => { toast.style.opacity='0'; toast.style.transition='opacity 0.4s'; setTimeout(()=>toast.remove(),400); }, 1500);
        }

        // Mobil titreşim geri bildirimi
        function haptic(pattern = [10]) {
            if('vibrate' in navigator) { try { navigator.vibrate(pattern); } catch(e) {} }
        }

        // ==============================================================
        // BİLDİRİM İZİN YÖNETİMİ (PROFİL BUTONU)
        // ==============================================================
        async function handleNotifPermission() {
            if (!('Notification' in window)) {
                alert("Bu tarayıcı bildirimleri desteklemiyor.");
                return;
            }
            if (Notification.permission === 'denied') {
                alert("Bildirim izni engellendi. Lütfen tarayıcı ayarlarından FreeriderTR için bildirimlere izin verin.");
                return;
            }
            haptic([10, 50, 10]);
            await requestPushPermission();
        }

        function updateNotifBtnState() {
            const btn = document.getElementById('notif-perm-btn');
            const icon = document.getElementById('notif-btn-icon');
            const txt = document.getElementById('notif-btn-text');
            if (!btn || !('Notification' in window)) return;
            if (Notification.permission === 'granted') {
                btn.className = 'w-full bg-green-900/40 border border-green-600/50 text-green-400 py-4 rounded-xl font-bold text-sm mt-4 btn-premium-hover flex items-center justify-center gap-2 transition-all';
                if (icon) icon.textContent = '✅';
                if (txt) txt.textContent = 'Bildirimler Açık';
            } else if (Notification.permission === 'denied') {
                btn.className = 'w-full bg-red-950/40 border border-sky-800/50 text-sky-300 py-4 rounded-xl font-bold text-sm mt-4 flex items-center justify-center gap-2 transition-all cursor-not-allowed';
                if (icon) icon.textContent = '🔕';
                if (txt) txt.textContent = 'Bildirimler Engellendi';
            } else {
                btn.className = 'w-full bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-300 py-4 rounded-xl font-bold text-sm mt-4 btn-premium-hover flex items-center justify-center gap-2';
                if (icon) icon.textContent = '🔔';
                if (txt) txt.textContent = 'Bildirimleri Aç';
            }
        }

        // DUZELTME #3: sendAction — silent parametre eklendi.
        // Onceki kodda alert() + throw() birlikte kullaniliyordu:
        //   - alert() kullaniciya popup gosterir
        //   - throw() cagrilan yerin catch blogu TEKRAR hata isliyordu
        // Bu cift-hata dongusu butonlara basilinca donmaya yol aciyordu.
        // silent=true gecilirse alert bastiriliyor, sadece exception firlatiliyor.
        async function sendAction(action, data, silent = false) {
            let res;
            try {
                res = await fetch('/api/data', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' }, 
                    body: JSON.stringify({ action: action, data: data }) 
                });
            } catch(networkErr) {
                const msg = navigator.onLine 
                    ? 'Sunucuya ulaşılamadı. Sunucu geçici olarak kapatılmış olabilir, lütfen tekrar dene.'
                    : 'Internet bağlantın yok. Lütfen bağlantını kontrol et.';
                if(!silent) alert(msg);
                throw networkErr;
            }
            // Sunucu 500/HTML döndürdüğünde JSON parse crash'ını önle
            let result;
            try {
                result = await res.json();
            } catch(parseErr) {
                if(!silent) alert(`Sunucu hatası (${res.status}). Sunucu yanıtı geçersiz. Lütfen tekrar dene.`);
                throw parseErr;
            }
            if(result.status === 'error') { 
                if(result.message === 'Giris yapmaniz gerekiyor!' || result.message === 'Giris yapmalisiniz!') {
                    alert("Sunucu guncellendi veya oturumun suresi doldu. Lutfen tekrar giris yap.");
                    logout();
                    return;
                }
                if(!silent) alert(result.message); 
                throw new Error(result.message); 
            } 
            return result;
        }

        async function loadData(silent = false) {
            try {
                const res = await fetch('/api/data'); 
                const newData = await res.json();
                
                // Mevcut mesajları koru (realtime + cache)
                const existingMessages = db.messages || [];
                const existingDms = db.dms || [];
                
                db = newData;
                
                // Tüm array alanlarını garantile
                if(!db.stories)  db.stories  = [];
                if(!db.messages) db.messages = [];
                if(!db.dms)      db.dms      = [];
                if(!db.users)    db.users    = [];
                if(!db.markers)  db.markers  = [];
                if(!db.market)   db.market   = [];
                if(!db.events)   db.events   = [];
                if(!db.news)     db.news     = [];
                if(!db.banned)   db.banned   = [];
                
                // Sunucu boş veya az dönerse mevcut mesajları koru
                existingMessages.forEach(m => {
                    if(!db.messages.find(x => x.id === m.id)) db.messages.push(m);
                });
                existingDms.forEach(m => {
                    if(!db.dms.find(x => x.id === m.id)) db.dms.push(m);
                });
                
                // Mesajları kronolojik olarak sırala (UUID bug'ını önlemek için created_at veya timestamp id kullanılır)
                db.messages.sort((a,b) => {
                    let timeA = 0, timeB = 0;
                    if (a.created_at) timeA = new Date(a.created_at).getTime();
                    else if (a.id && /^\\d{13}$/.test(String(a.id))) timeA = parseInt(a.id);
                    
                    if (b.created_at) timeB = new Date(b.created_at).getTime();
                    else if (b.id && /^\\d{13}$/.test(String(b.id))) timeB = parseInt(b.id);
                    
                    if (timeA === timeB) return String(a.id).localeCompare(String(b.id));
                    return timeA - timeB;
                });
                window._chatNeedsFullRedraw = true;
                
                // LocalStorage'a yedekle
                try {
                    localStorage.setItem('fr_msg_cache', JSON.stringify(db.messages.slice(-50)));
                } catch(e) {}
                
                if (currentUser) {
                    const me = db.users.find(u => u.username === currentUser.username);
                    if (me) { 
                        const oldRank = _myLastRank;
                        // Admin koruması: role üzerine yazılmasını önle
                        const wasAdmin = (currentUser.role === 'Admin' || currentUser.username === 'Admin' || currentUser.username.toLowerCase() === 'admin');
                        const oldChatRules = currentUser.accepted_chat_rules;
                        currentUser = me;
                        if (wasAdmin) {
                            currentUser.role = 'Admin';
                        }
                        if (oldChatRules) {
                            currentUser.accepted_chat_rules = true;
                        }
                        localStorage.setItem("fr_user", JSON.stringify(currentUser)); 
                        updateProfileUI(); 
                        checkMissions();
                        checkLeaderboardPosition(oldRank); 
                        
                        // Referans sekmesi açıksa hemen güncelle
                        if(!document.getElementById('screen-referral').classList.contains('hidden')) {
                            renderReferralTab();
                        }
                    }
                    if (db.banned.includes(currentUser.username) || (db.maintenance && currentUser.role !== 'Admin')) {
                        logout(); 
                    }
                }
                
                if(currentMarkerId && !document.getElementById("marker-sheet").classList.contains("hidden")) {
                    const m = db.markers.find(x => x.id === currentMarkerId);
                    if(m) showMarkerSheet(m, true);
                }
                if(currentEventId && !document.getElementById("event-sheet").classList.contains("hidden")) {
                    const e = db.events.find(x => x.id === currentEventId);
                    if(e) showEventSheet(e);
                }

                // Kullanıcı sayacı güncellemesi
                updateUserCountDisplays();
                
                if(!silent) syncMap();
                return true;
            } catch(e) { 
                console.error("Veri çekme hatası:", e);
                return false; 
            }
        }

        function updateUserCountDisplays() {
            const total = db.total_users || 300;
            const active = db.active_users || 0;
            // Login ekranı
            const la = document.getElementById('login-active-users');
            const lt = document.getElementById('login-total-users');
            if(la) la.textContent = active;
            if(lt) lt.textContent = total.toLocaleString('tr-TR');
            // Leaderboard
            const ra = document.getElementById('rank-active-users');
            const rt = document.getElementById('rank-total-users');
            if(ra) ra.textContent = active;
            if(rt) rt.textContent = total.toLocaleString('tr-TR');
        }
        
        async function fetchWeather(lat, lon) {
            // Hava durumu gösterimi kaldırıldı — fonksiyon çağrılsa da hiçbir şey yapmıyor
            return;
        }

        function updateMyLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((position) => {
                    const { latitude, longitude } = position.coords;
                    userLat = latitude;
                    userLng = longitude;
                    fetchWeather(latitude, longitude);
                    if(typeof sendLocationToSupabase === "function") {
                        sendLocationToSupabase(latitude, longitude);
                    }
                    if (currentUser && currentUser.stats && currentUser.stats.riding_until > Date.now()) {
                        sendAction('update_user', {
                            username: currentUser.username,
                            stats: { ...currentUser.stats, riding_lat: latitude, riding_lng: longitude }
                        }).catch(e => {});
                    }
                }, (error) => { console.log("Konum izni alinamadi:", error.code); });
            }
        }

        async function handleGoogleLogin() {
            alert("Google ile giriş şimdilik kullanılamaz.");
            return;
            
            if (!supaClient) return alert("Sistem henüz hazır değil, lütfen bekleyin.");
            try {
                const { error } = await supaClient.auth.signInWithOAuth({
                    provider: 'google',
                    options: {
                        redirectTo: window.location.origin + '/',
                        queryParams: { access_type: 'offline', prompt: 'consent' }
                    }
                });
                if (error) throw error;
            } catch (err) {
                alert("Google ile giriş başlatılamadı: " + err.message);
            }
        }

        async function submitGoogleOnboarding(e) {
            const email = document.getElementById("go-email").value.trim();
            const avatar_url = document.getElementById("go-avatar").value.trim();
            const username = document.getElementById("go-username").value.trim();
            const name = document.getElementById("go-name").value.trim();
            const password = document.getElementById("go-password").value.trim();
            const city = document.getElementById("go-city").value.trim();
            const ref_code = document.getElementById("go-ref-code").value.trim();
            
            if (!username || !name || !city || !password) return alert("Lütfen kullanıcı adı, şifre, ad soyad ve şehir alanlarını doldurun.");
            if (password.length < 4) return alert("Şifre en az 4 karakter olmalıdır.");
            
            const btn = e.currentTarget;
            const originalText = btn.innerHTML;
            btn.innerHTML = "KAYDEDİLİYOR...";
            btn.disabled = true;
            
            try {
                const loadScreen = document.getElementById("app-loading-screen");
                if(loadScreen) { loadScreen.style.display = "flex"; loadScreen.style.opacity = "1"; }
                
                const res = await sendAction('complete_google_onboarding', {
                    email, avatar_url, username, password, name, city, ref_code
                });
                
                if (res && res.status === 'ok') {
                    currentUser = res.user;
                    window.currentUser = currentUser;
                    localStorage.setItem("fr_user", JSON.stringify(currentUser));
                    const meIdx = db.users.findIndex(u => u.username === currentUser.username);
                    if (meIdx !== -1) { db.users[meIdx] = currentUser; } else { db.users.push(currentUser); }
                    document.getElementById("google-onboarding-modal").classList.add("hidden");
                    loginSuccess();
                } else {
                    alert(res.message || "Bilinmeyen bir hata oluştu.");
                }
            } catch (err) {
                alert("Bağlantı hatası: " + err.message);
            } finally {
                btn.innerHTML = originalText;
                btn.disabled = false;
                const loadScreen = document.getElementById("app-loading-screen");
                if(loadScreen) { loadScreen.style.opacity = "0"; setTimeout(() => { loadScreen.style.display = "none"; }, 500); }
            }
        }

        window.onload = async function() {
            if (supaClient) {
                // Google OAuth callback'i yakala (hem hash hem de PKCE/code akisi)
                const _hash = window.location.hash || '';
                const _search = window.location.search || '';
                const _isOAuthCallback = _hash.includes('access_token') || _search.includes('code=') || _hash.includes('error=');

                supaClient.auth.onAuthStateChange(async (event, session) => {
                    if ((event === 'SIGNED_IN' || event === 'INITIAL_SESSION') && session && _isOAuthCallback) {
                        const email = session.user.email;
                        const name = session.user.user_metadata?.full_name || '';
                        const avatar_url = session.user.user_metadata?.avatar_url || '';
                        
                        // URL'yi temizle
                        window.history.replaceState(null, null, window.location.pathname);
                        
                            try {
                                const loadScreen = document.getElementById("app-loading-screen");
                                if(loadScreen) { loadScreen.style.display = "flex"; loadScreen.style.opacity = "1"; }
                                
                                const res = await sendAction('google_login', { email, name, avatar_url });
                                if (res && res.status === 'ok') {
                                    currentUser = res.user;
                                    window.currentUser = currentUser;
                                    localStorage.setItem("fr_user", JSON.stringify(currentUser));
                                    const meIdx3 = db.users.findIndex(u => u.username === currentUser.username);
                                    if (meIdx3 !== -1) { db.users[meIdx3] = currentUser; } else { db.users.push(currentUser); }
                                    if(res.user.just_got_daily) {
                                        alert("🎉 Harika! Günlük giriş ödülü olarak +" + res.user.just_got_daily + " XP kazandın.");
                                    }
                                    loginSuccess();
                                } else if (res && res.status === 'needs_onboarding') {
                                    document.getElementById("go-email").value = res.email;
                                    document.getElementById("go-name").value = res.name;
                                    document.getElementById("go-avatar").value = res.avatar_url;
                                    if (res.name) {
                                        const cleanName = res.name.toLowerCase().replace(/[^a-z0-9]/g, '');
                                        document.getElementById("go-username").value = cleanName + Math.floor(Math.random() * 1000);
                                    }
                                    document.getElementById("google-onboarding-modal").classList.remove("hidden");
                                } else {
                                    alert("Google girişi başarısız: " + (res.message || "Bilinmeyen hata"));
                                }
                            } catch(err) {
                                alert("Google sunucusuna bağlanırken hata: " + err.message);
                            } finally {
                                const loadScreen = document.getElementById("app-loading-screen");
                                if(loadScreen) { loadScreen.style.opacity = "0"; setTimeout(() => { loadScreen.style.display = "none"; }, 500); }
                            }
                        }
                });
            }
            // Beni hatırla kapatıldı, eski kayıtları temizle
            localStorage.removeItem("fr_remembered_username");
            localStorage.removeItem("fr_remembered_password");
            
            // DUZELTME #2: loadData hata firlatsa bile loading screen kapatilmali.
            // Onceki kodda await loadData() exception atarsa asagisi hic calismiyor,
            // ekran sonsuza kadar "Yukleniyor" modunda kaliyordu.
            try {
                await loadData(true);
            } catch(e) {
                console.error("[FreeriderTR] loadData basarisiz:", e);
            } finally {
                // Her durumda (hata olsa da) loading screen'i kapat
                const loadScreen = document.getElementById("app-loading-screen");
                if(loadScreen) {
                    loadScreen.style.opacity = "0";
                    setTimeout(() => { loadScreen.style.display = "none"; }, 500);
                }
            }

            const savedSessionToken = localStorage.getItem("fr_session_token");
            const savedSessionUser = localStorage.getItem("fr_session_username");
            if (savedSessionToken && savedSessionUser) {
                try {
                    const res = await sendAction('login_with_token', { username: savedSessionUser, token: savedSessionToken });
                    if(res && res.status === 'ok') {
                        currentUser = res.user;
                        window.currentUser = currentUser; 
                        localStorage.setItem("fr_user", JSON.stringify(currentUser));
                        if(res.user.just_got_daily) {
                            alert("🎉 Harika! Günlük giriş ödülü olarak +" + res.user.just_got_daily + " XP kazandın.");
                        }
                        loginSuccess();
                    } else {
                        localStorage.removeItem("fr_session_token");
                        localStorage.removeItem("fr_session_username");
                    }
                } catch(e) {
                    console.warn('[Oturum] Otomatik giriş başarısız (network hatası):', e);
                }
            } else {
                // Eski şifreli sistemden kalan kullanıcıları mağdur etmeden yeni ID (token) sistemine taşıyalım
                const oldUserRaw = localStorage.getItem("fr_user");
                if (oldUserRaw) {
                    try {
                        const oldUser = JSON.parse(oldUserRaw);
                        if (oldUser && oldUser.username) {
                            const res = await sendAction('login_legacy', { username: oldUser.username }, true);
                            if(res && res.status === 'ok') {
                                currentUser = res.user;
                                window.currentUser = currentUser; 
                                localStorage.setItem("fr_user", JSON.stringify(currentUser));
                                if (res.user.session_token) {
                                    localStorage.setItem("fr_session_token", res.user.session_token);
                                    localStorage.setItem("fr_session_username", currentUser.username);
                                }
                                loginSuccess();
                            }
                        }
                    } catch(e) {}
                }
            }

            // ============================================================
            // AKILLI REALTIME SİSTEMİ
            // Tek kanal = tek bağlantı = 200 limit yerine 1 slot kullanır
            // Sayfa arka plana geçince bağlantı kesilir, öne gelince tekrar açılır
            // ============================================================
            let _realtimeChannel = null;
            let _realtimePaused = false;

            function startRealtime() {
                if (_realtimeChannel) {
                    try { supaClient.removeChannel(_realtimeChannel); } catch(e) {}
                }
                _realtimeChannel = supaClient.channel('fr-main', {
                    config: { broadcast: { self: false } }
                })
                // ---- MESAJLAR ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, async payload => {
                    if(!currentUser) return;
                    if(!db.messages) db.messages = [];
                    if (payload.eventType === 'INSERT' && payload.new) {
                        if (!db.messages.find(m => m.id == payload.new.id)) {
                            db.messages.push(payload.new);
                        }
                        if (payload.new.user && !db.users.find(u => u.username === payload.new.user) && !['Freerider AI', 'Moderatör AI', 'SİSTEM AI', 'Admin'].includes(payload.new.user)) {
                            try {
                                const { data } = await supaClient.from('users').select('username, name, bio, city, avatar, role, xp, stats, accepted_chat_rules').eq('username', payload.new.user).single();
                                if (data) db.users.push(data);
                            } catch(e) {}
                        }
                    } else if (payload.eventType === 'DELETE' && payload.old) {
                        db.messages = db.messages.filter(m => m.id != payload.old.id);
                    } else if (payload.eventType === 'UPDATE' && payload.new) {
                        const idx = db.messages.findIndex(m => m.id == payload.new.id);
                        if (idx !== -1) {
                            // Eksik alanları eski veriden koru (REPLICA IDENTITY olmadan tam gelmiyor olabilir)
                            db.messages[idx] = { ...db.messages[idx], ...payload.new };
                        }
                    }
                    const chatVisible = !document.getElementById('screen-chat').classList.contains('hidden');
                    if (chatVisible) {
                        renderChat(true);
                        if (payload.eventType === 'INSERT' && payload.new && payload.new.user !== currentUser.username) {
                            // sound muted
                        }
                    } else if (payload.eventType === 'INSERT' && payload.new && payload.new.user !== currentUser.username) {
                        showChatBadge();
                        // sound muted
                    }
                })
                // ---- DM ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'dms' }, payload => {
                    if(!currentUser) return;
                    if (payload.eventType === 'INSERT') {
                        if (payload.new.participants && payload.new.participants.includes(currentUser.username)) {
                            if (!db.dms.find(m => m.id == payload.new.id)) db.dms.push(payload.new);
                            // DM badge göster (chat açık değilse)
                            const chatVisible = !document.getElementById('screen-chat').classList.contains('hidden');
                            if (payload.new.sender !== currentUser.username) {
                                if (!chatVisible) showChatBadge();
                                // sound muted
                                if (currentDmUser !== payload.new.sender || !chatVisible) {
                                    showToast("💬 " + payload.new.sender + " sana mesaj gönderdi", "info");
                                }
                            }
                        }
                    } else if (payload.eventType === 'DELETE') {
                        db.dms = db.dms.filter(m => m.id != payload.old.id);
                    }
                    renderDmList();
                    if (currentDmUser) renderDmThread(currentDmUser);
                })
                // ---- HARİTA NOKTALARI ----
                 .on('postgres_changes', { event: '*', schema: 'public', table: 'markers' }, payload => {
                    if(!currentUser) return;
                    if (payload.eventType === 'INSERT') {
                        const existing = db.markers.find(m => m.id == payload.new.id);
                        if (existing) {
                            // Zaten frontend'de var (kullanıcı az önce ekledi) — sadece addedBy güncelle
                            existing.addedBy = payload.new.addedBy || existing.addedBy;
                            return; // syncMap çağırma — duplikat oluşur
                        }
                        db.markers.push(payload.new);
                    } else if (payload.eventType === 'DELETE') {
                        db.markers = db.markers.filter(m => m.id != payload.old.id);
                    } else if (payload.eventType === 'UPDATE') {
                        const idx = db.markers.findIndex(m => m.id == payload.new.id);
                        if (idx !== -1) db.markers[idx] = payload.new;
                    }
                    if (map) syncMap();
                    if (payload.new && currentMarkerId === payload.new.id && !document.getElementById("marker-sheet").classList.contains("hidden")) {
                        showMarkerSheet(payload.new, true);
                    }
                })
                // ---- PAZAR ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'market' }, payload => {
                    if(!currentUser) return;
                    if (payload.eventType === 'INSERT') {
                        if (!db.market.find(m => m.id == payload.new.id)) db.market.unshift(payload.new);
                    } else if (payload.eventType === 'DELETE') {
                        db.market = db.market.filter(m => m.id != payload.old.id);
                    } else if (payload.eventType === 'UPDATE') {
                        const idx = db.market.findIndex(m => m.id == payload.new.id);
                        if (idx !== -1) db.market[idx] = payload.new;
                    }
                    if (!document.getElementById('screen-market').classList.contains('hidden')) renderMarket();
                })
                // ---- STORY ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'stories' }, payload => {
                    if(!currentUser) return;
                    if(!db.stories) db.stories = [];
                    const now = Math.floor(Date.now()/1000);
                    if (payload.eventType === 'INSERT' && payload.new.expires_at > now) {
                        if (!db.stories.find(s => s.id === payload.new.id)) db.stories.unshift(payload.new);
                    } else if (payload.eventType === 'DELETE') {
                        db.stories = db.stories.filter(s => s.id != payload.old.id);
                    }
                    if (!document.getElementById('screen-chat').classList.contains('hidden')) renderStoryBar();
                })
                // ---- ETKİNLİKLER ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'events' }, payload => {
                    if(!currentUser) return;
                    if (payload.eventType === 'INSERT') {
                        if (!db.events.find(e => e.id === payload.new.id)) db.events.push(payload.new);
                    } else if (payload.eventType === 'DELETE') {
                        db.events = db.events.filter(e => e.id != payload.old.id);
                    } else if (payload.eventType === 'UPDATE') {
                        const idx = db.events.findIndex(e => e.id === payload.new.id);
                        if (idx !== -1) db.events[idx] = payload.new;
                    }
                    if (map) syncMap();
                    if (payload.new && currentEventId === payload.new.id && !document.getElementById("event-sheet").classList.contains("hidden")) {
                        showEventSheet(payload.new);
                    }
                })
                // ---- KULLANICILAR (XP, online, premium) ----
                .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'users' }, payload => {
                    if(!currentUser) return;
                    const updated = payload.new;
                    const idx = db.users.findIndex(u => u.username === updated.username);
                    if (idx !== -1) {
                        // Kendi verimizi tam güncelle, başkalarının garage'ini alma
                        if (updated.username === currentUser.username) {
                            db.users[idx] = updated;
                            currentUser = updated;
                            localStorage.setItem("fr_user", JSON.stringify(currentUser));
                            updateProfileUI();
                            checkMissions();
                        } else {
                            // Başkası için sadece temel alanlar
                            db.users[idx] = {
                                ...db.users[idx],
                                xp: updated.xp,
                                stats: { ...(updated.stats || {}) },
                                avatar: updated.avatar,
                                role: updated.role
                            };
                        }
                    } else if (updated.username !== currentUser.username) {
                        db.users.push(updated);
                    }
                    // Lider tablosu açıksa güncelle
                    if (!document.getElementById('screen-rank').classList.contains('hidden')) renderLeaderboard();
                })
                // ---- YASAKLI KULLANICILAR ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'banned' }, payload => {
                    if(!currentUser) return;
                    if (payload.eventType === 'INSERT') {
                        if (!db.banned.includes(payload.new.username)) db.banned.push(payload.new.username);
                        // Kendi hesabım banlandıysa çıkış yap
                        if (payload.new.username === currentUser.username) {
                            alert("Hesabınız banlanmıştır!");
                            logout();
                        }
                    } else if (payload.eventType === 'DELETE') {
                        db.banned = db.banned.filter(u => u !== payload.old.username);
                    }
                })
                // ---- HABERLER ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'news' }, payload => {
                    if(!currentUser) return;
                    if (payload.eventType === 'INSERT') {
                        if (!db.news.find(n => n.id === payload.new.id)) db.news.unshift(payload.new);
                    } else if (payload.eventType === 'DELETE') {
                        db.news = db.news.filter(n => n.id != payload.old.id);
                    }
                    if (!document.getElementById('screen-news').classList.contains('hidden')) renderNews();
                })
                // ---- AYARLAR (pinned mesaj, bakım modu) ----
                .on('postgres_changes', { event: '*', schema: 'public', table: 'settings' }, payload => {
                    if(!currentUser) return;
                    if (payload.new && payload.new.id === 'pinned_message') {
                        try {
                            db.pinned_message = JSON.parse(payload.new.value || '{}');
                            renderChat(true);
                        } catch(e) {}
                    }
                    if (payload.new && payload.new.id === 'maintenance') {
                        db.maintenance = payload.new.value === 'true';
                        if (db.maintenance && currentUser.role !== 'Admin' && currentUser.role !== 'SubAdmin') {
                            alert("Sistem bakım moduna alındı. Lütfen daha sonra tekrar deneyin.");
                            logout();
                        }
                    }
                })
                .subscribe((status) => {
                    if (status === 'SUBSCRIBED') {
                        console.log('✅ Realtime bağlantısı kuruldu');
                        _realtimePaused = false;
                    } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
                        console.log('⚠️ Realtime bağlantısı kesildi, 5sn sonra tekrar denenecek...');
                        setTimeout(() => { if(!_realtimePaused) startRealtime(); }, 5000);
                    }
                });
            }

            // Sayfa görünürlüğü değişince bağlantıyı yönet (200 limit koruması)
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    // Sayfa arka plana geçti - bağlantıyı kapat, slot serbest bırak
                    _realtimePaused = true;
                    if (_realtimeChannel) {
                        try { supaClient.removeChannel(_realtimeChannel); _realtimeChannel = null; } catch(e) {}
                    }
                } else {
                    // Sayfa öne geldi - yeniden bağlan ve son veriyi çek
                    _realtimePaused = false;
                    startRealtime();
                    loadData(true); // Arka planda kaçırılan güncellemeleri al
                }
            });

            // İlk bağlantıyı kur
            startRealtime();

            // ── Çevrimdışı / Çevrimiçi Bildirimi ──
            function showOfflineBanner() {
                let b = document.getElementById('offline-banner');
                if (!b) {
                    b = document.createElement('div');
                    b.id = 'offline-banner';
                    b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:999999;background:#0284c7;color:#fff;text-align:center;padding:8px 16px;font-size:12px;font-weight:900;letter-spacing:0.05em;text-transform:uppercase;';
                    b.textContent = '📵 İnternet bağlantısı yok — Önbellek modunda çalışıyor';
                    document.body.appendChild(b);
                }
            }
            function hideOfflineBanner() {
                const b = document.getElementById('offline-banner');
                if (b) b.remove();
            }
            window.addEventListener('offline', showOfflineBanner);
            window.addEventListener('online', () => {
                hideOfflineBanner();
                loadData(true);
            });
            if (!navigator.onLine) showOfflineBanner();
        };

        // YANDAN AÇILIR MENÜ (SIDEBAR) FONKSİYONU
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const overlay = document.getElementById("sidebar-overlay");
            if(sidebar.classList.contains("-translate-x-full")) {
                sidebar.classList.remove("-translate-x-full");
                overlay.classList.remove("hidden");
                setTimeout(() => { overlay.style.opacity = "1"; }, 10);
            } else {
                sidebar.classList.add("-translate-x-full");
                overlay.style.opacity = "0";
                setTimeout(() => { overlay.classList.add("hidden"); }, 300);
            }
        }

        // =========================================================
        // MARKER UI & API HELPERS
        // =========================================================
        function openCategorySelectModal() {
            document.getElementById('category-select-modal').classList.remove('hidden');
        }

        function selectMarkerCategory(cat) {
            selectedMarkerCategory = cat;
            document.getElementById('category-select-modal').classList.add('hidden');
            
            // Set Add Marker Modal Title & Category Label
            document.getElementById('modal-marker-title').textContent = "📍 " + cat.toUpperCase() + " EKLE";
            document.getElementById('modal-marker-category-label').textContent = "Seçilen Tür: " + cat;
            
            const diffSelect = document.getElementById("new-marker-difficulty");
            const diffContainer = diffSelect.parentElement;
            
            if (cat === "Market" || cat === "Bisikletçi") {
                diffContainer.style.display = "flex";
                diffSelect.innerHTML = `
                    <option value="Ucuz">🟢 Uygun Fiyatlı</option>
                    <option value="Orta Pahalılık" selected>🟡 Orta Pahalılık</option>
                    <option value="Pahalı">🔴 Pahalı</option>
                `;
            } else if (cat === "Su Kaynağı" || cat === "Toplanma Noktası" || cat === "Tamir Noktası") {
                diffContainer.style.display = "none";
                diffSelect.innerHTML = `<option value="Yok" selected>Yok</option>`;
            } else {
                diffContainer.style.display = "flex";
                diffSelect.innerHTML = `
                    <option value="Kolay">🟢 Kolay Seviye</option>
                    <option value="Orta" selected>🟡 Orta Seviye</option>
                    <option value="Zor">🔴 Zor Seviye</option>
                    <option value="Tehlike">💀 Çok Tehlikeli</option>
                `;
            }
            
            if(tempLat && tempLng && !isAddingMarkerMode) {
                document.getElementById('add-marker-modal').classList.remove('hidden');
            } else {
                toggleAddMarkerMode();
            }
        }

        function closeMarkerModal() {
            document.getElementById('add-marker-modal').classList.add('hidden');
            if(isAddingMarkerMode) {
                toggleAddMarkerMode(); // Exit from adding state if open
            }
        }

        function toggleMarkerFilter(cat) {
            activeMarkerFilter = cat;
            
            // Update UI buttons
            const btns = document.querySelectorAll('.marker-filter-btn');
            btns.forEach(b => {
                b.classList.remove('bg-sky-600/30', 'text-sky-300', 'active');
                if(!b.classList.contains('hover:bg-zinc-800')) b.classList.add('hover:bg-zinc-800');
            });
            const activeBtn = document.getElementById('filter-' + cat);
            if(activeBtn) {
                activeBtn.classList.remove('hover:bg-zinc-800');
                activeBtn.classList.add('bg-sky-600/30', 'text-sky-300', 'active');
            }
            
            // Re-render markers
            syncMap();
        }

        // Viewport based marker loading removed        // =========================================================
        // HARİTA FONKSİYONU
        // =========================================================
        function initMap() {
            if(map) return;
            
            map = L.map('map', { 
                zoomControl: false,
                preferCanvas: true,
                touchZoom: true,
                bounceAtZoomLimits: false,
                maxBoundsViscosity: 0.0,
                fadeAnimation: true,
                zoomAnimation: true,
                markerZoomAnimation: true,
                renderer: L.canvas({ padding: 0.5 })
            }).setView([window._prefetchedLat||39.0, window._prefetchedLng||35.0], window._prefetchedLat ? 15 : 6);

            // Yol haritası — CartoDB Dark
            var roads = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                subdomains: 'abcd',
                maxZoom: 22,
                maxNativeZoom: 19,
                keepBuffer: 4,
                updateWhenIdle: false,
                updateWhenZooming: false,
                crossOrigin: true,
                attribution: '© <a href="https://carto.com">CARTO</a> © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            });

            // Uydu görüntüsü — Google Hybrid
            var satellite = L.tileLayer('https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
                maxZoom: 24,
                maxNativeZoom: 21,
                keepBuffer: 4,
                updateWhenIdle: false,
                updateWhenZooming: false,
                crossOrigin: true,
                attribution: '© Google Maps'
            });

            satellite.addTo(map);

            var baseMaps = {
                "🛰️ Google Uydu": satellite,
                "🌑 Koyu Harita": roads
            };

            L.control.layers(baseMaps, null, { 
                collapsed: false, 
                position: 'topright' 
            }).addTo(map);

            // Zoom butonları — sağ alt, parmak dostu
            L.control.zoom({ position: 'bottomright' }).addTo(map);

            if (typeof L.Control.Geocoder !== 'undefined') {
                L.Control.geocoder({
                    defaultMarkGeocode: true,
                    placeholder: "Yer veya Rampa ara...",
                }).addTo(map);
            }
            syncMap();
            // Prefetch konum varsa mavi noktayı direk koy
            if(window._prefetchedLat && window._prefetchedLng) {
                userLat = window._prefetchedLat; userLng = window._prefetchedLng;
                updateLocationMarker(userLat, userLng);
                window._prefetchedLat = null; window._prefetchedLng = null;
            }
            if(!locationInterval) {
                locationInterval = setInterval(() => { fetchLocationAndUpdateMarker(false); }, 180000);
            }

            function onMapSelect(e) {
                // Crosshair UI kullanıldığı için tıklama devre dışı
                return;
            }
            map.on('click', onMapSelect);

            // Bulletproof touch click for Android WebViews (using capture phase)
            let mapTouchStartX = 0;
            let mapTouchStartY = 0;
            let mapTouchStartTime = 0;
            const mapEl = document.getElementById('map');
            mapEl.addEventListener('touchstart', function(e) {
                if(e.touches.length > 0) {
                    mapTouchStartX = e.touches[0].clientX;
                    mapTouchStartY = e.touches[0].clientY;
                    mapTouchStartTime = Date.now();
                }
            }, {passive: true, capture: true});
            
            mapEl.addEventListener('touchend', function(e) {
                // Crosshair UI kullanıldığı için dokunma ile yer işaretleme iptal edildi
            }, {passive: true, capture: true});

        }

        // =========================================================
        // E-POSTA DOĞRULAMA FONKSİYONLARI
        // =========================================================
        function skipVerification() {
            document.getElementById("email-verify-modal").classList.add("hidden");
            if(!currentUser) {
                alert("Kayıt tamamlandı, ancak e-postanız henüz doğrulanmadı. Daha sonra 'Profil' menüsünden doğrulayabilirsiniz.");
                showLoginTab();
                document.getElementById("login-username").value = verificationUsername;
            }
        }

        async function submitVerificationCode() {
            const code = document.getElementById("verify-code-input").value;
            if(!code || code.length !== 6) return alert("Lütfen geçerli bir 6 haneli kod girin.");
            
            try {
                await sendAction('verify_email', { username: verificationUsername || currentUser?.username, code: code });
                alert("E-posta adresiniz başarıyla doğrulandı!");
                document.getElementById("email-verify-modal").classList.add("hidden");
                
                if(!currentUser) { 
                    showLoginTab();
                    document.getElementById("login-username").value = verificationUsername;
                } else { 
                    await loadData(true);
                    openSettingsModal();
                }
            } catch(e) {}
        }

        async function completeOnboarding() {
            document.getElementById("onboarding-modal").classList.add("hidden");
            if (currentUser && currentUser.stats) {
                currentUser.stats.onboarding = true;
                await sendAction('update_user', currentUser);
            }
            if(navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (pos) => {
                        userLat = pos.coords.latitude;
                        userLng = pos.coords.longitude;
                        if(typeof fetchWeather === 'function') fetchWeather(userLat, userLng);
                        if(typeof sendLocationToSupabase === 'function') sendLocationToSupabase(userLat, userLng);
                        if(map) map.setView([userLat, userLng], 14);
                    },
                    (err) => { console.log('Konum izni reddedildi:', err.code); },
                    { enableHighAccuracy: true, timeout: 10000 }
                );
            }
            requestPushPermission();
        }

        async function checkMissions() {
            if(!currentUser || !currentUser.stats) return;
            let stats = currentUser.stats;
            if(!stats.missions)        stats.missions        = {};
            if(!stats.daily_missions)  stats.daily_missions  = {};
            if(!stats.weekly_missions) stats.weekly_missions = {};

            const dailyData  = getDailyMissions();
            const weeklyData = getWeeklyMissions();
            const todayKey   = dailyData.key;
            const weekKey    = weeklyData.key;

            // Günlük sıfırlama
            if(stats.daily_missions.date !== todayKey) {
                stats.daily_missions = { date: todayKey, daily_login: 1 };
            }
            // Haftalık sıfırlama
            if(stats.weekly_missions.week !== weekKey) {
                stats.weekly_missions = { week: weekKey };
            }

            // Sunucuya claim isteği gönderen yardımcı
            async function claimOnServer(mission_type, mission_id, xp) {
                try {
                    const res = await sendAction('claim_mission', { mission_type, mission_id, xp });
                    if(res && res.status === 'ok' && res.earned_xp > 0) {
                        currentUser.xp = res.new_xp;
                        stats.monthly_xp = (stats.monthly_xp || 0) + res.earned_xp;
                        stats.weekly_xp  = (stats.weekly_xp  || 0) + res.earned_xp;
                        return 'claimed';
                    }
                    if(res && res.status === 'ok' && res.already_done) return 'already_done';
                    if(res && res.status === 'ok' && res.not_ready) return 'not_ready';
                } catch(e) {}
                return 'error';
            }

            // --- Kalıcı görevler ---
            for(let m of MISSIONS) {
                if(!stats.missions[m.id]) {
                    let progress = stats[m.type] || 0;
                    if(progress >= m.target) {
                        const result = await claimOnServer('perm', m.id, m.xp);
                        if(result === 'claimed') {
                            stats.missions[m.id] = true;
                            if(m.badge) {
                                if(!stats.earned_badges) stats.earned_badges = [];
                                if(!stats.earned_badges.includes(m.badge)) stats.earned_badges.push(m.badge);
                            }
                            showMissionToast(m.title, m.xp, m.icon);
                        } else if(result === 'already_done') {
                            stats.missions[m.id] = true; // local senkronize et, toast yok
                        }
                    }
                }
            }

            // --- Günlük görevler ---
            for(let m of dailyData.missions) {
                const doneKey = 'done_' + m.id;
                if(!stats.daily_missions[doneKey]) {
                    let progress = m.type === 'daily_login' ? 1 : (stats.daily_missions[m.type] || 0);
                    if(progress >= m.target) {
                        const result = await claimOnServer('daily', m.id, m.xp);
                        if(result === 'claimed') {
                            stats.daily_missions[doneKey] = true;
                            showMissionToast(m.title + ' (Günlük)', m.xp, m.icon);
                        } else if(result === 'already_done') {
                            stats.daily_missions[doneKey] = true; // sessiz senkronize
                        }
                    }
                }
            }

            // --- Haftalık görevler ---
            for(let m of weeklyData.missions) {
                const doneKey = 'done_' + m.id;
                if(!stats.weekly_missions[doneKey]) {
                    let progress = stats.weekly_missions[m.type] || 0;
                    if(progress >= m.target) {
                        const result = await claimOnServer('weekly', m.id, m.xp);
                        if(result === 'claimed') {
                            stats.weekly_missions[doneKey] = true;
                            showMissionToast(m.title + ' (Haftalık)', m.xp, m.icon);
                        } else if(result === 'already_done') {
                            stats.weekly_missions[doneKey] = true; // sessiz senkronize
                        }
                    }
                }
            }

            updateProfileUI();
            renderMissions();
        }

        // ============================================================
        // STORY SİSTEMİ
        // ============================================================
        let _storyIndex = 0;
        let _storyList = [];
        let _storyTimer = null;

        function renderStoryBar() {
            const bar = document.getElementById('story-items');
            if(!bar || !db.stories) return;
            bar.innerHTML = '';
            const now = Math.floor(Date.now()/1000);
            const active = db.stories.filter(s => s.expires_at > now);
            if(active.length === 0) { bar.innerHTML = '<div class="text-[10px] text-zinc-600 flex items-center h-14 font-medium">Henuz story yok</div>'; return; }
            active.forEach((s, i) => {
                const u = db.users.find(x => x.username === s.user);
                const avatar = u ? u.avatar : 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
                const seen = s.viewers && s.viewers.includes(currentUser.username);
                const premBorder = getUserPremiumTier(s.user) > 0 ? getPremiumBorderClass(s.user) : '';
                bar.innerHTML += `
                <div onclick="viewStory(${i})" class="flex flex-col items-center gap-1 shrink-0 cursor-pointer">
                    <div class="w-14 h-14 rounded-full overflow-hidden ${seen ? 'story-seen' : 'story-ring'} ${premBorder}">
                        <img src="${avatar}" class="w-full h-full object-cover">
                    </div>
                    <span class="text-[9px] font-bold uppercase tracking-widest max-w-[56px] truncate ${seen ? 'text-zinc-600' : 'text-zinc-400'}">${s.user}</span>
                </div>`;
            });
        }

        function viewStory(startIndex) {
            _storyList = db.stories.filter(s => s.expires_at > Math.floor(Date.now()/1000));
            _storyIndex = startIndex;
            showCurrentStory();
            document.getElementById('story-view-modal').classList.remove('hidden');
        }

        function showCurrentStory() {
            if(_storyTimer) clearTimeout(_storyTimer);
            const s = _storyList[_storyIndex];
            if(!s) { closeStoryView(); return; }
            const u = db.users.find(x => x.username === s.user);
            const avatar = u ? u.avatar : 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
            document.getElementById('story-view-avatar').src = avatar;
            document.getElementById('story-view-username').textContent = s.user;
            const secsAgo = Math.floor(Date.now()/1000) - s.created_at;
            document.getElementById('story-view-time').textContent = secsAgo < 3600 ? Math.floor(secsAgo/60) + ' dk once' : Math.floor(secsAgo/3600) + ' saat once';
            const imgEl = document.getElementById('story-view-img');
            const txtEl = document.getElementById('story-view-text');
            if(s.image) { imgEl.src = s.image; imgEl.style.display='block'; txtEl.style.display='none'; }
            else { imgEl.style.display='none'; txtEl.style.display='flex'; document.getElementById('story-view-text-content').textContent = s.text; }
            const viewers = s.viewers || [];
            document.getElementById('story-viewer-count').textContent = viewers.length + ' kisi izledi';
            // Progress bars
            const pbContainer = document.getElementById('story-progress-bars');
            pbContainer.innerHTML = '';
            _storyList.forEach((_, i) => {
                const pb = document.createElement('div');
                pb.style.cssText = 'flex:1;height:3px;background:rgba(255,255,255,0.3);border-radius:3px;overflow:hidden;';
                const fill = document.createElement('div');
                fill.style.cssText = 'height:100%;background:#fff;border-radius:3px;';
                fill.style.width = i < _storyIndex ? '100%' : (i === _storyIndex ? '0%' : '0%');
                if(i === _storyIndex) { fill.style.transition = 'width 5s linear'; setTimeout(()=>fill.style.width='100%', 50); }
                pb.appendChild(fill); pbContainer.appendChild(pb);
            });
            // Show delete btn for own stories
            const delBtn = document.getElementById('story-delete-btn');
            if(delBtn) {
                if(s.user === currentUser.username || (currentUser.role === 'Admin')) {
                    delBtn.classList.remove('hidden');
                } else {
                    delBtn.classList.add('hidden');
                }
            }
            // Mark as viewed
            sendAction('view_story', {id: s.id}).catch(()=>{});
            // Auto advance
            _storyTimer = setTimeout(() => { _storyIndex++; showCurrentStory(); }, 5000);
        }

        async function deleteCurrentStory() {
            const s = _storyList[_storyIndex];
            if(!s) return;
            if(!confirm("Bu story'yi silmek istiyor musun?")) return;
            await sendAction('delete_story', { id: s.id });
            _storyList.splice(_storyIndex, 1);
            if(_storyList.length === 0) { closeStoryView(); return; }
            if(_storyIndex >= _storyList.length) _storyIndex = _storyList.length - 1;
            showCurrentStory();
        }

        function closeStoryView() {
            if(_storyTimer) clearTimeout(_storyTimer);
            document.getElementById('story-view-modal').classList.add('hidden');
            renderStoryBar();
        }

        document.addEventListener('DOMContentLoaded', () => { localStorage.removeItem('userCache'); localStorage.removeItem('fr_user_cache');
            const sv = document.getElementById('story-view-modal');
            if(sv) {
                sv.addEventListener('click', (e) => {
                    // DUZELTME #5: currentUser henuz null iken tiklanirsa race condition olusur
                    if(!currentUser) return;
                    const rect = sv.getBoundingClientRect();
                    if(e.clientX < rect.width/2) { _storyIndex = Math.max(0,_storyIndex-1); showCurrentStory(); }
                    else { _storyIndex++; showCurrentStory(); }
                });
            }

            // ── GPS ÖN YÜKLEME: Login ekranındayken arka planda konum çek ──
            // Böylece harita açıldığında konum hazır olur, bekleme olmaz
            if(navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(pos => {
                    window._prefetchedLat = pos.coords.latitude;
                    window._prefetchedLng = pos.coords.longitude;
                    console.log('📍 Konum önceden alındı:', window._prefetchedLat, window._prefetchedLng);
                }, err => {
                    console.log('GPS prefetch başarısız:', err.code);
                }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
            }
        });

        function openAddStoryModal() {
            const premTier = getUserPremiumTier(currentUser.username);
            if(premTier < 1) {
                alert('Story paylasabilmek icin Standart, Deluxe veya Ultra+ uyelik gereklidir!');
                switchTab(6); return;
            }
            document.getElementById('add-story-modal').classList.remove('hidden');
        }

        async function submitStory() {
            const text = document.getElementById('story-text-input').value.trim();
            const file = document.getElementById('story-photo-input').files[0];
            if(!text && !file) return alert('Lutfen bir metin veya fotograf ekleyin!');
            let img = '';
            if(file) { img = await resizeImage(file, 1200); }
            await sendAction('add_story', { text, image: img });
            document.getElementById('add-story-modal').classList.add('hidden');
            document.getElementById('story-text-input').value = '';
            document.getElementById('story-photo-input').value = '';
        }

        // ============================================================
        // YORUM SİSTEMİ
        // ============================================================
        let _commentTargetType = '';
        let _commentTargetId = '';

        async function openComments(targetType, targetId) {
            if(!targetId) return;
            _commentTargetType = targetType;
            _commentTargetId = targetId;
            const label = targetType === 'marker' ? 'Rampa Yorumları' : 'Etkinlik Yorumları';
            document.getElementById('comment-modal-title').innerHTML = '💬 ' + label;
            document.getElementById('comment-list').innerHTML = '<div class="text-zinc-500 text-xs text-center py-4 animate-pulse">Yorumlar yükleniyor...</div>';
            document.getElementById('comment-modal').classList.remove('hidden');
            try {
                const res = await sendAction('get_comments', { target_id: targetId });
                renderComments(res.comments || []);
            } catch(e) { document.getElementById('comment-list').innerHTML = '<div class="text-zinc-500 text-xs text-center py-4">Yorum yuklenemedi.</div>'; }
        }

        function renderComments(comments) {
            const c = document.getElementById('comment-list');
            if(comments.length === 0) {
                c.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-6">Henuz yorum yok. Ilk yorumu sen yaz!</div>';
                return;
            }
            c.innerHTML = '';
            comments.forEach(cm => {
                const u = db.users.find(x => x.username === cm.user);
                const avatar = u ? u.avatar : 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
                const isMe = cm.user === currentUser.username;
                const isAdmin2 = currentUser.role === 'Admin';
                const delBtn = (isMe || isAdmin2) ? `<button onclick="deleteComment('${cm.id}')" class="text-[9px] text-sky-400 hover:text-sky-300 ml-2">sil</button>` : '';
                const secsAgo = Math.floor(Date.now()/1000) - cm.created_at;
                const timeStr = secsAgo < 60 ? 'az once' : secsAgo < 3600 ? Math.floor(secsAgo/60)+' dk' : Math.floor(secsAgo/3600)+' saat';
                c.innerHTML += `<div class="flex gap-3 items-start slide-up-anim">
                    <img src="${avatar}" class="w-9 h-9 rounded-full object-cover border border-zinc-700 shrink-0 cursor-pointer" onclick="showOtherProfile('${cm.user}')">
                    <div class="flex-1 bg-black/40 rounded-2xl px-3 py-2 border border-zinc-800">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-white cursor-pointer hover:text-zinc-300" onclick="showOtherProfile('${cm.user}')">${cm.user}</span>
                            <span class="text-[9px] text-zinc-600">${timeStr} ${delBtn}</span>
                        </div>
                        <div class="text-sm text-zinc-300 mt-1 leading-relaxed">${cm.text}</div>
                    </div>
                </div>`;
            });
            c.scrollTop = c.scrollHeight;
        }

        async function submitComment() {
            const inp = document.getElementById('comment-input');
            const text = inp.value.trim();
            if(!text) return;
            inp.value = '';
            await sendAction('add_comment', { target_type: _commentTargetType, target_id: _commentTargetId, text });
            const res = await sendAction('get_comments', { target_id: _commentTargetId });
            renderComments(res.comments || []);
        }

        async function deleteComment(id) {
            await sendAction('delete_comment', { id });
            const res = await sendAction('get_comments', { target_id: _commentTargetId });
            renderComments(res.comments || []);
        }

        // ============================================================
        // SEVİYE ATLAMA KUTLAMA ANİMASYONU
        // ============================================================
        let _lastTitleName = null;

        function checkLevelUp() {
            if(!currentUser) return;
            const title = getTitle(currentUser.xp);
            if(_lastTitleName && _lastTitleName !== title.name) {
                showLevelUpAnimation(title);
            }
            _lastTitleName = title.name;
        }

        function showLevelUpAnimation(title) {
            const overlay = document.getElementById('levelup-overlay');
            const card = document.getElementById('levelup-card');
            document.getElementById('levelup-icon').textContent = title.icon;
            document.getElementById('levelup-name').textContent = title.name;
            document.getElementById('levelup-desc').textContent = 'Yeni unvanina ulastin!';
            overlay.classList.remove('hidden');
            overlay.style.pointerEvents = 'none';
            card.style.animation = 'none';
            card.offsetHeight;
            card.style.animation = 'levelUpPulse 0.7s cubic-bezier(0.34,1.56,0.64,1) both';
            haptic([100, 50, 100, 50, 300]);
            showSpinConfetti();
            setTimeout(() => overlay.classList.add('hidden'), 4000);
        }

        // Hava durumu fonksiyonları kaldırıldı
        function getWeatherRouteAdvice(weatherCode) { return { emoji:'🌡️', text:'', color:'text-zinc-400', ride: false }; }
        function updateWeatherWidget(temp, weatherCode) { /* devre dışı */ }

        // ============================================================
        // TEMA & ARAYÜZ RENGİ (Premium)
        // ============================================================
        function applyTheme(themeName) {
            const premTier = getUserPremiumTier(currentUser.username);
            if(premTier < 1) { alert('Tema ozelligi Premium uyelerere ozgudur!'); switchTab(6); return; }
            document.body.className = document.body.className.replace(/theme-[a-z]+/g, '').trim();
            document.body.classList.add('theme-' + themeName);
            localStorage.setItem('fr_theme', themeName);
            if(currentUser.stats) {
                currentUser.stats.ui_theme = themeName;
                sendAction('update_user', { username: currentUser.username, stats: currentUser.stats }).catch(()=>{});
            }
            haptic([20]);
        }

        function loadSavedTheme() {
            const saved = localStorage.getItem('fr_theme') || (currentUser && currentUser.stats && currentUser.stats.ui_theme);
            if(saved) {
                document.body.className = document.body.className.replace(/theme-[a-z]+/g, '').trim();
                document.body.classList.add('theme-' + saved);
            }
        }

        // ============================================================
        // DESTEK MODALI
        // ============================================================
        function openSupportModal() {
            const premTier = getUserPremiumTier(currentUser.username);
            const badge = document.getElementById('support-priority-badge');
            if(premTier >= 2) {
                badge.textContent = '🔴 Oncelikli Destek - 24 saat icinde cevaplanir';
                badge.className = 'mb-4 text-center py-2 rounded-xl text-xs font-black uppercase tracking-widest bg-red-900/40 text-sky-300 border border-sky-800/50';
            } else if(premTier === 1) {
                badge.textContent = '🟡 Normal Destek - 48-72 saat icinde cevaplanir';
                badge.className = 'mb-4 text-center py-2 rounded-xl text-xs font-black uppercase tracking-widest bg-yellow-900/40 text-yellow-400 border border-yellow-800/50';
            } else {
                badge.textContent = '⚪ Ucretsiz Destek - Yoğunluğa gore cevaplanir';
                badge.className = 'mb-4 text-center py-2 rounded-xl text-xs font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 border border-zinc-700';
            }
            document.getElementById('support-message').value = '';
            document.getElementById('support-modal').classList.remove('hidden');
        }

        async function submitSupport() {
            const msg = document.getElementById('support-message').value.trim();
            if(!msg) return alert('Lutfen bir mesaj yazin!');
            await sendAction('send_support', { message: msg });
            document.getElementById('support-modal').classList.add('hidden');
            alert('Destek talebiniz alindi! En kisa surede cevaplayacagiz.');
        }

        // ============================================================
        // RAMPA PUANLAMA
        // ============================================================
        async function rateMarker(rating) {
            if(!currentMarkerId) return;
            haptic([20]);
            // Update stars UI
            const stars = document.querySelectorAll('#ms-stars span');
            stars.forEach((s,i) => {
                s.textContent = i < rating ? '⭐' : '☆';
                s.style.opacity = i < rating ? '1' : '0.4';
            });
            try {
                const m = db.markers.find(x=>x.id===currentMarkerId);
                await sendAction('rate_marker', {
                    marker_id: currentMarkerId,
                    marker_name: m ? m.name : '',
                    rating
                });
                showMissionToast('Puan Verildi!', 0, '⭐');
            } catch(e) {}
        }

        function updateMarkerRating(marker) {
            const avgEl = document.getElementById('ms-avg-rating');
            const stars = document.querySelectorAll('#ms-stars span');
            if(!avgEl || !stars.length) return;
            const ratings = marker.ratings || {};
            const myRating = ratings[currentUser.username] || 0;
            const avg = marker.avg_rating || 0;
            const count = Object.keys(ratings).length;
            avgEl.textContent = avg > 0 ? avg.toFixed(1) + ' (' + count + ' oy)' : 'Henuz oy yok';
            stars.forEach((s,i) => {
                s.textContent = i < myRating ? '⭐' : '☆';
                s.style.opacity = i < myRating ? '1' : '0.4';
            });
        }

        // ============================================================
        // TEHLİKE BİLDİRİMİ
        // ============================================================
        function openDangerReport() {
            document.getElementById('danger-reason-input').value = '';
            document.getElementById('danger-modal').classList.remove('hidden');
        }

        function setDangerReason(reason) {
            document.getElementById('danger-reason-input').value = reason;
        }

        async function submitDangerReport() {
            const reason = document.getElementById('danger-reason-input').value.trim();
            if(!reason) return alert('Lutfen bir sebep secin veya yazin!');
            const m = db.markers.find(x=>x.id===currentMarkerId);
            await sendAction('report_danger', {
                marker_id: currentMarkerId,
                marker_name: m ? m.name : '',
                reason
            });
            document.getElementById('danger-modal').classList.add('hidden');
            showMissionToast('Tehlike Bildirildi', 0, '⚠️');
        }

        // ============================================================
        // TAM EKRAN FOTOĞRAF GÖRÜNTÜLEYİCİ
        // ============================================================
        let _fsImages = [];
        let _fsIndex  = 0;

        function openFullscreen(imgs, startIndex) {
            _fsImages = Array.isArray(imgs) ? imgs : [imgs];
            _fsIndex = startIndex || 0;
            _showFullscreenImg();
            document.getElementById('fullscreen-img-modal').classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }

        function closeFullscreenImg() {
            document.getElementById('fullscreen-img-modal').classList.add('hidden');
            document.body.style.overflow = '';
        }

        function _showFullscreenImg() {
            document.getElementById('fullscreen-img').src = _fsImages[_fsIndex];
            const navEl = document.getElementById('fullscreen-nav');
            if(navEl) navEl.style.display = _fsImages.length > 1 ? 'flex' : 'none';
            const ctr = document.getElementById('fullscreen-counter');
            if(ctr) ctr.textContent = _fsImages.length > 1 ? (_fsIndex+1)+' / '+_fsImages.length : '';
        }

        function fullscreenNext() { _fsIndex = (_fsIndex+1) % _fsImages.length; _showFullscreenImg(); }
        function fullscreenPrev() { _fsIndex = (_fsIndex-1+_fsImages.length) % _fsImages.length; _showFullscreenImg(); }

        // Swipe support on fullscreen
        (function(){
            let startX = 0;
            document.addEventListener('touchstart', e => {
                if(document.getElementById('fullscreen-img-modal').classList.contains('hidden')) return;
                startX = e.touches[0].clientX;
            }, {passive:true});
            document.addEventListener('touchend', e => {
                if(document.getElementById('fullscreen-img-modal').classList.contains('hidden')) return;
                const dx = e.changedTouches[0].clientX - startX;
                if(Math.abs(dx) > 50) { dx < 0 ? fullscreenNext() : fullscreenPrev(); }
            }, {passive:true});
        })();

        // ============================================================
        // EMOJI REAKSİYONLARI
        // ============================================================
        async function addReaction(msgId, emoji) {
            haptic([10]);
            try {
                await sendAction('add_reaction', {msg_id: msgId, emoji});
                // Update local state
                const msg = db.messages.find(m=>m.id===msgId);
                if(msg) {
                    if(!msg.reactions) msg.reactions = {};
                    const users = msg.reactions[emoji] || [];
                    const idx = users.indexOf(currentUser.username);
                    if(idx >= 0) users.splice(idx,1); else users.push(currentUser.username);
                    msg.reactions[emoji] = users;
                    renderChat(true);
                }
            } catch(e) {}
        }

        function showTrialExpiredModal() {
            const modal = document.getElementById('trial-expired-modal');
            if(modal) modal.classList.remove('hidden');
            // Clear trial_expired flag so it doesn't show again
            if(currentUser && currentUser.stats) {
                currentUser.stats.trial_expired = false;
                sendAction('update_user', { username: currentUser.username, stats: currentUser.stats }).catch(()=>{});
            }
        }

        function showTrialBanner() {
            const existing = document.getElementById('trial-active-banner');
            if(existing) return;
            const banner = document.createElement('div');
            banner.id = 'trial-active-banner';
            banner.className = 'fixed top-16 left-0 right-0 z-[9998] flex justify-center px-4 trial-banner';
            const expDate = currentUser.stats && currentUser.stats.premium_expire_date ? currentUser.stats.premium_expire_date : '?';
            banner.innerHTML = `<div class="bg-gradient-to-r from-yellow-600 to-amber-500 text-black px-5 py-2.5 rounded-2xl font-black text-xs  flex items-center gap-3 max-w-sm w-full">
                <span class="text-lg">🎁</span>
                <span class="flex-1">3 Gun Ucretsiz Ultra+ Denemen Aktif! Bitis: ${expDate}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="text-black/60 hover:text-black text-sm">✕</button>
            </div>`;
            document.body.appendChild(banner);
            setTimeout(() => { if(banner.parentElement) banner.remove(); }, 6000);
        }

        function showMissionToast(title, xp, icon) {
            const toast = document.createElement('div');
            toast.className = 'fixed top-10 left-1/2 -translate-x-1/2 z-[99999] bg-gradient-to-r from-yellow-600 to-orange-500 text-white px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2 scale-in-anim pointer-events-none opacity-90';
            toast.innerHTML = '<span class="text-2xl">' + icon + '</span><div><div class="text-[10px] uppercase tracking-widest opacity-80">Gorev Tamamlandi!</div><div>' + title + ' +' + xp + ' XP</div></div>';
            document.body.appendChild(toast);
            haptic([50, 30, 50]);
            setTimeout(() => { toast.style.opacity='0'; toast.style.transition='opacity 0.5s'; setTimeout(()=>toast.remove(),500); }, 1500);
        }
        function renderMissions() {
            const c = document.getElementById("missions-list");
            if(!c || !currentUser) return;
            const stats = currentUser.stats || {};

            const dailyData = getDailyMissions();
            const weeklyData = getWeeklyMissions();
            const dm = stats.daily_missions || {};
            const wm = stats.weekly_missions || {};
            const todayKey = dailyData.key;
            const weekKey = weeklyData.key;

            let html = '<div class="flex bg-zinc-950 rounded-xl p-1 mb-5 border border-zinc-800">';
            html += '<button onclick="setMissionTab(0)" id="mtab-0" class="flex-1 py-2 bg-zinc-800 text-white rounded-lg font-bold text-xs transition">Kalici</button>';
            html += '<button onclick="setMissionTab(1)" id="mtab-1" class="flex-1 py-2 text-zinc-500 rounded-lg font-bold text-xs transition">Gunluk</button>';
            html += '<button onclick="setMissionTab(2)" id="mtab-2" class="flex-1 py-2 text-zinc-500 rounded-lg font-bold text-xs transition">Haftalik</button>';
            html += '</div>';

            // === KALICI ===
            html += '<div id="m-perm">';
            MISSIONS.forEach(m => {
                let progress = stats[m.type] || 0;
                let isDone = stats.missions && stats.missions[m.id] === true;
                let percent = Math.min((progress / m.target) * 100, 100);
                let pbHtml = isDone ? '' : '<div class="progress-bar-bg mt-2"><div class="progress-bar-fill" style="width:' + percent + '%;"></div></div>';
                let btnHtml = isDone
                    ? '<span class="text-green-400 text-xs font-bold">TAMAM</span>'
                    : '<div class="text-right"><div class="text-white font-black teko-font text-lg">+' + m.xp + ' XP</div><div class="text-[9px] text-zinc-500">' + progress + '/' + m.target + '</div></div>';
                html += '<div class="glass-panel p-4 rounded-2xl border ' + (isDone ? 'border-green-800/40' : 'border-zinc-700') + ' flex items-center gap-3 mb-3 ">';
                html += '<div class="text-3xl w-12 h-12 flex items-center justify-center bg-black/50 rounded-xl border border-zinc-800 shrink-0">' + m.icon + '</div>';
                html += '<div class="flex-1 min-w-0"><div class="font-bold text-sm ' + (isDone ? 'text-green-400' : 'text-white') + '">' + m.title + '</div><div class="text-[10px] text-zinc-500 mt-0.5">' + m.desc + '</div>' + pbHtml + '</div>' + btnHtml + '</div>';
            });
            html += '</div>';

            // === GUNLUK ===
            html += '<div id="m-daily" class="hidden">';
            html += '<div class="text-[10px] text-zinc-500 uppercase tracking-widest font-bold mb-3">Bugunun Gorevleri: ' + todayKey + '</div>';
            dailyData.missions.forEach(m => {
                const doneKey = 'done_' + m.id;
                const isDone = dm.date === todayKey && dm[doneKey];
                const progress = m.type === 'daily_login' ? (dm.date === todayKey ? 1 : 0) : (dm.date === todayKey ? (dm[m.type] || 0) : 0);
                const percent = Math.min((progress / m.target) * 100, 100);
                let pbHtml = isDone ? '' : '<div class="progress-bar-bg mt-2"><div class="progress-bar-fill" style="width:' + percent + '%;"></div></div>';
                let btnHtml = isDone
                    ? '<span class="text-green-400 text-xs font-bold">TAMAM</span>'
                    : '<div class="text-right"><div class="text-white font-black teko-font text-lg">+' + m.xp + ' XP</div><div class="text-[9px] text-zinc-500">' + progress + '/' + m.target + '</div></div>';
                html += '<div class="glass-panel p-4 rounded-2xl border ' + (isDone ? 'border-green-800/40' : 'border-yellow-900/40') + ' flex items-center gap-3 mb-3 ">';
                html += '<div class="text-3xl w-12 h-12 flex items-center justify-center bg-black/50 rounded-xl border border-zinc-800 shrink-0">' + m.icon + '</div>';
                html += '<div class="flex-1 min-w-0"><div class="font-bold text-sm ' + (isDone ? 'text-green-400' : 'text-yellow-400') + '">' + m.title + '</div><div class="text-[10px] text-zinc-500 mt-0.5">' + m.desc + '</div>' + pbHtml + '</div>' + btnHtml + '</div>';
            });
            html += '</div>';

            // === HAFTALIK ===
            html += '<div id="m-weekly" class="hidden">';
            html += '<div class="text-[10px] text-zinc-500 uppercase tracking-widest font-bold mb-3">Bu Haftanin Gorevleri (Pzt: ' + weekKey + ')</div>';
            weeklyData.missions.forEach(m => {
                const doneKey = 'done_' + m.id;
                const isDone = wm.week === weekKey && wm[doneKey];
                const progress = wm.week === weekKey ? (wm[m.type] || 0) : 0;
                const percent = Math.min((progress / m.target) * 100, 100);
                let pbHtml = isDone ? '' : '<div class="progress-bar-bg mt-2"><div class="progress-bar-fill" style="background:linear-gradient(90deg,#7c3aed,#4f46e5);width:' + percent + '%;"></div></div>';
                let btnHtml = isDone
                    ? '<span class="text-green-400 text-xs font-bold">TAMAM</span>'
                    : '<div class="text-right"><div class="text-white font-black teko-font text-lg">+' + m.xp + ' XP</div><div class="text-[9px] text-zinc-500">' + progress + '/' + m.target + '</div></div>';
                html += '<div class="glass-panel p-4 rounded-2xl border ' + (isDone ? 'border-green-800/40' : 'border-purple-900/40') + ' flex items-center gap-3 mb-3 ">';
                html += '<div class="text-3xl w-12 h-12 flex items-center justify-center bg-black/50 rounded-xl border border-zinc-800 shrink-0">' + m.icon + '</div>';
                html += '<div class="flex-1 min-w-0"><div class="font-bold text-sm ' + (isDone ? 'text-green-400' : 'text-purple-400') + '">' + m.title + '</div><div class="text-[10px] text-zinc-500 mt-0.5">' + m.desc + '</div>' + pbHtml + '</div>' + btnHtml + '</div>';
            });
            html += '</div>';

            c.innerHTML = html;
            window._missionTab = window._missionTab || 0;
            setMissionTab(window._missionTab);
        }

        function setMissionTab(idx) {
            window._missionTab = idx;
            ['m-perm','m-daily','m-weekly'].forEach((id,i) => {
                const el = document.getElementById(id);
                if(el) el.classList.toggle('hidden', i !== idx);
            });
            [0,1,2].forEach(i => {
                const btn = document.getElementById('mtab-'+i);
                if(!btn) return;
                btn.className = i === idx
                    ? 'flex-1 py-2 bg-zinc-800 text-white rounded-lg font-bold text-xs transition'
                    : 'flex-1 py-2 text-zinc-500 rounded-lg font-bold text-xs transition';
            });
        }
        // ==============================================================
        // ==============================================================
        // BİSİKLET YARIŞMASI SİSTEMİ
        // ==============================================================
        let _compCurrentCategory = 'Tümü';
        let _compCurrentEntries = [];
        let _ratingTargetId = null;

        function getWeekId() {
            const now = new Date();
            const jan1 = new Date(now.getFullYear(), 0, 1);
            const week = Math.ceil(((now - jan1) / 86400000 + jan1.getDay() + 1) / 7);
            return now.getFullYear() + '-W' + String(week).padStart(2, '0');
        }

        // =====================================================
        // ÇEKİLİŞ (GIVEAWAY) SİSTEMİ
        // =====================================================
        window.renderGiveaway = async function() {
            const loading  = document.getElementById('gw-loading');
            const listContainer = document.getElementById('gw-list-container');
            const adminEl  = document.getElementById('gw-admin-panel');
            if(!loading || !listContainer) return;

            loading.style.display = 'block';
            loading.innerHTML = 'Yükleniyor...';
            listContainer.innerHTML = '';

            // Admin panelini yalnızca adminlere göster
            const isAdmin = currentUser && (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin');
            if(adminEl && isAdmin) adminEl.classList.remove('hidden');

            try {
                const r = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'get_giveaway'})
                });
                const res = await r.json();
                loading.style.display = 'none';
                
                let giveaways = Array.isArray(res.data) ? res.data : (res.data ? [res.data] : []);

                if(giveaways.length === 0) {
                    listContainer.innerHTML = `<div class="text-center py-16">
                        <div class="text-5xl mb-4">🎁</div>
                        <div class="text-zinc-400 font-bold text-lg">Şu an kayıtlı bir çekiliş yok.</div>
                        <div class="text-zinc-600 text-sm mt-2">Yakında yeni çekilişler başlayacak, takipte kal!</div>
                    </div>`;
                    return;
                }

                let html = '';
                giveaways.forEach(gw => {
                    const participants = gw.participants || [];
                    const count = participants.length;
                    const alreadyJoined = currentUser && participants.includes(currentUser.username);
                    const imageHtml = gw.image ? `<img src="${gw.image}" alt="Giveaway" class="w-full h-48 md:h-64 object-cover">` : '';
                    
                    if(gw.is_active) {
                        let joinArea = '';
                        if(alreadyJoined) {
                            joinArea = `<button disabled class="w-full py-4 bg-zinc-700 text-zinc-400 font-black text-lg rounded-xl cursor-not-allowed">✅ Katıldınız!</button>`;
                        } else {
                            joinArea = `
                            <div class="mb-4">
                                <div class="text-xs text-zinc-400 mb-2 font-bold ml-1">Instagram Kullanıcı Adınız (Zorunlu)</div>
                                <div class="relative">
                                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-bold">@</span>
                                    <input type="text" id="ig-input-${gw.id}" placeholder="kullanici_adiniz" class="w-full bg-black/50 border border-zinc-700 focus:border-emerald-500 text-white pl-8 pr-4 py-3 rounded-xl outline-none transition-colors">
                                </div>
                            </div>
                            <button id="btn-join-${gw.id}" onclick="window.joinGiveaway('${gw.id}')" class="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-lg rounded-xl shadow-lg shadow-emerald-500/20 hover:scale-[1.02] hover:shadow-emerald-500/40 active:scale-95 transition-all">
                                🎉 Çekilişe Katıl
                            </button>
                            `;
                        }
                        
                        let adminControls = isAdmin ? `
                        <div class="mt-4 pt-4 border-t border-zinc-800">
                            <button onclick="window.adminDrawGiveaway('${gw.id}')" class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-xl shadow-lg shadow-purple-500/20 hover:scale-[1.02] transition-all">🎲 Bu Çekilişin Kazananını Seç</button>
                            <button onclick="window.adminDeleteGiveaway('${gw.id}')" class="w-full py-2 mt-2 bg-zinc-800 hover:bg-red-900/40 text-zinc-400 hover:text-red-400 font-bold rounded-xl transition-all text-sm">🗑️ Bu Çekilişi Sil</button>
                        </div>
                        ` : '';

                        html += `
                        <div class="bg-zinc-900 border border-emerald-500/30 rounded-2xl overflow-hidden shadow-[0_0_20px_rgba(16,185,129,0.15)] relative">
                            ${imageHtml}
                            <div class="p-6">
                                <div class="inline-block px-3 py-1 bg-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-widest rounded-lg mb-3">🔥 Aktif Çekiliş</div>
                                <h3 class="text-2xl font-black text-white mb-2 leading-tight">${gw.title || ''}</h3>
                                <p class="text-zinc-400 text-sm font-medium mb-6 leading-relaxed whitespace-pre-wrap">${gw.desc || ''}</p>
                                
                                <div class="flex items-center justify-between mb-6 p-4 bg-black/40 rounded-xl border border-zinc-800">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 text-xl">👥</div>
                                        <div>
                                            <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Katılımcı Sayısı</div>
                                            <div class="text-lg font-black text-white">${count} Kişi</div>
                                        </div>
                                    </div>
                                </div>
                                ${joinArea}
                                ${adminControls}
                            </div>
                        </div>
                        `;
                    } else {
                        const winnerIg = (gw.participants_ig && gw.winner) ? gw.participants_ig[gw.winner] : '';
                        const winnerIgText = winnerIg ? `<div class="text-sm text-pink-300 font-bold mt-2">📸 Instagram: @${winnerIg}</div>` : '';
                        html += `
                        <div class="bg-zinc-900 border border-purple-500/30 rounded-2xl overflow-hidden shadow-[0_0_20px_rgba(168,85,247,0.15)] text-center p-8 relative">
                            <div class="absolute top-4 right-4 bg-zinc-800 text-zinc-400 text-[10px] font-bold px-2 py-1 rounded">Sona Erdi</div>
                            <div class="text-4xl mb-4 animate-bounce">🏆</div>
                            <h3 class="text-xl font-black text-white mb-2">${gw.title || 'Çekiliş'} - Sonuçlandı!</h3>
                            <div class="text-xs text-zinc-500 mb-6">Toplam ${count} kişi katılmıştı.</div>
                            <div class="p-4 bg-gradient-to-r from-purple-900/40 to-pink-900/40 border border-purple-500/30 rounded-xl inline-block px-8">
                                <div class="text-[10px] text-purple-300 font-bold uppercase tracking-widest mb-1">KAZANAN</div>
                                <div class="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">@${gw.winner || 'Bilinmiyor'}</div>
                                ${winnerIgText}
                            </div>
                        </div>
                        `;
                    }
                });
                
                listContainer.innerHTML = html;

            } catch(e) {
                if(loading) {
                    loading.style.display = 'none';
                }
                if(listContainer) {
                    listContainer.innerHTML = '<div class="text-center text-red-400 py-10">Yüklenemedi, sayfayı yenile.</div>';
                }
            }
        };


        window.joinGiveaway = async function(gw_id) {
            const btn = document.getElementById('btn-join-' + gw_id);
            const igInp = document.getElementById('ig-input-' + gw_id);
            const igVal = igInp ? igInp.value.trim().replace(/^@/, '') : '';
            if(!igVal) {
                if(typeof showToast === 'function') showToast('Instagram kullanıcı adınızı girin!', 'error', 2500);
                if(igInp) igInp.focus();
                return;
            }
            if(btn) { btn.disabled = true; btn.textContent = 'Katılınıyor...'; }
            try {
                const r = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'join_giveaway', gw_id: gw_id, instagram: igVal})
                });
                const res = await r.json();
                if(res.status === 'ok') {
                    if(typeof showToast === 'function') showToast('🎉 Çekilişe katıldınız!', 'success', 3000);
                    window.renderGiveaway();
                } else {
                    if(typeof showToast === 'function') showToast(res.message || 'Hata!', 'error', 3000);
                    if(btn) { btn.disabled = false; btn.textContent = '🎉 Çekilişe Katıl'; }
                }
            } catch(e) {
                if(typeof showToast === 'function') showToast('Bağlantı hatası!', 'error', 2000);
                if(btn) { btn.disabled = false; btn.textContent = '🎉 Çekilişe Katıl'; }
            }
        };

        // Admin: resim base64 önizleme + compress
        window.gwAdminPickImageChange = function(e) {
            const file = e.target.files[0];
            if(!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let width = img.width;
                    let height = img.height;
                    const MAX_DIM = 800;
                    if(width > height) {
                        if(width > MAX_DIM) { height *= MAX_DIM / width; width = MAX_DIM; }
                    } else {
                        if(height > MAX_DIM) { width *= MAX_DIM / height; height = MAX_DIM; }
                    }
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                    
                    window._gwAdminImageBase64 = dataUrl;
                    const preview = document.getElementById('gw-admin-img-preview');
                    if(preview) { preview.src = dataUrl; preview.classList.remove('hidden'); }
                    const lbl = document.getElementById('gw-admin-img-label');
                    if(lbl) lbl.textContent = '✅ ' + file.name;
                };
                img.src = ev.target.result;
            };
            reader.readAsDataURL(file);
        };

        window.adminSaveGiveaway = async function() {
            const title = document.getElementById('gw-admin-title').value.trim();
            const desc  = document.getElementById('gw-admin-desc').value.trim();
            const imageUrl = document.getElementById('gw-admin-image') ? document.getElementById('gw-admin-image').value.trim() : '';
            const imageB64 = window._gwAdminImageBase64 || '';
            const image = imageB64 || imageUrl;

            if(!title) { if(typeof showToast === 'function') showToast('Başlık zorunludur!', 'error', 2000); return; }
            
            const saveBtn = document.getElementById('gw-save-btn');
            if(saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Başlatılıyor...'; }

            try {
                const r = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'admin_save_giveaway', title, desc, image})
                });
                const res = await r.json();
                if(res.status === 'ok') {
                    if(typeof showToast === 'function') showToast('✅ Yeni Çekiliş başlatıldı! Herkese bildirim gönderildi.', 'success', 3000);
                    document.getElementById('gw-admin-title').value = '';
                    document.getElementById('gw-admin-desc').value  = '';
                    if(document.getElementById('gw-file-input')) document.getElementById('gw-file-input').value = '';
                    if(document.getElementById('gw-admin-image')) document.getElementById('gw-admin-image').value = '';
                    window._gwAdminImageBase64 = null;
                    const preview = document.getElementById('gw-admin-img-preview');
                    if(preview) preview.classList.add('hidden');
                    const lbl = document.getElementById('gw-admin-img-label');
                    if(lbl) lbl.textContent = "Eğer galeriniz açılmıyorsa alt kısımdan resim URL'si yapıştırabilirsiniz.";
                    window.renderGiveaway();
                } else {
                    if(typeof showToast === 'function') showToast(res.message || 'Hata!', 'error', 3000);
                }
            } catch(e) {
                if(typeof showToast === 'function') showToast('Bağlantı hatası! Tekrar dene.', 'error', 2500);
            } finally {
                if(saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Yeni Çekiliş Başlat'; }
            }
        };

        window.adminDrawGiveaway = async function(gw_id) {
            if(!confirm('Rastgele bir kazanan seçmek istediğinizden emin misiniz? Bu işlem geri alınamaz!')) return;
            try {
                const r = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'admin_draw_giveaway', gw_id: gw_id})
                });
                const res = await r.json();
                if(res.status === 'ok') {
                    if(typeof showToast === 'function') showToast('🏆 Kazanan: @' + res.winner + (res.winner_ig ? ' (IG: @'+res.winner_ig+')' : '') + ' — Tebrikler!', 'success', 6000);
                    if(typeof _launchGiveawayConfetti === 'function') _launchGiveawayConfetti();
                    window.renderGiveaway();
                } else {
                    if(typeof showToast === 'function') showToast(res.message || 'Hata!', 'error', 3000);
                }
            } catch(e) {
                if(typeof showToast === 'function') showToast('Bağlantı hatası!', 'error', 2000);
            }
        };

        window.adminDeleteGiveaway = async function(gw_id) {
            if(!confirm('Bu çekilişi silmek istediğinize emin misiniz?')) return;
            try {
                const r = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'admin_delete_giveaway', gw_id: gw_id})
                });
                const res = await r.json();
                if(res.status === 'ok') {
                    if(typeof showToast === 'function') showToast('Çekiliş silindi.', 'success', 2000);
                    window.renderGiveaway();
                } else {
                    if(typeof showToast === 'function') showToast(res.message || 'Hata!', 'error', 3000);
                }
            } catch(e) {
                if(typeof showToast === 'function') showToast('Bağlantı hatası!', 'error', 2000);
            }
        };

        function _launchGiveawayConfetti() {
            const colors = ['#10b981','#06b6d4','#a855f7','#f59e0b','#ef4444','#3b82f6'];
            const container = document.body;
            for(let i = 0; i < 80; i++) {
                const c = document.createElement('div');
                const size = Math.random() * 10 + 6;
                c.style.cssText = `
                    position:fixed; pointer-events:none; z-index:999999;
                    width:${size}px; height:${size}px; border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
                    background:${colors[Math.floor(Math.random()*colors.length)]};
                    left:${Math.random()*100}vw; top:-20px;
                    animation: confettiFall ${1.5 + Math.random()*2}s ease-in forwards;
                    animation-delay:${Math.random()*1.5}s;
                    opacity:0.9;
                `;
                container.appendChild(c);
                setTimeout(() => c.remove(), 4000);
            }
        }

        async function renderCompetition() {
            if (!currentUser) return;
            document.getElementById('comp-week-label').textContent = 'Yükleniyor...';
            document.getElementById('comp-entries-list').innerHTML = '<div class="text-center text-zinc-600 text-xs py-10 animate-pulse">Yükleniyor...</div>';
            try {
                // week_id sunucu tarafindan hesaplanir, biz gondermeyelim
                const res = await sendAction('get_competitions', {});
                if (res && res.status === 'ok') {
                    _compCurrentEntries = res.entries || [];
                    document.getElementById('comp-week-label').textContent = (res.week_id || '') + ' Haftası';
                    renderCompetitionList(_compCurrentEntries);
                    renderCompetitionWinners(res.prev_winners || []);
                } else {
                    document.getElementById('comp-entries-list').innerHTML = '<div class="text-center text-red-400 text-xs py-10 font-bold">❌ ' + (res?.message || 'Hata oluştu.') + '<br><span class="text-zinc-500 font-normal">Supabase veritabanında bike_competitions tablosunu oluşturdunuz mu?</span></div>';
                }
            } catch(e) {
                document.getElementById('comp-entries-list').innerHTML = '<div class="text-center text-zinc-500 text-xs py-10">Veriler yüklenemedi. Bağlantıyı kontrol edin.</div>';
            }
        }

        function setCompetitionCategory(cat) {
            _compCurrentCategory = cat;
            document.querySelectorAll('.comp-cat-btn').forEach(btn => {
                btn.classList.remove('bg-orange-500', 'text-white');
                btn.classList.add('bg-zinc-800', 'text-zinc-400');
            });
            const activeBtn = document.getElementById('ctab-' + cat);
            if (activeBtn) { activeBtn.classList.add('bg-orange-500', 'text-white'); activeBtn.classList.remove('bg-zinc-800', 'text-zinc-400'); }
            const filtered = cat === 'Tümü' ? _compCurrentEntries : _compCurrentEntries.filter(e => e.category === cat);
            renderCompetitionList(filtered);
        }

        function renderCompetitionList(entries) {
            const container = document.getElementById('comp-entries-list');
            document.getElementById('comp-entry-count').textContent = entries.length + ' bisiklet';
            if (entries.length === 0) {
                container.innerHTML = '<div class="text-center text-zinc-600 text-xs py-12 italic">Bu kategoride henüz yarışmacı yok.<br><span class="text-orange-400 font-bold">İlk sen ekle!</span></div>';
                return;
            }
            const isAdmin = currentUser && (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin');
            container.innerHTML = '';
            entries.forEach((entry, idx) => {
                const bike = entry.bike_data || {};
                const img = Array.isArray(bike.image) ? bike.image[0] : (bike.image || '');
                const avgRating = entry.avg_rating || 0;
                const ratingCount = (entry.user_ratings || []).length;
                const myRating = (entry.user_ratings || []).find(r => r.user === currentUser.username);
                const rank = entry.final_rank;
                const rankBadge = rank === 1 ? '<span class="text-yellow-400 font-black text-lg">🥇</span>' : rank === 2 ? '<span class="text-zinc-300 font-black text-lg">🥈</span>' : rank === 3 ? '<span class="text-orange-400 font-black text-lg">🥉</span>' : '';
                const isMine = entry.username === currentUser.username;
                const stars = avgRating > 0 ? '⭐ ' + avgRating.toFixed(1) : '—';
                const starColor = avgRating >= 8 ? 'text-yellow-400' : avgRating >= 5 ? 'text-orange-400' : 'text-zinc-500';

                let adminBtns = '';
                if (isAdmin) {
                    adminBtns = `<div class="flex gap-1 mt-2">
                        <button onclick="adminSetWinner('${entry.id}', 1)" class="flex-1 py-1 text-[9px] font-black bg-yellow-500/20 border border-yellow-500/40 text-yellow-400 rounded-lg hover:bg-yellow-500/40 transition">🥇 1.</button>
                        <button onclick="adminSetWinner('${entry.id}', 2)" class="flex-1 py-1 text-[9px] font-black bg-zinc-500/20 border border-zinc-500/40 text-zinc-300 rounded-lg hover:bg-zinc-500/40 transition">🥈 2.</button>
                        <button onclick="adminSetWinner('${entry.id}', 3)" class="flex-1 py-1 text-[9px] font-black bg-orange-500/20 border border-orange-500/40 text-orange-400 rounded-lg hover:bg-orange-500/40 transition">🥉 3.</button>
                    </div>
                    <button onclick="removeFromCompetition('${entry.id}', true)" class="w-full mt-1 py-1 text-[9px] font-black bg-red-500/20 border border-red-500/40 text-red-400 rounded-lg hover:bg-red-500/40 transition">❌ Diskalifiye Et</button>`;
                }

                let rateBtn = '';
                if (isMine) {
                    rateBtn = `<button onclick="removeFromCompetition('${entry.id}', false)" class="text-[10px] font-black text-red-400 bg-red-500/10 border border-red-500/30 px-3 py-1.5 rounded-xl hover:bg-red-500/20 transition">❌ Yarıştan Çek</button>`;
                } else {
                    rateBtn = myRating
                        ? `<button onclick="openRateBikeModal('${entry.id}', '${(bike.model||'').replace(/'/g,"\\'")}', '${entry.username}')" class="text-[10px] font-black text-orange-400 bg-orange-500/10 border border-orange-500/30 px-3 py-1.5 rounded-xl hover:bg-orange-500/20 transition">✏️ Puanı Düzenle (${myRating.score})</button>`
                        : `<button onclick="openRateBikeModal('${entry.id}', '${(bike.model||'').replace(/'/g,"\\'")}', '${entry.username}')" class="text-[10px] font-black text-white bg-orange-500 px-3 py-1.5 rounded-xl hover:opacity-80 transition ">⭐ Puanla</button>`;
                }

                container.innerHTML += `
                <div onclick="openCompBikeDetail('${entry.id}')" class="bg-black/40 border ${rank > 0 ? 'border-yellow-500/30' : 'border-zinc-800'} rounded-2xl overflow-hidden  hover:border-zinc-500 transition cursor-pointer group flex flex-col relative btn-premium-hover">
                    ${img ? `<img src="${img}" class="w-full h-48 md:h-56 object-cover border-b border-zinc-700/50 group-hover:scale-105 transition duration-500">` : `<div class="w-full h-48 md:h-56 bg-zinc-900 border-b border-zinc-700/50 flex items-center justify-center text-5xl">🚵</div>`}
                    <div class="p-4 flex-1 flex flex-col relative z-10 bg-black/60">
                        <div class="flex justify-between items-start mb-2">
                            <div>
                                <div class="flex items-center gap-2 mb-1">
                                    ${rankBadge}
                                    <span class="text-white font-black text-lg truncate">${bike.model || 'Bisiklet'}</span>
                                </div>
                                <div class="text-xs text-zinc-400 font-bold uppercase tracking-widest">${bike.brand || ''} • ${entry.category}</div>
                            </div>
                            <div class="text-right">
                                <div class="font-black text-xl ${starColor}">${stars}</div>
                                <div class="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">${ratingCount} puan</div>
                            </div>
                        </div>
                        <div class="mt-auto pt-3 flex justify-between items-center border-t border-zinc-800/50">
                            <div class="text-xs text-zinc-400 font-bold hover:text-white transition" onclick="event.stopPropagation(); showOtherProfile('${entry.username}')">👤 ${entry.username}</div>
                            <div onclick="event.stopPropagation()">${rateBtn}</div>
                        </div>
                        ${adminBtns ? `<div class="mt-3" onclick="event.stopPropagation()">${adminBtns}</div>` : ''}
                    </div>
                </div>`;
            });
        }

        function renderCompetitionWinners(winners) {
            const section = document.getElementById('comp-winners-section');
            const list = document.getElementById('comp-winners-list');
            if (!winners || winners.length === 0) { section.classList.add('hidden'); return; }
            section.classList.remove('hidden');
            const rankEmoji = { 1: '🥇', 2: '🥈', 3: '🥉' };
            list.innerHTML = '';
            winners.forEach(w => {
                const bike = w.bike_data || {};
                list.innerHTML += `
                <div class="flex items-center gap-3 bg-yellow-950/20 border border-yellow-800/30 rounded-xl p-3">
                    <span class="text-2xl">${rankEmoji[w.final_rank] || '🏅'}</span>
                    <div class="flex-1 min-w-0">
                        <div class="text-white font-black text-xs truncate">${bike.model || 'Bisiklet'}</div>
                        <div class="text-[10px] text-yellow-400 font-bold">${w.username} • ${w.category}</div>
                    </div>
                    <div class="text-yellow-400 font-black text-sm">⭐ ${(w.avg_rating||0).toFixed(1)}</div>
                </div>`;
            });
        }

        function openSubmitBikeModal(preSelectIndex) {
            if (!currentUser) return;
            const garage = (currentUser.stats || {}).garage || [];
            const gDiv = document.getElementById('submit-bike-garage');
            if (garage.length === 0) {
                gDiv.innerHTML = '<div class="col-span-2 text-xs text-zinc-500 italic text-center py-4">Garajınızda bisiklet yok. Önce profil sayfanızdan bisiklet ekleyin.</div>';
            } else {
                gDiv.innerHTML = '';
                garage.forEach((b, idx) => {
                    const img = Array.isArray(b.image) ? b.image[0] : (b.image || '');
                    gDiv.innerHTML += `
                    <div onclick="selectGarageBikeForComp(${idx})" id="comp-bike-${idx}" class="comp-bike-sel bg-black/50 rounded-xl overflow-hidden border border-zinc-700 cursor-pointer hover:border-orange-400 transition p-2">
                        ${img ? `<img src="${img}" class="w-full h-16 object-cover rounded-lg mb-1">` : `<div class="w-full h-16 rounded-lg bg-zinc-900 flex items-center justify-center text-2xl mb-1">🚵</div>`}
                        <div class="text-white text-[10px] font-bold truncate">${b.model || 'Bisiklet'}</div>
                        <div class="text-zinc-500 text-[9px] uppercase font-bold truncate">${b.type || ''}</div>
                    </div>`;
                });
            }
            window._selectedBikeIndex = null;
            document.getElementById('submit-bike-modal').classList.remove('hidden');
            // Eğer garajdan direkt butona basıldıysa o bisikleti önceden seç
            if (preSelectIndex !== undefined && preSelectIndex !== null) {
                setTimeout(() => selectGarageBikeForComp(preSelectIndex), 50);
            }
        }

        function selectGarageBikeForComp(idx) {
            window._selectedBikeIndex = idx;
            document.querySelectorAll('.comp-bike-sel').forEach(el => {
                el.classList.remove('border-orange-400', 'bg-orange-500/10');
                el.classList.add('border-zinc-700');
            });
            const sel = document.getElementById('comp-bike-' + idx);
            if (sel) { sel.classList.add('border-orange-400', 'bg-orange-500/10'); sel.classList.remove('border-zinc-700'); }
        }

        async function submitBikeToCompetition() {
            if (window._selectedBikeIndex === null || window._selectedBikeIndex === undefined) {
                showToast('🚵 Lütfen bir bisiklet seçin!'); return;
            }
            const category = document.getElementById('submit-bike-category').value;
            try {
                const res = await sendAction('submit_bike', { bike_index: window._selectedBikeIndex, category });
                if (res && res.status === 'ok') {
                    document.getElementById('submit-bike-modal').classList.add('hidden');
                    showToast('✅ Bisikletiniz yarışmaya eklendi!');
                    await renderCompetition();
                } else {
                    showToast('❌ ' + (res?.message || 'Hata oluştu.'));
                }
            } catch(e) { showToast('❌ Ağ hatası.'); }
        }

        function openRateBikeModal(entryId, bikeModel, ownerName) {
            _ratingTargetId = entryId;
            document.getElementById('rate-bike-info').innerHTML = `
                <div class="bg-zinc-900 rounded-xl p-3 border border-zinc-700">
                    <div class="text-white font-black text-sm">${bikeModel}</div>
                    <div class="text-zinc-400 text-[10px] font-bold mt-0.5">👤 ${ownerName}</div>
                </div>`;
            document.getElementById('rate-score-slider').value = 5;
            document.getElementById('rate-score-display').textContent = '5';
            document.getElementById('rate-bike-modal').classList.remove('hidden');
        }

        async function submitBikeRating() {
            if (!_ratingTargetId) return;
            const score = parseFloat(document.getElementById('rate-score-slider').value);
            try {
                const res = await sendAction('rate_bike', { entry_id: _ratingTargetId, score });
                if (res && res.status === 'ok') {
                    document.getElementById('rate-bike-modal').classList.add('hidden');
                    showToast('⭐ Puanınız kaydedildi! Ortalama: ' + res.avg_rating);
                    // Update local entry avg_rating
                    const entry = _compCurrentEntries.find(e => e.id === _ratingTargetId);
                    if (entry) {
                        entry.avg_rating = res.avg_rating;
                        const existing = (entry.user_ratings || []).findIndex(r => r.user === currentUser.username);
                        if (existing >= 0) entry.user_ratings[existing].score = score;
                        else entry.user_ratings.push({ user: currentUser.username, score });
                    }
                    const cat = _compCurrentCategory;
                    const filtered = cat === 'Tümü' ? _compCurrentEntries : _compCurrentEntries.filter(e => e.category === cat);
                    renderCompetitionList(filtered);
                } else {
                    showToast('❌ ' + (res?.message || 'Hata oluştu.'));
                }
            } catch(e) { showToast('❌ Ağ hatası.'); }
        }

        async function adminSetWinner(entryId, rank) {
            if (!confirm(rank + '. sıra olarak belirlemek istediğine emin misin? Kullanıcıya rozet ve XP verilecek.')) return;
            try {
                const res = await sendAction('admin_set_winner', { entry_id: entryId, rank });
                if (res && res.status === 'ok') {
                    showToast('🏆 ' + (res.message || 'Kazanan belirlendi!'));
                    await renderCompetition();
                } else {
                    showToast('❌ ' + (res?.message || 'Hata oluştu.'));
                }
            } catch(e) { showToast('❌ Ağ hatası.'); }
        }

        async function removeFromCompetition(entryId, isDisqualify) {
            const msg = isDisqualify ? 'Bu bisikleti yarışmadan diskalifiye etmek istediğine emin misin?' : 'Bisikletini yarışmadan çekmek istediğine emin misin?';
            if (!confirm(msg)) return;
            try {
                const res = await sendAction('remove_from_competition', { entry_id: entryId });
                if (res && res.status === 'ok') {
                    showToast('✅ ' + (res.message || 'Bisiklet yarışmadan çıkarıldı.'));
                    document.getElementById('comp-bike-detail-modal').classList.add('hidden');
                    await renderCompetition();
                } else {
                    showToast('❌ ' + (res?.message || 'Hata oluştu.'));
                }
            } catch(e) { showToast('❌ Ağ hatası.'); }
        }

        function openCompBikeDetail(entryId) {
            const entry = _compCurrentEntries.find(e => e.id === entryId);
            if (!entry) return;
            const bike = entry.bike_data || {};
            const img = Array.isArray(bike.image) ? bike.image[0] : (bike.image || 'https://placehold.co/400x300/121214/FFF?text=FOTO+YOK');
            
            document.getElementById('cbd-image').src = img;
            document.getElementById('cbd-model').textContent = bike.model || 'Bisiklet';
            document.getElementById('cbd-brand').textContent = bike.brand || '';
            document.getElementById('cbd-category').textContent = entry.category;
            
            const ownerEl = document.getElementById('cbd-owner');
            ownerEl.textContent = '👤 ' + entry.username;
            ownerEl.onclick = () => {
                document.getElementById('comp-bike-detail-modal').classList.add('hidden');
                showOtherProfile(entry.username);
            };
            
            const avgRating = entry.avg_rating || 0;
            const ratingCount = (entry.user_ratings || []).length;
            const starColor = avgRating >= 8 ? 'text-yellow-400' : avgRating >= 5 ? 'text-orange-400' : 'text-zinc-500';
            document.getElementById('cbd-stars').textContent = avgRating > 0 ? '⭐ ' + avgRating.toFixed(1) : '—';
            document.getElementById('cbd-stars').className = `text-2xl font-black  ${starColor}`;
            document.getElementById('cbd-rating-count').textContent = `${ratingCount} oy`;

            const fields = [
                ["Marka", bike.brand],
                ["Kategori", bike.type],
                ["Kadro", bike.frame],
                ["Maşa", bike.fork],
                ["Şok", bike.shock],
                ["Frenler", bike.brakes],
                ["Aktarıcı", bike.drivetrain],
                ["Zincir", bike.chain],
                ["Krank / BB", bike.crankset],
                ["Jantlar", bike.wheelset],
                ["Lastikler", bike.tires],
                ["Gidon", bike.handlebar],
                ["Sele", bike.saddle],
                ["Pedallar", bike.pedals],
                ["Ağırlık", bike.weight],
            ];
            
            let specsHtml = "";
            fields.forEach(([label, val]) => {
                if(val) specsHtml += `<div class="flex justify-between py-2 border-b border-zinc-800/50">
                    <span class="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">${label}</span>
                    <span class="text-xs text-zinc-200 font-medium text-right max-w-[55%]">${val}</span>
                </div>`;
            });
            document.getElementById('cbd-specs').innerHTML = specsHtml || "<div class='text-zinc-600 text-xs italic text-center'>Ek detay girilmemiş.</div>";
            
            const isMine = entry.username === currentUser.username;
            const myRating = (entry.user_ratings || []).find(r => r.user === currentUser.username);
            let actionHtml = '';
            
            if (isMine) {
                actionHtml = `<button onclick="removeFromCompetition('${entry.id}', false)" class="w-full py-4 text-xs font-black text-red-400 bg-red-900/20 border border-red-500/30 rounded-xl hover:bg-red-900/40 transition uppercase tracking-widest btn-premium-hover">❌ Yarıştan Çek</button>`;
            } else {
                actionHtml = myRating
                    ? `<button onclick="document.getElementById('comp-bike-detail-modal').classList.add('hidden'); openRateBikeModal('${entry.id}', '${(bike.model||'').replace(/'/g,"\\'")}', '${entry.username}')" class="w-full py-4 text-xs font-black text-orange-400 bg-orange-900/20 border border-orange-500/30 rounded-xl hover:bg-orange-900/40 transition uppercase tracking-widest btn-premium-hover">✏️ Puanı Düzenle (${myRating.score})</button>`
                    : `<button onclick="document.getElementById('comp-bike-detail-modal').classList.add('hidden'); openRateBikeModal('${entry.id}', '${(bike.model||'').replace(/'/g,"\\'")}', '${entry.username}')" class="w-full py-4 text-xs font-black text-black bg-gradient-to-r from-orange-500 to-yellow-500 rounded-xl hover:opacity-90 transition  uppercase tracking-widest btn-premium-hover">⭐ Puan Ver</button>`;
            }
            document.getElementById('cbd-actions').innerHTML = actionHtml;
            
            document.getElementById('comp-bike-detail-modal').classList.remove('hidden');
        }

        // ==============================================================
        // BİSİKLET YARIŞMASI GERİ SAYIM
        // ==============================================================
        let compCountdownInterval;
        function startCompCountdown() {
            if (compCountdownInterval) clearInterval(compCountdownInterval);
            
            function updateCountdown() {
                const now = new Date();
                // Find next Sunday 23:59:59
                const nextSunday = new Date(now);
                const day = now.getDay();
                // If today is Sunday, and we are before 23:59:59, next sunday is today
                // If we are past, or any other day, calculate days until next Sunday
                let diff = 7 - day;
                if (day === 0) diff = 0; // Today is Sunday
                
                nextSunday.setDate(now.getDate() + diff);
                nextSunday.setHours(23, 59, 59, 999);
                
                const timeDiff = nextSunday - now;
                if (timeDiff <= 0) {
                    document.getElementById('comp-countdown').textContent = "00:00:00 (Güncelleniyor...)";
                    return;
                }
                
                const d = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
                const h = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const m = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
                const s = Math.floor((timeDiff % (1000 * 60)) / 1000);
                
                let str = "";
                if (d > 0) str += `${d} GÜN `;
                str += `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
                
                const el = document.getElementById('comp-countdown');
                if (el) el.textContent = str;
            }
            
            updateCountdown();
            compCountdownInterval = setInterval(updateCountdown, 1000);
        }

        // ==============================================================
        // DAVET ET KAZAN (REFERANS) SEKMESİ İŞLEMLERİ
        // ==============================================================
        function renderReferralTab() {
            if(!currentUser) return;
            const stats = currentUser.stats || {};
            // Gerçek ref kodu stats'tan, yoksa fallback
            const refCode = stats.ref_code || currentUser.username;
            document.getElementById("my-ref-code").value = refCode;
            const refCount = stats.ref_count || 0;
            const claimable = stats.claimable_refs || 0;
            
            const maxRef = 10;
            const refPercent = Math.min((refCount / maxRef) * 100, 100);
            
            document.getElementById("ref-monthly-limit").innerText = `BU AYKİ KULLANIM: ${refCount} / ${maxRef}`;
            document.getElementById("ref-monthly-bar").style.width = `${refPercent}%`;
            document.getElementById("claimable-ref-count").innerText = claimable;
            
            const claimArea = document.getElementById("ref-claim-area");
            if(claimable > 0) {
                claimArea.style.opacity = "1";
                claimArea.style.pointerEvents = "auto";
                claimArea.style.filter = "none";
                claimArea.style.transform = "scale(1)";
                claimArea.style.transition = "all 0.3s ease";
            } else {
                claimArea.style.opacity = "0.35";
                claimArea.style.pointerEvents = "none";
                claimArea.style.filter = "grayscale(80%)";
                claimArea.style.transform = "scale(0.98)";
            }
        }

        function copyRefCode() {
            const code = document.getElementById("my-ref-code").value;
            navigator.clipboard.writeText(code);
            alert("Referans kodunuz başarıyla kopyalandı! Arkadaşlarınıza gönderebilirsiniz.");
        }

        async function claimRefReward() {
            const reward = document.getElementById("ref-reward-select").value;
            try {
                const res = await sendAction('claim_ref_reward', { reward_choice: reward });
                if(res.status === 'ok') {
                    alert("Tebrikler! Ödül başarıyla hesabınıza tanımlandı. Bol pedallı günler!");
                    loadData(true); 
                }
            } catch(e) {}
        }

        // ================================================================
        // REELS SİSTEMİ JS
        // ================================================================

        // ── Aktif IntersectionObserver listesi (eski kod uyumu — artık kullanılmıyor) ──
        const _reelObservers = [];

        // ──────────────────────────────────────────────────────────────
        // stopAllMedia() — Tüm video/ses medyayı durdurur, merkezi
        // feed observer'ı bağlantısını keser.
        // Sayfa geçişlerinde ve modal kapanışlarında çağrılır.
        // ──────────────────────────────────────────────────────────────
        function stopAllMedia() {
            document.querySelectorAll('video, audio').forEach(el => {
                try { el.pause(); } catch(_) {}
            });
            if(typeof _feedObserver !== 'undefined' && _feedObserver) {
                _feedObserver.disconnect();
                _feedObserver = null;
            }
        }

        // ──────────────────────────────────────────────────────────────
        // openReels(videoId) — Reels sayfasını açar ve belirtilen ID'li
        // videoya scroll ederek otomatik oynatır.
        // Profilden Reels'e ışınlanmak için kullanılır.
        // ──────────────────────────────────────────────────────────────
        window.openReels = async function(videoId) {
            stopAllMedia();
            // Tüm açık modalleri kapat
            ['other-profile-modal','reel-comment-modal','reel-upload-modal'].forEach(id => {
                const m = document.getElementById(id);
                if(m) m.classList.add('hidden');
            });
            // Reels ekranını aç
            const screenReels = document.getElementById('screen-reels');
            if(screenReels) {
                screenReels.style.display = 'flex';
                screenReels.style.flexDirection = 'column';
                screenReels.style.zIndex = '9990';
                screenReels.classList.remove('hidden');
            }
            const bottomNav = document.getElementById('bottom-nav');
            if(bottomNav) bottomNav.style.display = 'none';
            const soundBtn = document.getElementById('reel-sound-btn');
            if(soundBtn) { soundBtn.style.display = 'flex'; soundBtn.textContent = _reelMuted ? '🔇' : '🔊'; }
            const gridBtn = document.getElementById('grid-view-btn');
            if(gridBtn) gridBtn.style.display = 'flex';
            const uploadTopBtn = document.getElementById('reels-upload-top-btn');
            if(uploadTopBtn) uploadTopBtn.style.display = 'flex';

            // Her zaman yeniden yükle (feed güncel olsun, observer temiz başlasın)
            await loadReels(true);

            // loadReels render tamamlandıktan sonra scroll + oynat
            if(videoId && reelsData.length) {
                const idx = reelsData.findIndex(r => String(r.id) === String(videoId));
                const feed = document.getElementById('reels-feed');
                if(feed && idx >= 0) {
                    // 2 frame bekle: render + observer kurulumu tamamlansın
                    requestAnimationFrame(() => requestAnimationFrame(() => {
                        const cards = feed.querySelectorAll(':scope > div');
                        const targetCard = cards[idx];
                        if(!targetCard) return;
                        // observer'ı geçici durdur, scroll sırasında yanlış video çalmasın
                        if(_feedObserver) _feedObserver.disconnect();
                        // Tüm videolar durdurulmuş, scroll et
                        targetCard.scrollIntoView({ behavior: 'instant', block: 'start' });
                        // Scroll sonrası hedef videoyu oynat ve observer'ı yeniden kur
                        requestAnimationFrame(() => {
                            const video = targetCard.querySelector('video');
                            if(video) {
                                video.muted = _reelMuted;
                                video.play().catch(() => { video.muted = true; video.play().catch(() => {}); });
                            }
                            _setupFeedObserver();
                        });
                    }));
                }
            }
            history.pushState({ reelsOpen: true }, '');
        };

        function escapeHtml(str) {
            if(str == null) return '';
            return String(str)
                .replace(/&/g,'&amp;')
                .replace(/</g,'&lt;')
                .replace(/>/g,'&gt;')
                .replace(/"/g,'&quot;')
                .replace(/'/g,'&#39;');
        }

        let _reelMuted = false; // Varsayılan: ses açık

        // Reels'i kapat, önceki sekmeye dön
        function closeReels() {
            stopAllMedia(); // Hayalet ses önleme — tüm medyayı durdur
            const reelsEl = document.getElementById('screen-reels');
            if(reelsEl) {
                reelsEl.style.display = 'none';
                reelsEl.classList.add('hidden');
            }
            const bottomNav = document.getElementById('bottom-nav');
            if(bottomNav) bottomNav.style.display = '';
            const soundBtn = document.getElementById('reel-sound-btn');
            if(soundBtn) soundBtn.style.display = 'none';
            const gridBtn = document.getElementById('grid-view-btn');
            if(gridBtn) gridBtn.style.display = 'none';
            const uploadTopBtnC = document.getElementById('reels-upload-top-btn');
            if(uploadTopBtnC) uploadTopBtnC.style.display = 'none';
            document.querySelectorAll('#reels-feed video').forEach(v => v.pause());
            // Alt nav butonlarını güncelle
            const bnavIds = [0,1,9,3,7];
            bnavIds.forEach(i => {
                const btn = document.getElementById('bnav-' + i);
                if(!btn) return;
                if(i === _prevTab) {
                    btn.classList.add('text-white','bg-zinc-800/80');
                    btn.classList.remove('text-zinc-500');
                } else {
                    btn.classList.remove('text-white','bg-zinc-800/80');
                    btn.classList.add('text-zinc-500');
                }
            });
            // Önceki sekmeye geç (reels değilse)
            const target = (_prevTab === 9) ? 0 : _prevTab;
            const tabs = ['screen-map','screen-chat','screen-market','screen-rank','screen-news','screen-missions','screen-premium','screen-profile','screen-referral','screen-reels','screen-competition','screen-giveaway'];
            tabs.forEach((t, i) => {
                const el = document.getElementById(t);
                if(!el) return;
                if(i === target) {
                    el.style.display = 'flex';
                    el.style.flexDirection = 'column';
                    el.style.zIndex = '20';
                    el.classList.remove('hidden');
                } else {
                    el.style.display = 'none';
                    el.classList.add('hidden');
                }
            });
            if(target === 0 && map) map.invalidateSize();
        }

        function toggleReelSound() {
            _reelMuted = !_reelMuted;
            const btn = document.getElementById('reel-sound-btn');
            if(btn) btn.textContent = _reelMuted ? '🔇' : '🔊';
            document.querySelectorAll('#reels-feed video').forEach(v => { v.muted = _reelMuted; });
        }

        // ── TEK merkezi IntersectionObserver — tüm feed kartları için ──
        // Kart başına değil, feed render bittikten sonra tek seferde kurulur.
        let _feedObserver = null;
        function _setupFeedObserver() {
            if(_feedObserver) { _feedObserver.disconnect(); _feedObserver = null; }
            if(_reelsGridMode) return; // Grid modunda observer gerekmez
            const feed = document.getElementById('reels-feed');
            if(!feed) return;
            _feedObserver = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    const video = entry.target.querySelector('video');
                    if(!video) return;
                    if(_reelsGridMode) { video.pause(); return; }
                    if(entry.isIntersecting) {
                        // Diğer tüm feed videolarını durdur → sadece görünür kart çalar
                        document.querySelectorAll('#reels-feed video').forEach(v => {
                            if(v !== video) v.pause();
                        });
                        video.muted = _reelMuted;
                        video.play().catch(() => { video.muted = true; video.play().catch(() => {}); });
                    } else {
                        video.pause();
                    }
                });
            }, { threshold: 0.6, rootMargin: '0px' });
            feed.querySelectorAll(':scope > div').forEach(card => _feedObserver.observe(card));
        }

        async function loadReels(forceRefresh = false) {
            const feed = document.getElementById('reels-feed');
            
            // Zaten yüklüyse ve zorunlu yenileme istenmiyorsa, tekrar indirme (önbellekten kullan)
            if (!forceRefresh && reelsData && reelsData.length > 0 && feed && feed.children.length > 0) {
                if(_feedObserver) { _feedObserver.disconnect(); _feedObserver = null; }
                requestAnimationFrame(() => _setupFeedObserver());
                return;
            }

            // Observer ve medyayı temizle
            if(_feedObserver) { _feedObserver.disconnect(); _feedObserver = null; }
            document.querySelectorAll('#reels-feed video, #reels-feed audio').forEach(el => {
                try { el.pause(); el.removeAttribute('src'); el.load(); } catch(_) {}
            });
            reelsData = [];
            
            const emptyEl = document.getElementById('reels-empty');
            const loadingEl = document.getElementById('reels-loading');
            if(!feed) return;

            if(loadingEl) loadingEl.style.display = 'flex';
            if(emptyEl) emptyEl.classList.add('hidden');

            try {
                const res = await sendAction('get_reels', { offset: 0 });
                if(res && res.reels) reelsData = res.reels;
            } catch(e) { console.error('Reel yükleme hatası:', e); }

            if(loadingEl) loadingEl.style.display = 'none';

            const soundBtn = document.getElementById('reel-sound-btn');
            if(soundBtn) { soundBtn.style.display = 'flex'; soundBtn.textContent = _reelMuted ? '🔇' : '🔊'; }

            if(!reelsData.length) {
                if(emptyEl) emptyEl.classList.remove('hidden');
                return;
            }

            // Feed'i temizle ve yeniden render et
            while(feed.firstChild) feed.removeChild(feed.firstChild);
            reelsData.forEach((reel) => {
                try { renderReelCard(reel, feed); }
                catch(e) { console.error('Reel render hatası:', reel?.id, e); }
            });

            // Tek merkezi observer'ı kur (render bittikten sonra)
            requestAnimationFrame(() => _setupFeedObserver());
        }

        function renderReelCard(reel, container) {
            if(!reel) return;
            const user = db.users.find(u => u.username === reel.user) || { username: reel.user, avatar: '' };
            const avatar = user.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
            const isLiked = currentUser && (reel.likes || []).includes(currentUser.username);
            const likeCount = (reel.likes || []).length;
            const isOwner = currentUser && (currentUser.username === reel.user || currentUser.role === 'Admin' || currentUser.role === 'SubAdmin');

            // Story halkası: db.stories içinde aktif story var mı?
            const now = Math.floor(Date.now() / 1000);
            const hasActiveStory = db.stories && db.stories.some(s => s.user === reel.user && s.expires_at > now);
            const avatarRingClass = hasActiveStory ? 'story-ring' : 'border-2 border-white';
            
            const card = document.createElement('div');
            card.className = 'relative w-full shrink-0 bg-black flex items-center justify-center';
            card.style.cssText = 'height:100dvh;scroll-snap-align:start;scroll-snap-stop:always;';
            
            let mediaHtml = '';
            if(reel.media_type === 'video') {
                mediaHtml = `<video src="${escapeHtml(reel.media_url)}" class="w-full h-full object-contain" playsinline loop preload="none" style="max-height:100%;"></video>`;
            } else {
                mediaHtml = `<img src="${escapeHtml(reel.media_url)}" class="w-full h-full object-contain" style="max-height:100%;">`;
            }
            
            const timeAgo = formatTimeAgo(reel.created_at);
            
            card.innerHTML = `
                ${mediaHtml}
                <!-- Play/Pause flash ikonu -->
                <div class="reel-play-flash" style="pointer-events:none;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" width="80" height="80">
                        <circle cx="40" cy="40" r="38" fill="rgba(255,255,255,0.22)" stroke="rgba(255,255,255,0.5)" stroke-width="2"/>
                        <polygon class="flash-play-icon" points="30,22 62,40 30,58" fill="white" style="display:none;"/>
                        <g class="flash-pause-icon" style="display:none;">
                            <rect x="24" y="22" width="10" height="36" rx="3" fill="white"/>
                            <rect x="46" y="22" width="10" height="36" rx="3" fill="white"/>
                        </g>
                    </svg>
                </div>
                <!-- Gradient overlay -->
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none"></div>
                <!-- Sol alt: kullanıcı + açıklama -->
                <div class="absolute bottom-4 left-4 right-16 z-10">
                    <div class="flex items-center gap-2 mb-2 cursor-pointer" onclick="window.openProfileOrStory('${escapeHtml(reel.user)}')">
                        <div class="w-9 h-9 rounded-full overflow-hidden ${avatarRingClass} shrink-0">
                            <img src="${escapeHtml(avatar)}" class="w-full h-full object-cover">
                        </div>
                        <span class="text-white font-black text-sm ">${escapeHtml(reel.user)}</span>
                        <span class="text-zinc-400 text-xs">${timeAgo}</span>
                    </div>
                    ${reel.caption ? `<p class="text-white text-sm leading-snug  break-words line-clamp-2">${escapeHtml(reel.caption)}</p>` : ''}
                </div>
                <!-- Sağ: aksiyonlar -->
                <div class="absolute right-3 bottom-8 z-10 flex flex-col items-center gap-5">
                    <div class="flex flex-col items-center gap-1">
                        <button onclick="toggleReelLike('${reel.id}', this)" class="w-10 h-10 rounded-full bg-black/50  flex items-center justify-center text-xl border border-white/20 ${isLiked ? 'text-sky-400' : 'text-white'}">${isLiked ? '❤️' : '🤍'}</button>
                        <span onclick="showReelLikes('${reel.id}')" class="text-white text-xs font-bold  reel-like-count cursor-pointer hover:underline p-1">${likeCount}</span>
                    </div>
                    <button onclick="openReelComments('${reel.id}')" class="flex flex-col items-center gap-1">
                        <div class="w-10 h-10 rounded-full bg-black/50  flex items-center justify-center text-xl border border-white/20 text-white">💬</div>
                        <span class="text-white text-xs font-bold ">${reel.comment_count || 0}</span>
                    </button>
                    ${isOwner ? `<button onclick="deleteReel('${reel.id}')" class="flex flex-col items-center gap-1">
                        <div class="w-10 h-10 rounded-full bg-red-900/60  flex items-center justify-center text-xl border border-sky-400/30 text-white">🗑️</div>
                    </button>` : ''}
                </div>
            `;
            container.appendChild(card);

            // ── Video tap-to-pause: click → SVG flash ikonu ──
            if(reel.media_type === 'video') {
                const video = card.querySelector('video');
                const flashEl = card.querySelector('.reel-play-flash');
                video.muted = _reelMuted;
                if(video && flashEl) {
                    const playIcon  = flashEl.querySelector('.flash-play-icon');
                    const pauseIcon = flashEl.querySelector('.flash-pause-icon');
                    video.addEventListener('click', function(e) {
                        e.stopPropagation();
                        if(video.paused) {
                            // Diğer tüm feed videolarını önce durdur
                            document.querySelectorAll('#reels-feed video').forEach(v => { if(v !== video) v.pause(); });
                            video.play().catch(()=>{});
                            if(playIcon)  playIcon.style.display = 'none';
                            if(pauseIcon) pauseIcon.style.display = 'block';
                        } else {
                            video.pause();
                            if(playIcon)  playIcon.style.display = 'block';
                            if(pauseIcon) pauseIcon.style.display = 'none';
                        }
                        flashEl.classList.remove('show');
                        void flashEl.offsetWidth;
                        flashEl.classList.add('show');
                    });
                }
            }
            // NOT: IntersectionObserver artık kart başına DEĞİL,
            // loadReels() sonunda _setupFeedObserver() ile tek seferde kurulur.
        }

        async function toggleReelLike(reelId, btn) {
            if(!currentUser) { alert('Beğenmek için giriş yapın!'); return; }
            
            // Anlık UI güncellemesi — sunucu cevabını beklemeden
            const icon = btn;
            const count = btn ? btn.parentElement.querySelector('.reel-like-count') : null;
            const reel = reelsData ? reelsData.find(r => r.id === reelId) : null;
            
            // Optimistic update: hemen beğen/beğenme göster
            const wasLiked = reel && reel.likes && reel.likes.includes(currentUser.username);
            if (icon) { icon.textContent = wasLiked ? '🤍' : '❤️'; }
            if (count && reel) count.textContent = wasLiked ? Math.max(0, (reel.likes||[]).length - 1) : ((reel.likes||[]).length + 1);
            
            try {
                const res = await sendAction('like_reel', { reel_id: reelId });
                if(res && res.status === 'ok') {
                    // Sunucu cevabıyla kesin değeri güncelle
                    if(icon) { icon.textContent = res.liked ? '❤️' : '🤍'; }
                    if(count) count.textContent = res.likes;
                    
                    // reelsData içindeki yerel kopyayı da güncelle — çıkıp girmeden doğru göstersin
                    if(reel) {
                        if(res.liked) {
                            if(!reel.likes) reel.likes = [];
                            if(!reel.likes.includes(currentUser.username)) reel.likes.push(currentUser.username);
                        } else {
                            reel.likes = (reel.likes || []).filter(u => u !== currentUser.username);
                        }
                        reel.like_count = res.likes;
                    }
                } else {
                    // Sunucu hata verdiyse geri al
                    if(icon) { icon.textContent = wasLiked ? '❤️' : '🤍'; }
                    if(count && reel) count.textContent = (reel.likes||[]).length;
                }
            } catch(e) {
                // Hata durumunda geri al
                if(icon) { icon.textContent = wasLiked ? '❤️' : '🤍'; }
                if(count && reel) count.textContent = (reel.likes||[]).length;
            }
        }

        async function deleteReel(reelId) {
            if(!confirm("Bu Reels'i silmek istediğinize emin misiniz?")) return;
            await sendAction('delete_reel', { reel_id: reelId });
            loadReels();
        }

        function showReelLikes(reelId) {
            const reel = reelsData.find(r => r.id === reelId);
            if(!reel || !reel.likes || reel.likes.length === 0) return;
            
            const listDiv = document.getElementById('reel-likes-list');
            listDiv.innerHTML = '';
            
            reel.likes.forEach(username => {
                const u = db.users.find(x => x.username === username) || { username: username, avatar: '' };
                const avatar = u.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
                
                const item = document.createElement('div');
                item.className = 'flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition cursor-pointer';
                item.onclick = () => { 
                    document.getElementById('reel-likes-modal').classList.add('hidden');
                    window.openProfileOrStory(username); 
                };
                
                item.innerHTML = `
                    <img src="${escapeHtml(avatar)}" class="w-10 h-10 rounded-full object-cover border border-zinc-600 shrink-0">
                    <span class="text-white font-bold text-sm">${escapeHtml(username)}</span>
                `;
                listDiv.appendChild(item);
            });
            
            document.getElementById('reel-likes-modal').classList.remove('hidden');
        }

        async function openReelComments(reelId) {
            currentReelId = reelId;
            const modal = document.getElementById('reel-comment-modal');
            const list = document.getElementById('reel-comments-list');
            modal.classList.remove('hidden');
            list.innerHTML = '<div class="text-zinc-500 text-sm text-center py-4">Yorumlar yükleniyor...</div>';
            try {
                const res = await sendAction('get_comments', { target_id: reelId });
                const comments = res.comments || [];
                if(!comments.length) {
                    list.innerHTML = '<div class="text-zinc-500 text-sm text-center py-4">Henüz yorum yok. İlk yorumu sen yap!</div>';
                    return;
                }
                list.innerHTML = comments.map(c => {
                    const u = db.users.find(x => x.username === c.user) || {};
                    const av = u.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
                    return `<div class="flex items-start gap-2">
                        <img src="${escapeHtml(av)}" class="w-8 h-8 rounded-full object-cover shrink-0 border border-zinc-700">
                        <div class="bg-zinc-900/80 rounded-xl px-3 py-2 flex-1">
                            <span class="text-pink-400 font-black text-xs">${escapeHtml(c.user)} </span>
                            <span class="text-white text-xs">${escapeHtml(c.text)}</span>
                        </div>
                    </div>`;
                }).join('');
            } catch(e) { list.innerHTML = '<div class="text-zinc-500 text-sm text-center py-4">Yorumlar yüklenemedi.</div>'; }
        }

        async function submitReelComment() {
            if(!currentUser) { alert('Yorum yapmak için giriş yapın!'); return; }
            const inp = document.getElementById('reel-comment-input');
            const text = inp.value.trim();
            if(!text) return;
            inp.value = '';
            await sendAction('comment_reel', { reel_id: currentReelId, text });
            openReelComments(currentReelId);
        }

        function openReelUploadModal() {
            if(!currentUser) { alert('Reel paylaşmak için giriş yapın!'); return; }
            const modal = document.getElementById('reel-upload-modal');
            const infoEl = document.getElementById('reel-limit-info');
            const tier = getMyTier();
            let infoText = '';
            if(tier === 0) infoText = '⚪ Ücretsiz: Günde <b>1 fotoğraf</b> paylaşabilirsiniz. Video için Standart üyelik gerekli.';
            else if(tier === 1) infoText = '⭐ Standart: Günde <b>1 fotoğraf veya video</b> paylaşabilirsiniz.';
            else infoText = '💎 Deluxe/Ultra+: Günde <b>2 Reel</b> paylaşabilirsiniz.';
            if(infoEl) infoEl.innerHTML = infoText;
            const videoLabel = document.getElementById('reel-video-btn');
            if(videoLabel) {
                videoLabel.style.opacity = tier >= 1 ? '1' : '0.5';
                videoLabel.title = tier < 1 ? 'Video için Standart üyelik gerekli' : '';
            }
            clearReelFile();
            modal.classList.remove('hidden');
        }

        function clearReelFile() {
            reelFileData = null;
            reelFileObj = null;
            reelFileType = null;
            const previewCont = document.getElementById('reel-preview-container');
            const previewImg = document.getElementById('reel-preview-img');
            const previewVid = document.getElementById('reel-preview-video');
            if(previewCont) previewCont.classList.add('hidden');
            if(previewImg) { previewImg.classList.add('hidden'); previewImg.src = ''; }
            if(previewVid) { previewVid.classList.add('hidden'); previewVid.src = ''; }
            const pi = document.getElementById('reel-photo-input');
            const vi = document.getElementById('reel-video-input');
            if(pi) pi.value = '';
            if(vi) vi.value = '';
        }

        function getMyTier() {
            if(!currentUser) return 0;
            if(currentUser.role === 'Admin') return 3;
            let st = currentUser.stats;
            if(typeof st === 'string') { try { st = JSON.parse(st); } catch(e) { st = {}; } }
            return parseInt((st || {}).premium_tier || 0);
        }

        async function handleReelFile(input, type) {
            const tier = getMyTier();
            const file = input.files[0];
            if(!file) return;

            if(type === 'video') {
                if(tier < 1) {
                    input.value = '';
                    if(confirm("Video paylaşmak için Standart üyelik gereklidir. Üyelik almak ister misin?")) {
                        document.getElementById('reel-upload-modal').classList.add('hidden');
                        switchTab(6);
                    }
                    return;
                }
                if(file.size > 50 * 1024 * 1024) {
                    alert('Video boyutu maksimum 50MB olmalıdır!');
                    input.value = '';
                    return;
                }
            }

            const previewCont = document.getElementById('reel-preview-container');
            const previewImg = document.getElementById('reel-preview-img');
            const previewVid = document.getElementById('reel-preview-video');
            const compressInfo = document.getElementById('reel-compress-info');
            previewCont.classList.remove('hidden');

            if(type === 'image') {
                const compressed = await compressImage(file, 960, 0.75);
                reelFileData = compressed; // Resim ise base64 kullanmaya devam edebiliriz (çok küçük)
                reelFileObj = null;
                reelFileType = 'image';
                previewImg.src = compressed;
                previewImg.classList.remove('hidden');
                previewVid.classList.add('hidden');
                if(compressInfo) compressInfo.classList.remove('hidden');
            } else {
                previewImg.classList.add('hidden');
                previewVid.classList.remove('hidden');
                if(compressInfo) compressInfo.classList.add('hidden');
                reelFileData = null;
                reelFileObj = file; // Video ise doğrudan File objesini tut
                reelFileType = 'video';
                previewVid.src = URL.createObjectURL(file);
            }
        }

        async function compressImage(file, maxSize, quality) {
            return new Promise(resolve => {
                if(!file) { resolve(null); return; }
                const reader = new FileReader();
                reader.onload = e => resolve(e.target.result);
                reader.onerror = () => resolve(null);
                reader.readAsDataURL(file);
            });
        }

        async function submitReel() {
            if(!currentUser) return;

            if(reelFileType === 'video' && !reelFileObj) {
                alert('Videonuz henüz hazır değil veya seçilmedi.');
                return;
            }
            if(reelFileType === 'image' && !reelFileData) {
                alert('Resim henüz hazır değil veya seçilmedi.');
                return;
            }
            if(!reelFileData && !reelFileObj) { alert('Önce bir fotoğraf veya video seçin!'); return; }

            const caption = document.getElementById('reel-caption').value.trim();
            const submitBtn = document.getElementById('reel-submit-btn');
            const progressDiv = document.getElementById('reel-upload-progress');
            const progressBar = document.getElementById('reel-progress-bar');
            const progressLabel = progressDiv ? progressDiv.querySelector('.text-xs') : null;

            submitBtn.disabled = true;
            submitBtn.textContent = 'Yükleniyor...';
            if(progressDiv) progressDiv.classList.remove('hidden');

            function setProgress(pct, label) {
                if(progressBar) progressBar.style.width = pct + '%';
                if(progressLabel) progressLabel.textContent = label;
            }

            try {
                setProgress(15, reelFileType === 'video' ? 'Video sunucuya yükleniyor...' : 'Fotoğraf yükleniyor...');
                
                let uploadData = null;

                // Adım 1: Medyayı R2'ye yükle
                if (reelFileType === 'video' && reelFileObj) {
                    const chunkSize = 512 * 1024; // 512KB parça (Nginx 1MB varsayılan limitini aşmamak için)
                    const totalChunks = Math.ceil(reelFileObj.size / chunkSize);
                    const uploadId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
                    
                    for (let i = 0; i < totalChunks; i++) {
                        const chunk = reelFileObj.slice(i * chunkSize, (i + 1) * chunkSize);
                        const formData = new FormData();
                        formData.append('chunk', chunk, 'chunk.mp4');
                        formData.append('uploadId', uploadId);
                        formData.append('chunkIndex', i);
                        
                        let chunkRes;
                        let retries = 3;
                        while (retries > 0) {
                            try {
                                chunkRes = await fetch('/api/upload_chunk', { method: 'POST', body: formData });
                                if (chunkRes.ok) break;
                            } catch (e) {
                                // Ağ koptu veya Failed to fetch hatası
                            }
                            retries--;
                            if (retries === 0) throw new Error('Bağlantı koptu (İnternet sorunu veya sunucu kısıtlaması). Lütfen tekrar deneyin.');
                            await new Promise(r => setTimeout(r, 1000)); // 1 saniye bekle ve tekrar dene
                        }
                        
                        if (!chunkRes || !chunkRes.ok) {
                            throw new Error('Parça yüklenemedi: ' + (chunkRes ? chunkRes.status : 'Bilinmeyen hata'));
                        }
                        
                        // Cloudflare Anti-DDoS veya Nginx Rate Limit'e takılmamak için her parça arası 150ms bekle
                        await new Promise(r => setTimeout(r, 150));
                        
                        // İlerleme çubuğunu GERÇEK ZAMANLI güncelle
                        const percent = 15 + Math.round(((i + 1) / totalChunks) * 65); // 15'ten 80'e kadar ilerler
                        setProgress(percent, `Video Yükleniyor: %${Math.round(((i + 1) / totalChunks) * 100)}`);
                    }
                    
                    setProgress(85, 'Sunucu videoyu işliyor...');
                    
                    const finishRes = await fetch('/api/upload_finish', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            uploadId: uploadId,
                            totalChunks: totalChunks,
                            mimeType: reelFileObj.type || 'video/mp4',
                            folder: 'reels'
                        })
                    });
                    
                    if(!finishRes.ok) throw new Error('Sunucu hatası: Video birleştirilemedi (' + finishRes.status + ')');
                    uploadData = await finishRes.json();
                } else {
                    const uploadRes = await fetch('/api/data', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'upload_media', data: { media_data: reelFileData, folder: 'reels' } })
                    });
                    if(!uploadRes.ok) throw new Error('Sunucu hatası: ' + uploadRes.status);
                    uploadData = await uploadRes.json();
                }

                setProgress(80, 'Reel kaydediliyor...');

                if(!uploadData || !uploadData.url) {
                    if(uploadData?.message === 'Giriş yapmalısınız!') {
                        alert('Oturumun süresi dolmuş, lütfen tekrar giriş yap.');
                        logout();
                        return;
                    }
                    throw new Error(uploadData?.message || 'Medya sunucuya yüklenemedi.');
                }

                // Adım 2: Sadece URL ile add_reel — küçük payload
                const res = await fetch('/api/data', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'add_reel', data: {
                        media_url: uploadData.url,
                        media_type: reelFileType,
                        caption: caption
                    }})
                });

                if(!res.ok) throw new Error('Kayıt hatası: ' + res.status);
                const resData = await res.json();
                setProgress(100, 'Tamamlandı!');

                if(resData && resData.status === 'ok') {
                    setTimeout(() => {
                        document.getElementById('reel-upload-modal').classList.add('hidden');
                        clearReelFile();
                        document.getElementById('reel-caption').value = '';
                        loadReels();
                    }, 400);
                } else {
                    if(resData?.message === 'Giriş yapmalısınız!') { alert('Oturumun süresi dolmuş, lütfen tekrar giriş yap.'); logout(); return; }
                    alert(resData?.message || 'Reel paylaşılamadı, tekrar deneyin.');
                }
            } catch(e) {
                console.error('Reel upload error:', e);
                alert('Yükleme hatası: ' + (e.message || 'Bilinmeyen hata. Lütfen tekrar deneyin.'));
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'PAYLAŞ';
                if(progressDiv) setTimeout(() => progressDiv.classList.add('hidden'), 600);
            }
        }

        function formatTimeAgo(ts) {
            if(!ts) return '';
            const diff = Math.floor(Date.now() / 1000) - ts;
            if(diff < 60) return 'Az önce';
            if(diff < 3600) return Math.floor(diff/60) + 'dk';
            if(diff < 86400) return Math.floor(diff/3600) + 'sa';
            return Math.floor(diff/86400) + 'g';
        }
        // ── Herhangi bir reel objesini direkt tam ekran aç ──
        // Hem profil grid tıklamasından hem de ileride başka yerlerden çağrılabilir.
        window.openReelDirect = function(reel) {
            if(!reel || !reel.media_url) return;
            stopAllMedia(); // Önceki sesleri temizle

            // Önce reels sekmesini arka planda aktif et (butonlar görünsün diye)
            const screenReels = document.getElementById('screen-reels');
            if(screenReels) {
                screenReels.style.display = 'flex';
                screenReels.style.flexDirection = 'column';
                screenReels.style.zIndex = '9990';
                screenReels.classList.remove('hidden');
            }
            const bottomNav = document.getElementById('bottom-nav');
            if(bottomNav) bottomNav.style.display = 'none';
            const soundBtn = document.getElementById('reel-sound-btn');
            if(soundBtn) { soundBtn.style.display = 'flex'; soundBtn.textContent = _reelMuted ? '🔇' : '🔊'; }
            const gridBtn = document.getElementById('grid-view-btn');
            if(gridBtn) gridBtn.style.display = 'flex';
            const uploadTopBtn = document.getElementById('reels-upload-top-btn');
            if(uploadTopBtn) uploadTopBtn.style.display = 'flex';

            // Önceki overlay varsa temizle
            const oldOverlay = document.getElementById('reel-direct-overlay');
            if(oldOverlay) oldOverlay.remove();

            const user = (typeof db !== 'undefined' && db.users)
                ? (db.users.find(u => u.username === reel.user) || { username: reel.user, avatar: '' })
                : { username: reel.user, avatar: '' };
            const avatar = user.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
            const likeCount = (reel.likes || []).length;
            const timeAgo = typeof formatTimeAgo === 'function' ? formatTimeAgo(reel.created_at) : '';

            const overlay = document.createElement('div');
            overlay.id = 'reel-direct-overlay';
            overlay.style.cssText = 'position:absolute;inset:0;z-index:500;background:#000;display:flex;align-items:center;justify-content:center;';

            // Medya
            let mediaEl;
            if(reel.media_type === 'video') {
                mediaEl = document.createElement('video');
                mediaEl.src = reel.media_url;
                mediaEl.style.cssText = 'width:100%;height:100%;object-fit:contain;max-height:100%;';
                mediaEl.setAttribute('playsinline', '');
                mediaEl.setAttribute('loop', '');
                mediaEl.muted = _reelMuted;
                mediaEl.autoplay = true;
            } else {
                mediaEl = document.createElement('img');
                mediaEl.src = reel.media_url;
                mediaEl.style.cssText = 'width:100%;height:100%;object-fit:contain;max-height:100%;';
            }

            // Gradient overlay
            const grad = document.createElement('div');
            grad.style.cssText = 'position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,0.8) 0%,transparent 50%);pointer-events:none;';

            // Kapat butonu (sağ üst — overlay'e özel)
            const closeBtn = document.createElement('button');
            closeBtn.innerHTML = '✕';
            closeBtn.style.cssText = 'position:absolute;top:calc(env(safe-area-inset-top, 0px) + 72px);right:16px;z-index:10;width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,0.65);color:#fff;font-size:18px;font-weight:bold;border:1px solid rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;cursor:pointer;';
            closeBtn.onclick = () => {
                if(mediaEl.tagName === 'VIDEO') {
                    mediaEl.pause();
                    mediaEl.removeAttribute('src');
                    mediaEl.load(); // tarayıcıyı tamamen sıfırla, ses kesilir
                }
                overlay.remove();
                closeReels();
            };

            // Sol alt: kullanıcı + açıklama
            const info = document.createElement('div');
            info.style.cssText = 'position:absolute;bottom:16px;left:16px;right:64px;z-index:10;';
            info.innerHTML = `
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;cursor:pointer;" onclick="showOtherProfile('${escapeHtml(reel.user)}')">
                    <div style="width:36px;height:36px;border-radius:50%;overflow:hidden;border:2px solid #fff;flex-shrink:0;">
                        <img src="${escapeHtml(avatar)}" style="width:100%;height:100%;object-fit:cover;">
                    </div>
                    <span style="color:#fff;font-weight:900;font-size:14px;text-shadow:0 1px 4px rgba(0,0,0,0.8);">${escapeHtml(reel.user)}</span>
                    <span style="color:#a1a1aa;font-size:12px;">${timeAgo}</span>
                </div>
                ${reel.caption ? `<p style="color:#fff;font-size:13px;line-height:1.4;word-break:break-word;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">${escapeHtml(reel.caption)}</p>` : ''}
            `;

            // Sağ: beğeni
            const actions = document.createElement('div');
            actions.style.cssText = 'position:absolute;right:12px;bottom:32px;z-index:10;display:flex;flex-direction:column;align-items:center;gap:16px;';
            const isLiked = (typeof currentUser !== 'undefined' && currentUser) && (reel.likes || []).includes(currentUser.username);
            actions.innerHTML = `
                <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
                    <div style="width:40px;height:40px;border-radius:50%;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;font-size:20px;border:1px solid rgba(255,255,255,0.2);">${isLiked ? '❤️' : '🤍'}</div>
                    <span style="color:#fff;font-size:12px;font-weight:bold;">${likeCount}</span>
                </div>
            `;

            overlay.appendChild(mediaEl);
            overlay.appendChild(grad);
            overlay.appendChild(closeBtn);
            overlay.appendChild(info);
            overlay.appendChild(actions);

            if(screenReels) screenReels.appendChild(overlay);
            if(mediaEl.tagName === 'VIDEO') mediaEl.play().catch(()=>{});

            history.pushState({ reelDirect: true }, '');
        };

        // ── Merkezi popstate yöneticisi — tüm reel geri tuşu durumları ──
        window.addEventListener('popstate', function _reelDirectPopstate(e) {
            const state = e.state || {};
            if(state.reelDirect) {
                stopAllMedia();
                const ov = document.getElementById('reel-direct-overlay');
                if(ov) ov.remove();
                closeReels();
            }
            if(state.reelsOpen) {
                stopAllMedia();
                closeReels();
            }
            // reelFullscreen: yukarıdaki ayrı listener zaten handle ediyor
        });

        // ================================================================
        // REELS — YENİ GLOBAL FONKSİYONLAR
        // ================================================================

        // 1. Story varsa story görüntüleyiciyi aç, yoksa profile git
        window.openProfileOrStory = async function(username) {
            if(!username) return;
            const now = Math.floor(Date.now() / 1000);
            const activeStories = (db.stories || []).filter(s => s.user === username && s.expires_at > now);
            if(activeStories.length > 0) {
                // Story viewer'ı o kullanıcının story'siyle aç
                _storyList = activeStories;
                _storyIndex = 0;
                showCurrentStory();
                const modal = document.getElementById('story-view-modal');
                if(modal) modal.classList.remove('hidden');
            } else {
                showOtherProfile(username);
            }
        };

        // 2. Grid ↔ Feed geçiş
        let _reelsGridMode = false;
        let _reelFullscreenIdx = -1;
        let _reelFullscreenOverlay = null;

        window.toggleReelsGridView = function() {
            const feed = document.getElementById('reels-feed');
            const gridBtn = document.getElementById('grid-view-btn');
            const soundBtn = document.getElementById('reel-sound-btn');
            if(!feed) return;

            _reelsGridMode = !_reelsGridMode;

            if(_reelsGridMode) {
                // Grid moda geç
                // Observer'ı durdur — grid'de video otomatik çalmasın
                if(_feedObserver) { _feedObserver.disconnect(); _feedObserver = null; }
                feed.classList.add('grid-mode');
                if(soundBtn) soundBtn.style.display = 'none';
                // Tüm videoları durdur ve sessize al
                feed.querySelectorAll('video').forEach(v => { v.pause(); v.muted = true; });
                // Grid kartlarına click ekle (duplicate önleme: data flag ile)
                feed.querySelectorAll(':scope > div').forEach((card, idx) => {
                    card.dataset.reelIdx = idx;
                    if(!card.dataset.gridClickBound) {
                        card.dataset.gridClickBound = '1';
                        card.addEventListener('click', _onGridCardClick);
                    }
                    card.style.cursor = 'pointer';
                });
                if(gridBtn) gridBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px;"><rect x="2" y="3" width="20" height="18" rx="2"/><line x1="2" y1="9" x2="22" y2="9"/><line x1="2" y1="15" x2="22" y2="15"/></svg>`;
            } else {
                // Feed moduna dön
                feed.classList.remove('grid-mode');
                if(soundBtn && reelsData.length) soundBtn.style.display = 'flex';
                // Grid click listener'larını kaldır ve flag'i temizle
                feed.querySelectorAll(':scope > div').forEach(card => {
                    card.removeEventListener('click', _onGridCardClick);
                    delete card.dataset.gridClickBound;
                });
                // Observer'ı yeniden kur, mevcut scroll pozisyonunda oynayan videoyu başlat
                _setupFeedObserver();
                if(gridBtn) gridBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px;"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`;
            }
        };

        // Grid kart click handler (ayrı referans olmalı ki removeEventListener çalışsın)
        function _onGridCardClick(e) {
            const idx = parseInt(this.dataset.reelIdx);
            if(!isNaN(idx)) window.openReelsGridItem(idx);
        }

        // 3. Izgaradan bir video → tam ekran
        // 3. Izgaradan bir video/fotoğraf → tam ekran (body'e ekle → fixed parent sorunu yok)
        window.openReelsGridItem = function(idx) {
            if(!reelsData[idx]) return;
            const reel = reelsData[idx];

            // Önceki overlay varsa sessizce temizle
            window.exitReelFullscreen(true);

            _reelFullscreenIdx = idx;

            const overlay = document.createElement('div');
            overlay.id = 'reel-fs-overlay';
            // body'e fixed ekliyoruz — screenReels'e değil (fixed-in-fixed sorunu çözüldü)
            overlay.style.cssText = 'position:fixed;inset:0;z-index:999999;background:#000;display:flex;align-items:center;justify-content:center;overflow:hidden;';

            // Kapatma butonu
            const closeBtn = document.createElement('button');
            closeBtn.innerHTML = '✕';
            closeBtn.style.cssText = 'position:absolute;top:calc(env(safe-area-inset-top,0px) + 72px);right:16px;z-index:10;width:44px;height:44px;border-radius:50%;background:rgba(0,0,0,0.7);color:#fff;font-size:18px;font-weight:bold;border:1.5px solid rgba(255,255,255,0.35);display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 2px 12px rgba(0,0,0,0.6);';
            closeBtn.onclick = (e) => { e.stopPropagation(); window.exitReelFullscreen(false); };

            if(reel.media_type === 'video') {
                const video = document.createElement('video');
                video.src = reel.media_url;
                video.style.cssText = 'width:100%;height:100%;object-fit:contain;max-height:100%;display:block;';
                video.setAttribute('playsinline', '');
                video.setAttribute('loop', '');
                video.muted = false;
                video.autoplay = true;
                video.addEventListener('click', () => {
                    if(video.paused) video.play().catch(()=>{});
                    else video.pause();
                });
                overlay.appendChild(video);
                video.play().catch(() => { video.muted = true; video.play().catch(() => {}); });
            } else {
                const img = document.createElement('img');
                img.src = reel.media_url;
                img.style.cssText = 'width:100%;height:100%;object-fit:contain;max-height:100%;display:block;';
                overlay.appendChild(img);
            }

            overlay.appendChild(closeBtn);
            document.body.appendChild(overlay);  // ← body'e ekle
            _reelFullscreenOverlay = overlay;

            // Geri tuşu desteği
            history.pushState({ reelFullscreen: true, reelIdx: idx }, '');
        };

        // 4. Tam ekranı kapat → grid görünümüne geri dön
        window.exitReelFullscreen = function(silent) {
            const ov = document.getElementById('reel-fs-overlay');
            if(ov) {
                const v = ov.querySelector('video');
                if(v) { try { v.pause(); v.removeAttribute('src'); v.load(); } catch(_){} }
                ov.remove();
            }
            _reelFullscreenOverlay = null;
            _reelFullscreenIdx = -1;
            // Grid modundaysa ses butonunu gizli tut
            if(_reelsGridMode) {
                const soundBtn = document.getElementById('reel-sound-btn');
                if(soundBtn) soundBtn.style.display = 'none';
            }
        };

        // 5. Geri tuşu / popstate → tam ekranı kapat, grid'e dön
        window.addEventListener('popstate', function(e) {
            if(e.state && e.state.reelFullscreen) {
                window.exitReelFullscreen(false);
                e.preventDefault && e.preventDefault();
            }
        });

        // ================================================================
        // REELS SİSTEMİ JS SONU
        // ================================================================

        async function toggleRidingMode() {
            if(!currentUser) return;
            
            let stats = currentUser.stats || {};
            const isCurrentlyRiding = stats.riding_until && stats.riding_until > Date.now();
            
            if(isCurrentlyRiding) {
                if(confirm("Sürüş modunu kapatmak istiyor musun? Haritadan gizleneceksin.")) {
                    stats.riding_until = 0;
                    await sendAction('update_user', currentUser);
                    
                    document.getElementById("radar-info").classList.add("hidden");
                    document.getElementById("btn-riding-mode").innerHTML = "📡 RADAR (SÜRÜŞTEYİM)";
                    document.getElementById("btn-riding-mode").className = "bg-green-600/90  hover:bg-green-500 btn-premium-hover px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-green-400/50 pointer-events-auto";
                    
                    syncMap();
                    alert("Sürüş modu kapatıldı.");
                }
            } else {
                if(!userLat || !userLng) return alert("Konumunuz henüz bulunamadı. Lütfen önce 🎯 butonuna basarak konum izni verin.");
                
                if(confirm("Konumun 3 saat boyunca haritada diğer sürücülere canlı olarak gösterilecek. Onaylıyor musun?")) {
                    stats.riding_until = Date.now() + (3 * 60 * 60 * 1000); 
                    stats.riding_lat = userLat;
                    stats.riding_lng = userLng;
                    
                    await sendAction('update_user', currentUser);
                    
                    document.getElementById("radar-info").classList.remove("hidden");
                    document.getElementById("btn-riding-mode").innerHTML = "🛑 SÜRÜŞÜ BİTİR";
                    document.getElementById("btn-riding-mode").className = "bg-sky-600/90  hover:bg-red-500 btn-premium-hover px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-red-400/50 pointer-events-auto";
                    
                    syncMap();
                    alert("Sürüş modu aktif! Artık haritada radar olarak parlıyorsun.");
                }
            }
        }

        // ==============================================================
        // BİSİKLET DÜZENLEME VE SİLME FONKSİYONLARI 
        // ==============================================================
        async function deleteBike(index) {
            if(!confirm("Bu bisikleti garajından kalıcı olarak silmek istediğine emin misin?")) return;
            
            currentUser.stats.garage.splice(index, 1); 
            await sendAction('update_user', currentUser);
            const meIdx2 = db.users.findIndex(u => u.username === currentUser.username);
            if(meIdx2 !== -1) db.users[meIdx2] = {...db.users[meIdx2], stats: currentUser.stats};
            renderGarage(currentUser.username, 'self'); 
            document.getElementById("bike-detail-modal").classList.add("hidden"); 
        }

        function editBike(index) {
            document.getElementById("bike-detail-modal").classList.add("hidden");
            editingBikeIndex = index;
            const b = currentUser.stats.garage[index];
            if(!b) return;

            // Fill all fields safely
            const sf = (id, val) => { const el=document.getElementById(id); if(el) el.value=val||""; };
            sf("bike-model",    b.model);
            sf("bike-type",     b.type);
            sf("bike-fork",     b.fork);
            sf("bike-shock",    b.shock);
            sf("bike-brakes",   b.brakes);
            sf("bike-rotor",    b.rotor);
            sf("bike-drivetrain",b.drivetrain);
            sf("bike-chain",    b.chain);
            sf("bike-crankset", b.crankset);
            sf("bike-cassette", b.cassette);
            sf("bike-wheelset", b.wheelset);
            sf("bike-tires",    b.tires);
            sf("bike-tire-size",b.tire_size);
            sf("bike-handlebar",b.handlebar);
            sf("bike-stem",     b.stem);
            sf("bike-grips",    b.grips);
            sf("bike-seatpost", b.seatpost);
            sf("bike-saddle",   b.saddle);
            sf("bike-pedals",   b.pedals);
            sf("bike-weight",   b.weight);
            sf("bike-desc",     b.desc);
            sf("bike-photo",    "");

            const premTier = getUserPremiumTier(currentUser.username);
            let maxPhotos = premTier>=3?10:premTier>=2?4:premTier>=1?2:1;
            const lbl = document.getElementById("bike-photo-label");
            if(lbl) lbl.textContent = `Yeni Fotograf (Maks ${maxPhotos}) - Bos birakırsan eskileri kalır`;

            document.getElementById("add-bike-modal").classList.remove("hidden");
        }

        function openAddBikeModal() {
            if(!currentUser) return;
            editingBikeIndex = null; 
            
            const premTier = getUserPremiumTier(currentUser.username); 
            const garage = currentUser.stats.garage || [];
            
            let maxBikes = 1; // Ücretsiz kullanıcılar 1 bisiklet ekleyebilir
            let maxPhotos = 1; // Ücretsiz kullanıcılar 1 fotoğraf ekleyebilir
            
            if(premTier === 1) { maxBikes = 1; maxPhotos = 2; }
            if(premTier === 2) { maxBikes = 2; maxPhotos = 4; }
            if(premTier === 3) { maxBikes = 4; maxPhotos = 10; }
            if(garage.length >= maxBikes) {
                return alert(`Mevcut paketiniz garajınıza en fazla ${maxBikes} bisiklet eklemenize izin veriyor! Plus menüsünden paketinizi yükseltin.`);
            }

            document.getElementById("bike-model").value = ""; 
            document.getElementById("bike-fork").value = ""; 
            document.getElementById("bike-shock").value = ""; 
            document.getElementById("bike-brakes").value = ""; 
            document.getElementById("bike-desc").value = ""; 
            document.getElementById("bike-photo").value = "";
            document.getElementById("bike-photo-label").textContent = `Bisiklet Fotoğrafları (Maksimum ${maxPhotos} adet)`;
            document.getElementById("add-bike-modal").classList.remove("hidden");
        }
        
        async function saveBike() {
            const premTier = getUserPremiumTier(currentUser.username);
            const model = document.getElementById("bike-model").value.trim();
            const type = document.getElementById("bike-type").value;
            const files = document.getElementById("bike-photo").files;

            if(!model) return alert("Bisiklet marka/modelini giriniz!");

            for(let i=0; i<files.length; i++) {
                if(!checkFileSize(files[i], 10)) return;
            }
            let maxPhotos = premTier >= 3 ? 10 : premTier >= 2 ? 4 : premTier >= 1 ? 2 : 1;
            if(files.length > maxPhotos) return alert(`En fazla ${maxPhotos} fotograf ekleyebilirsiniz.`);

            const g = id => { const el=document.getElementById(id); return el?el.value.trim():""; };
            const bikeData = {
                model, type,
                fork:        g("bike-fork"),
                shock:       g("bike-shock"),
                brakes:      g("bike-brakes"),
                rotor:       g("bike-rotor"),
                drivetrain:  g("bike-drivetrain"),
                chain:       g("bike-chain"),
                crankset:    g("bike-crankset"),
                cassette:    g("bike-cassette"),
                wheelset:    g("bike-wheelset"),
                tires:       g("bike-tires"),
                tire_size:   g("bike-tire-size"),
                handlebar:   g("bike-handlebar"),
                stem:        g("bike-stem"),
                grips:       g("bike-grips"),
                seatpost:    g("bike-seatpost"),
                saddle:      g("bike-saddle"),
                pedals:      g("bike-pedals"),
                weight:      g("bike-weight"),
                desc:        g("bike-desc"),
            };

            document.getElementById("add-bike-modal").classList.add("hidden");

            let photoDataArray = [];
            for(let i=0; i<Math.min(files.length, maxPhotos); i++) {
                let b64 = await resizeImage(files[i], 800);
                if(b64) photoDataArray.push(b64);
            }

            if(editingBikeIndex !== null) {
                const existing = currentUser.stats.garage[editingBikeIndex];
                Object.assign(existing, bikeData);
                if(photoDataArray.length > 0) existing.image = photoDataArray;
                alert("Bisiklet guncellendi!");
            } else {
                if(photoDataArray.length === 0) photoDataArray = ["https://placehold.co/400x300/121214/FFF?text=FOTO+YOK"];
                if(!currentUser.stats) currentUser.stats = {};
                if(!currentUser.stats.garage) currentUser.stats.garage = [];
                bikeData.id = Date.now();
                bikeData.image = photoDataArray;
                currentUser.stats.garage.push(bikeData);
                alert("Bisiklet garaja eklendi!");
            }
            await sendAction('update_user', currentUser);
            // Lokal db'yi güncelle
            const meIdx = db.users.findIndex(u => u.username === currentUser.username);
            if(meIdx !== -1) db.users[meIdx] = {...db.users[meIdx], stats: currentUser.stats};
            renderGarage(currentUser.username, 'self');
            
            // Eğer reel modalı açıksa, oradaki mini garaj listesini anında güncelle
            const gDiv = document.getElementById('submit-bike-garage');
            const reelModal = document.getElementById('submit-reel-modal');
            if(gDiv && reelModal && !reelModal.classList.contains('hidden')) {
                const garage = currentUser.stats.garage || [];
                if (garage.length === 0) {
                    gDiv.innerHTML = "<div class='col-span-2 text-center text-xs text-zinc-500 italic py-4'>Garaj boş.</div>";
                } else {
                    gDiv.innerHTML = "";
                    garage.forEach((b, idx) => {
                        let img = Array.isArray(b.image) ? b.image[0] : (b.image || "https://placehold.co/400x300/121214/FFF?text=FOTO+YOK");
                        gDiv.innerHTML += `
                        <div onclick="selectReelBike(${idx})" id="reel-bike-card-${idx}" class="relative bg-zinc-900 border border-zinc-700 rounded-lg p-2 cursor-pointer hover:border-blue-500 transition flex items-center gap-3">
                            <img src="${img}" class="w-12 h-12 object-cover rounded-md">
                            <div class="flex-1 min-w-0">
                                <div class="text-white text-sm font-bold truncate">${b.model || 'Model Yok'}</div>
                                <div class="text-zinc-400 text-xs truncate">${b.type || 'Tür Yok'}</div>
                            </div>
                        </div>
                        `;
                    });
                }
            }

            editingBikeIndex = null;
        }
        function viewBikeDetail(username, index) {
            const u = db.users.find(x => x.username === username);
            if(!u || !u.stats || !u.stats.garage || !u.stats.garage[index]) return;
            const b = u.stats.garage[index];

            const imgContainer = document.getElementById("bd-image-container");
            imgContainer.innerHTML = "";
            let images = Array.isArray(b.image) ? b.image : [b.image||"https://placehold.co/400x300/121214/FFF?text=FOTO+YOK"];
            images.forEach(img => {
                imgContainer.innerHTML += `<img src="${img}" onclick="openFullscreen(images,${imgContainer.children.length})" class="h-full w-auto object-contain shrink-0 rounded-xl scroll-snap-align-center cursor-pointer hover:opacity-90 transition-opacity">`;
            });

            // Basic
            document.getElementById("bd-model").textContent  = b.model || "-";
            document.getElementById("bd-type").textContent   = b.type  || "-";
            document.getElementById("bd-fork").textContent   = b.fork  || "Belirtilmemis";
            document.getElementById("bd-shock").textContent  = b.shock || "Belirtilmemis";
            document.getElementById("bd-brakes").textContent = b.brakes|| "Belirtilmemis";
            document.getElementById("bd-desc").textContent   = b.desc  || "Belirtilmemis";

            // Extended fields - add dynamically if container exists
            const extra = document.getElementById("bd-extra-specs");
            if(extra) {
                const fields = [
                    ["Disk Caplaari", b.rotor],
                    ["Vites Sistemi", b.drivetrain],
                    ["Zincir", b.chain],
                    ["Krank / BB", b.crankset],
                    ["Kasnak", b.cassette],
                    ["Jantlar", b.wheelset],
                    ["Lastikler", b.tires],
                    ["Lastik Boyutu", b.tire_size],
                    ["Gidon", b.handlebar],
                    ["Stem", b.stem],
                    ["Tutus", b.grips],
                    ["Seatpost", b.seatpost],
                    ["Sele", b.saddle],
                    ["Pedallar", b.pedals],
                    ["Agirlik", b.weight],
                ];
                let extraHtml = "";
                fields.forEach(([label, val]) => {
                    if(val) extraHtml += `<div class="flex justify-between py-2 border-b border-zinc-800/50">
                        <span class="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">${label}</span>
                        <span class="text-xs text-zinc-200 font-medium text-right max-w-[55%]">${val}</span>
                    </div>`;
                });
                extra.innerHTML = extraHtml || "<div class='text-zinc-600 text-xs italic'>Ek detay girilmemis.</div>";
            }

            const actionsArea = document.getElementById("bd-actions-area");
            if(actionsArea) {
                if(username === currentUser.username) {
                    actionsArea.innerHTML = `
                        <button onclick="editBike(${index})" class="flex-1 bg-blue-900/50 hover:bg-blue-800 btn-premium-hover transition text-blue-400 border border-blue-500/50 py-3 rounded-xl font-bold text-xs uppercase tracking-widest ">DUZENLE</button>
                        <button onclick="deleteBike(${index})" class="flex-1 bg-red-950/50 hover:bg-sky-900/80 btn-premium-hover transition text-sky-400 border border-sky-900/50 py-3 rounded-xl font-bold text-xs uppercase tracking-widest">SIL</button>`;
                } else {
                    actionsArea.innerHTML = "";
                }
            }
            document.getElementById("bike-detail-modal").classList.remove("hidden");
        }

        function renderGarage(username, targetDivId = 'self') {
            const isSelf = targetDivId === 'self'; 
            const container = document.getElementById(isSelf ? "garage-list" : "op-garage"); 
            
            if(!container) return;
            
            let u = isSelf ? currentUser : db.users.find(x => x.username === username);
            
            if(!u || !u.stats || !u.stats.garage || u.stats.garage.length === 0) { 
                container.innerHTML = "<div class='col-span-2 text-center text-xs text-zinc-500 italic py-4'>Garaj boş.</div>"; 
                return; 
            }
            
            container.innerHTML = "";
            
            u.stats.garage.forEach((b, index) => {
                let delBtn = isSelf 
                    ? `<button onclick="event.stopPropagation(); deleteBike(${index})" class="absolute top-1 right-1 bg-red-600 hover:bg-red-500 transition w-6 h-6 rounded-full flex items-center justify-center text-white text-xs  z-20 btn-premium-hover">✕</button>` 
                    : '';
                
                let mainImg = Array.isArray(b.image) ? b.image[0] : (b.image || "https://placehold.co/400x300/121214/FFF?text=FOTO+YOK");
                
                container.innerHTML += `
                <div onclick="viewBikeDetail('${u.username}', ${index})" class="bg-black/50 rounded-xl overflow-hidden border border-zinc-800  relative group cursor-pointer hover:border-zinc-500 transition btn-premium-hover">
                    ${delBtn}
                    <img src="${mainImg}" class="w-full h-24 object-cover">
                    <div class="p-2">
                        <div class="font-bold text-white text-[11px] truncate tracking-wide">${b.model}</div>
                        <div class="text-zinc-500 text-[9px] mt-0.5 truncate uppercase font-bold tracking-widest">${b.type}</div>
                        ${isSelf ? `<button onclick="event.stopPropagation(); openSubmitBikeModal(${index})" class="mt-1.5 w-full text-[9px] font-black text-orange-400 bg-orange-500/10 border border-orange-500/30 py-1 rounded-lg hover:bg-orange-500/20 transition">🏁 Yarışmaya Gönder</button>` : ''}
                    </div>
                </div>`;
            });
        }

        async function logout() {
            if(confirm("Sistemden çıkış yapmak istediğine emin misin?")) {
                // Bellek sızıntısını önle: interval'ları temizle
                if (_heartbeatInterval) { clearInterval(_heartbeatInterval); _heartbeatInterval = null; }
                if (_locationInterval)  { clearInterval(_locationInterval);  _locationInterval  = null; }
                if (locationInterval)   { clearInterval(locationInterval);   locationInterval   = null; }

                try {
                    await sendAction('logout', {});
                } catch(e) {
                    console.log("Sunucu çıkış hatası, yerel veriler temizleniyor...");
                }
                
                // Android Native App'ten çıkış yap (Token ve OneSignal temizliği)
                if (typeof window.Android !== 'undefined' && window.Android !== null && typeof window.Android.onUserLogout === 'function') {
                    window.Android.onUserLogout();
                    console.log('📱 Android Native App çıkış yapıldı');
                }
                
                localStorage.removeItem("fr_user");
                localStorage.removeItem("fr_session_token");
                localStorage.removeItem("fr_session_username");
                currentUser = null;
                
                window.location.reload();
            }
        }
        
        function forgetMe() {
            if(confirm("Tüm yerel oturum verileriniz ve çerezleriniz silinecek. Uygulamaya baştan giriş yapmanız gerekecek. Emin misiniz?")) {
                if (_heartbeatInterval) { clearInterval(_heartbeatInterval); _heartbeatInterval = null; }
                if (_locationInterval)  { clearInterval(_locationInterval);  _locationInterval  = null; }
                if (locationInterval)   { clearInterval(locationInterval);   locationInterval   = null; }
                
                // Android Native App'ten çıkış yap (Token ve OneSignal temizliği)
                if (typeof window.Android !== 'undefined' && window.Android !== null && typeof window.Android.onUserLogout === 'function') {
                    window.Android.onUserLogout();
                }

                // Her şeyi temizle
                localStorage.removeItem("fr_user");
                localStorage.removeItem("fr_session_token");
                localStorage.removeItem("fr_session_username");
                localStorage.clear(); // Hepsini sıfırla
                sessionStorage.clear();
                
                // Tüm çerezleri (cookie) temizle
                document.cookie.split(";").forEach(function(c) {
                    document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
                });
                
                currentUser = null;
                alert("Tüm çerezler ve tokenlar başarıyla silindi. Sayfa yenileniyor.");
                window.location.reload();
            }
        }
        
        let _gwSelectedImageB64 = null;
        let _gwCurrentId = null;

        window.handleGwImage = function(e) {
            const file = e.target.files[0];
            if(!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let w = img.width, h = img.height;
                    const MAX = 800;
                    if(w > h) { if(w > MAX) { h *= MAX/w; w = MAX; } }
                    else { if(h > MAX) { w *= MAX/h; h = MAX; } }
                    canvas.width = w; canvas.height = h;
                    canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                    _gwSelectedImageB64 = canvas.toDataURL('image/jpeg', 0.8);
                    const prev = document.getElementById('gw-img-preview');
                    prev.src = _gwSelectedImageB64;
                    prev.classList.remove('hidden');
                };
                img.src = ev.target.result;
            };
            reader.readAsDataURL(file);
        };

        window.showCreateGiveawayModal = function() {
            document.getElementById('gw-title').value = '';
            document.getElementById('gw-prize').value = '';
            document.getElementById('gw-desc').value = '';
            document.getElementById('gw-date').value = '';
            document.getElementById('gw-winner-count').value = '1';
            document.getElementById('gw-admin-pick').checked = false;
            document.getElementById('gw-picked-users-row').classList.add('hidden');
            document.getElementById('gw-picked-usernames').value = '';
            _gwSelectedImageB64 = null;
            document.getElementById('gw-img-preview').classList.add('hidden');
            document.getElementById('gw-create-modal').classList.remove('hidden');
        };

        window.submitCreateGiveaway = async function() {
            const btn = document.getElementById('gw-save-btn');
            const title = document.getElementById('gw-title').value.trim();
            const prize = document.getElementById('gw-prize').value.trim();
            const desc = document.getElementById('gw-desc').value.trim();
            const date = document.getElementById('gw-date').value;
            const wCount = parseInt(document.getElementById('gw-winner-count').value) || 1;
            const adminPick = document.getElementById('gw-admin-pick').checked;
            const pickedRaw = document.getElementById('gw-picked-usernames').value.trim();
            const adminPickedUsernames = adminPick ? pickedRaw.split(',').map(u=>u.trim()).filter(Boolean) : [];

            if(!title || !prize || !date) return showToast('Tüm alanları doldurun!', 'error');
            if(adminPick && adminPickedUsernames.length === 0) return showToast('Kazanıcı kullanıcı adlarını girin!', 'error');

            btn.disabled = true; btn.textContent = 'YÜKLENİYOR...';
            try {
                const res = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: 'create_giveaway',
                        data: {
                            title: title, prize: prize, description: desc,
                            end_date: date, winner_count: wCount,
                            admin_pick_mode: adminPick,
                            admin_picked_usernames: adminPickedUsernames,
                            image_base64: _gwSelectedImageB64 || ''
                        }
                    })
                }).then(r=>r.json());

                if(res.status === 'ok') {
                    showToast('Çekiliş başlatıldı! 🎉', 'success');
                    document.getElementById('gw-create-modal').classList.add('hidden');
                    // Sunucudan güncel listeyi çek ve db'yi güncelle
                    try {
                        const gwRes = await fetch('/api/data').then(r=>r.json());
                        if(gwRes.giveaways) { db.giveaways = gwRes.giveaways; }
                    } catch(e) {}
                    loadGiveaways();
                } else showToast(res.message || 'Bir hata oluştu!', 'error');
            } catch(e) { showToast('Bağlantı hatası!', 'error'); }
            btn.disabled = false; btn.textContent = 'KAYDET';
        };

        window.loadGiveaways = async function() {
            // Her zaman API'den taze veri çek
            try {
                const c = document.getElementById('giveaway-list');
                if(c) c.innerHTML = '<div class="col-span-full text-center text-zinc-500 py-10"><div class="animate-pulse text-2xl">🎁</div><div class="text-xs mt-2">Yükleniyor...</div></div>';
                const res = await fetch('/api/giveaways').then(r=>r.json());
                if(res.status === 'ok' && res.data) {
                    db.giveaways = res.data;
                } else if(!db.giveaways) {
                    db.giveaways = [];
                }
            } catch(e) {
                if(!db.giveaways) db.giveaways = [];
            }
            renderGiveaways(db.giveaways);
        };

        window.renderGiveaways = function(list) {
            const c = document.getElementById('giveaway-list');
            if(!list || list.length === 0) {
                c.innerHTML = '<div style="text-align:center;color:#52525b;padding:60px 20px;"><div style="font-size:48px;margin-bottom:12px;">🎁</div><div style="font-size:15px;font-weight:700;">Henüz çekiliş yok.</div></div>';
                return;
            }
            c.innerHTML = list.map(g => renderGiveawayCard(g)).join('');
        };

        function _esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

        window.renderGiveawayCard = function(g) {
            const isAdmin = currentUser && (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin');
            const pCount = (g.participants || []).length;
            const isJoined = currentUser && (g.participants || []).some(p => (p.username || p) === currentUser.username);

            let statusColor, statusText;
            if(g.status === 'active')         { statusColor = 'bg-emerald-500'; statusText = 'AKTİF'; }
            else if(g.status === 'completed') { statusColor = 'bg-amber-500';   statusText = 'TAMAMLANDI'; }
            else                              { statusColor = 'bg-red-500';      statusText = 'İPTAL'; }

            const imgHtml = g.image_url
                ? `<img src="${g.image_url}" class="w-full h-44 object-cover" style="display:block;">`
                : `<div class="w-full h-32 flex items-center justify-center text-6xl" style="background:linear-gradient(135deg,#064e3b,#134e4a);">🎁</div>`;

            let footerRight = '';
            if(g.status === 'active' && !isJoined) footerRight = `<span style="color:#34d399;font-size:13px;font-weight:900;">Katıl →</span>`;
            else if(isJoined) footerRight = `<span style="color:#6ee7b7;font-size:13px;font-weight:900;">✅ Katıldın</span>`;

            return `<div data-gwid="${_esc(String(g.id))}" onclick="openGiveawayDetail(this.dataset.gwid)"
                style="background:#18181b;border:1px solid #27272a;border-radius:16px;overflow:hidden;cursor:pointer;margin-bottom:0;-webkit-tap-highlight-color:transparent;">
                ${imgHtml}
                <div style="padding:14px 16px 12px;">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:6px;">
                        <div style="font-size:17px;font-weight:900;color:#ffffff;line-height:1.25;flex:1;word-break:break-word;">${_esc(g.title)}</div>
                        <span style="font-size:10px;font-weight:800;padding:3px 8px;border-radius:20px;color:#fff;white-space:nowrap;flex-shrink:0;margin-top:2px;" class="${statusColor}">${statusText}</span>
                    </div>
                    <div style="font-size:14px;font-weight:700;color:#34d399;margin-bottom:10px;">🏆 ${_esc(g.prize)}</div>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding-top:10px;border-top:1px solid #27272a;">
                        <div style="display:flex;gap:12px;">
                            <span style="font-size:12px;color:#71717a;">👥 ${pCount}</span>
                            <span style="font-size:12px;color:#71717a;">📅 ${_esc(g.end_date)}</span>
                        </div>
                        ${footerRight}
                    </div>
                </div>
            </div>`;
        };

        // Çekiliş detay modalı - pazar stili büyüyen kart
        window.openGiveawayDetail = function(id) {
            const giveaways = db.giveaways || [];
            const g = giveaways.find(x => String(x.id) === String(id));
            if(!g) return;

            const isAdmin = currentUser && (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin');
            const pCount = (g.participants || []).length;
            const isJoined = currentUser && (g.participants || []).some(p => (p.username || p) === currentUser.username);

            const imgHtml = g.image_url
                ? `<img src="${g.image_url}" class="w-full max-h-64 object-cover rounded-2xl mb-4">`
                : `<div class="w-full h-32 bg-gradient-to-br from-emerald-900/50 to-teal-900/50 flex items-center justify-center text-6xl rounded-2xl mb-4">🎁</div>`;

            let actionHtml = '';
            if(g.status === 'active') {
                if(isJoined) {
                    actionHtml = `<button disabled class="w-full py-4 bg-zinc-800 text-zinc-500 font-black text-lg rounded-2xl cursor-not-allowed">✅ KATILDIN</button>`;
                } else {
                    actionHtml = `<button data-jid="${String(g.id).replace(/[^a-zA-Z0-9_-]/g,'')}" onclick="event.stopPropagation(); showJoinModal(this.dataset.jid)" class="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-lg rounded-2xl shadow-lg shadow-emerald-500/25 transition-all active:scale-95">🎯 KATIL</button>`;
                }
            } else if(g.status === 'completed') {
                let winnersNames = '';
                if(g.winners && g.winners.length > 0) {
                    winnersNames = g.winners.map(w => `<div class="text-white font-black text-xl">@${_esc(w.username)}</div>${w.instagram ? `<div class="text-zinc-400 text-sm">@${_esc(w.instagram)}</div>` : ''}`).join('<hr class="border-zinc-700 my-1">');
                } else if(g.winner_username) {
                    winnersNames = `<div class="text-white font-black text-xl">@${_esc(g.winner_username)}</div>`;
                }
                actionHtml = `<div class="p-4 bg-amber-900/20 border border-amber-500/40 rounded-2xl text-center"><div class="text-amber-400 font-bold text-xs uppercase mb-2">🏆 Kazananlar</div>${winnersNames}</div>`;
            } else {
                actionHtml = `<div class="p-4 bg-red-900/20 border border-red-500/40 rounded-2xl text-center text-red-400 font-bold">❌ İptal Edildi</div>`;
            }

            let adminHtml = '';
            if(isAdmin) {
                const safeId = String(g.id).replace(/[^a-zA-Z0-9_-]/g, '');
                adminHtml = `<div class="mt-3 flex flex-col gap-2 border-t border-zinc-800 pt-3">
                    ${g.status === 'active' ? `
                    <button data-aid="${safeId}" onclick="event.stopPropagation(); document.getElementById('gw-detail-modal').classList.add('hidden'); adminFinalizeGiveaway(this.dataset.aid)" class="w-full bg-amber-600 hover:bg-amber-500 text-white py-3 rounded-xl text-sm font-bold transition">🎲 ÇEKİLİŞİ YAP</button>
                    <button data-aid="${safeId}" data-gid="${safeId}" onclick="event.stopPropagation(); openWinnerPicker(this.dataset.gid)" class="w-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-400 hover:text-white py-2 rounded-xl text-xs font-bold transition border border-zinc-700/50">👑 Kazanan Seç</button>
                    ` : ''}
                    <button data-aid="${safeId}" onclick="event.stopPropagation(); document.getElementById('gw-detail-modal').classList.add('hidden'); adminDeleteGiveaway(this.dataset.aid)" class="w-full bg-red-900/60 hover:bg-red-800 text-red-400 hover:text-white py-2 rounded-xl text-xs font-bold transition">🗑️ SİL</button>
                </div>`;
            }

            let participantList = '';
            if(pCount > 0) {
                const parts = g.participants || [];
                const tableRows = parts.map((p, i) => {
                    const uname = _esc(p.username || p);
                    const ig = _esc(p.instagram || '');
                    return `<tr class="border-b border-zinc-800/60 hover:bg-zinc-800/30 transition-colors">
                        <td class="py-2 px-3 text-zinc-500 text-xs text-center">${i+1}</td>
                        <td class="py-2 px-3 text-white text-sm font-bold">@${uname}</td>
                        ${ig ? `<td class="py-2 px-3 text-zinc-400 text-xs">@${ig}</td>` : `<td class="py-2 px-3 text-zinc-600 text-xs">—</td>`}
                    </tr>`;
                }).join('');
                participantList = `<div class="mt-4 border-t border-zinc-800 pt-4">
                    <div class="flex items-center justify-between mb-3">
                        <div class="text-xs text-zinc-400 uppercase font-black tracking-widest">👥 Katılımcılar</div>
                        <div class="px-3 py-1 bg-emerald-900/40 border border-emerald-700/40 rounded-full text-emerald-400 font-black text-sm">${pCount} kişi</div>
                    </div>
                    <div class="rounded-xl border border-zinc-800 overflow-hidden">
                        <table class="w-full">
                            <thead><tr class="bg-zinc-800/60">
                                <th class="py-2 px-3 text-zinc-500 text-[10px] font-bold text-center">#</th>
                                <th class="py-2 px-3 text-zinc-500 text-[10px] font-bold text-left">Kullanıcı</th>
                                <th class="py-2 px-3 text-zinc-500 text-[10px] font-bold text-left">Instagram</th>
                            </tr></thead>
                            <tbody>${tableRows}</tbody>
                        </table>
                    </div>
                </div>`;
            } else {
                participantList = `<div class="mt-4 border-t border-zinc-800 pt-4 text-center text-zinc-600 text-sm py-3">Henüz katılımcı yok.</div>`;
            }

            document.getElementById('gw-detail-body').innerHTML = `
                ${imgHtml}
                <div class="flex justify-between items-start gap-2 mb-3">
                    <h2 class="text-2xl font-black text-white leading-tight flex-1">${_esc(g.title)}</h2>
                    <span class="text-[10px] font-bold px-2 py-1 rounded bg-zinc-800 text-zinc-400 shrink-0">${_esc(g.end_date)}</span>
                </div>
                <div class="flex items-center gap-3 mb-3">
                    <span class="text-sm font-bold text-emerald-400">🏆 ${_esc(g.prize)}</span>
                    <span class="text-xs text-zinc-500">${g.winner_count || 1} kazanan</span>
                    <span class="text-xs text-zinc-500">👥 ${pCount} katılımcı</span>
                </div>
                ${g.description ? `<p class="text-sm text-zinc-400 mb-4 leading-relaxed">${_esc(g.description)}</p>` : ''}
                ${actionHtml}
                ${adminHtml}
                ${participantList}
            `;
            const modal = document.getElementById('gw-detail-modal');
            modal.classList.remove('hidden');
            // Animasyon için
            const panel = modal.querySelector('.gw-detail-panel');
            if(panel) {
                panel.style.transition = 'none';
                panel.style.transform = 'scale(0.80)';
                panel.style.opacity = '0';
                setTimeout(() => {
                    panel.style.transition = 'transform 0.32s cubic-bezier(.34,1.56,.64,1), opacity 0.22s ease';
                    panel.style.transform = 'scale(1)';
                    panel.style.opacity = '1';
                }, 20);
            }
        };

        window.closeGiveawayDetail = function() {
            const modal = document.getElementById('gw-detail-modal');
            const panel = modal.querySelector('.gw-detail-panel');
            if(panel) {
                panel.style.transition = 'transform 0.18s ease, opacity 0.15s ease';
                panel.style.transform = 'scale(0.92)';
                panel.style.opacity = '0';
                setTimeout(() => { modal.classList.add('hidden'); panel.style.transform = ''; panel.style.opacity = ''; }, 180);
            } else modal.classList.add('hidden');
        };

        window.showJoinModal = function(id) {
            _gwCurrentId = id;
            document.getElementById('gw-ig-input').value = '';
            // Önce detay modalını kapat, sonra join modalını aç
            document.getElementById('gw-detail-modal').classList.add('hidden');
            document.getElementById('gw-join-modal').classList.remove('hidden');
        };

        window.submitJoinGiveaway = async function() {
            const btn = document.getElementById('gw-confirm-btn');
            const ig = document.getElementById('gw-ig-input').value.trim().replace(/^@/, '');
            if(!ig) return showToast('Instagram kullanıcı adı gerekli!', 'error');

            btn.disabled = true; btn.textContent = '...';
            try {
                const res = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'join_giveaway', data: {gw_id: _gwCurrentId, giveaway_id: _gwCurrentId, instagram: ig}})
                }).then(r=>r.json());

                if(res.status === 'ok') {
                    showToast('🎉 Çekilişe katıldın!', 'success');
                    document.getElementById('gw-join-modal').classList.add('hidden');
                    loadGiveaways();
                } else showToast(res.message || 'Hata oluştu', 'error');
            } catch(e) { showToast('Bağlantı hatası', 'error'); }
            btn.disabled = false; btn.textContent = 'KATIL';
        };

        window.adminFinalizeGiveaway = async function(id) {
            const isManual = confirm('Manuel olarak kazanan belirlemek istiyor musunuz? (İptal derseniz rastgele seçilir)');
            let manual_winners = [];
            if(isManual) {
                const w = prompt('Kazanan kullanıcı adlarını virgülle ayırarak girin (Örn: ali,veli):');
                if(!w) return;
                manual_winners = w.split(',').map(x=>x.trim()).filter(Boolean);
            } else {
                if(!confirm('Rastgele kazanan seçilecek. Emin misiniz?')) return;
            }
            try {
                const res = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'finalize_giveaway', data: {giveaway_id: id, manual_winners: manual_winners}})
                }).then(r=>r.json());
                
                if(res.status === 'ok') {
                    showToast(res.message, 'success');
                    loadGiveaways();
                } else showToast(res.message, 'error');
            } catch(e) { showToast('Hata', 'error'); }
        };

        let _wpCurrentId = null;

        window.openWinnerPicker = function(id) {
            _wpCurrentId = id;
            const giveaways = db.giveaways || [];
            const g = giveaways.find(x => String(x.id).replace(/[^a-zA-Z0-9_-]/g,'') === String(id));
            if(!g) return;

            const participants = g.participants || [];
            const winnerCount = g.winner_count || 1;
            const list = document.getElementById('gw-winner-picker-list');

            if(participants.length === 0) {
                list.innerHTML = '<div class="text-center text-zinc-500 py-8 text-sm">Henüz katılımcı yok.</div>';
            } else {
                list.innerHTML = participants.map(p => {
                    const uname = _esc(p.username || p);
                    const ig = _esc(p.instagram || '');
                    return `<label class="flex items-center gap-3 p-3 rounded-xl border border-zinc-800 hover:border-amber-600/50 hover:bg-amber-900/10 cursor-pointer transition-all">
                        <input type="checkbox" name="wp-check" value="${uname}" class="w-4 h-4 accent-amber-500 shrink-0">
                        <div class="flex-1 min-w-0">
                            <div class="text-white font-bold text-sm">@${uname}</div>
                            ${ig ? `<div class="text-zinc-500 text-xs">ig: @${ig}</div>` : ''}
                        </div>
                    </label>`;
                }).join('');
            }

            document.getElementById('gw-detail-modal').classList.add('hidden');
            const modal = document.getElementById('gw-winner-picker-modal');
            modal.classList.remove('hidden');
        };

        window.submitWinnerPicker = async function() {
            const checked = Array.from(document.querySelectorAll('#gw-winner-picker-list input[name="wp-check"]:checked'));
            if(checked.length === 0) { showToast('En az 1 kişi seçmelisin!', 'error'); return; }

            const manual_winners = checked.map(c => c.value);
            const btn = document.getElementById('gw-winner-picker-confirm');
            btn.disabled = true; btn.textContent = '...';

            try {
                const res = await fetch('/api/data', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'finalize_giveaway', data: {giveaway_id: _wpCurrentId, manual_winners}})
                }).then(r => r.json());

                if(res.status === 'ok') {
                    document.getElementById('gw-winner-picker-modal').classList.add('hidden');
                    showToast('🎉 Çekiliş tamamlandı!', 'success');
                    loadGiveaways();
                } else showToast(res.message || 'Hata oluştu', 'error');
            } catch(e) { showToast('Bağlantı hatası', 'error'); }

            btn.disabled = false; btn.textContent = '✅ ONAYLA';
        };

        window.adminDeleteGiveaway = async function(id) {
            if(!confirm('Silinsin mi?')) return;
            try {
                const res = await fetch('/api/data', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete_giveaway',data:{giveaway_id:id}})}).then(r=>r.json());
                if(res.status === 'ok') loadGiveaways();
            } catch(e) {}
        };

        window.initGiveawaySystem = function(isAdmin) {
            if(isAdmin) document.getElementById('btn-admin-gw-add').classList.remove('hidden');
            loadGiveaways();
        };

        function loginSuccess() { 
            document.getElementById("login-screen").classList.add("hidden"); 
            document.getElementById("main-app").classList.remove("hidden");
            const _bnav = document.getElementById("bottom-nav");
            if(_bnav) _bnav.style.display = '';
            // Önceki oturumdan mesaj cache'i yükle (anlık görünsün)
            try {
                const cached = localStorage.getItem('fr_msg_cache');
                if(cached) {
                    const msgs = JSON.parse(cached);
                    if(msgs && msgs.length > 0 && db.messages.length === 0) {
                        db.messages = msgs;
                    }
                }
            } catch(e) {}
            
            // Initialize Onboarding Tour if needed
            setTimeout(() => {
                if(typeof AppTour !== 'undefined') AppTour.init();
            }, 1000);
            
            // Trial bitti mi kontrol
            if(currentUser.stats && currentUser.stats.trial_expired) {
                setTimeout(() => showTrialExpiredModal(), 2000);
            }
            // Trial aktif - banner goster
            if(currentUser.stats && currentUser.stats.is_trial && currentUser.stats.premium_tier === 3) {
                setTimeout(() => showTrialBanner(), 800);
            } 
            
            updateProfileUI(); 
            initMap(); 
            
            // Kullanıcının güncel statlarını (Premium, rozet vb.) db.users içine aktar ki eski sohbet mesajlarında rozetler hemen görünsün.
            if (currentUser) {
                const uIdx = db.users.findIndex(u => u.username === currentUser.username);
                if (uIdx !== -1) {
                    db.users[uIdx] = currentUser;
                } else {
                    db.users.push(currentUser);
                }
            }
            
            switchTab(0); 
            renderChat(true);
            startCompCountdown(); // Yarışma geri sayımını başlat
            
            // Arka planda Reels videolarını indir (ilk girişte gri ekranı önlemek için)
            setTimeout(() => {
                if(!reelsData || reelsData.length === 0) {
                    loadReels(false);
                }
            }, 1500);
            // Çarkı önceden çiz — sekmede açılınca zaten hazır olsun
            setTimeout(initWheel3D, 500);  

            // Popup triggers removed per user request
            
            currentMessageCount = db.messages.length; 
            
            if(currentUser.stats && currentUser.stats.riding_until > Date.now()) {
                document.getElementById("radar-info").classList.remove("hidden");
                document.getElementById("btn-riding-mode").innerHTML = "🛑 SÜRÜŞÜ BİTİR";
                document.getElementById("btn-riding-mode").className = "bg-sky-600/90  hover:bg-red-500 btn-premium-hover transition px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-red-400/50 pointer-events-auto";
            }
            
            if (currentUser.stats && currentUser.stats.onboarding === false) {
                // Deneme bitiş tarihini doldur
                const expDate = currentUser.stats.premium_expire_date || '';
                const trialDateEl = document.getElementById('onboarding-trial-date');
                if(trialDateEl && expDate) {
                    trialDateEl.textContent = '⏰ Deneme Bitiş Tarihi: ' + expDate;
                }
                document.getElementById("onboarding-modal").classList.remove("hidden");
            }

            updateMyLocation();
            sendHeartbeat();
            // Heartbeat: her 60 sn — tekrarlı loginSuccess çağrısına karşı koruma
            if (!_heartbeatInterval) {
                _heartbeatInterval = setInterval(sendHeartbeat, 60000);
            }

            // Konum + radar: her 60 sn — tekrarlı aralık oluşturmayı engelle
            if (!_locationInterval) {
                _locationInterval = setInterval(() => {
                    updateMyLocation();
                    refreshRadars();
                }, 60000);
            }
            updateNotifBtnState();
            const isAdmin = currentUser.role === 'Admin' || currentUser.role === 'SubAdmin';
            if(typeof initGiveawaySystem === 'function') initGiveawaySystem(isAdmin);
            loadSavedTheme();
            _lastTitleName = getTitle(currentUser.xp).name;

            // Chat kuralları: localStorage'daki özel anahtarı da kontrol et
            if(localStorage.getItem('fr_chat_rules_' + currentUser.username) === '1') {
                currentUser.accepted_chat_rules = true;
            }

            // Konum iznini hemen ve açıkça iste — açılışta konumun görünmesi için
            if(navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (pos) => {
                        userLat = pos.coords.latitude;
                        userLng = pos.coords.longitude;
                        fetchWeather(userLat, userLng);
                        if(typeof sendLocationToSupabase === 'function') sendLocationToSupabase(userLat, userLng);
                        // Harita açıksa konuma zoom yap
                        if(map) map.setView([userLat, userLng], 14);
                    },
                    (err) => { console.log('Konum izni reddedildi:', err.code); },
                    { enableHighAccuracy: true, timeout: 10000 }
                );
            }

            // OneSignal: kullanıcı kimliğini set et (bildirim hedefleme için)
            setOneSignalUser();
        }

        // ── Modern Premium Bildirim Popup ──
        function showPremiumNotifPopup() {
            const overlay = document.createElement('div');
            overlay.className = 'notif-popup-overlay';
            overlay.id = 'premium-notif-popup';
            overlay.onclick = function(e) { if(e.target === overlay) closePremiumNotifPopup(); };
            overlay.innerHTML = `
                <div class="notif-popup-card">
                    <button onclick="closePremiumNotifPopup()" style="position:absolute;top:12px;right:14px;background:rgba(255,255,255,0.1);border:none;color:#999;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;cursor:pointer;transition:0.2s;z-index:10" onmouseover="this.style.background='rgba(255,255,255,0.2)';this.style.color='#fff'" onmouseout="this.style.background='rgba(255,255,255,0.1)';this.style.color='#999'">✕</button>
                    <div style="text-align:center;margin-bottom:18px">
                        <div style="font-size:32px;margin-bottom:8px">🚴‍♂️</div>
                        <div style="font-size:16px;font-weight:900;color:#fff;letter-spacing:0.5px">FreeriderTR Plus</div>
                        <div style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:2px;margin-top:4px">Premium Deneyim</div>
                    </div>
                    <div style="background:linear-gradient(135deg,rgba(59,130,246,0.15),rgba(168,85,247,0.1));border:1px solid rgba(59,130,246,0.2);border-radius:12px;padding:14px 16px;margin-bottom:18px">
                        <div style="display:flex;flex-direction:column;gap:8px">
                            <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#e2e8f0;font-weight:600">
                                <span style="font-size:14px">🎨</span> Özel isim renkleri ve profil efektleri
                            </div>
                            <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#e2e8f0;font-weight:600">
                                <span style="font-size:14px">🏍️</span> 4 bisiklet garajı ve 10 fotoğraflı ilanlar
                            </div>
                            <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#e2e8f0;font-weight:600">
                                <span style="font-size:14px">✅</span> Onaylı profil rozeti
                            </div>
                            <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#e2e8f0;font-weight:600">
                                <span style="font-size:14px">🤖</span> Sınırsız AI sohbet
                            </div>
                        </div>
                    </div>
                    <button onclick="closePremiumNotifPopup();switchTab(6);" style="width:100%;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#3b82f6,#8b5cf6);color:#fff;font-size:13px;font-weight:800;cursor:pointer;letter-spacing:0.5px;transition:0.2s;box-shadow:0 4px 20px rgba(59,130,246,0.4)" onmouseover="this.style.transform='translateY(-1px)';this.style.boxShadow='0 6px 25px rgba(59,130,246,0.5)'" onmouseout="this.style.transform='';this.style.boxShadow='0 4px 20px rgba(59,130,246,0.4)'">Paketleri İncele →</button>
                    <div style="text-align:center;margin-top:10px;font-size:10px;color:#64748b;font-weight:500">3 gün ücretsiz deneme ile başla</div>
                </div>
            `;
            document.body.appendChild(overlay);
        }
        function closePremiumNotifPopup() {
            const el = document.getElementById('premium-notif-popup');
            if(el) { el.style.opacity = '0'; el.style.transition = 'opacity 0.25s'; setTimeout(() => el.remove(), 250); }
        }

        async function refreshRadars() {
            try {
                const now = Date.now();
                // stats bir JSONB kolon - nested select sözdizimi yanlış, direkt stats seç
                const { data, error } = await supaClient.from('users')
                    .select('username, stats');
                        
                if (data && !error) {
                    data.forEach(fetchedUser => {
                        const s = fetchedUser.stats;
                        if (!s) return;
                        let existingUser = db.users.find(u => u.username === fetchedUser.username);
                        if (existingUser) {
                            if(!existingUser.stats) existingUser.stats = {};
                            // Radar güncelle
                            existingUser.stats.riding_lat = s.riding_lat;
                            existingUser.stats.riding_lng = s.riding_lng;
                            existingUser.stats.riding_until = s.riding_until;
                            // ÇEVRİM İÇİ: last_seen_ts güncelle (kritik!)
                            if (s.last_seen_ts) existingUser.stats.last_seen_ts = s.last_seen_ts;
                        }
                    });
                    if (map) syncMap();
                }
            } catch(e) { console.error("Radar hatası:", e); }
        }

        function updateProfileUI() {
            if(!currentUser) return;
            checkLevelUp();
            
            const stats = currentUser.stats || { markers: 0, events: 0, market: 0, profile_views: 0 };
            const premTier = parseInt(stats.premium_tier) || 0; 
            const premColor = stats.premium_color || 'std-blue';
            
            const textCls = (premTier > 0) ? getPremiumTextClass(premColor) : ''; 
            const inlineStyle = (premTier > 0) ? getPremiumInlineStyle(premColor) : '';
            const borderCls = (premTier > 0) ? getPremiumBorderClass(currentUser.username) : 'border-zinc-700';
            
            let tick = (premTier === 3) ? verifiedTick : ''; 
            let adminTag = (currentUser.role === 'Admin') ? '<span class="ml-2 bg-red-600 text-white px-2 py-0.5 rounded text-[9px] tracking-widest uppercase  relative z-50">👑 Yönetici</span>' : (currentUser.role === 'SubAdmin' ? '<span class="ml-2 bg-orange-800 text-orange-200 px-2 py-0.5 rounded text-[9px] uppercase font-bold tracking-widest">🛡️ Yrd. Admin</span>' : '');
            
            const topUserEl = document.getElementById("top-username");
            topUserEl.innerHTML = `${currentUser.username} ${tick} ${adminTag}`; 
            topUserEl.className = `font-bold text-sm flex items-center transition-all ${textCls ? textCls : 'text-white'}`;
            topUserEl.setAttribute("style", inlineStyle);

            document.getElementById("top-avatar").src = currentUser.avatar || `https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg`; 
            document.getElementById("top-avatar").className = `w-10 h-10 rounded-full object-cover border transition-all ${borderCls}`;
            
            const title = getTitle(currentUser.xp); 
            document.getElementById("top-title").textContent = title.name;
            
            const profileNameEl = document.getElementById("profile-name");
            profileNameEl.innerHTML = `${currentUser.username} ${tick} ${adminTag}`; 
            profileNameEl.className = `text-4xl font-bold break-all teko-font tracking-wide flex justify-center items-center gap-2  transition-all ${textCls ? textCls : 'text-white'}`;
            profileNameEl.setAttribute("style", inlineStyle);

            document.getElementById("profile-bio").textContent = currentUser.bio || "Biyografi eklenmemiş."; 
            document.getElementById("profile-xp").textContent = currentUser.xp;
            
            document.getElementById("profile-avatar").src = currentUser.avatar || `https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg`; 
            document.getElementById("profile-avatar").className = `w-32 h-32 mx-auto rounded-full object-cover cursor-pointer bg-zinc-900 border-4 transition-all duration-300 group-hover:scale-105 ${borderCls}`;
            // Parcacik efektini uygula
            const myEffect = (currentUser.stats && currentUser.stats.avatar_effect) || 'none';
            applyAvatarEffect(myEffect);



            // Streak freeze badge
            const freezeBadge = document.getElementById('streak-freeze-badge');
            const freezeCount = document.getElementById('streak-freeze-count');
            const freezeAmt = parseInt(stats.streak_freeze||0);
            if(freezeBadge) {
                if(freezeAmt > 0) {
                    freezeBadge.classList.remove('hidden');
                    if(freezeCount) freezeCount.textContent = freezeAmt + ' adet kalkaning var';
                } else {
                    freezeBadge.classList.add('hidden');
                }
            }

            // Profil goruntuleme butonu guncelle
            const viewerBtn = document.getElementById('profile-viewer-btn-text');
            if(viewerBtn) {
                const viewCount = stats.profile_views || 0;
                const viewers = stats.profile_viewer_log || [];
                viewerBtn.textContent = viewCount + ' Profil Goruntulemesi - Kimlerin Gordu?';
            }
            document.getElementById("profile-title").textContent = title.icon + " " + title.name;
            document.getElementById("profile-title").className = `text-lg font-bold mt-2  transition-colors ${title.color}`;

            // XP ilerleme cubugu
            const prog = getTitleProgress(currentUser.xp);
            const xpBarEl = document.getElementById("profile-xp-progress");
            if(xpBarEl) {
                if(prog.nextName) {
                    xpBarEl.innerHTML = `
                    <div class="mt-3 px-2">
                        <div class="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-1">
                            <span class="${title.color}">${title.icon} ${title.name}</span>
                            <span class="text-zinc-400">${prog.xpLeft} XP sonra ${prog.nextIcon} ${prog.nextName}</span>
                        </div>
                        <div class="w-full bg-zinc-800 rounded-full h-2 overflow-hidden border border-zinc-700">
                            <div class="h-full rounded-full transition-all duration-700" style="width:${prog.percent}%;background:linear-gradient(90deg,#0ea5e9,#f59e0b);box-shadow:0 0 8px rgba(14,165,233,0.5);"></div>
                        </div>
                        <div class="text-center text-[10px] text-zinc-500 mt-1 font-bold">${prog.percent}% tamamlandi</div>
                    </div>`;
                } else {
                    xpBarEl.innerHTML = `<div class="mt-2 text-center text-xs font-bold text-prem-rainbow">MAX SEVIYE 🌟</div>`;
                }
            }

            let badges = "";
            // Premium badges - all with explicit blocks to avoid else-if chain issues
            if(stats.is_trial) { badges += `<span class="bg-gradient-to-r from-yellow-500 to-amber-400 text-black px-3 py-1.5 rounded-lg text-[10px] font-black  uppercase tracking-widest scale-in-anim animate-pulse">🎁 3 Gun Deneme</span> `; }
            if(premTier === 3) { badges += `<span class="bg-yellow-500 text-black px-3 py-1.5 rounded-lg text-[10px] font-black  uppercase tracking-widest scale-in-anim">👑 Ultra+</span> `; }
            else if(premTier === 2) { badges += `<span class="bg-purple-600 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold  uppercase tracking-widest scale-in-anim">🌟 Deluxe</span> `; }
            else if(premTier === 1) { badges += `<span class="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold  uppercase tracking-widest scale-in-anim">⭐ Standart</span> `; }
            // Activity badges
            if(stats.markers >= 10){ badges += `<span class="bg-emerald-900/50 text-emerald-300 border border-emerald-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🗺️ Haritaci</span> `; }
            else if(stats.markers >= 1){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">📍 Kasif</span> `; }
            if(stats.events >= 5){ badges += `<span class="bg-blue-900/50 text-blue-300 border border-blue-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🏆 Topluluk Lideri</span> `; }
            else if(stats.events >= 1){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">📅 Organizator</span> `; }
            if(stats.market >= 5){ badges += `<span class="bg-amber-900/50 text-amber-300 border border-amber-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">💰 Pazar Ustasi</span> `; }
            else if(stats.market >= 1){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🤝 Esnaf</span> `; }
            if(stats.login_streak >= 100){ badges += `<span class="bg-violet-900/50 text-violet-300 border border-violet-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">⚡ 100 Gun</span> `; }
            else if(stats.login_streak >= 30){ badges += `<span class="bg-indigo-900/50 text-indigo-300 border border-indigo-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">💎 Demir Uye</span> `; }
            else if(stats.login_streak >= 7){ badges += `<span class="bg-orange-900/50 text-orange-300 border border-orange-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🔥 Seri Girisci</span> `; }
            if(stats.total_messages >= 200){ badges += `<span class="bg-cyan-900/50 text-cyan-300 border border-cyan-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">👑 Chat Efsanesi</span> `; }
            else if(stats.total_messages >= 50){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🗣️ Sohbet Tutkunu</span> `; }
            // XP level badges
            if(currentUser.xp >= 50000){ badges += `<span class="bg-gradient-to-r from-red-700 to-purple-700 text-white px-2 py-1 rounded-lg text-[10px] font-black scale-in-anim text-prem-rainbow">🌟 Downhill Efsanesi</span> `; }
            else if(currentUser.xp >= 20000){ badges += `<span class="bg-red-900/50 text-red-300 border border-sky-600 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">👑 Efsane</span> `; }
            else if(currentUser.xp >= 10000){ badges += `<span class="bg-yellow-900/50 text-yellow-300 border border-yellow-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🏆 Sampiyon</span> `; }
            else if(currentUser.xp >= 7000){ badges += `<span class="bg-rose-900/50 text-rose-300 border border-rose-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">💥 Elite</span> `; }
            else if(currentUser.xp >= 4000){ badges += `<span class="bg-orange-900/50 text-orange-300 border border-orange-700 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🔥 Usta</span> `; }
            // Earned mission badges
            const eb = stats.earned_badges || [];
            eb.forEach(b => { badges += `<span class="bg-zinc-800 text-zinc-200 border border-zinc-600 px-2 py-1 rounded-lg text-[10px] font-bold scale-in-anim">🏅 ${b}</span> `; });

            if(!badges.trim()) {
                badges = "<span class='text-zinc-600 text-xs italic font-medium'>Henuz kazanilmis bir rozet yok.</span>";
            }
            document.getElementById("profile-badges").innerHTML = badges;
            
            if (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin' || currentUser.username === 'Admin' || currentUser.username.toLowerCase() === 'admin') {
                document.getElementById("admin-btn").classList.remove("hidden");
            } else {
                document.getElementById("admin-btn").classList.add("hidden");
            }
            
            if(premTier > 0) {
                document.getElementById("premium-buy-section").classList.add("hidden");
                document.getElementById("premium-settings-section").classList.remove("hidden");

                // Paket kartlarını gizle (zaten üye, tekrar satın alma görseli gösterme)
                const packageCardsWrap = document.querySelector('#screen-premium .space-y-4');
                if (packageCardsWrap) packageCardsWrap.classList.add('hidden');

                // Aktif plan kartını doldur
                const planNames = { 1: '⭐ Standart Paket', 2: '🌟 Deluxe Paket', 3: '👑 Ultra+ Paket' };
                const planColors = { 1: 'bg-blue-900/60 text-blue-300 border border-blue-700/50', 2: 'bg-purple-900/60 text-purple-300 border border-purple-700/50', 3: 'bg-yellow-900/60 text-yellow-300 border border-yellow-700/50' };
                const planNameEl = document.getElementById('current-plan-name');
                const planBadgeEl = document.getElementById('current-plan-badge');
                const planExpiryEl = document.getElementById('current-plan-expiry');
                if (planNameEl) planNameEl.textContent = planNames[premTier] || 'Plus Üye';
                if (planBadgeEl) { planBadgeEl.textContent = 'AKTİF'; planBadgeEl.className = 'text-xs font-black px-3 py-1 rounded-lg ' + (planColors[premTier] || ''); }
                if (planExpiryEl) {
                    const expDate = stats.premium_expire_date;
                    planExpiryEl.textContent = expDate ? '📅 Bitiş tarihi: ' + expDate : '♾️ Süresiz aktif';
                }

                // Yükselt butonu: Standart (1) veya Deluxe (2) kullanıcısına göster, Ultra+ (3) için gizle
                const upgradeSec = document.getElementById('upgrade-plan-section');
                const upgradeSelect = document.getElementById('upgrade-tier-select');
                const upgradeHint = document.getElementById('upgrade-hint-text');
                if (premTier < 3 && upgradeSec && upgradeSelect) {
                    upgradeSec.classList.remove('hidden');
                    upgradeSelect.innerHTML = '';
                    if (premTier === 1) {
                        upgradeSelect.innerHTML += '<option value="freeridertr_deluxe_pack_monthly">🌟 Deluxe Paket — 20 TL/Ay</option>';
                        upgradeSelect.innerHTML += '<option value="freeridertr_ultra_pack_monthly">👑 Ultra+ Paket — 30 TL/Ay</option>';
                        if (upgradeHint) upgradeHint.textContent = 'Deluxe veya Ultra+ a gecerek daha fazla ozellik ac.';
                    } else if (premTier === 2) {
                        upgradeSelect.innerHTML += '<option value="freeridertr_ultra_pack_monthly">👑 Ultra+ Paket — 30 TL/Ay</option>';
                        if (upgradeHint) upgradeHint.textContent = 'Ultra+ a gecerek tum ozelliklerin kilidini ac.';
                    }
                } else if (upgradeSec) {
                    upgradeSec.classList.add('hidden');
                }

                const colorContainer = document.getElementById("color-options");
                if(colorContainer) {
                    let html = "";
                    if (premTier >= 1) {
                        html += `<div class="w-full text-[10px] text-zinc-500 uppercase tracking-widest font-bold mb-1 mt-2">Standart Renkler:</div>`;
                        html += createColorBtn('std-blue', 'Mavi', premColor);
                        html += createColorBtn('std-yellow', 'Sarı', premColor);
                        html += createColorBtn('std-pink', 'Pembe', premColor);
                        html += createColorBtn('std-green', 'Yeşil', premColor);
                    }
                    if (premTier >= 2) {
                        html += `<div class="w-full text-[10px] text-yellow-500 uppercase tracking-widest font-bold mb-1 mt-3 border-t border-zinc-800 pt-3">Deluxe Renkler:</div>`;
                        html += createColorBtn('ult-gold', 'Altın', premColor);
                        html += createColorBtn('ult-rainbow', 'Gökkuşağı', premColor);
                        html += createColorBtn('dlx-blue', 'Simli Mavi', premColor);
                        html += createColorBtn('dlx-pink', 'Simli Pembe', premColor);
                        html += createColorBtn('dlx-green', 'Simli Yeşil', premColor);
                    }
                    if (premTier >= 3) {
                        html += `<div class="w-full text-[10px] text-sky-400 uppercase tracking-widest font-bold mb-1 mt-3 border-t border-zinc-800 pt-3">Ultra+ Özel Renk (Hex):</div>`;
                        html += `<div class="w-full flex gap-2 mb-2 items-center">
                                    <input type="color" id="custom-hex-color" class="w-12 h-10 rounded cursor-pointer bg-zinc-900 border border-zinc-700 " value="${premColor.startsWith('#') ? premColor : '#ff0000'}">
                                    <button onclick="applyCustomHex()" class="bg-white text-black px-4 py-2 rounded-lg text-xs font-bold  hover:bg-gray-200 transition btn-premium-hover">Uygula</button>
                                 </div>`;
                        
                        html += `<div class="w-full text-[10px] text-sky-400 uppercase tracking-widest font-bold mb-1 mt-2">Ultra+ Profil Efekti:</div>`;
                        const currentEffect = stats.avatar_effect || 'none';
                        html += createEffectBtn('none', 'Efekt Yok', currentEffect);
                        html += createEffectBtn('fire', '🔥 Alev', currentEffect);
                        html += createEffectBtn('ice', '❄️ Buz', currentEffect);
                    }
                    colorContainer.innerHTML = html;
                }
            } else {
                document.getElementById("premium-buy-section").classList.remove("hidden");
                document.getElementById("premium-settings-section").classList.add("hidden");
                // Üye değilse paket kartlarını tekrar göster
                const packageCardsWrap = document.querySelector('#screen-premium .space-y-4');
                if (packageCardsWrap) packageCardsWrap.classList.remove('hidden');
            }
            
            renderGarage(currentUser.username, 'self');
        }

        // ── Google Play IAP Satın Alma Akışı ──────────────────────────────────────
        // ── Web / Tarayıcı Satın Alma Talebi ─────────────────────────────────────
        // Android/iOS yoksa admin'e DM + push bildirimi gönderir.
        async function _sendWebPurchaseRequest(productId) {
            const confirmed = window.confirm(
                'Web üzerinden alımlarda ödeme onayı için yönetici ile iletişime geçilecektir.\\n\\nDevam etmek istiyor musunuz?'
            );
            if (!confirmed) return;

            const btns = document.querySelectorAll('[onclick*="requestPremium"],[onclick*="requestUpgrade"],[onclick*="handleBuyButton"]');
            btns.forEach(b => { b.disabled = true; b.style.opacity = '0.6'; });

            try {
                const res = await fetch('/api/web_purchase_request', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ productId })
                });
                const data = await res.json();
                if (data.status === 'ok') {
                    showToast(data.message || '✅ Talebiniz yöneticiye iletildi!');
                } else if (data.status === 'wait') {
                    showToast(data.message || '⏳ Zaten bir talebiniz var, lütfen bekleyin.');
                } else {
                    showToast('❌ ' + (data.message || 'Bir hata oluştu, tekrar deneyin.'));
                }
            } catch(err) {
                console.error('[IAP] Web purchase request hatası:', err);
                showToast('❌ Bağlantı hatası. İnternet bağlantınızı kontrol edin.');
            } finally {
                btns.forEach(b => { b.disabled = false; b.style.opacity = '1'; });
            }
        }

        // ── Premium Kart Toggle (Detay Aç/Kapat) ─────────────────────────────
        const _premCards = {
            std: {
                productId: 'freeridertr_standard_pack_monthly',
                color: 'border-sky-500',
                btnStyle: 'background:linear-gradient(135deg,#0369a1,#0ea5e9);color:#fff;',
                features: [
                    ['💎','İsim Rengi','4 farklı özel renk seçeneği'],
                    ['🤖','Sınırsız AI','Günlük sınırsız Freerider AI erişimi'],
                    ['🎬','Video Reels','Sürüş videolarını topluluğa göster'],
                    ['📸','2 Foto İlan','Pazaryeri ilanlarına 2 fotoğraf'],
                    ['🚲','Dijital Garaj','1 bisiklet — marka, model, detayları'],
                    ['📍','Haritaya Ekle','Rampa ve rota işaretleme'],
                    ['🎡','2 Çark Hakkı','Günlük şans çarkından 2 çevirme'],
                    ['💬','Sohbet & DM','Grup + özel mesajlar sınırsız'],
                    ['🗓️','Etkinlik','Buluşma ve yarışma oluşturma'],
                ]
            },
            dlx: {
                productId: 'freeridertr_deluxe_pack_monthly',
                color: 'border-purple-500',
                btnStyle: 'background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;',
                features: [
                    ['⭐','Standart dahil',"Standart'taki her şey +"],
                    ['👑','Elite Rozeti','Deluxe çerçeve & profil badgei'],
                    ['🎨','Simli Renkler','Hareketli/simli isim renkleri'],
                    ['🚀','Pazar Bump','İlanı tek tuşla en üste taşı'],
                    ['📸','4 Foto İlan','Her ilanına 4 fotoğraf'],
                    ['⚙️','Detaylı Donanım','Maşa, Şok, Fren detayları'],
                    ['🔥','Özel İkonlar','💀🔥👑 gibi rampa ikonları'],
                    ['🚲','2 Bisiklet Garajı','2 farklı bisiklet ekle'],
                    ['🎙️','Sesli Mesaj','Grup sohbetinde ses kaydı'],
                ]
            },
            ult: {
                productId: 'freeridertr_ultra_pack_monthly',
                color: 'border-yellow-500',
                btnStyle: 'background:linear-gradient(135deg,#d97706,#f59e0b);color:#000;',
                features: [
                    ['🌟','Deluxe dahil',"Deluxe'teki her şey +"],
                    ['⚡','Sistem Efsanesi','En üst düzey rütbe ve altın kart'],
                    ['🔥','Canlı Efektler','Alev veya buz avatar animasyonu'],
                    ['🎨','HEX Renk','İstediğin renk kodunu gir'],
                    ['📌','Mesaj Sabitle','Gruptaki mesajlarını sabitle'],
                    ['✅','Mavi Tik','Doğrulanmış Verified rozeti'],
                    ['🌈','Gökkuşağı Radar','Haritada taçlı gökkuşağı radar'],
                    ['🚲','4 Bisiklet Garajı','Koleksiyoner seviyesi garaj'],
                    ['📸','10 Foto İlan','İlanlara maksimum 10 fotoğraf'],
                ]
            }
        };
        let _openCard = null;

        function togglePremCard(key) {
            const panel = document.getElementById('prem-detail-panel');
            const content = document.getElementById('prem-detail-content');
            const btn = document.getElementById('prem-buy-btn');
            const allKeys = ['std','dlx','ult'];

            // Aynı karta tıklanırsa kapat
            if (_openCard === key) {
                panel.classList.add('hidden');
                _openCard = null;
                allKeys.forEach(k => {
                    const glow = document.getElementById('card-' + k + '-glow');
                    if (glow) glow.style.opacity = '0';
                    const arrow = document.getElementById('card-' + k + '-arrow');
                    if (arrow) arrow.textContent = '▼';
                });
                return;
            }

            // Tüm kartları sıfırla
            allKeys.forEach(k => {
                const glow = document.getElementById('card-' + k + '-glow');
                if (glow) glow.style.opacity = '0';
                const arrow = document.getElementById('card-' + k + '-arrow');
                if (arrow) arrow.textContent = '▼';
            });

            _openCard = key;
            const card = _premCards[key];

            // Seçili kartı vurgula
            const glow = document.getElementById('card-' + key + '-glow');
            if (glow) glow.style.opacity = '1';
            const arrow = document.getElementById('card-' + key + '-arrow');
            if (arrow) arrow.textContent = '▲';

            // Panel stilini ayarla
            const panelBorderMap = {
                std: 'rgba(56,189,248,0.5)',
                dlx: 'rgba(168,85,247,0.5)',
                ult: 'rgba(234,179,8,0.6)'
            };
            panel.style.borderColor = panelBorderMap[key] || 'rgba(255,255,255,0.2)';
            const bgMap = {
                std: 'linear-gradient(145deg,#0a1628,#0d1f3c)',
                dlx: 'linear-gradient(145deg,#150a28,#1e0d3c)',
                ult: 'linear-gradient(145deg,#1a1000,#2a1d00)'
            };
            panel.style.background = bgMap[key] || '#111';
            panel.style.border = '1px solid ' + panelBorderMap[key];

            // Özellikleri yaz
            content.innerHTML = card.features.map(([icon, title, desc]) =>
                `<div class="flex items-start gap-2.5 py-1.5 border-b border-white/5 last:border-0">
                    <span class="text-base mt-0.5 shrink-0">${icon}</span>
                    <div><span class="text-white font-bold">${title}:</span> <span class="text-zinc-400">${desc}</span></div>
                </div>`
            ).join('');

            // Satın Al butonu güncelle
            btn.style.cssText = card.btnStyle + 'width:100%;margin-top:16px;padding:14px;border-radius:12px;font-weight:900;font-size:14px;letter-spacing:.1em;display:flex;align-items:center;justify-content:center;gap:8px;border:none;cursor:pointer;';
            btn.onclick = () => {
                const sel = document.getElementById('premium-tier-select');
                if (sel) sel.value = card.productId;
                requestPremium();
            };

            panel.classList.remove('hidden');
            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // ── Aktivasyon Kodu Kullan ────────────────────────────────────────────
        async function redeemActivationCode() {
            const input = document.getElementById('activation-code-input');
            const resultEl = document.getElementById('activation-code-result');
            const btn = document.getElementById('activation-code-btn');
            const code = (input?.value || '').trim().toUpperCase();
            if (!code) { showToast('Lütfen bir aktivasyon kodu girin.'); return; }
            if (!code.startsWith('FRK-')) { 
                showToast('❌ Geçersiz kod formatı. Kod FRK- ile başlamalıdır.');
                return;
            }
            if (!currentUser) { showToast('Lütfen önce giriş yapın.'); return; }

            btn.disabled = true;
            btn.textContent = '⏳ Kontrol ediliyor...';
            resultEl.classList.add('hidden');

            try {
                const res = await sendAction('redeem_code', { code });
                if (res && res.status === 'ok') {
                    // Üyeliği frontend'de de güncelle
                    if (res.stats) {
                        currentUser.stats = { ...currentUser.stats, ...res.stats };
                        window.currentUser = currentUser;
                        localStorage.setItem('fr_user', JSON.stringify(currentUser));
                    }

                    resultEl.className = 'mt-3 text-center text-sm font-bold rounded-xl py-2.5 px-4 bg-green-900/60 border border-green-500/50 text-green-300';
                    resultEl.textContent = res.message || '🎉 Üyelik aktive edildi!';
                    resultEl.classList.remove('hidden');
                    input.value = '';

                    // Premium ekranını yenile
                    setTimeout(() => { renderPremiumScreen(); }, 500);
                    showToast(res.message || '🎉 Freerider Plus aktive edildi!');
                } else {
                    resultEl.className = 'mt-3 text-center text-sm font-bold rounded-xl py-2.5 px-4 bg-red-900/60 border border-red-500/50 text-red-300';
                    resultEl.textContent = res?.message || '❌ Geçersiz kod.';
                    resultEl.classList.remove('hidden');
                }
            } catch(e) {
                resultEl.className = 'mt-3 text-center text-sm font-bold rounded-xl py-2.5 px-4 bg-red-900/60 border border-red-500/50 text-red-300';
                resultEl.textContent = '❌ Ağ hatası. Lütfen tekrar deneyin.';
                resultEl.classList.remove('hidden');
            }

            btn.disabled = false;
            btn.innerHTML = '⚡ AKTİVE ET';
        }

        // requestPremium() fonksiyonu artık Google Play Billing Library'yi tetikler.
        // Mobil uygulama (WebView içinde), bu fonksiyonu çağıran JS Bridge üzerinden
        // Android uygulamasına productId'yi iletir ve satın alım akışını başlatır.
        // Satın alım tamamlandığında Android, verifyGooglePurchase() fonksiyonunu
        // çağırarak purchaseToken'ı backend'e doğrulama için gönderir.
        async function requestPremium() {
            const sel = document.getElementById("premium-tier-select");
            if (!sel) { showToast('⚠️ Ürün seçici bulunamadı.'); return; }
            const productId = sel.value;
            if (!productId) { showToast('⚠️ Lütfen bir paket seçin.'); return; }

            // ── Android WebView JS Bridge kontrolü ──────────────────────────────
            // window.Android nesnesi yoksa veya launchBilling metodu tanımlı değilse
            // uyarı göster; uygulamayı çökertme.
            if (typeof window.Android !== 'undefined' && window.Android !== null) {
                if (typeof window.Android.launchBilling === 'function') {
                    try {
                        window.Android.launchBilling(productId);
                    } catch(e) {
                        showToast('Google Play başlatılamadı. Lütfen tekrar deneyin.');
                        console.error('[IAP] launchBilling hatası:', e);
                    }
                    return;
                } else {
                    // window.Android var ama launchBilling metodu yok → eski uygulama sürümü
                    showToast("⚠️ Uygulama güncel değil. Lütfen Google Play'den güncelleyin.");
                    console.warn('[IAP] window.Android mevcut ama launchBilling metodu yok.');
                    return;
                }
            }

            // iOS WKWebView köprüsü (gelecekteki iOS desteği için)
            if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.billing) {
                try {
                    window.webkit.messageHandlers.billing.postMessage({ productId });
                } catch(e) {
                    showToast('In-app satın alım başlatılamadı.');
                }
                return;
            }

            // Tarayıcı / web ortamı → admin'e satın alma talebi gönder
            await _sendWebPurchaseRequest(productId);
        }

        // ── Üyelik Yükseltme ─────────────────────────────────────────────────────
        async function requestUpgrade() {
            const sel = document.getElementById("upgrade-tier-select");
            if (!sel) { showToast('⚠️ Yükseltme seçici bulunamadı.'); return; }
            const productId = sel.value;
            if (!productId) { showToast('⚠️ Lütfen bir paket seçin.'); return; }

            if (typeof window.Android !== 'undefined' && window.Android !== null) {
                if (typeof window.Android.launchBilling === 'function') {
                    try {
                        window.Android.launchBilling(productId);
                    } catch(e) {
                        showToast('Google Play başlatılamadı. Lütfen tekrar deneyin.');
                        console.error('[IAP] launchBilling hatası:', e);
                    }
                    return;
                } else {
                    showToast("⚠️ Uygulama güncel değil. Lütfen Google Play'den güncelleyin.");
                    return;
                }
            }
            if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.billing) {
                try { window.webkit.messageHandlers.billing.postMessage({ productId }); } catch(e) { showToast('In-app satın alım başlatılamadı.'); }
                return;
            }
            // Tarayıcı / web ortamı → admin'e satın alma talebi gönder
            await _sendWebPurchaseRequest(productId);
        }

        // Android uygulaması satın alım tamamlandığında bu fonksiyonu çağırır.
        // Android kodu: webView.evaluateJavascript("verifyGooglePurchase(...)", null);
        async function verifyGooglePurchase(purchaseToken, productId, purchaseType) {
            try {
                showToast('Ödeme doğrulanıyor...');
                const res = await fetch('/api/verify_google_purchase', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        purchaseToken: purchaseToken,
                        productId:     productId,
                        purchaseType:  purchaseType || 'subscription'
                    })
                });
                const json = await res.json();
                if (json.status === 'ok') {
                    showToast('✅ Aboneliğin aktive edildi! Hoş geldin.');
                    // Kullanıcı verilerini yenile
                    await loadMyData();
                    renderProfile();
                } else {
                    showToast('⚠️ Doğrulama hatası: ' + (json.message || 'Bilinmeyen hata'));
                }
            } catch(e) {
                showToast('Ağ hatası oluştu, lütfen tekrar deneyin.');
            }
        }

        async function showOtherProfile(targetUsername) {
            if(targetUsername === currentUser.username) { 
                switchTab(7); 
                document.getElementById('market-detail-modal').classList.add('hidden'); 
                return; 
            }
            
            let u = db.users.find(x => x.username === targetUsername); 
            if(!u) {
                try {
                    const { data, error } = await supaClient.from('users').select('*').eq('username', targetUsername).single();
                    if(data) {
                        u = data;
                        db.users.push(u);
                    } else {
                        return;
                    }
                } catch(e) { return; }
            }

            sendAction('increment_profile_view', { username: targetUsername }).catch(e => {});

            const stats = u.stats || { markers: 0, events: 0, market: 0, profile_views: 0 };
            const premTier = parseInt(stats.premium_tier) || 0; 
            const premColor = stats.premium_color || 'std-blue';
            
            const textCls = (premTier > 0) ? getPremiumTextClass(premColor) : ''; 
            const inlineStyle = (premTier > 0) ? getPremiumInlineStyle(premColor) : '';
            const borderCls = (premTier > 0) ? getPremiumBorderClass(u.username) : 'border-zinc-700';
            
            let tick = (premTier === 3) ? verifiedTick : ''; 
            let adminTag = (u.role === 'Admin') ? '<span class="ml-2 bg-red-600 text-white px-2 py-0.5 rounded text-[9px] uppercase font-bold tracking-widest ">👑 Yönetici</span>' : (u.role === 'SubAdmin' ? '<span class="ml-2 bg-orange-800 text-orange-200 px-2 py-0.5 rounded text-[9px] uppercase font-bold tracking-widest">🛡️ Yrd. Admin</span>' : '');

            document.getElementById("op-avatar").src = u.avatar || `https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg`; 
            document.getElementById("op-avatar").className = `w-28 h-28 mx-auto rounded-full object-cover mt-6 bg-zinc-950  border-4 transition-all duration-300 ${borderCls}`;
            
            const badge = document.getElementById("op-premium-badge");
            if(premTier === 3) { 
                badge.classList.remove("hidden"); 
                badge.className = `mt-3 text-[10px] font-black uppercase tracking-widest text-yellow-500 `; 
                badge.textContent = "👑 Ultra+"; 
            } else if (premTier === 2) { 
                badge.classList.remove("hidden"); 
                badge.className = `mt-3 text-[10px] font-bold uppercase tracking-widest text-purple-400 `; 
                badge.textContent = "🌟 Deluxe"; 
            } else if (premTier === 1) { 
                badge.classList.remove("hidden"); 
                badge.className = `mt-3 text-[10px] font-bold uppercase tracking-widest  ${textCls}`; 
                badge.textContent = "⭐ Standart"; 
            } else { 
                badge.classList.add("hidden"); 
            }

            const opNameEl = document.getElementById("op-username");
            opNameEl.innerHTML = `${u.username} ${tick} ${adminTag}`; 
            opNameEl.className = `text-4xl font-bold break-all teko-font tracking-wide flex items-center justify-center  transition-all ${textCls ? textCls : 'text-white'}`;
            opNameEl.setAttribute("style", inlineStyle);
            
            const tickBox = document.getElementById("op-verified-badge");
            if (premTier === 3) { 
                tickBox.innerHTML = verifiedTick; 
                tickBox.classList.remove("hidden"); 
            } else { 
                tickBox.classList.add("hidden"); 
            }
            
            document.getElementById("op-bio").textContent = u.bio || "Kullanıcı biyo girmemiş."; 
            document.getElementById("op-xp").textContent = u.xp;
            
            const title = getTitle(u.xp); 
            document.getElementById("op-title").textContent = title.name; 
            document.getElementById("op-title").className = `text-sm font-bold truncate uppercase mt-1  ${title.color}`;
            
            const opOnlineEl = document.getElementById("op-online-status");
            if(opOnlineEl) {
                const s = getOnlineStatus(u);
                if(s.status === 'online') {
                    opOnlineEl.innerHTML = `<span class="online-dot-sm"></span><span class="online-label">${s.label}</span>`;
                    opOnlineEl.className = "flex items-center gap-2 justify-center mt-2";
                } else if(s.status === 'recent') {
                    opOnlineEl.innerHTML = `<span class="recent-dot"></span><span class="recent-label">${s.label}</span>`;
                    opOnlineEl.className = "flex items-center gap-2 justify-center mt-2";
                } else {
                    opOnlineEl.innerHTML = '';
                    opOnlineEl.className = "hidden";
                }
            }

            
            let badges = "";
            if(stats.markers >= 1){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-3 py-1 rounded-lg text-[10px] font-bold ">📍 Kâşif</span>`; }
            if(stats.events >= 1){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-3 py-1 rounded-lg text-[10px] font-bold ">📅 Organizatör</span>`; }
            if(stats.market >= 1){ badges += `<span class="bg-zinc-800 text-zinc-300 border border-zinc-700 px-3 py-1 rounded-lg text-[10px] font-bold ">🤝 Esnaf</span>`; }
            if(u.xp > 1000){ badges += `<span class="bg-orange-900/50 text-orange-300 border border-orange-700 px-3 py-1 rounded-lg text-[10px] font-bold ">🔥 Kıdemli</span>`; }
            const oEarnedBadges = stats.earned_badges || [];
            oEarnedBadges.forEach(b => {
                badges += `<span class="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-700/50 text-yellow-400 px-3 py-1 rounded-lg text-[10px] font-black uppercase ">🏆 ${b}</span>`;
            });
            
            if(badges === "") {
                badges = "<span class='text-zinc-500 text-xs italic font-medium'>Rozet yok.</span>";
            }
            document.getElementById("op-badges").innerHTML = badges;

            renderGarage(u.username, 'other');

            let actionsHtml = `<button onclick="startDm('${u.username}')" class="bg-white hover:bg-gray-200 transition text-black py-4 rounded-xl text-sm font-bold w-full  mb-3 btn-premium-hover">💬 ÖZEL MESAJ</button>`;
            
            // Engel durumunu kontrol et
            const myBlockedList = (currentUser.stats && currentUser.stats.blocked_users) ? currentUser.stats.blocked_users : [];
            const isBlocked = myBlockedList.includes(u.username);
            if(isBlocked) {
                actionsHtml += `<button onclick="unblockUser('${u.username}')" class="w-full bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 transition text-zinc-400 py-3 rounded-xl font-bold text-xs uppercase tracking-widest mb-3 btn-premium-hover">✅ ENGELİ KALDIR</button>`;
            } else {
                actionsHtml += `<button onclick="blockUser('${u.username}')" class="w-full bg-black border border-sky-900/50 hover:bg-red-950/30 transition text-sky-400 py-3 rounded-xl font-bold text-xs uppercase tracking-widest mb-2 btn-premium-hover">🚫 ENGELLE</button>`;
            }
            actionsHtml += `<button onclick="openReportUserModal('${u.username}')" class="w-full bg-black border border-orange-900/50 hover:bg-orange-950/20 transition text-orange-400 py-3 rounded-xl font-bold text-xs uppercase tracking-widest mb-3 btn-premium-hover">🚨 ŞİKAYET ET</button>`;
            
            if(currentUser.role === 'Admin' || currentUser.username === 'Admin' || currentUser.username.toLowerCase() === 'admin') {
                actionsHtml += `
                <div class="rounded-2xl p-4 border border-zinc-700/60 mb-3" style="background:rgba(0,0,0,0.5)">
                    <div class="text-[10px] text-zinc-400 uppercase font-bold tracking-widest mb-3">👑 Ana Admin — Yönetim</div>
                    <div class="flex gap-2 mb-3">
                        <select id="admin-tier-select" class="flex-1 bg-zinc-900 border border-zinc-600 rounded-lg px-3 py-2 text-white text-xs outline-none cursor-pointer font-bold">
                            <option value="0" ${stats.premium_tier == 0 ? 'selected' : ''}>Ücretsiz (İptal)</option>
                            <option value="1" ${stats.premium_tier == 1 ? 'selected' : ''}>⭐ Standart</option>
                            <option value="2" ${stats.premium_tier == 2 ? 'selected' : ''}>🌟 Deluxe</option>
                            <option value="3" ${stats.premium_tier == 3 ? 'selected' : ''}>👑 Ultra+</option>
                        </select>
                        <button onclick="adminSetPremium('${u.username}')" class="bg-gradient-to-r from-purple-700 to-pink-700 hover:opacity-90 text-white py-2 px-4 rounded-lg text-[10px] font-bold transition uppercase tracking-widest btn-premium-hover">KAYDET</button>
                    </div>
                    <div class="flex gap-2 mb-3">
                        <input id="admin-xp-amount" type="number" placeholder="XP miktarı" class="w-1/2 bg-black/60 text-white rounded-xl px-4 py-3 text-sm border border-zinc-700 outline-none focus:border-white transition font-bold">
                        <button onclick="giveXP('${u.username}')" class="w-1/2 bg-zinc-800 hover:bg-zinc-700 transition text-white py-3 rounded-xl text-xs font-bold uppercase tracking-widest btn-premium-hover">XP VER</button>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <button onclick="openUserActivity('${u.username}')" class="bg-blue-950/50 hover:bg-blue-900/60 transition text-blue-400 py-3 rounded-xl text-xs font-bold uppercase tracking-widest border border-blue-800/50 btn-premium-hover">🔍 Aktivite</button>
                        <button onclick="banUser('${u.username}')" class="bg-red-950/50 hover:bg-sky-900/80 transition text-sky-400 py-3 rounded-xl text-xs font-bold uppercase tracking-widest border border-sky-800/50 btn-premium-hover">🚨 Banla</button>
                    </div>
                </div>`;
            } else if(currentUser.role === 'SubAdmin') {
                actionsHtml += `
                <div class="rounded-2xl p-4 border border-orange-900/40 mb-3" style="background:rgba(120,53,15,0.12)">
                    <div class="text-[10px] text-orange-400 uppercase font-bold tracking-widest mb-3">🛡️ Yrd. Admin İşlemleri</div>
                    <div class="grid grid-cols-2 gap-2">
                        <button onclick="openUserActivity('${u.username}')" class="bg-blue-950/50 hover:bg-blue-900/60 transition text-blue-400 py-3 rounded-xl text-xs font-bold uppercase tracking-widest border border-blue-800/50 btn-premium-hover">🔍 Aktivite</button>
                        <button onclick="banUser('${u.username}')" class="bg-red-950/50 hover:bg-sky-900/80 transition text-sky-400 py-3 rounded-xl text-xs font-bold uppercase tracking-widest border border-sky-800/50 btn-premium-hover">🚨 Banla</button>
                    </div>
                </div>`;
            }
            
            document.getElementById("op-actions").innerHTML = actionsHtml;

            // ── Profil Reels Sekmesi ──
            // op-actions altına reels tab ekle (varsa önce temizle)
            const existingReelsTab = document.getElementById('op-reels-section');
            if(existingReelsTab) existingReelsTab.remove();
            const reelsSection = document.createElement('div');
            reelsSection.id = 'op-reels-section';
            reelsSection.className = 'mt-4';
            reelsSection.innerHTML = `
                <div class="flex items-center gap-2 mb-3">
                    <button id="op-reels-tab-btn" onclick="window.loadOtherProfileReels('${escapeHtml(u.username)}')"
                        class="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-pink-900/60 to-sky-900/40 border border-pink-700/40 text-white text-xs font-black uppercase tracking-widest hover:opacity-90 transition btn-premium-hover">
                        🎬 Reels'leri Gör
                    </button>
                </div>
                <div id="op-reels-grid" class="hidden grid grid-cols-3 gap-1 rounded-xl overflow-hidden"></div>
                <div id="op-reels-loading" class="hidden flex items-center justify-center py-6">
                    <div class="w-6 h-6 rounded-full border-2 border-pink-500 border-t-transparent animate-spin"></div>
                </div>
                <div id="op-reels-empty" class="hidden text-center text-zinc-500 text-xs py-4">Bu kullanıcının henüz Reels paylaşımı yok.</div>
            `;
            const opActionsEl = document.getElementById('op-actions');
            if(opActionsEl && opActionsEl.parentNode) {
                opActionsEl.parentNode.insertBefore(reelsSection, opActionsEl.nextSibling);
            }

            document.getElementById("other-profile-modal").classList.remove("hidden");
        }

        // ── Diğer Kullanıcının Reels'lerini Yükle ──
        window.loadOtherProfileReels = async function(profileUsername) {
            const grid    = document.getElementById('op-reels-grid');
            const loading = document.getElementById('op-reels-loading');
            const empty   = document.getElementById('op-reels-empty');
            const tabBtn  = document.getElementById('op-reels-tab-btn');
            if(!grid) return;

            // Butonu gizle, loading göster
            if(tabBtn) tabBtn.style.display = 'none';
            if(loading) { loading.classList.remove('hidden'); loading.style.display = 'flex'; }
            if(empty) empty.classList.add('hidden');
            grid.classList.add('hidden');
            grid.innerHTML = '';

            try {
                // Supabase'den doğrudan sorgula
                const { data, error } = await supaClient
                    .from('reels')
                    .select('id, media_url, media_type, caption, likes, created_at')
                    .eq('user', profileUsername)
                    .order('created_at', { ascending: false })
                    .limit(12);

                if(loading) { loading.classList.add('hidden'); loading.style.display = 'none'; }

                const reels = data || [];
                if(reels.length === 0) {
                    if(empty) empty.classList.remove('hidden');
                    return;
                }

                reels.forEach((r, idx) => {
                    const item = document.createElement('div');
                    item.className = 'relative aspect-square bg-zinc-900 overflow-hidden cursor-pointer';
                    item.style.cssText = 'border-radius:4px;';

                    if(r.media_type === 'video') {
                        item.innerHTML = `
                            <video src="${escapeHtml(r.media_url)}" class="w-full h-full object-cover" muted playsinline preload="metadata" style="pointer-events:none;"></video>
                            <div style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,0.6);border-radius:6px;padding:2px 5px;">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="12" height="12" fill="white"><path d="M3 2l10 6-10 6V2z"/></svg>
                            </div>
                            <div style="position:absolute;bottom:4px;left:4px;font-size:10px;color:rgba(255,255,255,0.8);font-weight:bold;">❤ ${(r.likes||[]).length}</div>`;
                    } else {
                        item.innerHTML = `
                            <img src="${escapeHtml(r.media_url)}" class="w-full h-full object-cover" onerror="this.parentElement.innerHTML='<div style=\\'width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:24px;color:#555\\'>📸</div>'">
                            <div style="position:absolute;bottom:4px;left:4px;font-size:10px;color:rgba(255,255,255,0.8);font-weight:bold;">❤ ${(r.likes||[]).length}</div>`;
                    }

                    // Tıklayınca Reels sayfasına ışın — direkt o videodan başlat
                    item.addEventListener('click', () => {
                        document.getElementById('other-profile-modal').classList.add('hidden');
                        window.openReels(r.id);
                    });

                    grid.appendChild(item);
                });

                grid.classList.remove('hidden');
                grid.style.display = 'grid';
            } catch(err) {
                if(loading) { loading.classList.add('hidden'); loading.style.display = 'none'; }
                if(empty) empty.classList.remove('hidden');
                console.error('Profil reels yükleme hatası:', err);
            }
        };

        async function adminSetPremium(target) {
            const tier = document.getElementById("admin-tier-select").value;
            await sendAction('admin_toggle_premium', { username: target, tier: tier });
            alert("Abonelik başarıyla güncellendi!");
            document.getElementById("other-profile-modal").classList.add("hidden");
        }

        async function giveXP(u) { 
            const a = document.getElementById("admin-xp-amount").value; 
            if(!a) return; 
            
            await sendAction('give_xp', { username: u, amount: a }); 
            alert("XP Başarıyla Eklendi!"); 
            document.getElementById("other-profile-modal").classList.add("hidden"); 
        }
        
        async function banUser(u) { 
            if(confirm("Bu kullanıcıyı kalıcı olarak banlamak istediğinize emin misiniz?")) { 
                await sendAction('add_ban', { username: u });
                db.banned.push(u);
            } 
        }

        async function blockUser(target) {
            if(!confirm(`${target} adlı kullanıcıyı engellemek istediğine emin misin? Engellenince seni göremez ve sana mesaj gönderemez.`)) return;
            const res = await sendAction('block_user', { target });
            if(res && res.status === 'ok') {
                if(!currentUser.stats) currentUser.stats = {};
                if(!currentUser.stats.blocked_users) currentUser.stats.blocked_users = [];
                if(!currentUser.stats.blocked_users.includes(target)) currentUser.stats.blocked_users.push(target);
                document.getElementById('other-profile-modal').classList.add('hidden');
                showToast(`🚫 ${target} engellendi.`);
            } else {
                alert(res?.message || 'Bir hata oluştu.');
            }
        }

        async function unblockUser(target) {
            const res = await sendAction('unblock_user', { target });
            if(res && res.status === 'ok') {
                if(currentUser.stats && currentUser.stats.blocked_users) {
                    currentUser.stats.blocked_users = currentUser.stats.blocked_users.filter(u => u !== target);
                }
                document.getElementById('other-profile-modal').classList.add('hidden');
                showToast(`✅ ${target} engeli kaldırıldı.`);
            } else {
                alert(res?.message || 'Bir hata oluştu.');
            }
        }

        function openDeleteAccountModal() {
            document.getElementById('settings-modal').classList.add('hidden');
            document.getElementById('delete-account-password').value = '';
            document.getElementById('delete-account-modal').classList.remove('hidden');
        }

        async function confirmDeleteAccount() {
            const pw = document.getElementById('delete-account-password').value.trim();
            if(!pw) { alert('Lütfen şifreni gir.'); return; }
            if(!confirm('Son onay: Hesabın ve TÜM verilerin kalıcı olarak silinecek. Devam etmek istiyor musun?')) return;
            const res = await sendAction('delete_account', { password: pw });
            if(res && res.status === 'ok') {
                alert('Hesabın başarıyla silindi. Görüşmek üzere! 🏔️');
                window.location.reload();
            } else {
                alert(res?.message || 'Bir hata oluştu.');
            }
        }

        // ---- KULLANICI RAPORLAMA ----
        let _reportUserTarget = '';
        let _reportUserReason = '';
        let _reportMsgId = '';
        let _reportMsgUser = '';
        let _reportMsgText = '';
        let _reportMsgReason = '';

        function openReportUserModal(username) {
            _reportUserTarget = username;
            _reportUserReason = '';
            document.getElementById('report-user-target-label').textContent = username;
            document.getElementById('report-user-detail').value = '';
            document.getElementById('other-profile-modal').classList.add('hidden');
            document.getElementById('report-user-modal').classList.remove('hidden');
        }

        function setReportReason(reason) {
            _reportUserReason = reason;
            document.querySelectorAll('#report-user-modal .grid button').forEach(b => {
                b.classList.toggle('border-orange-500', b.textContent.trim().includes(reason.split('/')[0].trim()));
            });
        }

        async function submitReportUser() {
            const detail = document.getElementById('report-user-detail').value.trim();
            const reason = _reportUserReason ? _reportUserReason + (detail ? ': ' + detail : '') : detail;
            if(!reason) { alert('Lütfen bir şikayet sebebi seçin.'); return; }
            const res = await sendAction('report_user', { target: _reportUserTarget, reason });
            document.getElementById('report-user-modal').classList.add('hidden');
            if(res && res.status === 'ok') {
                showToast('Şikayetiniz admin ekibine iletildi. Teşekkürler!');
            } else {
                alert(res?.message || 'Bir hata oluştu.');
            }
        }

        function openReportMsgModal(encodedId, encodedUser, encodedText) {
            try {
                _reportMsgId = decodeURIComponent(atob(encodedId));
                _reportMsgUser = decodeURIComponent(atob(encodedUser));
                _reportMsgText = decodeURIComponent(atob(encodedText));
            } catch(e) {
                _reportMsgId = encodedId;
                _reportMsgUser = encodedUser;
                _reportMsgText = encodedText;
            }
            _reportMsgReason = '';
            document.getElementById('report-msg-preview').textContent = _reportMsgText || '(Mesaj içeriği)';
            document.getElementById('report-msg-modal').classList.remove('hidden');
        }

        function setMsgReportReason(reason) {
            _reportMsgReason = reason;
            document.querySelectorAll('#report-msg-modal .grid button').forEach(b => {
                b.classList.toggle('border-orange-500', b.textContent.trim().includes(reason.split('/')[0].trim()));
            });
        }

        async function submitReportMsg() {
            if(!_reportMsgReason) { alert('Lütfen bir şikayet sebebi seçin.'); return; }
            document.getElementById('report-msg-modal').classList.add('hidden');
            try {
                // sendAction üzerinden /api/data'ya gönder — session yönetimi güvenilir
                const data = await sendAction('report_message', {
                    msg_id:   String(_reportMsgId),
                    msg_text: String(_reportMsgText),
                    msg_user: String(_reportMsgUser),
                    reason:   String(_reportMsgReason)
                }, true);
                if (data && data.status === 'ok') {
                    // Local state'i güncelle — sayfa yenilenmeden flag badge görünsün
                    const localMsg = db.messages.find(m => m.id === String(_reportMsgId));

                    if (data.message && typeof showToast === 'function') {
                        showToast(data.message);
                    }

                    if (data.should_remove) {
                        // flag_count >= 2 — mesaj otomatik silindi, local'den de kaldır
                        db.messages = db.messages.filter(m => m.id !== String(_reportMsgId));
                        _renderedMsgIds.delete(String(_reportMsgId));
                    } else if (localMsg && data.is_flagged === true) {
                        localMsg.is_flagged = true;
                        localMsg.flag_count = data.flag_count || (localMsg.flag_count || 0) + 1;
                    }
                    renderChat(true); // Tüm mesajları yeniden çiz (flag badge dahil)

                    // AI moderasyon uyarısı varsa sohbete ekle
                    if (data.warning && data.ai_chat_msg) {
                        try {
                            db.messages.push(data.ai_chat_msg);
                            const container = document.getElementById('chat-messages');
                            if (container) {
                                const msgHtml = buildMsgHTML(data.ai_chat_msg);
                                container.insertAdjacentHTML('beforeend', msgHtml);
                                container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
                            }
                        } catch(e) { console.warn('[Moderasyon] AI mesaj ekleme hatası:', e); }
                    }

                    if (data.should_remove) {
                        showToast('🚫 Mesaj çok fazla şikayet aldı ve otomatik kaldırıldı.', 'error', 4000);
                    } else if (data.warning) {
                        showToast('⚠️ İçerik uygunsuz bulundu ve admin ekibine iletildi!', 'warning');
                    } else {
                        showToast('✅ Mesaj moderasyon ekibine iletildi. Teşekkürler!', 'success');
                    }
                } else {
                    showToast('❌ Bildirim gönderilemedi: ' + (data?.message || 'Hata'), 'error');
                }
            } catch(err) {
                console.error('[Moderasyon] Hata:', err);
                showToast('❌ Bağlantı hatası. Tekrar deneyin.');
            }
        }

        // Sohbet ekranına Freerider AI moderatör mesajı ekler
        function injectModerationSystemMessage(senderUsername, systemMsg) {
            const container = document.getElementById('chat-messages') || document.getElementById('dm-messages');
            if (!container) return;
            const aiMsg = {
                id: String(Date.now()) + '_mod',
                user: 'Freerider AI',
                text: '🛡️ ' + senderUsername + ', mesajın topluluk kurallarına aykırı bulundu ve admin ekibine bildirildi. Lütfen kurallara uygun davranın. Tekrarlayan ihlaller hesabınızın askıya alınmasına neden olabilir.',
                type: 'text'
            };
            db.messages.push(aiMsg);
            const msgHtml = buildMsgHTML(aiMsg);
            container.insertAdjacentHTML('beforeend', msgHtml);
            container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
        }

        function toggleAddMarkerMode() { 
            if(isAddingEventMode) toggleAddEventMode(); 
            isAddingMarkerMode = !isAddingMarkerMode; 
            
            const btn = document.getElementById("btn-add-marker-mode"); 
            const mapContainer = document.getElementById("map"); 
            const crosshair = document.getElementById("map-crosshair");
            const confirmBtn = document.getElementById("map-confirm-btn-container");
            
            if(isAddingMarkerMode) { 
                btn.className = "bg-red-600 px-3 py-2 rounded-xl  font-bold text-white animate-pulse text-[10px] uppercase tracking-widest pointer-events-auto "; 
                btn.innerHTML = "❌ İPTAL ET"; 
                btn.onclick = toggleAddMarkerMode;
                mapContainer.classList.add("map-add-mode"); 
                if(crosshair) crosshair.classList.remove("hidden");
                if(confirmBtn) confirmBtn.classList.remove("hidden");
            } else { 
                btn.className = "bg-sky-600/90  hover:bg-red-500 btn-premium-hover transition px-3 py-2 rounded-xl  font-bold text-white text-[10px] uppercase tracking-widest border border-red-400/50 pointer-events-auto"; 
                btn.innerHTML = "📍 YER EKLE"; 
                btn.onclick = openCategorySelectModal;
                mapContainer.classList.remove("map-add-mode"); 
                if(crosshair) crosshair.classList.add("hidden");
                if(confirmBtn) confirmBtn.classList.add("hidden");
            } 
        }
        
        function toggleAddEventMode() { 
            if(isAddingMarkerMode) toggleAddMarkerMode();
            isAddingEventMode = !isAddingEventMode; 
            
            const btn = document.getElementById("btn-add-event-mode"); 
            const mapContainer = document.getElementById("map"); 
            const crosshair = document.getElementById("map-crosshair");
            const confirmBtn = document.getElementById("map-confirm-btn-container");
            
            if(isAddingEventMode) { 
                btn.className = "bg-green-600 px-3 py-2 rounded-xl  font-bold text-white animate-pulse text-[10px] uppercase tracking-widest pointer-events-auto "; 
                btn.innerHTML = "❌ İPTAL ET"; 
                mapContainer.classList.add("map-add-mode"); 
                if(crosshair) crosshair.classList.remove("hidden");
                if(confirmBtn) confirmBtn.classList.remove("hidden");
            } else { 
                btn.className = "bg-blue-600/90  hover:bg-blue-500 btn-premium-hover transition px-3 py-2 rounded-xl  flex items-center justify-center text-[10px] uppercase tracking-widest font-bold text-white border border-blue-400/50 pointer-events-auto"; 
                btn.innerHTML = "📅 BULUŞMA EKLE"; 
                mapContainer.classList.remove("map-add-mode"); 
                if(crosshair) crosshair.classList.add("hidden");
                if(confirmBtn) confirmBtn.classList.add("hidden");
            } 
        }

        function confirmMapSelection() {
            if(!map) return;
            const center = map.getCenter();
            tempLat = center.lat;
            tempLng = center.lng;
            
            if (isAddingMarkerMode) { 
                document.getElementById('add-marker-modal').classList.remove('hidden');
            } else if (isAddingEventMode) { 
                toggleAddEventMode(); 
                openAddEventModal(); 
            }
        }

        function useCurrentLocationForMarker() {
            if(!userLat || !userLng) {
                return alert("Konumunuz bulunamadı! Lütfen haritadaki GPS (🎯) butonuna tıklayıp konum izni verin.");
            }
            tempLat = userLat;
            tempLng = userLng;
            editingMarkerId = null;
            document.getElementById("modal-marker-title").textContent = "📍 " + selectedMarkerCategory.toUpperCase() + " EKLE (Şu Anki Konum)";
            showToast("Şu anki konumunuz başarıyla alındı! Detayları girip kaydedebilirsiniz.");
        }

        function quickAddMarkerCurrentLocation() {
            if(!userLat || !userLng) {
                return alert("Konumunuz bulunamadı! Lütfen haritadaki GPS (🎯) butonuna tıklayıp konum izni verin.");
            }
            tempLat = userLat;
            tempLng = userLng;
            editingMarkerId = null;
            
            document.getElementById("new-marker-name").value = "";
            document.getElementById("new-marker-desc").value = "";
            document.getElementById("new-marker-extranote").value = "";
            document.getElementById("new-marker-difficulty").value = "Orta";
            document.getElementById("new-marker-photo").value = "";
            
            openCategorySelectModal();
        }
        
        function editMarker(id) {
            const m = db.markers.find(x => x.id === id);
            if(!m) return;
            
            editingMarkerId = m.id;
            editingMarkerLat = m.lat;
            editingMarkerLng = m.lng;
            
            document.getElementById("modal-marker-title").textContent = "✏️ RAMPA DÜZENLE";
            document.getElementById("new-marker-name").value = m.name || "";
            document.getElementById("new-marker-desc").value = m.desc || "";
            document.getElementById("new-marker-difficulty").value = m.difficulty || "Orta";
            document.getElementById("new-marker-photo").value = ""; 
            
            if(getUserPremiumTier(currentUser.username) >= 2 || currentUser.role === 'Admin') {
                document.getElementById("new-marker-icon").classList.remove("hidden");
                document.getElementById("new-marker-icon").value = m.icon_type || "🚴";
            }
            
            closeMarkerSheet();
            document.getElementById("add-marker-modal").classList.remove("hidden");
        }
        
        async function deleteMarker(id) {
            if(confirm("Bu noktayı haritadan kalıcı olarak silmek istediğine emin misin?")) {
                closeMarkerSheet();
                await sendAction('delete_marker', {id: id});
                db.markers = db.markers.filter(m => m.id !== id);
                if(map) syncMap();
            }
        }

        function showMarkerSheet(m, updateOnly = false) {
            currentMarkerId = m.id;
            const sheet = document.getElementById("marker-sheet");
            
            if(!updateOnly) sheet.classList.remove("hidden");
            
            document.getElementById("ms-title").textContent = m.title || m.name;
            document.getElementById("ms-category").textContent = m.category || m.icon_type || "Rampa";
            document.getElementById("ms-difficulty").textContent = m.difficulty || "Orta";
            document.getElementById("ms-desc").textContent = m.desc || "Açıklama yok.";

            // Kim ekledi
            const addedByContainer = document.getElementById("ms-addedby-container");
            const addedByBtn = document.getElementById("ms-addedby-btn");
            if (m.addedBy && addedByContainer && addedByBtn) {
                addedByContainer.classList.remove("hidden");
                addedByBtn.textContent = "@" + m.addedBy;
                addedByBtn.onclick = () => { closeMarkerSheet(); showOtherProfile(m.addedBy); };
            } else if (addedByContainer) {
                addedByContainer.classList.add("hidden");
            }
            
            if (m.extra_note && m.extra_note.trim() !== "") {
                document.getElementById("ms-extranote-container").classList.remove("hidden");
                document.getElementById("ms-extranote").textContent = m.extra_note;
            } else {
                document.getElementById("ms-extranote-container").classList.add("hidden");
            }
            
            const imgContainer = document.getElementById("ms-image-container");
            if(m.image) {
                imgContainer.innerHTML = `<img src="${m.image}" onclick="openFullscreen(['${m.image}'],0)" class="w-full h-48 object-cover rounded-xl border border-zinc-800  cursor-pointer hover:opacity-90 transition-opacity">`;
            } else {
                imgContainer.innerHTML = "";
            }
            
            let likesCount = m.likes ? m.likes.length : 0; 
            let dislikesCount = m.dislikes ? m.dislikes.length : 0;
            let isLiked = m.likes && m.likes.includes(currentUser.username);
            let isDisliked = m.dislikes && m.dislikes.includes(currentUser.username);
            
            document.getElementById("ms-likes-count").textContent = likesCount;
            document.getElementById("ms-dislikes-count").textContent = dislikesCount;
            
            const likeBtn = document.getElementById("ms-btn-like");
            const dislikeBtn = document.getElementById("ms-btn-dislike");
            
            if(isLiked) likeBtn.classList.add("bg-red-950/40", "border-sky-900/50"); else likeBtn.classList.remove("bg-red-950/40", "border-sky-900/50");
            if(isDisliked) dislikeBtn.classList.add("bg-zinc-800"); else dislikeBtn.classList.remove("bg-zinc-800");

            document.getElementById("ms-btn-directions").href = `https://maps.google.com/?q=${m.lat},${m.lng}`;
            updateMarkerRating(m);
            const dangerBanner = document.getElementById('ms-danger-banner');
            if(dangerBanner) {
                const dr = m.danger_reports || [];
                if(m.is_dangerous && dr.length > 0) { dangerBanner.classList.remove('hidden'); dangerBanner.innerHTML = '⚠️ ' + dr[dr.length-1].reason; }
                else { dangerBanner.classList.add('hidden'); }
            }

            const adminControls = document.getElementById("ms-admin-controls");
            if (currentUser && (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin' || m.addedBy === currentUser.username)) {
                adminControls.classList.remove("hidden");
                document.getElementById("ms-btn-edit").onclick = () => editMarker(m.id);
                document.getElementById("ms-btn-delete").onclick = () => deleteMarker(m.id);
            } else {
                adminControls.classList.add("hidden");
            }
        }
        
        function closeMarkerSheet() {
            document.getElementById("marker-sheet").classList.add("hidden");
            currentMarkerId = null;
        }

        async function toggleMarkerInteraction(type) {
            if(!currentMarkerId) return;
            const m = db.markers.find(x => x.id === currentMarkerId);
            if(m) {
                if(!m.likes) m.likes = [];
                if(!m.dislikes) m.dislikes = [];
                
                if(type === 'like') {
                    if(m.likes.includes(currentUser.username)) m.likes = m.likes.filter(u => u !== currentUser.username);
                    else { m.likes.push(currentUser.username); m.dislikes = m.dislikes.filter(u => u !== currentUser.username); }
                } else {
                    if(m.dislikes.includes(currentUser.username)) m.dislikes = m.dislikes.filter(u => u !== currentUser.username);
                    else { m.dislikes.push(currentUser.username); m.likes = m.likes.filter(u => u !== currentUser.username); }
                }
                showMarkerSheet(m, true);
            }
            
            if(type === 'like') await sendAction('like_marker', {id: currentMarkerId});
            else await sendAction('dislike_marker', {id: currentMarkerId});
        }

        function openAddEventModal() { 
            if(!tempLat) { 
                alert("Lütfen önce harita üzerinden bir noktaya dokunarak yer seçin!"); 
                toggleAddEventMode(); 
                return; 
            } 
            document.getElementById("add-event-modal").classList.remove("hidden"); 
        }

        function syncMap() {
            // Her seferinde eski cluster'i tamamen yok et ve yenisini oluştur
            if (markerCluster) {
                try { map.removeLayer(markerCluster); } catch(e) {}
                markerCluster.clearLayers();
            }
            markerLayers = [];
            
            markerCluster = L.markerClusterGroup({
                disableClusteringAtZoom: 16,
                maxClusterRadius: 35,
                spiderfyOnMaxZoom: true,
                showCoverageOnHover: false,
                zoomToBoundsOnClick: true,
                animateAddingMarkers: false,
                chunkedLoading: true,
                iconCreateFunction: function(cluster) {
                    var count = cluster.getChildCount();
                    var size = count < 10 ? 38 : count < 50 ? 46 : 54;
                    return L.divIcon({
                        html: '<div style="width:' + size + 'px;height:' + size + 'px;position:relative;display:flex;align-items:center;justify-content:center;"><div style="width:' + (size-8) + 'px;height:' + (size-8) + 'px;border-radius:50%;background:linear-gradient(135deg,#dc2626,#7f1d1d);color:white;font-weight:bold;display:flex;align-items:center;justify-content:center;border:2px solid white;box-shadow:0 0 16px rgba(220,38,38,0.7);font-size:13px;">' + count + '</div></div>',
                        className: '',
                        iconSize: L.point(size, size)
                    });
                }
            });
            
            // Kategori emoji ve renk haritası
            var catEmoji = {'Rampa':'🏔️','Bisikletçi':'🔧','Market':'🛒','Trail':'🗺️','Drop':'⬇️','Dirt Jump':'⚡','Tamir Noktası':'🔨','Su Kaynağı':'💧','Toplanma Noktası':'🤝','Tehlikeli Bölge':'⚠️','Downhill':'🚵','Freeride':'🤟','Transfer':'🪜','Step-Up':'⬆️','Step-Down':'📉','Gap':'🌉','Tabletop':'🏗️','Double':'✌️','Triple':'3️⃣','Hip Jump':'🔀','Bunny':'🐇','Rock Garden':'🪨','Root Section':'🌿','Chute':'🎿','Slab':'🗿','Wallride':'🧱','Skinny':'🪵','Shark Fin':'🦈','Berm':'🌀','Switchback':'🔁','Roller':'🎢'};
            var catColor1 = {'Rampa':'#0ea5e9','Bisikletçi':'#f97316','Market':'#22c55e','Trail':'#10b981','Drop':'#a855f7','Dirt Jump':'#eab308','Tamir Noktası':'#3b82f6','Su Kaynağı':'#06b6d4','Toplanma Noktası':'#ec4899','Tehlikeli Bölge':'#ef4444','Downhill':'#ef4444','Freeride':'#f97316','Transfer':'#818cf8','Step-Up':'#84cc16','Step-Down':'#ec4899','Gap':'#f59e0b','Tabletop':'#14b8a6','Double':'#8b5cf6','Triple':'#f43f5e','Hip Jump':'#f59e0b','Bunny':'#22c55e','Rock Garden':'#a8a29e','Root Section':'#84cc16','Chute':'#22d3ee','Slab':'#94a3b8','Wallride':'#d946ef','Skinny':'#a3a3a3','Shark Fin':'#3b82f6','Berm':'#f97316','Switchback':'#14b8a6','Roller':'#22c55e'};
            var catColor2 = {'Rampa':'#0369a1','Bisikletçi':'#c2410c','Market':'#15803d','Trail':'#047857','Drop':'#7e22ce','Dirt Jump':'#a16207','Tamir Noktası':'#1d4ed8','Su Kaynağı':'#0e7490','Toplanma Noktası':'#be185d','Tehlikeli Bölge':'#b91c1c','Downhill':'#b91c1c','Freeride':'#c2410c','Transfer':'#4338ca','Step-Up':'#4d7c0f','Step-Down':'#be185d','Gap':'#b45309','Tabletop':'#0f766e','Double':'#6d28d9','Triple':'#be123c','Hip Jump':'#b45309','Bunny':'#15803d','Rock Garden':'#78716c','Root Section':'#4d7c0f','Chute':'#0e7490','Slab':'#475569','Wallride':'#a21caf','Skinny':'#737373','Shark Fin':'#1d4ed8','Berm':'#c2410c','Switchback':'#0f766e','Roller':'#15803d'};

            db.markers.forEach(function(m) {
                if (!m.lat || !m.lng) return;
                var cat = m.category || m.icon_type || 'Rampa';
                if (activeMarkerFilter !== 'Tümü' && activeMarkerFilter !== cat) return;
                var emoji = catEmoji[cat] || '📍';
                var c1 = catColor1[cat] || '#0ea5e9';
                var c2 = catColor2[cat] || '#0369a1';
                var shortName = cat.length > 9 ? cat.substring(0,8)+'..' : cat;
                // Küçük Yuvarlak İkon Pin (Sadece Emoji)
                var iconHtml =
                    '<div style="display:flex;flex-direction:column;align-items:center;cursor:pointer;transform:translateZ(0);">' +
                      '<div style="width:26px;height:26px;border-radius:50%;background:linear-gradient(145deg,' + c1 + 'EE,' + c2 + 'DD);border:1.5px solid ' + c1 + ';box-shadow:0 0 8px ' + c1 + '99,0 4px 10px rgba(0,0,0,0.6),inset 0 1px 0 rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);">' +
                        '<span style="font-size:13px;line-height:1;filter:drop-shadow(0 1px 2px rgba(0,0,0,0.8));">' + emoji + '</span>' +
                      '</div>' +
                      '<div style="width:2px;height:5px;background:linear-gradient(' + c1 + ',' + c2 + ');border-radius:0 0 2px 2px;"></div>' +
                      '<div style="width:4px;height:4px;border-radius:50%;background:' + c1 + ';box-shadow:0 0 6px ' + c1 + ';"></div>' +
                    '</div>';
                var icon = L.divIcon({ html: iconHtml, className: '', iconSize: [26,35], iconAnchor: [13,35] });
                var mk = L.marker([m.lat, m.lng], {icon: icon});
                (function(marker) { mk.on('click', function() { showMarkerSheet(marker); }); })(m);
                markerLayers.push(mk);
            });

            db.events.forEach(function(e) {
                if (!e.lat || !e.lng) return;
                var c1 = '#8b5cf6', c2 = '#4c1d95'; // Aggressive purple for events
                var iconHtml =
                    '<div style="width:24px;height:30px;display:flex;flex-direction:column;align-items:center;cursor:pointer;filter:drop-shadow(0px 3px 4px rgba(0,0,0,0.5));transform:translateZ(0);">' +
                      '<div style="width:22px;height:22px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:linear-gradient(135deg,' + c1 + ',' + c2 + ');border:1.5px solid #09090b;box-shadow:inset 0 1px 3px rgba(255,255,255,0.4);display:flex;align-items:center;justify-content:center;">' +
                        '<div style="transform:rotate(45deg);font-size:10px;line-height:1;text-shadow:0 1px 2px rgba(0,0,0,0.7);">📅</div>' +
                      '</div>' +
                    '</div>';
                var icon = L.divIcon({ html: iconHtml, className: '', iconSize: [24,30], iconAnchor: [12,28] });
                var mk = L.marker([e.lat, e.lng], {icon: icon});
                (function(ev) { mk.on('click', function() { showEventSheet(ev); }); })(e);
                markerLayers.push(mk);
            });

            var now = Date.now();
            db.users.forEach(function(u) {
                if (u.stats && u.stats.riding_until > now && u.stats.riding_lat && u.stats.riding_lng) {
                    var isMe = u.username === currentUser.username;
                    var avatar = u.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
                    var premTier = getUserPremiumTier(u.username);
                    var borderColor = isMe ? '#4ade80' : '#d4d4d8';
                    var crownHtml = '';
                    if (premTier === 3) { borderColor = '#facc15'; crownHtml = '<div style="position:absolute;top:-10px;font-size:12px;">👑</div>'; }
                    var iconHtml = '<div style="position:relative;width:48px;height:48px;display:flex;align-items:center;justify-content:center;cursor:pointer;transform:translateZ(0);">' + crownHtml + '<img src="' + avatar + '" style="width:40px;height:40px;border-radius:50%;border:2px solid ' + borderColor + ';object-fit:cover;box-shadow:0 2px 4px rgba(0,0,0,0.4);"></div>';
                    var icon = L.divIcon({ html: iconHtml, className: '', iconSize: [48,48], iconAnchor: [24,24] });
                    var mk = L.marker([u.stats.riding_lat, u.stats.riding_lng], {icon: icon});
                    (function(uname) { mk.on('click', function() { showOtherProfile(uname); }); })(u.username);
                    markerLayers.push(mk);
                }
            });

            markerCluster.addLayers(markerLayers);
            map.addLayer(markerCluster);
        }
        
        let myLocationMarker = null;
        let locationInterval = null;

        function fetchLocationAndUpdateMarker(shouldZoom) {
            if(navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(pos => {
                    userLat = pos.coords.latitude;
                    userLng = pos.coords.longitude;
                    
                    if(map) {
                        if(shouldZoom) {
                            setTimeout(() => {
                                map.invalidateSize();
                                map.setView([userLat, userLng], 15);
                            }, 500); // Tab animasyonunun bitmesini bekle ki Leaflet ignore etmesin
                        } else {
                            setTimeout(() => { map.invalidateSize(); }, 100);
                        }
                        updateLocationMarker(userLat, userLng);
                    }
                }, err => {
                    console.log("Konum alınamadı: ", err);
                    // Düşük hassasiyetle tekrar dene
                    if(shouldZoom) {
                        navigator.geolocation.getCurrentPosition(pos2 => {
                            userLat = pos2.coords.latitude; userLng = pos2.coords.longitude;
                            if(map) {
                                setTimeout(() => {
                                    map.invalidateSize();
                                    map.setView([userLat, userLng], 15);
                                }, 500);
                            }
                            updateLocationMarker(userLat, userLng);
                        }, e => {}, { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 });
                    }
                }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 });
            }
        }

        function autoZoomToUserLocation() { 
            // Eğer sayfa yüklenirken önceden konum çekildiyse — anında kullan
            if(window._prefetchedLat && window._prefetchedLng) {
                userLat = window._prefetchedLat;
                userLng = window._prefetchedLng;
                if(map) {
                    setTimeout(() => {
                        map.invalidateSize();
                        map.setView([userLat, userLng], 15);
                    }, 300);
                    updateLocationMarker(userLat, userLng);
                }
                // Prefetch'i sil ki bir sonraki butona basışta tekrar GPS'ten çeksin
                window._prefetchedLat = null;
                window._prefetchedLng = null;
            } else {
                // Prefetch yoksa normal GPS'ten çek
                fetchLocationAndUpdateMarker(true);
            }
            
            // Her 3 dakikada bir arka planda konumu güncelle (harita kaymaz)
            if(!locationInterval) {
                locationInterval = setInterval(() => {
                    fetchLocationAndUpdateMarker(false);
                }, 180000);
            }
        }

        function updateLocationMarker(lat, lng) {
            if(!map) return;
            if(myLocationMarker) {
                myLocationMarker.setLatLng([lat, lng]);
            } else {
                const blueDotIcon = L.divIcon({
                    html: `<div class="relative flex items-center justify-center w-6 h-6">
                            <div class="absolute inset-0 bg-blue-500 rounded-full opacity-50 animate-ping" style="animation-duration: 2s;"></div>
                            <div class="relative w-4 h-4 bg-blue-500 rounded-full border-2 border-white "></div>
                           </div>`,
                    className: '',
                    iconSize: [24, 24],
                    iconAnchor: [12, 12]
                });
                myLocationMarker = L.marker([lat, lng], {icon: blueDotIcon, zIndexOffset: 1000}).addTo(map);
            }
        }
        
        function showNearbyRoutes() { 
            if(!userLat || !userLng) return alert("Mevcut konumunuz henüz bulunamadı! Lütfen haritadaki GPS (🎯) butonuna tıklayıp konum izni verin.");
            
            const c = document.getElementById("nr-list");
            c.innerHTML = "";
            
            let withDist = db.markers.map(m => {
                let dLat = m.lat - userLat;
                let dLng = m.lng - userLng;
                let dist = Math.sqrt(dLat*dLat + dLng*dLng) * 111;
                return {...m, distance: dist};
            }).sort((a,b) => a.distance - b.distance);
            
            if(withDist.length === 0) {
                c.innerHTML = "<p class='text-zinc-500 text-xs italic text-center mt-5 font-medium'>Çevrenizde kayıtlı rampa veya rota bulunamadı.</p>";
            } else {
                withDist.slice(0, 10).forEach(m => {
                    let img = m.image ? `<img src="${m.image}" class="w-16 h-16 rounded-xl object-cover shrink-0 border border-zinc-700 ">` : `<div class="w-16 h-16 rounded-xl bg-black/60 border border-zinc-700  flex items-center justify-center text-2xl shrink-0">${m.icon_type || '🚴'}</div>`;
                    c.innerHTML += `
                    <div class="bg-black/50 p-3 rounded-2xl border border-zinc-800 flex items-center gap-3 mb-3 cursor-pointer hover:bg-zinc-800 hover:border-zinc-600 transition-colors  group" onclick="map.setView([${m.lat}, ${m.lng}], 16); document.getElementById('nearby-routes-modal').classList.add('hidden');">
                        ${img}
                        <div class="overflow-hidden flex-1">
                            <div class="text-white font-bold text-sm tracking-wide truncate group-hover:text-blue-300 transition-colors">${m.title || m.name || 'İsimsiz Nokta'}</div>
                            <div class="text-sky-400 text-[10px] font-black uppercase tracking-widest mt-1">${m.distance.toFixed(1)} KM UZAKLIKTA</div>
                            <div class="text-zinc-500 text-[10px] font-bold uppercase tracking-widest mt-0.5">Seviye: ${m.difficulty || 'Belirtilmemiş'}</div>
                        </div>
                        <div class="text-zinc-400 bg-zinc-900 border border-zinc-700 w-8 h-8 rounded-full flex items-center justify-center shrink-0 group-hover:bg-zinc-700 group-hover:text-white transition-colors">➜</div>
                    </div>`;
                });
            }
            
            document.getElementById("nearby-routes-modal").classList.remove("hidden"); 
        }
        
        async function saveNewMarker() { 
            const n = document.getElementById("new-marker-name").value;
            const d = document.getElementById("new-marker-desc").value; 
            const diff = document.getElementById("new-marker-difficulty").value; 
            const eNote = document.getElementById("new-marker-extranote").value;
            const photoFile = document.getElementById("new-marker-photo").files[0]; 
            
            if(!n) {
                showToast("📍 Başlık zorunludur!");
                return;
            }
            
            closeMarkerModal(); 
            
            let base64Photo = null; 
            if(photoFile) {
                base64Photo = await resizeImage(photoFile, 500); 
            }
            
            let targetId = editingMarkerId ? editingMarkerId : Date.now().toString();
            let targetLat = editingMarkerId ? editingMarkerLat : tempLat;
            let targetLng = editingMarkerId ? editingMarkerLng : tempLng;
            
            let finalImage = base64Photo;
            if(editingMarkerId && !base64Photo) {
                const existingMarker = db.markers.find(m => m.id === editingMarkerId);
                if(existingMarker) finalImage = existingMarker.image;
            }
            
            try { 
                const newMarkerData = { 
                    id: targetId, 
                    lat: targetLat, 
                    lng: targetLng, 
                    name: n, 
                    difficulty: diff, 
                    desc: d, 
                    extra_note: eNote,
                    category: selectedMarkerCategory,
                    icon_type: selectedMarkerCategory,
                    image: finalImage 
                };
                
                const res = await sendAction('add_marker', newMarkerData); 
                
                if (res && res.status === 'ok') {
                    showToast("✅ " + (editingMarkerId ? "Nokta güncellendi!" : "Nokta eklendi!"));
                    
                    // Frontend listesini anında güncelle (önbelleğe takılmamak için)
                    newMarkerData.addedBy = currentUser.username;
                    if(!newMarkerData.likes) newMarkerData.likes = [];
                    if(!newMarkerData.dislikes) newMarkerData.dislikes = [];
                    
                    if (editingMarkerId) {
                        const idx = db.markers.findIndex(m => m.id === editingMarkerId);
                        if (idx !== -1) db.markers[idx] = { ...db.markers[idx], ...newMarkerData };
                    } else {
                        db.markers.push(newMarkerData);
                    }
                    
                    syncMap();
                } else {
                    showToast(res?.message || "❌ Hata oluştu");
                }
                
                editingMarkerId = null;
                tempLat = null;
                tempLng = null;
                document.getElementById("new-marker-name").value = "";
                document.getElementById("new-marker-desc").value = "";
                document.getElementById("new-marker-extranote").value = "";
                document.getElementById("new-marker-photo").value = "";
                document.getElementById("modal-marker-title").textContent = "📍 NOKTA EKLE";
                document.getElementById("modal-marker-category-label").textContent = "";
            } catch(e) {
                console.error(e);
                showToast("❌ Ağ hatası.");
            }
        }

        
        async function saveEvent() { 
            const t = document.getElementById("ev-title").value; 
            const d = document.getElementById("ev-date").value; 
            const tm = document.getElementById("ev-time").value; 
            
            if(!t || !d || !tm) return alert("Tüm alanları doldurunuz!");
            
            const newEventData = { 
                id: Date.now().toString(), 
                lat: tempLat, 
                lng: tempLng, 
                title: t, 
                datetime: `${d} ${tm}`, 
                max: document.getElementById("ev-max").value, 
                desc: document.getElementById("ev-desc").value 
            };
            
            await sendAction('add_event', newEventData); 
            
            // Frontend listesini anında güncelle
            newEventData.creator = currentUser.username;
            newEventData.attendees = [currentUser.username];
            db.events.push(newEventData);
            
            syncMap();
            document.getElementById("add-event-modal").classList.add("hidden");
            showToast("✅ Buluşma eklendi!");
        }
        
        function showEventSheet(e) { 
            currentEventId = e.id; 
            document.getElementById("event-sheet").classList.remove("hidden"); 
            document.getElementById("es-title").textContent = e.title; 
            document.getElementById("es-time").textContent = e.datetime; 
            document.getElementById("es-desc").textContent = e.desc || "Açıklama yok."; 
            
            const att = e.attendees || []; 
            
            const attContainer = document.getElementById("es-attendees");
            attContainer.innerHTML = "";
            if (att.length === 0) {
                attContainer.innerHTML = "<span class='text-zinc-500 text-xs italic font-medium'>Henüz katılan yok. İlk sen ol!</span>";
            } else {
                att.forEach(u => {
                    let isMe = u === currentUser.username;
                    attContainer.innerHTML += `<span class="bg-black/60 text-[10px] px-3 py-1.5 rounded-xl border ${isMe ? 'border-green-500 text-green-400 font-bold ' : 'border-zinc-700 text-zinc-300'}  tracking-widest uppercase">${u}</span>`;
                });
            }

            const btn = document.getElementById("btn-join"); 
            btn.disabled = false;
            
            let maxCapacity = e.max ? parseInt(e.max) : 0;

            if(att.includes(currentUser.username)) {
                btn.textContent = "AYRIL"; 
                btn.className = "w-full bg-red-950/80 hover:bg-sky-900/80 btn-premium-hover transition text-sky-400 border border-sky-900/50 py-4 rounded-xl font-bold text-sm  mb-2";
            } else {
                if (maxCapacity > 0 && att.length >= maxCapacity) {
                    btn.textContent = `KAPASİTE DOLU (${att.length}/${maxCapacity})`;
                    btn.className = "w-full bg-black/50 text-zinc-500 py-4 rounded-xl font-bold text-sm cursor-not-allowed mb-2 border border-zinc-700 ";
                    btn.disabled = true;
                } else {
                    let limitText = maxCapacity > 0 ? `KATIL (${att.length}/${maxCapacity} Kişi)` : `KATIL (${att.length} Kişi)`;
                    btn.textContent = limitText;
                    btn.className = "w-full bg-green-700 hover:bg-green-600 transition text-white py-4 rounded-xl font-bold text-sm  mb-2 btn-premium-hover";
                }
            }
            
            document.getElementById("btn-directions").href = `https://maps.google.com/?q=${e.lat},${e.lng}`;

            if(e.creator === currentUser.username || currentUser.role === 'Admin') {
                document.getElementById("btn-del-event").classList.remove("hidden");
            } else {
                document.getElementById("btn-del-event").classList.add("hidden");
            }
        }
        
        async function toggleJoinEvent() { 
            const ev = db.events.find(x => x.id == currentEventId); 
            if(!ev) return; 
            
            const att = ev.attendees || []; 
            document.getElementById("btn-join").disabled = true;

            if(att.includes(currentUser.username)) {
                await sendAction('leave_event', {id: ev.id}); 
            } else {
                let maxCapacity = ev.max ? parseInt(ev.max) : 0;
                if (maxCapacity > 0 && att.length >= maxCapacity) {
                    alert("Bu etkinliğin kapasitesi maalesef dolmuş!");
                    document.getElementById("btn-join").disabled = false;
                    return;
                }
                
                try {
                    await sendAction('join_event', {id: ev.id}); 
                } catch(e) {}
            }
            
            document.getElementById("event-sheet").classList.add("hidden");
        }

        async function deleteEvent() {
            if(confirm("Bu etkinliği silmek istediğinize emin misiniz?")) {
                await sendAction('delete_event', {id: currentEventId});
                db.events = db.events.filter(e => e.id !== currentEventId);
                document.getElementById("event-sheet").classList.add("hidden");
            }
        }

        // Bildirim badge fonksiyonları
        let chatBadgeCount = 0;
        function showChatBadge() {
            chatBadgeCount++;
            // Sidebar tab butonu
            const btn = document.getElementById('tab-btn-1');
            if(btn) {
                let badge = btn.querySelector('.notif-badge');
                if(!badge) {
                    badge = document.createElement('span');
                    badge.className = 'notif-badge absolute -top-1 -right-1 bg-red-600 text-white text-[9px] font-black rounded-full w-5 h-5 flex items-center justify-center  border border-sky-400';
                    btn.style.position = 'relative';
                    btn.appendChild(badge);
                }
                badge.textContent = chatBadgeCount > 9 ? '9+' : chatBadgeCount;
                badge.style.animation = 'none';
                badge.offsetHeight;
                badge.style.animation = 'notifBounce 0.4s ease';
            }
            // Alt nav chat butonu
            const bnavBtn = document.getElementById('bnav-1');
            if(bnavBtn) {
                let badge2 = bnavBtn.querySelector('.notif-badge');
                if(!badge2) {
                    badge2 = document.createElement('span');
                    badge2.className = 'notif-badge absolute -top-0.5 -right-0.5 bg-red-600 text-white text-[9px] font-black rounded-full w-4 h-4 flex items-center justify-center  border border-sky-400';
                    bnavBtn.style.position = 'relative';
                    bnavBtn.appendChild(badge2);
                }
                badge2.textContent = chatBadgeCount > 9 ? '9+' : chatBadgeCount;
                badge2.style.animation = 'none';
                badge2.offsetHeight;
                badge2.style.animation = 'notifBounce 0.4s ease';
            }
        }
        function clearChatBadge() {
            chatBadgeCount = 0;
            ['tab-btn-1', 'bnav-1'].forEach(id => {
                const btn = document.getElementById(id);
                if(!btn) return;
                const badge = btn.querySelector('.notif-badge');
                if(badge) badge.remove();
            });
        }

        function switchChatTab(type) {
            if(type === 'group') { 
                document.getElementById("chat-group-area").classList.remove("hidden"); 
                document.getElementById("chat-dm-list-area").classList.add("hidden"); 
                document.getElementById("chat-dm-thread-area").classList.add("hidden"); 
                
                document.getElementById("chat-tab-group").className = "flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition "; 
                document.getElementById("chat-tab-dm").className = "flex-1 py-2 bg-transparent text-zinc-500 hover:text-white rounded font-bold text-xs transition"; 
                
                renderChat(true); 
            } else { 
                document.getElementById("chat-group-area").classList.add("hidden"); 
                document.getElementById("chat-dm-list-area").classList.remove("hidden"); 
                document.getElementById("chat-dm-thread-area").classList.add("hidden"); 
                
                document.getElementById("chat-tab-dm").className = "flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition "; 
                document.getElementById("chat-tab-group").className = "flex-1 py-2 bg-transparent text-zinc-500 hover:text-white rounded font-bold text-xs transition"; 
                
                renderDmList(); 
            }
        }

        let _renderedMsgIds = new Set();

        function buildMsgHTML(msg) {

                const isMe = msg.user === currentUser.username; 
                const isAI = msg.user === 'Freerider AI' || msg.user === 'Moderatör AI';
                
                const premColor = getUserPremiumColor(msg.user); 
                const premTier = getUserPremiumTier(msg.user); 
                
                const textCls = (premTier > 0) ? getPremiumTextClass(premColor) : '';
                const inlineStyle = (premTier > 0) ? getPremiumInlineStyle(premColor) : '';
                const borderCls = (premTier > 0 && !isAI) ? getPremiumBorderClass(msg.user) : 'border-zinc-700';
                
                const userInDb = db.users.find(u => u.username === msg.user);
                const isAdmin = msg.user === 'Admin' || msg.user.toLowerCase() === 'admin' || (userInDb && userInDb.role === 'Admin');
                const isSubAdmin = userInDb && userInDb.role === 'SubAdmin';
                const adminDel = (currentUser.role === 'Admin' || currentUser.role === 'SubAdmin' || isMe) ? `<button onclick="delMsg('${msg.id}')" class="text-[10px] bg-red-950/80 text-sky-300 px-2 py-1 rounded-lg ml-2 hover:bg-red-900 transition border border-sky-900/50 uppercase font-bold tracking-widest relative z-50 pointer-events-auto">SİL</button>` : '';
                const _encId = btoa(encodeURIComponent(msg.id)); const _encUser = btoa(encodeURIComponent(msg.user)); const _encText = btoa(encodeURIComponent((msg.text||'').substring(0,80)));
                const reportBtn = (!isMe && !isAI) ? `<button onclick="openReportMsgModal('${_encId}','${_encUser}','${_encText}')" class="text-[10px] bg-orange-950/60 text-orange-400 px-2 py-1 rounded-lg ml-1 hover:bg-orange-900/60 transition border border-orange-900/50 uppercase font-bold tracking-widest relative z-50 pointer-events-auto">🚨</button>` : '';
                
                const pinBtn = (isMe && getUserPremiumTier(currentUser.username) === 3 && msg.type === "text") ? `<button onclick="pinMsg('${msg.id}')" class="text-[10px] bg-yellow-900/50 text-yellow-500 px-2 py-1 rounded-lg ml-2 hover:bg-yellow-900 transition border border-yellow-700/50 uppercase font-bold tracking-widest relative z-50 pointer-events-auto">SABİTLE</button>` : '';

                // Flag göstergesi (DB'den gelen is_flagged + flag_count)
                const flagBadge = msg.is_flagged ? `<span class="text-[9px] bg-red-950/60 text-red-400 px-2 py-0.5 rounded-lg ml-1 border border-red-900/50 uppercase font-bold tracking-widest animate-pulse">🚩 ${msg.flag_count || 1}x</span>` : '';

                let tick = (premTier === 3) ? verifiedTick : ''; 
                let adminTag = isAdmin ? `<span class="ml-2 bg-red-600 text-white px-2 py-0.5 rounded text-[9px] tracking-widest uppercase ">👑 Yönetici</span>` : (isSubAdmin ? `<span class="ml-2 bg-orange-800 text-orange-200 px-2 py-0.5 rounded text-[9px] uppercase font-bold tracking-widest">🛡️ Yrd. Admin</span>` : '');
                let aiTag = isAI ? `<span class="ml-2 bg-cyan-500/20 border border-cyan-500/50 text-cyan-400 px-2 py-0.5 rounded-lg text-[9px] font-black tracking-widest uppercase  animate-pulse">🤖 YAPAY ZEKA</span>` : '';
                
                let msgDate = new Date(parseInt(msg.id));
                let timeStr = !isNaN(msgDate.getTime()) ? msgDate.getHours().toString().padStart(2, '0') + ":" + msgDate.getMinutes().toString().padStart(2, '0') : "";
                let timeHtml = `<span class="text-[9px] text-zinc-500 ml-2 font-bold tracking-widest bg-black/50 border border-zinc-800 px-1.5 py-0.5 rounded">${timeStr}</span>`;

                let avatarUrl = isAI ? 'https://cdn-icons-png.flaticon.com/512/4712/4712035.png' : (db.users.find(u => u.username === msg.user)?.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg');
                let avatarHtml = `<img src="${avatarUrl}" class="w-8 h-8 rounded-full object-cover border shrink-0 ${isMe ? 'ml-2' : 'mr-2'} cursor-pointer hover:scale-110 transition-transform ${borderCls}" onclick="${isAI ? '' : `showOtherProfile('${msg.user}')`}">`;

                let content = ""; 
                let bubbleClass = isMe ? 'bg-white text-black' : 'bg-black/60 border border-zinc-800 text-zinc-300';
                
                if (isAI) {
                    // AI moderatör uyarı mesajları — özel kırmızı gradient stil
                    const isModMsg = (msg.id && msg.id.endsWith('_mod')) || msg.user === 'Moderatör AI';
                    if (isModMsg) {
                        content = `<div class="ai-moderator-msg px-4 py-3 rounded-2xl text-sm break-words mt-1 font-bold leading-relaxed relative overflow-hidden"><span class="relative z-10">🛡️ ${escapeHtml(msg.text)}</span></div>`;
                    } else {
                        content = `<div class="bg-black/80 border border-cyan-500/50 text-cyan-100 px-4 py-3 rounded-2xl text-sm break-words mt-1  font-medium leading-relaxed relative overflow-hidden"><div class="absolute inset-0 bg-cyan-500/10 animate-pulse"></div><span class="relative z-10">${escapeHtml(msg.text)}</span></div>`;
                    }
                } else if (premTier >= 2) {
                    bubbleClass = isMe ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white ' : 'bg-gradient-to-r from-zinc-900 to-purple-950/40 border border-purple-500/50 text-white ';
                }
                
                if(!isAI) {
                    if (msg.type === "photo") {
                        content = `<img src="${msg.photo}" class="w-48 rounded-xl border border-zinc-700  mt-1 cursor-pointer hover:opacity-90 transition">`;
                    } else if (msg.type === "voice") {
                        content = `<div onclick="playVoice('${msg.audio}')" class="${bubbleClass} px-5 py-3 rounded-xl flex items-center gap-3 cursor-pointer mt-1  hover:scale-105 transition"><span class="text-xl">🎙️</span><span class="font-bold text-xs uppercase tracking-widest">Ses Kaydı</span></div>`;
                    } else {
                        content = `<div class="${bubbleClass} px-4 py-2.5 rounded-2xl text-sm break-words mt-1  font-medium leading-relaxed">${escapeHtml(msg.text)}</div>`;
                    }
                }
                
                let userDisplay = isAI ? `<span class="${msg.user === 'Moderatör AI' ? 'text-red-400' : 'text-cyan-400'} font-black tracking-widest ">${msg.user === 'Moderatör AI' ? '🛡️ Moderatör AI' : 'SİSTEM AI'}</span>` : `<span onclick="showOtherProfile('${msg.user}')" style="${inlineStyle}" class="cursor-pointer hover:text-white transition ${textCls ? textCls : 'text-zinc-400'}">${msg.user}</span>`;
                
                // Build reaction bar
                const reactions = msg.reactions || {};
                let reactBar = '<div class="flex flex-wrap gap-1 mt-1">';
                const emojiList = ['👍','🔥','😂','😮','❤️','💪'];
                emojiList.forEach(em => {
                    const users = reactions[em] || [];
                    const iReacted = users.includes(currentUser.username);
                    if(users.length > 0 || true) {
                        reactBar += `<button onclick="addReaction('${msg.id}','${em}')" class="flex items-center gap-0.5 text-xs px-2 py-0.5 rounded-full border transition-all ${iReacted ? 'bg-red-900/40 border-sky-600/60 text-white' : 'bg-black/30 border-zinc-700/50 text-zinc-500 hover:border-zinc-500'}">${em}${users.length > 0 ? `<span class="text-[10px] font-bold">${users.length}</span>` : ''}</button>`;
                    }
                });
                reactBar += '</div>';

                // İhlal durumuna göre mesaj görünümü
                const flagCount = msg.flag_count || 0;
                const isFlagged = msg.is_flagged && flagCount >= 1 && flagCount < 2;
                const isCollapsed = msg.is_flagged && flagCount >= 2;

                if (isCollapsed) {
                    // flag_count >= 2: tamamen collapse — tıklayınca açılabilir
                    return `
                    <div class="flex ${isMe ? "justify-end" : "justify-start"} items-start mb-4 w-full ${isMe ? 'slide-in-right' : 'slide-in-left'}">
                        ${!isMe ? avatarHtml : ''}
                        <div class="max-w-[80%] flex flex-col ${isMe ? 'items-end' : 'items-start'}">
                            <div class="flex items-center gap-1 text-[10px] uppercase font-bold tracking-widest mb-1">
                                ${userDisplay} ${tick} ${adminTag} ${flagBadge} ${timeHtml} ${adminDel}
                            </div>
                            <div class="msg-collapsed-wrap" onclick="this.querySelector('.msg-collapsed-content').classList.toggle('show')">
                                <div class="msg-collapsed-bar">🚫 Bu mesaj uygunsuz içerik içerdiği için gizlendi <span style='font-size:9px;opacity:0.6'>— görmek için tıkla</span></div>
                                <div class="msg-collapsed-content">${content}</div>
                            </div>
                        </div>
                        ${isMe ? avatarHtml : ''}
                    </div>`;
                }

                if (isFlagged) {
                    // flag_count 1: blur + overlay
                    return `
                    <div class="flex ${isMe ? "justify-end" : "justify-start"} items-start mb-4 w-full ${isMe ? 'slide-in-right' : 'slide-in-left'}" style="position:relative">
                        ${!isMe ? avatarHtml : ''}
                        <div class="max-w-[80%] flex flex-col ${isMe ? 'items-end' : 'items-start'}" style="position:relative">
                            <div class="flex items-center gap-1 text-[10px] uppercase font-bold tracking-widest mb-1">
                                ${userDisplay} ${tick} ${adminTag} ${flagBadge} ${timeHtml} ${adminDel} ${reportBtn}
                            </div>
                            <div class="flex flex-col gap-1 w-full">
                                <div class="msg-flagged-overlay"><span>🛡️ Bu mesaj uygunsuz içerik içerdiği için gizlendi</span></div>
                                <div class="msg-flagged">${content}</div>
                            </div>
                        </div>
                        ${isMe ? avatarHtml : ''}
                    </div>`;
                }

                return `
                <div class="flex ${isMe ? "justify-end" : "justify-start"} items-start mb-4 w-full ${isMe ? 'slide-in-right' : 'slide-in-left'}">
                    ${!isMe ? avatarHtml : ''}
                    <div class="max-w-[80%] flex flex-col ${isMe ? 'items-end' : 'items-start'}">
                        <div class="flex items-center gap-1 text-[10px] uppercase font-bold tracking-widest mb-1">
                            ${userDisplay}
                            ${tick} ${adminTag} ${aiTag} ${flagBadge} ${timeHtml} ${pinBtn} ${adminDel} ${reportBtn}
                        </div>
                        ${content}
                        ${reactBar}
                    </div>
                    ${isMe ? avatarHtml : ''}
                </div>`;
        }

        function renderChat(forceRedraw = false) {
            const container = document.getElementById("chat-messages");
            if(!container) return;
            if(!db.messages) db.messages = [];

            // Pinned mesaj
            const pinArea = document.getElementById("pinned-message-area"); 
            const pinText = document.getElementById("pinned-message-text");
            if(db.pinned_message && db.pinned_message.expires && db.pinned_message.expires > Date.now()) { 
                pinArea.classList.remove("hidden"); 
                pinText.textContent = `${db.pinned_message.user}: ${db.pinned_message.text}`; 
            } else { 
                pinArea.classList.add("hidden"); 
            }

            const wasAtBottom = container.scrollHeight - container.clientHeight <= container.scrollTop + 100;

            // Silinen mesaj var mı kontrol et
            const currentIds = new Set(db.messages.map(m => m.id));
            const hasDeleted = [..._renderedMsgIds].some(id => !currentIds.has(id));

            if (forceRedraw || hasDeleted || window._chatNeedsFullRedraw) {
                // Silme veya zorla yenile - tüm container'ı yeniden çiz
                while(container.firstChild) container.removeChild(container.firstChild);
                _renderedMsgIds.clear();
                window._chatNeedsFullRedraw = false;
            }

            // ── Empty State ──
            if (db.messages.length === 0) {
                const emptyEl = document.getElementById('_chat_empty_state_');
                if (!emptyEl) {
                    container.innerHTML = `
                        <div id="_chat_empty_state_" class="flex flex-col items-center justify-center h-full text-center py-16 fade-in-anim">
                            <div style="font-size:48px;margin-bottom:12px;opacity:0.6">💬</div>
                            <div class="text-zinc-400 text-sm font-bold mb-1">Henüz mesaj yok</div>
                            <div class="text-zinc-600 text-xs">İlk mesajı sen yaz! 🏔️</div>
                        </div>`;
                }
                return;
            }

            // Sadece yeni mesajları DOM'a ekle
            db.messages.forEach(msg => {
                if (!_renderedMsgIds.has(msg.id)) {
                    const div = document.createElement('div');
                    div.innerHTML = buildMsgHTML(msg);
                    const el = div.firstElementChild;
                    if(el) {
                        el.dataset.msgId = msg.id;
                        container.appendChild(el);
                    }
                    _renderedMsgIds.add(msg.id);
                }
            });

            if(wasAtBottom || _renderedMsgIds.size <= db.messages.length) {
                requestAnimationFrame(() => {
                    container.scrollTop = container.scrollHeight;
                });
            }
        }

        async function sendChatMessage() { 
            // localStorage'dan da kontrol et — sayfa yenilenmesine karşı dayanıklı
            const rulesAccepted = currentUser.accepted_chat_rules || localStorage.getItem('fr_chat_rules_' + currentUser.username) === '1';
            if(rulesAccepted) currentUser.accepted_chat_rules = true; // belleği de düzelt
            if(!currentUser.accepted_chat_rules) {
                return document.getElementById("chat-rules-modal").classList.remove("hidden");
            }
            const inp = document.getElementById("chat-input"); 
            if(!inp.value.trim()) return;
            haptic([8]);
            const t = inp.value; 
            inp.value = ""; 
            const id = Date.now().toString(); 

            // ── Optimistic UI: mesajı anında göster ──
            const optimisticMsg = { id, user: currentUser.username, text: t, type: 'text' };
            db.messages.push(optimisticMsg);
            renderChat();

            try {
                const result = await sendAction('add_message', { id: id, text: t, type: "text" }, true);

                if (result && result.warning) {
                    showToast(`⚠️ ${result.warning}`, 'warning', 5000);
                }

                // ── Proaktif AI moderasyon sonucu ──
                if (result && result.ai_flagged) {
                    // Mesajı flagged olarak güncelle
                    const localMsg = db.messages.find(m => m.id === id);
                    if (localMsg) {
                        localMsg.is_flagged = true;
                        localMsg.flag_count = 1;
                    }

                    // AI moderatör uyarı mesajını chat'e ekle
                    if (result.ai_moderation_msg) {
                        db.messages.push(result.ai_moderation_msg);
                    }

                    renderChat(true);

                    if (result.severity === 'high') {
                        showToast('🚫 İçeriğiniz topluluk kurallarını ihlal ediyor! Admin ekibine bildirildi.', 'error', 5000);
                    } else {
                        showToast('⚠️ Mesajınız uygunsuz içerik içeriyor ve işaretlendi.', 'warning', 4000);
                    }
                }
            } catch(err) {
                // Hata durumunda optimistic mesajı geri al
                db.messages = db.messages.filter(m => m.id !== id);
                renderChat(true);
                // err.message backend'den gelen "Çok fazla istek gönderdiniz" uyarısı olabilir
                const errMsg = err.message || 'Mesaj gönderilemedi. Tekrar deneyin.';
                showToast(`❌ ${errMsg}`, 'error');
                return;
            }

            // Daily/weekly mission counters
            if(currentUser.stats) {
                if(!currentUser.stats.daily_missions) currentUser.stats.daily_missions = {};
                if(!currentUser.stats.weekly_missions) currentUser.stats.weekly_missions = {};
                const todayKey = new Date().toISOString().split('T')[0];
                if(currentUser.stats.daily_missions.date !== todayKey) currentUser.stats.daily_missions = { date: todayKey };
                currentUser.stats.daily_missions.daily_msg = (currentUser.stats.daily_missions.daily_msg||0)+1;
                currentUser.stats.weekly_missions.weekly_msg = (currentUser.stats.weekly_missions.weekly_msg||0)+1;
                checkMissions();
            }
        }

        async function askAIGroup() {
            const rulesAccepted = currentUser.accepted_chat_rules || localStorage.getItem('fr_chat_rules_' + currentUser.username) === '1';
            if(rulesAccepted) currentUser.accepted_chat_rules = true;
            if(!currentUser.accepted_chat_rules) {
                return document.getElementById("chat-rules-modal").classList.remove("hidden");
            }
            const inp = document.getElementById("chat-input");
            const t = inp.value.trim();
            if(!t) return alert("Lutfen Freerider AI'a sormak istediginiz soruyu mesaj kutusuna yazin!");
            inp.value = "";
            await sendAction('ask_ai', { text: t });
            // Daily/weekly AI mission counter
            if(currentUser.stats) {
                if(!currentUser.stats.daily_missions) currentUser.stats.daily_missions = {};
                if(!currentUser.stats.weekly_missions) currentUser.stats.weekly_missions = {};
                const todayKey = new Date().toISOString().split('T')[0];
                if(currentUser.stats.daily_missions.date !== todayKey) currentUser.stats.daily_missions = { date: todayKey };
                currentUser.stats.daily_missions.daily_ai = (currentUser.stats.daily_missions.daily_ai||0)+1;
                currentUser.stats.weekly_missions.weekly_ai = (currentUser.stats.weekly_missions.weekly_ai||0)+1;
                checkMissions();
            }
        }

        function renderDmList() {
            const container = document.getElementById("dm-users-list");
            container.innerHTML = "";
            
            let uniqueUsers = new Set();
            db.dms.forEach(m => {
                if (m.participants && m.participants.includes(currentUser.username)) {
                    m.participants.forEach(p => { if (p !== currentUser.username) uniqueUsers.add(p); });
                }
            });

            uniqueUsers.add("Freerider AI");

            if(uniqueUsers.size === 0) {
                container.innerHTML = "<div class='text-zinc-500 text-xs italic text-center mt-5 font-medium'>Henüz kimseyle özel mesajlaşmadın.</div>";
                return;
            }

            let _html = "";

            Array.from(uniqueUsers).forEach(uName => {
                const u = db.users.find(x => x.username === uName);
                const isAI = uName === 'Freerider AI';
                
                let avatar = isAI ? 'https://cdn-icons-png.flaticon.com/512/4712/4712035.png' : (u ? u.avatar : 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg');
                
                let premColor = isAI ? '' : getUserPremiumColor(uName);
                let textCls = (getUserPremiumTier(uName) > 0) ? getPremiumTextClass(premColor) : '';
                let inlineStyle = (getUserPremiumTier(uName) > 0) ? getPremiumInlineStyle(premColor) : '';
                let nameHtml = isAI ? `<span class="text-cyan-400 font-black tracking-widest uppercase text-sm  animate-pulse">🤖 Freerider AI</span>` : `<span style="${inlineStyle}" class="font-bold text-sm tracking-wide ${textCls ? textCls : 'text-white'}">${uName}</span>`;

                const dmOnline = isAI ? '' : getOnlineHTML(u);
                _html += `
                <div onclick="renderDmThread('${uName}')" class="bg-black/50 p-3 rounded-2xl border border-zinc-800 flex items-center gap-3 cursor-pointer hover:bg-zinc-800 hover:border-zinc-600 transition-all duration-200  mb-3 slide-up-anim">
                    <div class="relative">
                        <img src="${avatar}" class="w-12 h-12 rounded-full object-cover border border-zinc-700 ">
                        ${!isAI && getOnlineStatus(u).status === 'online' ? '<span class="online-dot absolute bottom-0 right-0"></span>' : ''}
                    </div>
                    <div class="flex-1 overflow-hidden">
                        ${nameHtml}
                        <div class="flex items-center gap-2 mt-1">
                            ${dmOnline ? `<span class="flex items-center gap-1">${dmOnline}</span>` : `<span class="text-[10px] text-zinc-500 uppercase font-bold tracking-widest truncate">${isAI ? 'Özel Asistanın' : 'Görüntülemek için tıkla'}</span>`}
                        </div>
                    </div>
                    <div class="text-zinc-400 bg-zinc-900 w-8 h-8 rounded-full flex items-center justify-center border border-zinc-700">💬</div>
                </div>`;
            });
            container.innerHTML = _html;
        }

        function startDm(targetUser) {
            document.getElementById("other-profile-modal").classList.add("hidden");
            switchTab(1);
            switchChatTab('dm');
            renderDmThread(targetUser);
        }

        function renderDmThread(targetUser) {
            currentDmUser = targetUser;
            document.getElementById("chat-dm-list-area").classList.add("hidden");
            document.getElementById("chat-dm-thread-area").classList.remove("hidden");
            document.getElementById("dm-thread-name").innerHTML = targetUser === 'Freerider AI' ? '<span class="text-cyan-400  font-black tracking-widest">🤖 Freerider AI</span>' : targetUser;

            const container = document.getElementById("dm-messages");
            const isScrolled = container.scrollHeight - container.clientHeight <= container.scrollTop + 30;
            let _html = "";

            const threadMsgs = db.dms.filter(m => 
                m.participants && m.participants.includes(currentUser.username) && m.participants.includes(targetUser)
            ).sort((a,b) => parseInt(a.id) - parseInt(b.id));

            if(threadMsgs.length === 0) {
                container.innerHTML = `<div class="text-center text-xs text-zinc-500 mt-10 italic font-medium">Buradan sohbet edebilirsiniz. Mesajlar uçtan uca olmasa da izole şifrelenir.</div>`;
                return;
            }

            threadMsgs.forEach(msg => {
                const isMe = msg.sender === currentUser.username;
                const isAI = msg.sender === 'Freerider AI';
                let bubbleClass = isMe ? 'bg-white text-black' : 'bg-black/60 border border-zinc-800 text-zinc-300';
                
                if (isAI) {
                    bubbleClass = 'bg-black border border-cyan-500/50 text-cyan-100  font-medium';
                }

                let content = "";
                if (msg.type === "photo") {
                    content = `<img src="${msg.photo}" onclick="openFullscreen(['${msg.photo}'],0)" class="w-48 rounded-xl border border-zinc-700  mt-1 cursor-pointer hover:opacity-90 transition-opacity">`;
                } else {
                    content = `<div class="${bubbleClass} px-4 py-2.5 rounded-2xl text-sm break-words mt-1  leading-relaxed font-medium">${escapeHtml(msg.text)}</div>`;
                }

                let avatarUrl = isAI ? 'https://cdn-icons-png.flaticon.com/512/4712/4712035.png' : (db.users.find(u => u.username === msg.sender)?.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg');
                let avatarHtml = `<img src="${avatarUrl}" class="w-8 h-8 rounded-full object-cover border border-zinc-700 shrink-0 ${isMe ? 'ml-2' : 'mr-2'}">`;

                const _dmEncId = btoa(encodeURIComponent(msg.id)); const _dmEncSender = btoa(encodeURIComponent(msg.sender)); const _dmEncText = btoa(encodeURIComponent((msg.text||'').substring(0,80)));
                const dmReportBtn = (!isMe && !isAI)
                    ? `<button onclick="openReportMsgModal('${_dmEncId}','${_dmEncSender}','${_dmEncText}')" class="text-[10px] bg-orange-950/60 text-orange-400 px-1.5 py-0.5 rounded-lg ml-1 hover:bg-orange-900/60 transition border border-orange-900/50 uppercase font-bold tracking-widest relative z-50 pointer-events-auto" title="Mesajı Bildir">🚩</button>`
                    : '';

                _html += `
                <div class="flex ${isMe ? "justify-end" : "justify-start"} items-start mb-5 w-full slide-up-anim">
                    ${!isMe ? avatarHtml : ''}
                    <div class="max-w-[80%] flex flex-col ${isMe ? 'items-end' : 'items-start'}">
                        <div class="flex items-center gap-1 text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-1">
                            ${isMe ? 'Sen' : (isAI ? '<span class="text-cyan-400">AI</span>' : msg.sender)}
                            ${dmReportBtn}
                        </div>
                        ${content}
                    </div>
                    ${isMe ? avatarHtml : ''}
                </div>`;
            });
            container.innerHTML = _html;

            if(isScrolled || container.scrollTop === 0) {
                container.scrollTop = container.scrollHeight;
            }
        }

        function closeDmThread() {
            currentDmUser = null;
            document.getElementById("chat-dm-thread-area").classList.add("hidden");
            document.getElementById("chat-dm-list-area").classList.remove("hidden");
        }

        async function sendDmMessage() {
            const inp = document.getElementById("dm-input");
            const t = inp.value.trim();
            if(!t || !currentDmUser) return;
            
            inp.value = "";
            const id = Date.now().toString();
            
            db.dms.push({ id: id, sender: currentUser.username, receiver: currentDmUser, participants: [currentUser.username, currentDmUser], text: t, type: 'text' });
            renderDmThread(currentDmUser);

            await sendAction('send_dm', { id: id, text: t, receiver: currentDmUser, type: "text" });
        }

        function openMarketModal() {
            document.getElementById("mk-title").value = "";
            document.getElementById("mk-price").value = "";
            document.getElementById("mk-contact").value = "";
            document.getElementById("mk-desc").value = "";
            document.getElementById("mk-photos").value = "";
            
            const tier = getUserPremiumTier(currentUser.username);
            let maxP = 1;
            if(tier >= 3) maxP = 10; else if(tier >= 2) maxP = 4; else if(tier >= 1) maxP = 2;
            document.getElementById("mk-photo-label").textContent = `Fotoğraf Ekle (Maksimum ${maxP} Adet)`;
            
            document.getElementById("market-modal").classList.remove("hidden");
        }

        async function saveMarketItem() {
            const t = document.getElementById("mk-title").value;
            const p = document.getElementById("mk-price").value;
            const c = document.getElementById("mk-contact").value;
            const d = document.getElementById("mk-desc").value;
            const files = document.getElementById("mk-photos").files;

           if(files[0] && !checkFileSize(files[0], 10)) return;
            
            if(!t || !p || !c) return alert("Başlık, Fiyat ve İletişim zorunludur!");
            
            const tier = getUserPremiumTier(currentUser.username);
            let maxP = 1;
            if(tier >= 3) maxP = 10; else if(tier >= 2) maxP = 4; else if(tier >= 1) maxP = 2;
            
            if(files.length > maxP) return alert(`Mevcut paketiniz ${maxP} fotoğraf yüklemenize izin veriyor.`);
            
            document.getElementById("market-modal").classList.add("hidden");
            
            let photoDataArray = [];
            for(let i=0; i<files.length; i++) {
                if(i < maxP) {
                    let b64 = await resizeImage(files[i], 800);
                    if(b64) photoDataArray.push(b64);
                }
            }
            if(photoDataArray.length === 0) photoDataArray = ["https://placehold.co/400x300/121214/FFF?text=FOTO+YOK"];
            
            await sendAction('add_market', { id: Date.now().toString(), title: t, price: p, contact: c, desc: d, image: photoDataArray });
        }

        function renderMarket() {
            const container = document.getElementById("market-list");
            let _html = "";
            
            if(!db.market || db.market.length === 0) {
                container.innerHTML = "<div class='col-span-2 text-center text-zinc-500 italic mt-10 font-medium'>Pazar şu an boş.</div>";
                return;
            }
            
            const sortedMarket = db.market.sort((a,b) => (b.bumped_at || 0) - (a.bumped_at || 0));

            sortedMarket.forEach(item => {
                let mainImg = Array.isArray(item.image) ? item.image[0] : (item.image || "https://placehold.co/400x300/121214/FFF?text=FOTO+YOK");
                
                const ownerTier = getUserPremiumTier(item.owner);
                let borderClass = ownerTier >= 2 ? "border-purple-500 " : "border-zinc-800 ";
                let premiumTag = ownerTier >= 2 ? `<div class="absolute top-0 right-0 bg-purple-600 text-white text-[8px] font-black px-2 py-1 rounded-bl-lg  z-10 uppercase tracking-widest">Premium İlan</div>` : "";

                _html += `
                <div onclick="openMarketDetail('${item.id}')" class="h-48 w-full rounded-2xl overflow-hidden border ${borderClass} relative cursor-pointer hover:border-zinc-500 transition-all duration-300 hover:scale-[1.02] group bg-zinc-900">
                    <img src="${mainImg}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent pointer-events-none"></div>
                    
                    ${premiumTag}
                    
                    <div class="absolute bottom-0 left-0 w-full p-3 flex flex-col justify-end pointer-events-none">
                        <div class="flex justify-between items-start mb-1.5">
                            <h3 class="text-white font-bold text-xs tracking-wide line-clamp-2 break-words drop-shadow-md leading-snug flex-1 pr-1">${item.title || 'İlan Başlığı Yok'}</h3>
                        </div>
                        <div class="flex items-center justify-between mb-2">
                            <div class="bg-black/80 text-green-400 font-black text-xs px-2.5 py-1 rounded-lg border border-zinc-700 shadow-lg backdrop-blur-sm">${item.price} TL</div>
                            <span class="text-[10px] text-zinc-200 font-bold bg-black/60 px-2 py-1 rounded-lg backdrop-blur-sm border border-white/10">👁️ ${item.views || 0}</span>
                        </div>
                        <div class="text-[9px] text-zinc-300 font-bold uppercase tracking-widest flex items-center border-t border-white/20 pt-2">
                            <span class="truncate drop-shadow">👤 ${item.owner}</span>
                        </div>
                    </div>
                </div>`;
            });
            container.innerHTML = _html;
        }

        // openMarketDetail: renderMarket kartlarından çağrılan alias — viewMarketDetail ile aynıdır
        function openMarketDetail(id) {
            const item = db.market.find(x => String(x.id) === String(id));
            if(!item) { console.warn('[Market] openMarketDetail: ID bulunamadı:', id); return; }
            viewMarketDetail(id);
        }

        function viewMarketDetail(id) {
            const item = db.market.find(x => String(x.id) === String(id));
            if(!item) { console.warn('Market item not found for id:', id); return; }
            
            currentMarketId = id;
            window.currentOwner = item.owner;
            
            if(item.owner !== currentUser.username) {
                sendAction('increment_market_view', { id: id }).catch(e=>{});
            }

            const imgContainer = document.getElementById("md-photos");
            imgContainer.innerHTML = "";
            let images = Array.isArray(item.image) ? item.image : [item.image || "https://placehold.co/400x300/121214/FFF?text=FOTO+YOK"];
            images.forEach(img => {
                imgContainer.innerHTML += `<img src="${img}" class="h-full w-auto object-contain shrink-0 scroll-snap-align-center rounded-xl">`;
            });

            document.getElementById("md-title").textContent = item.title;
            document.getElementById("md-price").textContent = `${item.price} TL`;
            
            if(getUserPremiumTier(currentUser.username) === 3 || item.owner === currentUser.username) {
                document.getElementById("md-views-badge").classList.remove("hidden");
                document.getElementById("md-views-badge").textContent = `👁️ ${item.views || 0} Görüntülenme`;
            } else {
                document.getElementById("md-views-badge").classList.add("hidden");
            }
            
            const ownerObj = db.users.find(u => u.username === item.owner);
            document.getElementById("md-owner-avatar").src = ownerObj ? ownerObj.avatar : "https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg";
            document.getElementById("md-owner").textContent = item.owner;
            
            document.getElementById("md-desc").textContent = item.desc || "Açıklama girilmemiş.";
            document.getElementById("md-contact").textContent = item.contact;

            let actionsHtml = "";
            if(item.owner !== currentUser.username) {
                actionsHtml += `<button onclick="startDm('${item.owner}')" class="bg-white hover:bg-gray-200 transition text-black py-4 rounded-xl font-bold text-sm w-full  btn-premium-hover">✉️ SATICIYA MESAJ AT</button>`;
            }
            
            if(item.owner === currentUser.username && getUserPremiumTier(currentUser.username) >= 2) {
                actionsHtml += `<button onclick="bumpMarket('${item.id}')" class="bg-purple-900/50 hover:bg-purple-800 transition text-purple-400 border border-purple-500/50 py-3.5 rounded-xl font-bold text-xs w-full mt-3 uppercase tracking-widest  btn-premium-hover">🚀 İLANI EN ÜSTE TAŞI (BUMP)</button>`;
            }
            
            if(item.owner === currentUser.username || currentUser.role === 'Admin') {
                actionsHtml += `<button onclick="deleteMarket('${item.id}')" class="bg-red-950/50 hover:bg-sky-900/80 transition text-sky-400 border border-sky-900/50 py-3.5 rounded-xl font-bold text-xs w-full mt-3 uppercase tracking-widest btn-premium-hover ">İLANI SİL</button>`;
            }
            
            document.getElementById("md-actions-area").innerHTML = actionsHtml;
            document.getElementById("market-detail-modal").classList.remove("hidden");
        }

        async function bumpMarket(id) {
            await sendAction('bump_market', { id: id });
            alert("İlanınız başarıyla en üste taşındı!");
            document.getElementById("market-detail-modal").classList.add("hidden");
            renderMarket();
        }

        async function deleteMarket(id) {
            if(confirm("Bu ilanı silmek istediğinize emin misiniz?")) {
                await sendAction('delete_market', { id: id });
                db.market = db.market.filter(m => m.id !== id);
                document.getElementById("market-detail-modal").classList.add("hidden");
                renderMarket();
            }
        }

        function switchLeaderboard(tab) {
            currentLeaderboardTab = tab;
            document.getElementById("rank-tab-weekly").className = "flex-1 py-2 bg-transparent text-zinc-500 hover:text-white rounded font-bold text-xs transition";
            document.getElementById("rank-tab-month").className = "flex-1 py-2 bg-transparent text-zinc-500 hover:text-white rounded font-bold text-xs transition";
            document.getElementById("rank-tab-all").className = "flex-1 py-2 bg-transparent text-zinc-500 hover:text-white rounded font-bold text-xs transition";
            
            if(tab === 'weekly') {
                document.getElementById("rank-tab-weekly").className = "flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition ";
            } else if(tab === 'month') {
                document.getElementById("rank-tab-month").className = "flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition ";
            } else {
                document.getElementById("rank-tab-all").className = "flex-1 py-2 bg-zinc-800 text-white rounded font-bold text-xs transition ";
            }
            renderLeaderboard();
        }


        function renderLeaderboard() {
            const container = document.getElementById("leaderboard");
            let _html = "";

            // Admin sıralamada gösterilmez
            const visibleUsers = db.users.filter(u => u.username !== 'Admin' && u.role !== 'Admin');

            let sortedUsers = [];
            if(currentLeaderboardTab === 'weekly') {
                sortedUsers = [...visibleUsers].sort((a,b) => ((b.stats&&b.stats.weekly_xp)||0) - ((a.stats&&a.stats.weekly_xp)||0)).slice(0,50);
            } else if(currentLeaderboardTab === 'month') {
                sortedUsers = [...visibleUsers].sort((a,b) => ((b.stats&&b.stats.monthly_xp)||0) - ((a.stats&&a.stats.monthly_xp)||0)).slice(0,50);
            } else {
                sortedUsers = [...visibleUsers].sort((a,b) => (b.xp||0) - (a.xp||0)).slice(0,50);
            }

            if(sortedUsers.length === 0) {
                container.innerHTML = "<div class='text-zinc-500 text-xs italic text-center py-8'>Henuz siralamada kimse yok.</div>";
                return;
            }

            // Champion banner (1st place highlight)
            const champ = sortedUsers[0];
            if(champ) {
                const champColor = getUserPremiumColor(champ.username);
                const champTextCls = getUserPremiumTier(champ.username) > 0 ? getPremiumTextClass(champColor) : 'text-yellow-400';
                const tabLabel = currentLeaderboardTab === 'weekly' ? 'Bu Haftanin Birincisi' : currentLeaderboardTab === 'month' ? 'Bu Ayin Birincisi' : 'Tum Zamanlarin Birincisi';
                const champVal = currentLeaderboardTab === 'weekly' ? ((champ.stats&&champ.stats.weekly_xp)||0) : currentLeaderboardTab === 'month' ? ((champ.stats&&champ.stats.monthly_xp)||0) : (champ.xp||0);
                _html += `
                <div class="relative bg-gradient-to-r from-yellow-900/60 to-amber-900/40 rounded-3xl p-5 mb-5 border border-yellow-600/50  overflow-hidden">
                    <div class="absolute inset-0 opacity-10 pointer-events-none" style="background:radial-gradient(circle at 70% 50%, #fbbf24 0%, transparent 70%);"></div>
                    <div class="text-[10px] text-yellow-500 font-black uppercase tracking-[0.15em] mb-2 flex items-center gap-2">
                        <span class="animate-pulse">👑</span> ${tabLabel}
                    </div>
                    <div class="flex items-center gap-4">
                        <div class="relative">
                            <img src="${champ.avatar||'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg'}" class="w-16 h-16 rounded-full object-cover border-4 border-yellow-500 ">
                            <div class="absolute -bottom-1 -right-1 text-2xl">🥇</div>
                        </div>
                        <div class="flex-1">
                            <div class="font-black text-xl ${champTextCls} teko-font tracking-wide">${champ.username}</div>
                            <div class="text-yellow-400 font-black text-2xl teko-font">${champVal.toLocaleString()} XP</div>
                            <div class="text-[10px] text-zinc-400 mt-1">${currentLeaderboardTab === 'weekly' ? '🏆 1 Haftalik Ultra+ Odulu Kazanacak!' : currentLeaderboardTab === 'month' ? '🏆 1 Aylik Deluxe Odulu Kazanacak!' : ''}</div>
                        </div>
                    </div>
                </div>`;
            }

            sortedUsers.forEach((u, index) => {
                const title = getTitle(u.xp);
                const isMe = u.username === currentUser.username;
                let rankVisual = `<div class="w-8 h-8 rounded-full bg-black/60 border border-zinc-700 flex items-center justify-center font-black text-xs text-zinc-400">${index+1}</div>`;
                if(index === 0) rankVisual = `<div class="text-3xl  animate-pulse">🥇</div>`;
                if(index === 1) rankVisual = `<div class="text-3xl ">🥈</div>`;
                if(index === 2) rankVisual = `<div class="text-3xl ">🥉</div>`;

                const premColor = getUserPremiumColor(u.username);
                const textCls = getUserPremiumTier(u.username)>0 ? getPremiumTextClass(premColor) : '';
                const inlineStyle = getUserPremiumTier(u.username)>0 ? getPremiumInlineStyle(premColor) : '';
                const borderCls = getUserPremiumTier(u.username)>0 ? getPremiumBorderClass(u.username) : 'border-zinc-700';
                const onlineHtml = getOnlineHTML(u);

                let val = currentLeaderboardTab==='weekly' ? ((u.stats&&u.stats.weekly_xp)||0)
                        : currentLeaderboardTab==='month' ? ((u.stats&&u.stats.monthly_xp)||0)
                        : (u.xp||0);

                // Reward badge for top 3
                let rewardTag = '';
                if(index === 0 && currentLeaderboardTab === 'weekly') rewardTag = '<span class="text-[9px] bg-yellow-600 text-black px-2 py-0.5 rounded font-black ml-1">1HFT ULTRA+</span>';
                else if((index===1||index===2) && currentLeaderboardTab==='weekly') rewardTag = '<span class="text-[9px] bg-purple-600 text-white px-2 py-0.5 rounded font-black ml-1">1HFT DLX</span>';
                else if(index<=2 && currentLeaderboardTab==='month') rewardTag = '<span class="text-[9px] bg-blue-600 text-white px-2 py-0.5 rounded font-black ml-1">1AY DLX</span>';

                _html += `
                <div onclick="showOtherProfile('${u.username}')" class="bg-black/40 p-4 rounded-2xl border ${isMe?'border-zinc-400 ':'border-zinc-800'} flex items-center gap-4 cursor-pointer hover:bg-zinc-800/50 transition-all duration-200  group slide-up-anim mb-2">
                    <div class="w-10 flex justify-center shrink-0">${rankVisual}</div>
                    <div class="relative shrink-0">
                        <img src="${u.avatar||'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg'}" class="w-11 h-11 rounded-full object-cover border-2 ${borderCls}  group-hover:scale-110 transition-transform">
                        ${getOnlineStatus(u).status==='online'?'<span class="online-dot absolute bottom-0 right-0"></span>':''}
                    </div>
                    <div class="flex-1 overflow-hidden">
                        <div class="flex items-center gap-1 flex-wrap">
                            <span style="${inlineStyle}" class="font-bold text-sm tracking-wide truncate ${textCls||'text-white'}">${u.username}</span>${rewardTag}
                        </div>
                        <div class="flex items-center gap-2 mt-0.5">
                            <span class="text-[9px] text-zinc-500 font-bold uppercase">${title.icon} ${title.name}</span>
                            ${onlineHtml?`<span class="flex items-center gap-1">${onlineHtml}</span>`:''}
                        </div>
                    </div>
                    <div class="text-right shrink-0 bg-zinc-950/50 px-3 py-2 rounded-xl border border-zinc-800">
                        <div class="text-white font-black text-lg teko-font tracking-widest">${val.toLocaleString()}</div>
                        <div class="text-[9px] text-zinc-500 uppercase font-bold">XP</div>
                    </div>
                </div>`;
            });

            // Mevcut kullanici top 50de degilse kendi sirasini en alta goster
            if(currentUser && currentUser.username && currentUser.username !== 'Admin') {
                var meInList = sortedUsers.findIndex(function(u) { return u.username === currentUser.username; });
                if(meInList === -1) {
                    var allSorted2 = visibleUsers.slice().sort(function(a,b) {
                        if(currentLeaderboardTab === 'weekly') return (((b.stats&&b.stats.weekly_xp)||0) - ((a.stats&&a.stats.weekly_xp)||0));
                        if(currentLeaderboardTab === 'month') return (((b.stats&&b.stats.monthly_xp)||0) - ((a.stats&&a.stats.monthly_xp)||0));
                        return ((b.xp||0) - (a.xp||0));
                    });
                    var myGlobalRank = allSorted2.findIndex(function(u) { return u.username === currentUser.username; });
                    var myData2 = allSorted2.find(function(u) { return u.username === currentUser.username; }) || currentUser;
                    var myVal2 = currentLeaderboardTab === 'weekly' ? ((myData2.stats&&myData2.stats.weekly_xp)||0)
                               : currentLeaderboardTab === 'month' ? ((myData2.stats&&myData2.stats.monthly_xp)||0)
                               : (myData2.xp||0);
                    var myRankTxt = myGlobalRank >= 0 ? String(myGlobalRank + 1) : '50+';
                    var myAvatar = currentUser.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg';
                    _html += '<div style="margin-top:14px;border-top:1px solid #27272a;padding-top:14px">' +
                        '<div style="font-size:9px;color:#52525b;font-weight:900;text-transform:uppercase;text-align:center;letter-spacing:.1em;margin-bottom:8px">Senin Siran</div>' +
                        '<div style="background:rgba(24,24,27,.6);padding:14px;border-radius:16px;border:1px solid rgba(113,113,122,.4);display:flex;align-items:center;gap:14px">' +
                        '<div style="width:40px;display:flex;justify-content:center">' +
                        '<div style="width:32px;height:32px;border-radius:50%;background:rgba(63,63,70,.8);border:1px solid #71717a;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:11px;color:#d4d4d8">' + myRankTxt + '</div></div>' +
                        '<img src="' + myAvatar + '" style="width:42px;height:42px;border-radius:50%;object-fit:cover;border:2px solid #71717a;flex-shrink:0">' +
                        '<div style="flex:1;overflow:hidden">' +
                        '<div style="font-weight:700;font-size:13px;color:#e4e4e7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + currentUser.username + ' <span style="font-size:9px;color:#71717a;font-weight:400">(Sen)</span></div>' +
                        '<div style="font-size:9px;color:#71717a;font-weight:700;text-transform:uppercase;margin-top:2px">Top 50 disinda</div></div>' +
                        '<div style="text-align:right;flex-shrink:0;background:rgba(9,9,11,.5);padding:8px 12px;border-radius:12px;border:1px solid #27272a">' +
                        '<div style="color:#d4d4d8;font-weight:900;font-size:18px;letter-spacing:.08em">' + myVal2.toLocaleString() + '</div>' +
                        '<div style="font-size:9px;color:#71717a;text-transform:uppercase;font-weight:700">XP</div></div>' +
                        '</div></div>';
                }
            }

            container.innerHTML = _html;
        }
        function renderNews() {
            const container = document.getElementById("news-list");
            let _html = "";
            db.news.forEach(n => {
                let imgHtml = n.image ? `<img src="${n.image}" class="w-full h-48 object-cover rounded-xl mt-4 border border-zinc-700 ">` : '';
                let delBtn = currentUser.role === 'Admin' ? `<button onclick="deleteNews('${n.id}')" class="mt-4 bg-red-950/50 hover:bg-sky-900/80 text-sky-400 px-5 py-2.5 rounded-xl text-xs font-bold border border-sky-900/50 transition btn-premium-hover uppercase tracking-widest ">Haberi Sil</button>` : '';
                
                let displayDate = n.created_at || n.date || new Date().toLocaleDateString();
                let displayBody = n.body || n.content || '';

                _html += `
                <div class="glass-panel p-6 rounded-3xl border border-zinc-800  mb-5 slide-up-anim">
                    <h3 class="text-2xl text-white font-bold tracking-wide  leading-tight">${n.title}</h3>
                    <div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-2 flex items-center gap-2"><span class="animate-pulse">🕒</span> ${displayDate}</div>
                    ${imgHtml}
                    <p class="text-sm text-zinc-300 mt-5 leading-relaxed whitespace-pre-wrap font-medium">${displayBody}</p>
                    ${delBtn}
                </div>`;
            });
            container.innerHTML = _html;
        }

        function openNewsAdminModal() { document.getElementById("news-admin-modal").classList.remove("hidden"); }
        
        async function saveNews() {
            const t = document.getElementById("news-title").value.trim();
            const c = document.getElementById("news-content").value.trim();
            const f = document.getElementById("news-photo").files[0];
            
            if(!t || !c) return alert("İçerik başlık ve içerik zorunludur!");
            
            document.getElementById("news-admin-modal").classList.add("hidden");
            showToast('📤 Haber kaydediliyor...', 'info');

            let imgData = null;
            if(f) {
                // Önce R2'ye yükle, base64'" direkt JSON'a gönderme (Supabase sütun boyutu aşılır)
                try {
                    const resized = await resizeImage(f, 800);
                    if(resized) {
                        const uploadRes = await sendAction('upload_media', { media_data: resized, folder: 'news' }, true);
                        if(uploadRes && uploadRes.url) {
                            imgData = uploadRes.url; // R2 URL
                        }
                    }
                } catch(imgErr) {
                    console.warn('Resim yükleme hatası, habere resim eklenmeden devam ediliyor:', imgErr);
                }
            }
            
            let newObj = { id: Date.now().toString(), title: t, content: c, image: imgData, date: new Date().toISOString() };
            try {
                await sendAction('add_news', newObj);
                db.news.unshift(newObj);
                renderNews();
                showToast('✅ Haber başarıyla yayınlandı!', 'success');
            } catch(e) {
                showToast('❌ Haber eklenemedi: ' + (e.message || 'Bilinmeyen hata'), 'error');
            }
        }
        
        async function deleteNews(id) {
            if(confirm("Haberi silmek istiyor musunuz?")) {
                await sendAction('delete_news', {id: id});
                db.news = db.news.filter(n => n.id !== id);
                renderNews();
            }
        }

        let _lastRenderedTab = -1; // Son render edilen sekme indexi

        function switchTab(idx, skipHistory = false) {
            // Hayalet ses önleme — tüm medyayı durdur, observer bağlantısını kes
            stopAllMedia();
            document.querySelectorAll('#reels-feed video').forEach(v => { try { v.pause(); v.currentTime = 0; } catch(_){} });
            if(idx !== 9 && typeof _feedObserver !== 'undefined' && _feedObserver) {
                _feedObserver.disconnect();
                _feedObserver = null;
            }
            
            if (!skipHistory) {
                history.pushState({ tabIndex: idx }, '', '#tab' + idx);
            }
            
            if (idx !== 9) _prevTab = idx;
            const tabs = ['screen-map', 'screen-chat', 'screen-market', 'screen-rank', 'screen-news', 'screen-missions', 'screen-premium', 'screen-profile', 'screen-referral', 'screen-reels', 'screen-competition', 'screen-giveaway'];
            
            // 1. ADIM: Sadece görünürlük değişimi — çok hızlı, animasyon başlar
            tabs.forEach((t, i) => {
                const el = document.getElementById(t);
                if(!el) return;
                if(i === idx) {
                    el.style.display = 'flex';
                    el.style.flexDirection = 'column';
                    el.style.zIndex = '20';
                    el.style.opacity = '1';
                    el.style.pointerEvents = 'auto';
                    el.classList.remove('hidden');
                    el.style.animation = 'none';
                    el.offsetHeight; // reflow — animation restart
                    el.style.animation = 'slideUpFade 0.22s cubic-bezier(0.16, 1, 0.3, 1) both';
                } else {
                    el.style.display = 'none';
                    el.style.zIndex = '-1';
                    el.style.pointerEvents = 'none';
                    el.classList.add('hidden');
                    el.style.animation = 'none';
                }
            });

            // 2. ADIM: Alt nav / buton görünürlüğü — hızlı, senkron
            const bottomNav = document.getElementById('bottom-nav');
            const soundBtn2 = document.getElementById('reel-sound-btn');
            const gridBtn2  = document.getElementById('grid-view-btn');
            const uploadTopBtn2 = document.getElementById('reels-upload-top-btn');
            if(idx === 9) {
                if(bottomNav) bottomNav.style.display = 'none';
                if(soundBtn2) { soundBtn2.style.display = 'flex'; soundBtn2.textContent = _reelMuted ? '🔇' : '🔊'; }
                if(gridBtn2)  gridBtn2.style.display = 'flex';
                if(uploadTopBtn2) uploadTopBtn2.style.display = 'flex';
                document.getElementById('screen-map') && (document.getElementById('screen-map').style.zIndex = '1');
            } else {
                if(bottomNav) bottomNav.style.display = '';
                if(soundBtn2) soundBtn2.style.display = 'none';
                if(gridBtn2)  gridBtn2.style.display = 'none';
                if(uploadTopBtn2) uploadTopBtn2.style.display = 'none';
            }

            // tab-btn aktif/pasif durumu
            document.querySelectorAll(".tab-btn").forEach((btn, i) => {
                const addArr = i === idx ? ["text-white", "scale-105", "opacity-100", "bg-zinc-800/80"] : ["text-zinc-500", "opacity-70", "hover:bg-zinc-900/50"];
                const remArr = i === idx ? ["text-zinc-500", "opacity-70", "bg-zinc-900/50", "hover:bg-zinc-900/50"] : ["text-white", "scale-105", "opacity-100", "bg-zinc-800/80"];
                addArr.filter(Boolean).forEach(c => { try { btn.classList.add(c); } catch(e){} });
                remArr.filter(Boolean).forEach(c => { try { btn.classList.remove(c); } catch(e){} });
            });

            // Alt nav highlight — senkron
            const bnavIds = [0,1,9,3,7];
            bnavIds.forEach(i => {
                const btn = document.getElementById('bnav-' + i);
                if(!btn) return;
                const iconEl = btn.querySelector('span:first-child');
                const labelEl = btn.querySelector('span:last-child');
                if(i === idx) {
                    btn.classList.add('text-white');
                    btn.classList.remove('text-zinc-500');
                    btn.style.background = 'linear-gradient(135deg,rgba(2,132,199,0.3),rgba(3,105,161,0.15))';
                    btn.style.boxShadow = '0 0 16px rgba(14,165,233,0.25),inset 0 1px 0 rgba(255,255,255,0.05)';
                    if(iconEl) { iconEl.style.transform = 'scale(1.18) translateY(-1px)'; iconEl.style.filter = 'drop-shadow(0 0 6px rgba(14,165,233,0.8))'; }
                    if(labelEl) { labelEl.style.color = '#7dd3fc'; labelEl.style.opacity = '1'; }
                } else {
                    btn.classList.remove('text-white');
                    btn.classList.add('text-zinc-500');
                    btn.style.background = '';
                    btn.style.boxShadow = '';
                    if(iconEl) { iconEl.style.transform = ''; iconEl.style.filter = ''; }
                    if(labelEl) { labelEl.style.color = ''; labelEl.style.opacity = ''; }
                }
            });

            // 3. ADIM: Ağır render işlemleri — animasyon bittikten SONRA çalıştır
            // Aynı sekme tekrar açılırsa render'ı atla (gereksiz DOM yazımı önlenir)
            const isSameTab = (_lastRenderedTab === idx);
            _lastRenderedTab = idx;

            setTimeout(() => {
                if(idx === 0) { if(map) { map.invalidateSize(); } }
                if(idx === 1 && !isSameTab) { renderChat(); renderDmList(); clearChatBadge(); renderStoryBar(); }
                if(idx === 1 && isSameTab) { clearChatBadge(); }
                if(idx === 2 && !isSameTab) renderMarket();
                if(idx === 3) renderLeaderboard(); // Her açılışta taze sıralama göster
                if(idx === 4 && !isSameTab) renderNews();
                if(idx === 5 && !isSameTab) { renderMissions(); updateSpinInfo(); setTimeout(initWheel3D, 150); }
                if(idx === 7) { updateProfileUI(); updateNotifBtnState(); }
                if(idx === 8 && !isSameTab) renderReferralTab();
                if(idx === 9) { stopAllMedia(); loadReels(true); }
                if(idx === 10 && !isSameTab) renderCompetition();
                if(idx === 11 && !isSameTab) window.loadGiveaways();
            }, 50); // 50ms: animasyon (220ms) başladıktan hemen sonra render, kullanıcı fark etmez



            const sidebar = document.getElementById("sidebar");
            if(sidebar && !sidebar.classList.contains("-translate-x-full") && window.innerWidth < 768) {
                toggleSidebar();
            }
        }

        // ============================================================
        // PROMINENT DISCLOSURE — Fotoğraf (Google Play uyumu)
        // file input tetiklenmeden ÖNCE kullanıcıya amaç gösterilir.
        // ============================================================
        const _PD_PHOTO_CFG = {
            group:   { icon:'💬', title:'Sohbete Fotoğraf Ekle',   sub:'Grup Sohbeti',
                       desc:'Seçeceğin fotoğraf <strong class="text-white">grup sohbetine</strong> gönderilecek.',
                       items:['Fotoğraf yalnızca grup üyelerine görünür','Görsel otomatik boyutlandırılır (maks. 800px)','Yalnızca seçtiğin görsel paylaşılır'] },
            dm:      { icon:'✉️', title:'Mesaja Fotoğraf Ekle',     sub:'Özel Mesaj',
                       desc:'Seçeceğin fotoğraf <strong class="text-white">özel mesaj</strong> olarak gönderilecek.',
                       items:['Yalnızca mesaj gönderdiğin kişi görebilir','Görsel otomatik boyutlandırılır (maks. 800px)','Yalnızca seçtiğin görsel paylaşılır'] },
            profile: { icon:'👤', title:'Profil Fotoğrafı Güncelle', sub:'Profil Görseli',
                       desc:'Seçeceğin fotoğraf <strong class="text-white">profil resmin</strong> olarak ayarlanacak.',
                       items:['Tüm kullanıcılar profil fotoğrafını görebilir','Görsel otomatik kırpılır ve optimize edilir (400px)','Yalnızca seçtiğin görsel yüklenir'] },
            reel:    { icon:'🎬', title:'Reel Medya Seç',           sub:'Reel / Gönderi',
                       desc:'Seçeceğin fotoğraf veya video <strong class="text-white">reel olarak paylaşılacak</strong>.',
                       items:['Tüm topluluk üyeleri görebilir','Fotoğraflar optimize edilir, videolar maks. 50MB','Yalnızca seçtiğin dosya paylaşılır'] },
        };

        function _showPhotoDisclosure(context, onConfirm) {
            const cfg = _PD_PHOTO_CFG[context] || _PD_PHOTO_CFG.profile;
            document.getElementById('pd-photo-icon').textContent     = cfg.icon;
            document.getElementById('pd-photo-title').textContent    = cfg.title;
            document.getElementById('pd-photo-subtitle').textContent = cfg.sub;
            document.getElementById('pd-photo-desc').innerHTML       = cfg.desc;
            document.getElementById('pd-photo-list').innerHTML = cfg.items
                .map(t => `<li class="flex items-start gap-2"><span class="text-pink-400 shrink-0 mt-0.5">✔</span><span>${t}</span></li>`)
                .join('');
            const modal    = document.getElementById('pd-photo-modal');
            const allowBtn = document.getElementById('pd-photo-allow');
            const denyBtn  = document.getElementById('pd-photo-deny');
            modal.classList.remove('hidden');
            const cleanup = () => { allowBtn.removeEventListener('click', onAllow); denyBtn.removeEventListener('click', onDeny); };
            function onAllow() { modal.classList.add('hidden'); cleanup(); onConfirm(); }
            function onDeny()  { modal.classList.add('hidden'); cleanup(); }
            allowBtn.addEventListener('click', onAllow);
            denyBtn.addEventListener('click',  onDeny);
        }

        function openPhotoUpload(context) {
            currentPhotoContext = context;
            _showPhotoDisclosure(context, () => { document.getElementById("chat-photo-upload").click(); });
        }

        async function handleChatPhotoUpload(input) {
            if(!input.files[0]) return;
            const b64 = await resizeImage(input.files[0], 800);
            if(b64) {
                const id = Date.now().toString();
                if(currentPhotoContext === 'group') {
                    await sendAction('add_message', { id: id, photo: b64, type: "photo" });
                } else if(currentPhotoContext === 'dm' && currentDmUser) {
                    db.dms.push({ id: id, sender: currentUser.username, receiver: currentDmUser, participants: [currentUser.username, currentDmUser], photo: b64, type: 'photo' });
                    renderDmThread(currentDmUser);
                    await sendAction('send_dm', { id: id, photo: b64, receiver: currentDmUser, type: "photo" });
                }
            }
            input.value = "";
        }

        // ============================================================
        // PROMINENT DISCLOSURE — Mikrofon (Google Play uyumu)
        // getUserMedia() çağrısından ÖNCE kullanıcıya amaç gösterilir.
        // İzin zaten verildiyse modal atlanır, kayıt doğrudan başlar.
        // ============================================================
        async function toggleVoiceRecord(context) {
            if(getUserPremiumTier(currentUser.username) < 2) {
                return alert("Sesli mesaj gönderme özelliği Deluxe ve Ultra+ üyelerine özeldir!");
            }
            const btn = document.getElementById("voice-btn");

            // Aktif kayıt varsa durdur — disclosure gerektirmez
            // NOT: MediaRecorder.state değerleri: "inactive", "recording", "paused"
            // Önceki kodda "active" kullanılıyordu ki bu HİÇBİR ZAMAN true olmaz!
            if (mediaRecorder && mediaRecorder.state === "recording") {
                _voiceStopping = true;   // Blob işlenene kadar yeni kaydı engelle
                mediaRecorder.stop();
                // stop event handler içinde btn sıfırlanacak ve mediaRecorder = null yapılacak
                return;
            }

            // Blob henüz işleniyorsa (stop() sonrası kısa pencere) izin akışına düşme
            if (_voiceStopping) return;

            // İzin zaten verilmişse doğrudan kaydı başlat (modal gösterme)
            try {
                const perm = await navigator.permissions.query({ name: 'microphone' });
                if (perm.state === 'granted') { await _startVoiceCapture(context, btn); return; }
            } catch(_) { /* permissions API desteklenmiyor — modal göster */ }

            // Eğer modalı daha önce görüp İzin Ver'e bastıysa, tekrar sorma
            if (localStorage.getItem('mic_pd_shown') === 'true') {
                await _startVoiceCapture(context, btn);
                return;
            }

            // Prominent Disclosure modal — sadece izin granted DEĞİLSE gösterilir
            const modal    = document.getElementById('pd-mic-modal');
            const allowBtn = document.getElementById('pd-mic-allow');
            const denyBtn  = document.getElementById('pd-mic-deny');
            modal.classList.remove('hidden');
            const cleanup = () => { allowBtn.removeEventListener('click', onAllow); denyBtn.removeEventListener('click', onDeny); };
            async function onAllow() { localStorage.setItem('mic_pd_shown', 'true'); modal.classList.add('hidden'); cleanup(); await _startVoiceCapture(context, btn); }
            function onDeny()        { modal.classList.add('hidden'); cleanup(); }
            allowBtn.addEventListener('click', onAllow);
            denyBtn.addEventListener('click',  onDeny);
        }

        async function _startVoiceCapture(context, btn) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];
                btn.className = "bg-red-600 w-10 h-10 md:w-12 md:h-12 rounded-xl text-lg flex items-center justify-center animate-pulse  border border-sky-400 transition-all";
                btn.innerHTML = "⏹️";
                mediaRecorder.addEventListener("dataavailable", ev => { audioChunks.push(ev.data); });
                mediaRecorder.addEventListener("stop", async () => {
                    // Ses verisini hazırla ve gönder
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    const reader = new FileReader();
                    reader.readAsDataURL(audioBlob);
                    reader.onloadend = async function() {
                        const b64 = reader.result;
                        const id  = Date.now().toString();
                        if(context === 'group') await sendAction('add_message', { id, audio: b64, type: "voice" });
                    };
                    // Mikrofon stream'ini kapat
                    stream.getTracks().forEach(t => t.stop());
                    // Butonu sıfırla
                    btn.className = "bg-zinc-800/80 hover:bg-zinc-700 transition w-10 h-10 md:w-12 md:h-12 rounded-xl text-lg flex items-center justify-center border border-zinc-700 btn-premium-hover";
                    btn.innerHTML = "🎤";
                    // KRITIK: mediaRecorder'ı null yap ki sonraki tıklamada
                    // stale "inactive" state yüzünden yanlış dallanma olmasın
                    audioChunks = [];
                    mediaRecorder = null;
                    _voiceStopping = false; // Artık yeni kayda izin ver
                });
                // start() çağrısı event listener'lardan SONRA yapılmalı
                mediaRecorder.start();
            } catch(err) {
                console.error('Mikrofon hatası:', err);
                mediaRecorder = null;
                alert("Mikrofon izni alınamadı. Tarayıcı ayarlarından mikrofon iznini etkinleştir.");
            }
        }
        
        function playVoice(src) { const a = new Audio(src); a.play(); }

        // Premium modal animasyon yardımcısı
        function showModal(id) {
            const el = document.getElementById(id);
            if(!el) return;
            el.classList.remove('hidden');
            const inner = el.querySelector('.modal-inner, [class*="glass-panel"], [class*="bg-zinc"], [class*="bg-black"]');
            if(inner) {
                inner.style.animation = 'none';
                inner.offsetHeight;
                inner.style.animation = 'scaleInFade 0.32s cubic-bezier(0.34,1.56,0.64,1) both';
            }
        }
        function hideModal(id) {
            const el = document.getElementById(id);
            if(!el) return;
            el.classList.add('hidden');
        }

        function openSettingsModal() {
            document.getElementById("edit-name").value = currentUser.name || "";
            document.getElementById("edit-bio").value = currentUser.bio || "";
            document.getElementById("edit-password").value = "";
            
            const stats = currentUser.stats || {};
            document.getElementById("edit-email").value = stats.email || "";
            document.getElementById("edit-marketing").checked = stats.marketing_opt_in || false;
            
            const statusDiv = document.getElementById("profile-email-status");
            if(stats.email) {
                if(stats.email_verified) {
                    statusDiv.innerHTML = `<span class="bg-green-900/40 text-green-400 text-[10px] px-3 py-1.5 rounded-lg font-bold border border-green-800/50  uppercase tracking-widest inline-flex items-center gap-1"><span class="text-sm">✅</span> E-Posta Doğrulandı</span>`;
                } else {
                    statusDiv.innerHTML = `<span class="bg-yellow-900/40 text-yellow-500 text-[10px] px-3 py-1.5 rounded-lg font-bold border border-yellow-800/50  uppercase tracking-widest inline-flex items-center gap-1"><span class="text-sm">⚠️</span> E-Posta Doğrulanmadı</span>`;
                }
            } else {
                statusDiv.innerHTML = `<span class="bg-zinc-800 text-zinc-400 text-[10px] px-3 py-1.5 rounded-lg font-bold border border-zinc-700 uppercase tracking-widest inline-block">E-Posta Eklenmemiş</span>`;
            }

            checkEmailChange();
            document.getElementById("settings-modal").classList.remove("hidden");
        }

        function checkEmailChange() {
            const stats = currentUser.stats || {};
            const currentEmail = stats.email || "";
            const inputEmail = document.getElementById("edit-email").value.trim();
            const btn = document.getElementById("btn-verify-email");
            
            if (inputEmail !== "" && (inputEmail !== currentEmail || !stats.email_verified)) {
                btn.classList.remove("hidden");
            } else {
                btn.classList.add("hidden");
            }
        }

        function closeSettingsModal() { document.getElementById("settings-modal").classList.add("hidden"); }

        // --- Uygulama Turu Başlatma (Settings üzerinden güvenli) ---
        function startAppTourFromSettings() {
            // 1) Settings modal'i anında kapat ve görünmez yap
            const modal = document.getElementById('settings-modal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';  // hidden class yetmezse bunu da ekle
            }
            // 2) Haritaya hemen geç
            if (typeof switchTab === 'function') switchTab(0);
            // 3) Her şey yerleştikten sonra turu başlat
            setTimeout(function() {
                if (window.AppTour) window.AppTour.start(true);
            }, 600);
        }

        async function saveSettings() {
            const n = document.getElementById("edit-name").value;
            const b = document.getElementById("edit-bio").value;
            const p = document.getElementById("edit-password").value;
            
            const emailEl = document.getElementById("edit-email");
            const emailInput = emailEl ? emailEl.value.trim() : "";
            
            const stats = currentUser.stats || {};
            let emailChanged = false;
            
            const currentSavedEmail = (stats.email || "").trim().toLowerCase();
            const newEmailNorm = emailInput.toLowerCase();
            
            if (newEmailNorm !== currentSavedEmail && emailInput !== "") {
                // Gerçekten farklı bir email girildiyse değiştir
                emailChanged = true;
                stats.email = emailInput;
                stats.email_verified = false;
            } else if (emailInput === "") {
                // Email alanı boş bırakıldıysa mevcut emaili koru
                // stats.email değişmesin
            }
            // email aynıysa hiçbir şey yapma (email_verified korunur)

            if (p && p.trim() !== "") { 
                if (p.length < 4) return alert("Şifre en az 4 hane olmalı."); 
            }
            
            currentUser.name = n;
            currentUser.bio = b;
            
            const data = { username: currentUser.username, name: n, bio: b };
            if (p && p.trim() !== "") data.password = p;
            
            data.stats = stats;

            try {
                await sendAction('update_user', data);
                
                if (p && p.trim() !== "") {
                    if (localStorage.getItem("fr_remembered_username")) {
                        localStorage.setItem("fr_remembered_password", btoa(unescape(encodeURIComponent(p))));
                    }
                }

                currentUser.stats = stats;
                localStorage.setItem("fr_user", JSON.stringify(currentUser));

                updateProfileUI(); 
                
                if (emailChanged && emailInput !== "") {
                    alert("Profil güncellendi! E-posta adresiniz güncellendi ancak henüz ONAYLANMADI. 'Doğrulama Kodu Gönder' butonuyla e-postanızı onaylayın.");
                } else {
                    alert("Profil başarıyla güncellendi.");
                }
                closeSettingsModal(); 
            } catch(e) {
                alert("Hata oluştu: " + e.message);
            }
        }

        async function requestProfileEmailVerify() {
            const email = document.getElementById("edit-email").value.trim();
            const marketing = document.getElementById("edit-marketing").checked;
            if(!email) return alert("Lütfen bir e-posta adresi girin.");
            
            try {
                await sendAction('send_profile_verification', { email: email, marketing: marketing });
                
                document.getElementById("settings-modal").classList.add("hidden");
                verificationUsername = currentUser.username;
                
                document.getElementById("verify-code-input").value = ""; 
                document.getElementById("email-verify-modal").classList.remove("hidden");
                alert("Doğrulama kodu e-posta adresinize gönderildi!");
            } catch(e) { }
        }

        function openProfilePicUpload() {
            _showPhotoDisclosure('profile', () => { document.getElementById('pic-upload').click(); });
        }

        async function uploadProfilePic(input) {
            if(!input.files[0]) return;
            const file = input.files[0];
            try {
                // Resmi yüklemeden önce sıkıştır/küçült (max 1200px, %85 kalite)
                // Bu, Nginx 413 limitine takılmamak için kritik
                const compressedBlob = await new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        const img = new Image();
                        img.onload = () => {
                            const MAX = 1200;
                            let w = img.width, h = img.height;
                            if (w > MAX || h > MAX) {
                                if (w > h) { h = Math.round(h * MAX / w); w = MAX; }
                                else { w = Math.round(w * MAX / h); h = MAX; }
                            }
                            const canvas = document.createElement('canvas');
                            canvas.width = w; canvas.height = h;
                            canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                            canvas.toBlob((blob) => resolve(blob), 'image/jpeg', 0.85);
                        };
                        img.src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                });

                const formData = new FormData();
                formData.append('file', compressedBlob, 'avatar.jpg');
                formData.append('folder', 'avatars');

                const uploadRes = await fetch('/api/upload', {
                    method: 'POST',
                    body: formData
                });

                // HTML hata sayfası kontrolü (Nginx 413 vs)
                if (!uploadRes.ok) {
                    const text = await uploadRes.text();
                    if (text.trim().startsWith('<')) {
                        throw new Error('Sunucu hatası (' + uploadRes.status + '): Resim çok büyük olabilir.');
                    }
                    throw new Error('Yükleme hatası: ' + uploadRes.status);
                }

                const uploadData = await uploadRes.json();

                let avatarUrl = '';
                if (uploadData.status === 'ok') {
                    avatarUrl = uploadData.url;
                } else {
                    throw new Error(uploadData.message || 'Yükleme başarısız');
                }

                currentUser.avatar = avatarUrl;
                await sendAction('update_user', { username: currentUser.username, avatar: avatarUrl });
                updateProfileUI();
                alert("Profil fotoğrafı güncellendi!");
            } catch(e) {
                alert("Profil fotoğrafı yüklenirken hata oluştu: " + e.message);
                console.error(e);
            }
        }

        // ==============================================================
        // READY PLAYER ME 3D AVATAR
        // ==============================================================
        function openRpmModal() {
            const modal = document.getElementById('rpm-modal');
            const iframe = document.getElementById('rpm-iframe');
            const loading = document.getElementById('rpm-loading');
            modal.classList.remove('hidden');
            loading.classList.remove('hidden');
            iframe.classList.add('hidden');
            // RPM partner subdomain — freeridertr için özel subdomain yoksa genel URL
            const rpmUrl = 'https://freeridertr.readyplayer.me/avatar?frameApi&clearCache';
            iframe.src = rpmUrl;
            iframe.onload = () => {
                loading.classList.add('hidden');
                iframe.classList.remove('hidden');
            };
        }

        function closeRpmModal() {
            const modal = document.getElementById('rpm-modal');
            const iframe = document.getElementById('rpm-iframe');
            modal.classList.add('hidden');
            iframe.src = '';
        }

        // RPM iframe'den mesaj dinle — avatar URL'i gelince kaydet
        window.addEventListener('message', async (event) => {
            if(!event.data || typeof event.data !== 'string') return;
            // RPM, avatar URL'ini JSON veya düz string olarak gönderir
            let avatarUrl = null;
            try {
                const parsed = JSON.parse(event.data);
                if(parsed.source === 'readyplayerme' && parsed.eventName === 'v1.avatar.exported') {
                    avatarUrl = parsed.data?.url;
                }
            } catch(e) {
                // Bazı sürümlerde düz URL gelir
                if(typeof event.data === 'string' && event.data.includes('models.readyplayer.me')) {
                    avatarUrl = event.data;
                }
            }
            if(avatarUrl && currentUser) {
                // PNG render URL'i oluştur (fullbody portrait)
                const renderUrl = avatarUrl.replace('.glb', '.png') + '?scene=fullbody-portrait-v1-transparent&background=transparent&quality=100';
                closeRpmModal();
                // Kaydet
                currentUser.avatar = renderUrl;
                document.getElementById('profile-avatar').src = renderUrl;
                try {
                    await sendAction('update_user', { username: currentUser.username, avatar: renderUrl });
                    localStorage.setItem("fr_user", JSON.stringify(currentUser));
                    updateProfileUI();
                    haptic([50, 30, 100]);
                    // Küçük kutlama toast
                    const t = document.createElement('div');
                    t.className = 'fixed top-20 left-1/2 -translate-x-1/2 z-[99999] bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-3 rounded-2xl font-bold text-sm  flex items-center gap-3 scale-in-anim';
                    t.innerHTML = '<span style="font-size:20px">🎭</span><div><div style="font-size:10px;opacity:0.8;text-transform:uppercase;letter-spacing:0.1em">Avatar Kaydedildi!</div><div>3D avatarın profile eklendi</div></div>';
                    document.body.appendChild(t);
                    setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity 0.5s'; setTimeout(()=>t.remove(),500); }, 3000);
                } catch(e) { alert('Avatar kaydedilemedi: ' + e.message); }
            }
        });

        async function acceptChatRules() {
            await sendAction('accept_chat_rules', {});
            currentUser.accepted_chat_rules = true;
            // Hem fr_user hem de özel anahtar ile kalıcı hale getir
            localStorage.setItem('fr_chat_rules_' + currentUser.username, '1');
            localStorage.setItem("fr_user", JSON.stringify(currentUser));
            document.getElementById("chat-rules-modal").classList.add("hidden");
            alert("Kuralları kabul ettiniz, sisteme hoş geldiniz.");
        }

        // ===============================================================
        // GELİŞMİŞ ADMİN PANELİ - TAM SİSTEM
        // ===============================================================
        let _currentAdminTab = 'overview';
        let _uaCurrentUser = null;
        let _uaCurrentTab = 'messages';
        let _uaActivityData = null;

        function showAdminPanel() {
            const isMainAdmin = (currentUser && (currentUser.role === 'Admin' || currentUser.username === 'Admin' || currentUser.username.toLowerCase() === 'admin'));
            const isSubAdmin  = (currentUser && currentUser.role === 'SubAdmin');

            // Role label
            const roleTag = document.getElementById('admin-panel-role-tag');
            if(roleTag) roleTag.textContent = isMainAdmin ? '👑 Ana Yönetici' : '🛡️ Yardımcı Yönetici';

            // Ana admin only elements
            document.querySelectorAll('.admin-main-only').forEach(el => {
                el.style.display = isMainAdmin ? '' : 'none';
            });
            document.querySelectorAll('.admin-sub-only').forEach(el => {
                el.style.display = isSubAdmin ? '' : 'none';
            });

            // Ekip tab: sadece main admin
            const tabAdmins = document.getElementById('atab-admins');
            if(tabAdmins) tabAdmins.style.display = isMainAdmin ? '' : 'none';

            // Stats güncelle
            document.getElementById('astat-users').textContent = db.users.length;
            document.getElementById('astat-banned').textContent = db.banned.length;

            // Maintenance
            const maintChk = document.getElementById("admin-maintenance");
            if(maintChk) maintChk.checked = db.maintenance;

            // Google Play IAP — Bekleyen manuel onay listesi (main admin only)
            // NOT: Google Play IAP akışında satın alımlar /api/verify_google_purchase
            // üzerinden otomatik doğrulanır. Bu panel yalnızca otomatik doğrulaması
            // başarısız olan veya admin tarafından manuel onay gerektiren durumları gösterir.
            if(isMainAdmin) {
                const reqContainer = document.getElementById("admin-iap-requests");
                reqContainer.innerHTML = "";
                let hasReqs = false;
                db.users.forEach(u => {
                    // pending_premium: otomatik doğrulaması tamamlanamamış IAP'lar
                    if(u.stats && u.stats.pending_premium) {
                        hasReqs = true;
                        const tierNum = parseInt(u.stats.pending_premium);
                        const productId = u.stats.gp_product_id || '—';
                        const pName = tierNum === 3 ? "👑 Ultra+" : (tierNum === 2 ? "🌟 Deluxe" : "⭐ Standart");
                        const isAdminOverride = u.stats.gp_admin_override ? ' (Manuel)' : ' (IAP)';
                        reqContainer.innerHTML += `
                        <div class="rounded-xl p-3 border border-zinc-700/60 flex justify-between items-center admin-card-enter" style="background:rgba(0,0,0,0.5)">
                            <div>
                                <div class="font-bold text-white text-sm">${u.username}</div>
                                <div class="text-[10px] text-yellow-400 font-bold uppercase tracking-widest mt-0.5">${pName}${isAdminOverride}</div>
                                <div class="text-[9px] text-zinc-500 mt-0.5">Product: ${productId}</div>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="approvePrem('${u.username}', ${tierNum})" class="bg-green-800/80 hover:bg-green-700 px-3 py-2 rounded-lg text-[10px] font-bold text-white transition">✓ Onayla</button>
                                <button onclick="rejectPrem('${u.username}')" class="bg-red-900/60 hover:bg-red-800/80 px-3 py-2 rounded-lg text-[10px] font-bold text-white transition">✕ Red</button>
                            </div>
                        </div>`;
                    }
                });
                if(!hasReqs) reqContainer.innerHTML = "<div class='text-zinc-600 text-xs italic py-1 font-medium'>✅ Bekleyen IAP onayı yok.</div>";
            }

            adminSwitchTab('overview');
            document.getElementById("admin-panel").classList.remove("hidden");

            // Load sub-admin count for stats
            loadSubAdminCount();
        }

        async function loadSubAdminCount() {
            try {
                const res = await sendAction('get_all_sub_admins', {});
                if(res && res.sub_admins) {
                    const el = document.getElementById('astat-admins');
                    if(el) { el.textContent = res.sub_admins.length; el.classList.add('count-up-anim'); }
                }
            } catch(e) {}
        }

        function addMarkerFromAdminCoords() {
            const val = document.getElementById('admin-manual-coords').value.trim();
            if(!val) {
                if(typeof showToast === 'function') showToast("Lütfen koordinat girin!", "error");
                else alert("Lütfen koordinat girin!");
                return;
            }
            
            let parts = val.replace(/,/g, ' ').replace(/[\\s]+/g, ' ').split(' ');
            if(parts.length < 2) {
                if(typeof showToast === 'function') showToast("Geçersiz format!", "error");
                else alert("Geçersiz format!");
                return;
            }
            
            let lat = parseFloat(parts[0]);
            let lng = parseFloat(parts[1]);
            
            if(isNaN(lat) || isNaN(lng)) {
                if(typeof showToast === 'function') showToast("Koordinatlar sayı olmalıdır!", "error");
                else alert("Koordinatlar sayı olmalıdır!");
                return;
            }
            
            document.getElementById('admin-panel').classList.add('hidden');
            tempLat = lat;
            tempLng = lng;
            document.getElementById('add-marker-modal').classList.remove('hidden');
            document.getElementById('admin-manual-coords').value = '';
        }

        async function loadLeaderboardPreview() {
            var previewEl = document.getElementById('leaderboard-preview');
            previewEl.innerHTML = '<div style="color:#71717a;text-align:center;font-size:11px">Yukleniyor...</div>';
            try {
                var users = db.users || [];
                var visible = users.filter(function(u) { return u.username !== 'Admin' && u.role !== 'Admin'; });
                var weekly = visible.slice().sort(function(a,b){ return (((b.stats&&b.stats.weekly_xp)||0) - ((a.stats&&a.stats.weekly_xp)||0)); }).slice(0,3);
                var monthly = visible.slice().sort(function(a,b){ return (((b.stats&&b.stats.monthly_xp)||0) - ((a.stats&&a.stats.monthly_xp)||0)); }).slice(0,3);
                var medals = ['1.','2.','3.'];
                var h = '<div style="color:#c084fc;font-size:10px;font-weight:900;text-transform:uppercase;margin-bottom:6px">Haftalik Top 3</div>';
                weekly.forEach(function(u, i) {
                    var xp = ((u.stats&&u.stats.weekly_xp)||0).toLocaleString();
                    h += '<div style="display:flex;justify-content:space-between;padding:3px 0"><span>' + medals[i] + ' ' + u.username + '</span><span style="color:#facc15;font-weight:700">' + xp + ' XP</span></div>';
                });
                h += '<div style="color:#818cf8;font-size:10px;font-weight:900;text-transform:uppercase;margin:10px 0 6px">Aylik Top 3</div>';
                monthly.forEach(function(u, i) {
                    var xp = ((u.stats&&u.stats.monthly_xp)||0).toLocaleString();
                    h += '<div style="display:flex;justify-content:space-between;padding:3px 0"><span>' + medals[i] + ' ' + u.username + '</span><span style="color:#60a5fa;font-weight:700">' + xp + ' XP</span></div>';
                });
                previewEl.innerHTML = h || '<div style="color:#71717a;text-align:center">Veri yok</div>';
            } catch(e) {
                previewEl.innerHTML = '<div style="color:#f87171;text-align:center;font-size:11px">Yuklenemedi</div>';
            }
        }

        async function adminForceEndLeaderboard(period) {
            var label = period === 'weekly' ? 'Haftalik' : 'Aylik';
            var msg1 = label + ' siralamayi erken sonlandirmak istiyor musunuz? Ilk 3 kisiye odul verilecek ve tum XP sifirlanacak.';
            if (!confirm(msg1)) return;
            if (!confirm('Son onay: Bu islem geri alinamaz! Devam?')) return;

            var resultEl = document.getElementById('leaderboard-end-result');
            resultEl.className = 'text-[11px] font-bold p-3 rounded-xl border border-zinc-700 text-zinc-300';
            resultEl.textContent = 'Isleniyor, lutfen bekleyin...';
            resultEl.classList.remove('hidden');

            try {
                var res = await sendAction('admin_force_end_leaderboard', { period: period });
                if (res && res.status === 'ok') {
                    resultEl.className = 'text-[11px] font-bold p-3 rounded-xl border border-green-700/60 text-green-300';
                    var lines = [res.message || 'Tamamlandi.'];
                    if (res.rewarded && res.rewarded.length > 0) {
                        lines.push('Oduller:');
                        var medals = ['1.', '2.', '3.'];
                        res.rewarded.forEach(function(r) {
                            lines.push(medals[r.rank - 1] + ' ' + r.username + ' - ' + r.score.toLocaleString() + ' XP');
                        });
                    }
                    resultEl.innerText = lines.join(String.fromCharCode(10));
                    showToast(label + ' siralama sonlandirildi!', 'success');
                    setTimeout(function() { location.reload(); }, 3000);
                } else {
                    resultEl.className = 'text-[11px] font-bold p-3 rounded-xl border border-red-700/60 text-red-300';
                    resultEl.textContent = 'Hata: ' + ((res && res.message) ? res.message : 'Bilinmeyen hata');
                }
            } catch(err) {
                resultEl.className = 'text-[11px] font-bold p-3 rounded-xl border border-red-700/60 text-red-300';
                resultEl.textContent = 'Istek hatasi: ' + err.message;
            }
        }

        function adminSwitchTab(tab) {
            _currentAdminTab = tab;
            ['overview','users','commands','reports','reels','logs','admins'].forEach(t => {
                const btn = document.getElementById(`atab-${t}`);
                const content = document.getElementById(`admin-tab-${t}`);
                if(btn) btn.className = btn.className.replace(' active-admin-tab','').replace('active-admin-tab','') + (t === tab ? ' active-admin-tab' : '');
                if(content) content.classList.toggle('hidden', t !== tab);
            });
            if(tab === 'users') loadAllUsersForAdmin();
            if(tab === 'reports') loadAdminReports();
            if(tab === 'reels') loadAdminReels();
            if(tab === 'logs') loadAdminLogs();
            if(tab === 'admins') loadSubAdmins();
        }

        let _adminAllUsers = [];
        let _adminUserPage = 1;
        let _adminUserTotal = 0;

        async function loadAllUsersForAdmin(page = 1, search = '') {
            const container = document.getElementById('admin-user-list');
            if(!container) return;
            container.innerHTML = '<div class="text-center text-zinc-500 py-4 text-xs animate-pulse">Kullanıcılar yükleniyor...</div>';
            try {
                const res = await sendAction('get_all_users_admin', { page: page, per_page: 200, search: search });
                if (res && res.users) {
                    _adminAllUsers = res.users;
                    _adminUserPage = res.page || 1;
                    _adminUserTotal = res.total || res.users.length;
                    renderAdminUserList(res.users);
                    // Toplam kullanıcı sayısını stats'a yansıt
                    const statEl = document.getElementById('astat-users');
                    if(statEl) statEl.textContent = _adminUserTotal;
                } else {
                    renderAdminUserList(db.users);
                }
            } catch(e) {
                console.warn('Admin kullanıcı listesi yüklenemedi, fallback:', e);
                renderAdminUserList(db.users);
            }
        }

        function renderAdminUserList(users) {
            const container = document.getElementById('admin-user-list');
            if(!container) return;
            container.innerHTML = '';

            // Pagination info
            if(_adminUserTotal > 0) {
                container.innerHTML += `<div class="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mb-2 px-1">Toplam: ${_adminUserTotal} kullanıcı (Sayfa ${_adminUserPage})</div>`;
            }

            (users || []).forEach((u, i) => {
                const isBanned = db.banned.includes(u.username);
                const premTier = (u.stats && u.stats.premium_tier) ? parseInt(u.stats.premium_tier) : 0;
                const roleLabel = u.role === 'Admin' ? '👑' : (u.role === 'SubAdmin' ? '🛡️' : '');
                const premBadge = premTier === 3 ? '<span class="text-yellow-400 text-[8px] font-black">ULTRA+</span>' : (premTier === 2 ? '<span class="text-purple-400 text-[8px] font-black">DLX</span>' : (premTier === 1 ? '<span class="text-blue-400 text-[8px] font-black">STD</span>' : ''));
                container.innerHTML += `
                <div class="rounded-xl p-3 border flex items-center gap-3 admin-card-enter transition-all hover:border-zinc-600 cursor-pointer" style="background:rgba(0,0,0,0.45);border-color:rgba(63,63,70,0.7);animation-delay:${i*0.03}s" onclick="openUserActivity('${u.username}')">
                    <img src="${u.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg'}" class="w-10 h-10 rounded-full object-cover shrink-0 border-2 ${isBanned ? 'border-sky-600' : 'border-zinc-700'}">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-1.5">
                            <span class="text-white font-bold text-sm truncate">${u.username}</span>
                            <span>${roleLabel}</span>
                            ${premBadge}
                            ${isBanned ? '<span class="ban-reason-badge">Banlı</span>' : ''}
                        </div>
                        <div class="text-zinc-500 text-[10px] font-bold truncate mt-0.5">${u.city || '—'} · ${u.xp || 0} XP</div>
                    </div>
                    <div class="shrink-0 text-zinc-600 text-xs">›</div>
                </div>`;
            });
            if(!users || users.length === 0) container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4">Kullanıcı bulunamadı.</div>';
        }

        function adminSearchUsers() {
            const q = document.getElementById('admin-user-search').value.toLowerCase().trim();
            const filtered = q ? db.users.filter(u => u.username.toLowerCase().includes(q) || (u.city||'').toLowerCase().includes(q)) : db.users;
            renderAdminUserList(filtered);
        }

        async function loadAdminReels() {
            const container = document.getElementById('admin-reels-list');
            if(!container) return;
            container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4 animate-pulse">Yükleniyor...</div>';
            try {
                const res = await sendAction('get_reels', {offset: 0});
                const reels = (res && res.reels) ? res.reels : [];
                container.innerHTML = '';
                if(!reels.length) { container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4">Reel bulunamadı.</div>'; return; }
                reels.forEach((r, i) => {
                    const isVideo = r.media_type === 'video';
                    const dt = r.created_at ? new Date(r.created_at * 1000).toLocaleDateString('tr-TR') : '—';
                    container.innerHTML += `
                    <div class="rounded-xl p-3 border border-zinc-800/70 flex items-center gap-3 admin-card-enter" style="background:rgba(0,0,0,0.5);animation-delay:${i*0.04}s">
                        <div class="w-14 h-14 rounded-xl overflow-hidden shrink-0 border border-zinc-700 bg-zinc-900 flex items-center justify-center">
                            ${isVideo ? `<span class="text-2xl">🎥</span>` : `<img src="${r.media_url}" class="w-full h-full object-cover">`}
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="text-white font-bold text-sm truncate">${r.user}</div>
                            <div class="text-zinc-500 text-[10px] font-bold mt-0.5 truncate">${r.caption || '(Açıklama yok)'}</div>
                            <div class="flex items-center gap-2 mt-1">
                                <span class="text-zinc-600 text-[9px] font-bold">${dt}</span>
                                <span class="text-pink-500 text-[9px] font-bold">❤ ${(r.likes||[]).length}</span>
                                <span class="text-zinc-500 text-[9px] font-bold">${isVideo ? '🎥 Video' : '📸 Foto'}</span>
                            </div>
                        </div>
                        <button onclick="adminDeleteReel('${r.id}', '${r.user}', this)" class="shrink-0 w-8 h-8 rounded-lg bg-red-900/40 border border-sky-800/50 text-sky-300 hover:bg-sky-800/60 flex items-center justify-center text-sm transition hover:scale-110">🗑</button>
                    </div>`;
                });
            } catch(e) {
                container.innerHTML = '<div class="text-sky-400 text-xs italic text-center py-4">Yüklenirken hata oluştu.</div>';
            }
        }

        async function adminDeleteReel(reelId, owner, btn) {
            if(!confirm(`${owner} adlı kullanıcının reelini silmek istediğine emin misin?`)) return;
            btn.disabled = true; btn.textContent = '...';
            const res = await sendAction('delete_reel', {reel_id: reelId});
            if(res && res.status === 'ok') {
                btn.closest('.rounded-xl').style.opacity = '0.3';
                btn.textContent = '✓';
                showToast(`🗑️ Reel silindi.`);
            }
        }

        async function loadAdminLogs() {
            const container = document.getElementById('admin-logs-list');
            if(!container) return;
            container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4 animate-pulse">Yükleniyor...</div>';
            try {
                const res = await sendAction('get_admin_logs', {});
                const logs = (res && res.logs) ? res.logs : [];
                container.innerHTML = '';
                if(!logs.length) { container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4">Henüz kayıt yok.</div>'; return; }
                const actionColors = { ban_user: 'log-ban', delete_reel: 'log-delete', delete_message: 'log-delete', delete_marker: 'log-delete', assign_admin: 'log-assign', revoke_admin: 'log-revoke', notify_main: 'log-notify' };
                const actionEmojis = { ban_user: '🚨', delete_reel: '🎬', delete_message: '💬', delete_marker: '📍', assign_admin: '✅', revoke_admin: '❌', notify_main: '📢' };
                logs.forEach((l, i) => {
                    const colorClass = actionColors[l.action] || 'log-default';
                    const emoji = actionEmojis[l.action] || '🔧';
                    const dt = l.ts ? new Date(l.ts * 1000).toLocaleString('tr-TR') : '—';
                    container.innerHTML += `
                    <div class="rounded-xl p-3 pl-4 admin-card-enter ${colorClass}" style="background:rgba(0,0,0,0.5);animation-delay:${i*0.03}s">
                        <div class="flex items-center justify-between gap-2">
                            <div class="flex items-center gap-2 min-w-0">
                                <span class="text-sm shrink-0">${emoji}</span>
                                <div class="min-w-0">
                                    <div class="text-white text-xs font-bold"><span class="text-red-300">${l.admin}</span> → <span class="text-zinc-300">${l.target || '—'}</span></div>
                                    <div class="text-zinc-500 text-[10px] font-bold truncate mt-0.5">${l.detail || l.action}</div>
                                </div>
                            </div>
                            <div class="text-zinc-600 text-[9px] font-bold shrink-0">${dt}</div>
                        </div>
                    </div>`;
                });
            } catch(e) {
                container.innerHTML = '<div class="text-sky-400 text-xs italic text-center py-4">Yüklenirken hata oluştu.</div>';
            }
        }

        function togglePushTargetInput() {
            const targetType = document.getElementById('push-target-type').value;
            const usernamesInput = document.getElementById('push-usernames');
            if (targetType === 'all') {
                usernamesInput.style.display = 'none';
                usernamesInput.value = '';
            } else {
                usernamesInput.style.display = 'block';
            }
        }

        async function sendCustomPushNotification() {
            const targetType = document.getElementById('push-target-type').value;
            const usernames = (document.getElementById('push-usernames').value || '').trim();
            const title = (document.getElementById('push-title').value || '').trim();
            const message = (document.getElementById('push-message').value || '').trim();
            const resultDiv = document.getElementById('test-push-result');
            
            if (!title || !message) {
                resultDiv.className = 'text-[11px] font-bold p-3 rounded-xl border border-red-800 bg-red-950/40 text-red-300';
                resultDiv.textContent = '⚠️ Başlık ve mesaj boş olamaz!';
                resultDiv.classList.remove('hidden');
                return;
            }

            if (targetType === 'specific' && !usernames) {
                resultDiv.className = 'text-[11px] font-bold p-3 rounded-xl border border-red-800 bg-red-950/40 text-red-300';
                resultDiv.textContent = '⚠️ Kullanıcı adları boş olamaz!';
                resultDiv.classList.remove('hidden');
                return;
            }

            resultDiv.className = 'text-[11px] font-bold p-3 rounded-xl border border-zinc-700 bg-black/40 text-zinc-400 animate-pulse';
            resultDiv.textContent = '⏳ Bildirim gönderiliyor...';
            resultDiv.classList.remove('hidden');
            try {
                const res = await sendAction('admin_send_custom_push', { targetType, usernames, title, message });
                if (res && res.status === 'ok') {
                    resultDiv.className = 'text-[11px] font-bold p-3 rounded-xl border border-emerald-800 bg-emerald-950/40 text-emerald-300';
                    resultDiv.textContent = '✅ ' + (res.message || 'Bildirim başarıyla gönderildi!');
                    setTimeout(() => loadAdminLogs(), 3500);
                } else {
                    resultDiv.className = 'text-[11px] font-bold p-3 rounded-xl border border-red-800 bg-red-950/40 text-red-300';
                    resultDiv.textContent = '❌ Hata: ' + (res && res.message ? res.message : 'Bilinmeyen hata');
                }
            } catch(e) {
                resultDiv.className = 'text-[11px] font-bold p-3 rounded-xl border border-red-800 bg-red-950/40 text-red-300';
                resultDiv.textContent = '❌ Sunucu bağlantı hatası: ' + e.message;
            }
        }

        async function loadSubAdmins() {

            const container = document.getElementById('sub-admin-list');
            if(!container) return;
            container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-3 animate-pulse">Yükleniyor...</div>';
            try {
                const res = await sendAction('get_all_sub_admins', {});
                const admins = (res && res.sub_admins) ? res.sub_admins : [];
                const el2 = document.getElementById('astat-admins');
                if(el2) el2.textContent = admins.length;
                container.innerHTML = '';
                if(!admins.length) { container.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-3">Henüz yardımcı admin yok.</div>'; return; }
                admins.forEach((a, i) => {
                    container.innerHTML += `
                    <div class="flex items-center gap-3 p-2.5 rounded-xl admin-card-enter" style="background:rgba(0,0,0,0.4);animation-delay:${i*0.05}s">
                        <img src="${a.avatar || 'https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg'}" class="w-9 h-9 rounded-full object-cover border border-amber-700/60">
                        <div class="flex-1 min-w-0">
                            <div class="text-amber-300 font-bold text-sm truncate">${a.username}</div>
                            <div class="text-zinc-600 text-[10px] font-bold">${a.xp || 0} XP</div>
                        </div>
                        <button onclick="quickRevokeAdmin('${a.username}', this)" class="shrink-0 px-3 py-1.5 rounded-lg bg-sky-900/30 border border-sky-800/50 text-sky-300 hover:bg-sky-800/50 text-[10px] font-bold transition">Yetkiyi Al</button>
                    </div>`;
                });
            } catch(e) {
                container.innerHTML = '<div class="text-sky-400 text-xs italic text-center py-3">Yüklenirken hata oluştu.</div>';
            }
        }

        async function assignSubAdmin() {
            const uname = document.getElementById('assign-admin-username').value.trim();
            if(!uname) { showToast('Kullanıcı adı gir!'); return; }
            if(!confirm(`${uname} adlı kullanıcıya yardımcı admin yetkisi verilecek. Emin misin?`)) return;
            const res = await sendAction('assign_sub_admin', {username: uname});
            if(res && res.status === 'ok') {
                showToast(`✅ ${uname} artık yardımcı admin!`);
                document.getElementById('assign-admin-username').value = '';
                loadSubAdmins();
            } else {
                alert(res?.message || 'Hata oluştu.');
            }
        }

        async function revokeSubAdmin() {
            const uname = document.getElementById('revoke-admin-username').value.trim();
            if(!uname) { showToast('Kullanıcı adı gir!'); return; }
            if(!confirm(`${uname} adlı kullanıcının admin yetkisi alınacak. Emin misin?`)) return;
            const res = await sendAction('revoke_sub_admin', {username: uname});
            if(res && res.status === 'ok') {
                showToast(`❌ ${uname} yetkisi alındı.`);
                document.getElementById('revoke-admin-username').value = '';
                loadSubAdmins();
            } else {
                alert(res?.message || 'Hata oluştu.');
            }
        }

        async function quickRevokeAdmin(uname, btn) {
            if(!confirm(`${uname} yöneticilikten çıkarılsın mı?`)) return;
            btn.disabled = true; btn.textContent = '...';
            const res = await sendAction('revoke_sub_admin', {username: uname});
            if(res && res.status === 'ok') {
                btn.closest('.rounded-xl').style.opacity = '0.3';
                showToast(`❌ ${uname} yetkisi alındı.`);
                loadSubAdmins();
            }
        }

        async function adminNotifyMain() {
            const msg = document.getElementById('admin-notify-msg').value.trim();
            if(!msg) { showToast('Mesaj boş olamaz!'); return; }
            const res = await sendAction('admin_notify_main', {message: msg});
            if(res && res.status === 'ok') {
                document.getElementById('admin-notify-msg').value = '';
                showToast('📨 Ana admine bildirim gönderildi!');
            }
        }

        // ---- Kullanıcı Aktivite Modalı ----
        async function openUserActivity(username) {
            _uaCurrentUser = username;
            _uaActivityData = null;
            document.getElementById('ua-username-label').textContent = '@' + username;
            document.getElementById('ua-content').innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-6 animate-pulse">Yükleniyor...</div>';
            document.getElementById('user-activity-modal').classList.remove('hidden');
            uaTab('messages');

            try {
                const res = await sendAction('get_user_activity', {username});
                if(res && res.activity) {
                    _uaActivityData = res.activity;
                    uaRender(_uaCurrentTab);
                }
            } catch(e) {
                document.getElementById('ua-content').innerHTML = '<div class="text-sky-300 text-xs italic text-center py-6">Yüklenirken hata oluştu.</div>';
            }
        }

        function uaTab(tab) {
            _uaCurrentTab = tab;
            ['messages','dms','reels','markers','manage'].forEach(t => {
                const btn = document.getElementById(`uatab-${t}`);
                if(btn) {
                    btn.className = btn.className.replace(' ua-active-tab','').replace('ua-active-tab','');
                    if(t === tab) btn.className += ' ua-active-tab';
                }
            });
            if(_uaActivityData) uaRender(tab);
        }

        function uaRender(tab) {
            const container = document.getElementById('ua-content');
            if(!container || !_uaActivityData) return;
            const data_ua = _uaActivityData[tab] || [];
            container.innerHTML = '';
            if(!data_ua.length && tab !== 'manage') {
                container.innerHTML = `<div class="text-zinc-600 text-xs italic text-center py-6">Bu kategoride içerik yok.</div>`;
                return;
            }
            if(tab === 'manage') {
                const isMainAdmin = (currentUser && (currentUser.role === 'Admin' || currentUser.username === 'Admin' || currentUser.username.toLowerCase() === 'admin'));
                if(!isMainAdmin) {
                    container.innerHTML = `<div class="text-zinc-600 text-xs italic text-center py-6">Bu sekmeye erişim yetkiniz yok.</div>`;
                    return;
                }
                const targetUser = db.users.find(u => u.username === _uaCurrentUser) || {username: _uaCurrentUser};
                const stat = targetUser.stats ? (typeof targetUser.stats === 'string' ? JSON.parse(targetUser.stats) : targetUser.stats) : {};
                const premTier = stat.premium_tier || 0;
                let premText = "Premium Yok";
                if(premTier === 1) premText = "Standart";
                if(premTier === 2) premText = "Deluxe";
                if(premTier === 3) premText = "Ultra+";

                container.innerHTML = `
                <div class="space-y-3">
                    <div class="p-4 rounded-xl border border-zinc-800" style="background:rgba(0,0,0,0.4)">
                        <div class="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-3">Kullanıcı Detayları</div>
                        <div class="text-xs text-white mb-1"><span class="text-zinc-400">Şehir:</span> ${targetUser.city || 'Bilinmiyor'}</div>
                        <div class="text-xs text-white mb-1"><span class="text-zinc-400">XP:</span> ${targetUser.xp || 0}</div>
                        <div class="text-xs text-white mb-1"><span class="text-zinc-400">Rol:</span> ${targetUser.role || 'User'}</div>
                        <div class="text-xs text-white mb-3"><span class="text-zinc-400">Premium:</span> <span class="text-yellow-400 font-bold">${premText}</span></div>
                    </div>
                    <div class="p-4 rounded-xl border border-amber-900/30" style="background:rgba(120,53,15,0.1)">
                        <div class="text-[10px] text-amber-500 uppercase font-bold tracking-widest mb-3">Üyelik / Premium İşlemleri</div>
                        <div class="grid grid-cols-2 gap-2 mb-2">
                            <button onclick="execAdminCmd('${targetUser.username} standart gönder')" class="py-2 bg-blue-900/40 text-blue-300 text-[10px] font-bold rounded  hover:bg-blue-800/50 transition border border-blue-800/50">+ Standart Ver</button>
                            <button onclick="execAdminCmd('${targetUser.username} deluxe gönder')" class="py-2 bg-purple-900/40 text-purple-300 text-[10px] font-bold rounded  hover:bg-purple-800/50 transition border border-purple-800/50">+ Deluxe Ver</button>
                            <button onclick="execAdminCmd('${targetUser.username} ultra gönder')" class="py-2 bg-yellow-900/40 text-yellow-300 text-[10px] font-bold rounded  hover:bg-yellow-800/50 transition border border-yellow-800/50">+ Ultra+ Ver</button>
                            <button onclick="execAdminCmd('${targetUser.username} standart geri çek')" class="py-2 bg-red-900/40 text-red-300 text-[10px] font-bold rounded  hover:bg-red-800/50 transition border border-red-800/50">❌ Süre Sil</button>
                        </div>
                        <div class="text-[9px] text-zinc-500 font-bold">Not: Zaten premiumu varsa 'Ver' diyerek süresini uzatabilirsiniz.</div>
                    </div>
                    <div class="p-4 rounded-xl border border-zinc-800" style="background:rgba(0,0,0,0.4)">
                        <div class="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-3">Tehlikeli İşlemler</div>
                        <div class="space-y-2">
                            <button onclick="adminResetPassword('${targetUser.username}')" class="w-full py-2 bg-zinc-800 text-zinc-300 text-xs font-bold rounded hover:bg-zinc-700 transition">🔑 Şifre Sıfırla (Rastgele)</button>
                            <button onclick="adminChangeUsername('${targetUser.username}')" class="w-full py-2 bg-zinc-800 text-zinc-300 text-xs font-bold rounded hover:bg-zinc-700 transition">✏️ İsim Değiştir</button>
                            <button onclick="adminDeleteUser('${targetUser.username}')" class="w-full py-2 bg-red-950/50 border border-sky-900/50 text-sky-400 text-xs font-bold rounded hover:bg-sky-900/40 transition">🗑️ Hesabı Kalıcı Sil</button>
                        </div>
                    </div>
                </div>`;
                return;
            }
            if(tab === 'messages') {
                data_ua.forEach((m, i) => {
                    const txt = m.text ? String(m.text).substring(0,120) : (m.type || '?');
                    container.innerHTML += `
                    <div class="rounded-xl p-3 border border-zinc-800/70 flex items-start gap-2 admin-card-enter" style="background:rgba(0,0,0,0.45);animation-delay:${i*0.03}s">
                        <div class="flex-1 min-w-0">
                            <div class="text-zinc-300 text-xs font-medium">${txt}</div>
                            ${m.image ? `<div class="text-[9px] text-zinc-600 mt-1">📸 Görsel içerik</div>` : ''}
                        </div>
                        <button onclick="adminDelMsg('${m.id}', this)" class="shrink-0 w-7 h-7 bg-sky-900/30 border border-red-800/40 rounded-lg text-sky-300 hover:bg-sky-800/50 flex items-center justify-center text-[10px] transition">🗑</button>
                    </div>`;
                });
            } else if(tab === 'dms') {
                data_ua.forEach((m, i) => {
                    const others = (m.participants || []).filter(p => p !== _uaCurrentUser);
                    const txt = m.text ? String(m.text).substring(0,100) : (m.type || '?');
                    container.innerHTML += `
                    <div class="rounded-xl p-3 border border-zinc-800/70 admin-card-enter" style="background:rgba(0,0,0,0.45);animation-delay:${i*0.03}s">
                        <div class="text-[10px] text-zinc-500 font-bold mb-1">↔ ${others.join(', ') || '?'}</div>
                        <div class="text-zinc-300 text-xs font-medium">${txt}</div>
                    </div>`;
                });
            } else if(tab === 'reels') {
                data_ua.forEach((r, i) => {
                    const isVideo = r.media_type === 'video';
                    container.innerHTML += `
                    <div class="rounded-xl p-3 border border-zinc-800/70 flex items-center gap-3 admin-card-enter" style="background:rgba(0,0,0,0.45);animation-delay:${i*0.04}s">
                        <div class="w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                            ${isVideo ? `<span class="text-xl">🎥</span>` : `<img src="${r.media_url}" class="w-full h-full object-cover" onerror="this.parentElement.innerHTML='📸'">`}
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="text-zinc-300 text-xs font-medium truncate">${r.caption || '(Açıklama yok)'}</div>
                            <div class="text-pink-400 text-[9px] font-bold mt-0.5">❤ ${(r.likes||[]).length}</div>
                        </div>
                        <button onclick="adminDeleteReel('${r.id}','${r.user}',this)" class="shrink-0 w-7 h-7 bg-sky-900/30 border border-red-800/40 rounded-lg text-sky-300 hover:bg-sky-800/50 flex items-center justify-center text-[10px] transition">🗑</button>
                    </div>`;
                });
            } else if(tab === 'markers') {
                data_ua.forEach((m, i) => {
                    container.innerHTML += `
                    <div class="rounded-xl p-3 border border-zinc-800/70 flex items-center gap-3 admin-card-enter" style="background:rgba(0,0,0,0.45);animation-delay:${i*0.04}s">
                        <div class="w-10 h-10 rounded-lg bg-sky-900/30 border border-red-800/40 flex items-center justify-center text-xl shrink-0">${m.icon_type || '🚴'}</div>
                        <div class="flex-1 min-w-0">
                            <div class="text-white text-sm font-bold truncate">${m.name || '—'}</div>
                            <div class="text-zinc-500 text-[10px] font-bold">${m.difficulty || '—'}</div>
                        </div>
                        <button onclick="adminDelMarker('${m.id}','${m.name}',this)" class="shrink-0 w-7 h-7 bg-sky-900/30 border border-red-800/40 rounded-lg text-sky-300 hover:bg-sky-800/50 flex items-center justify-center text-[10px] transition">🗑</button>
                    </div>`;
                });
            }
        }

        async function adminDelMsg(msgId, btn) {
            if(!confirm('Bu mesajı silmek istediğine emin misin?')) return;
            btn.disabled = true; btn.textContent = '...';
            const res = await sendAction('admin_delete_message_by_id', {msg_id: msgId});
            if(res && res.status === 'ok') {
                btn.closest('.rounded-xl').style.opacity = '0.2';
                showToast('💬 Mesaj silindi.');
            }
        }

        async function adminDelMarker(markerId, markerName, btn) {
            if(!confirm(`"${markerName}" yerini silmek istediğine emin misin?`)) return;
            btn.disabled = true; btn.textContent = '...';
            const res = await sendAction('admin_delete_marker_by_id', {marker_id: markerId});
            if(res && res.status === 'ok') {
                btn.closest('.rounded-xl').style.opacity = '0.2';
                showToast('📍 Yer silindi.');
            }
        }

        async function adminBanFromActivity() {
            if(!_uaCurrentUser) return;
            const reason = prompt(`${_uaCurrentUser} adlı kullanıcıyı banlamak için sebep gir:`);
            if(!reason) return;
            const res = await sendAction('admin_ban_user', {username: _uaCurrentUser, reason});
            if(res && res.status === 'ok') {
                db.banned.push(_uaCurrentUser);
                document.getElementById('user-activity-modal').classList.add('hidden');
                showToast(`🚨 ${_uaCurrentUser} banlandı.`);
                document.getElementById('astat-banned').textContent = db.banned.length;
            }
        }

        async function approvePrem(u, tier) { await sendAction('admin_approve_premium', {username: u, tier: tier}); showToast('✅ Abonelik onaylandı!'); showAdminPanel(); }
        async function rejectPrem(u) { await sendAction('admin_reject_premium', {username: u}); showToast('❌ Abonelik reddedildi.'); showAdminPanel(); }
        async function toggleMaintenance() { const chk = document.getElementById("admin-maintenance").checked; await sendAction('toggle_maintenance', {status: chk}); showToast(chk ? '🔧 Bakım modu açıldı' : '✅ Bakım modu kapatıldı'); }
        async function delMsg(id) { if(confirm("Mesajı sil?")) { await sendAction('delete_message', {id: id}); db.messages = db.messages.filter(m=>m.id!==id); renderChat(true); } }
        async function pinMsg(id) {
            const m = db.messages.find(x => x.id === id);
            if(m && m.type === "text") {
                await sendAction('pin_message', { text: m.text, user: m.user, expires: Date.now() + (24*60*60*1000) });
                showToast('📌 Mesaj 24 saat sabitlendi!');
            }
        }

        // ==== 3D ÇARK MOTORU ====
        let _wheelAngle = 0;
        let _wheelSpinning = false;
        let _winnerIndex = -1;

        // Çark global state — açıkça tanımla (implicit global hatalarını önler)
        if(typeof window._wheelAngle    === 'undefined') window._wheelAngle    = 0;
        if(typeof window._wheelSpinning === 'undefined') window._wheelSpinning = false;
        if(typeof window._winnerIndex   === 'undefined') window._winnerIndex   = -1;

        function initWheel3D() {
            const canvas = document.getElementById('wheel-canvas-3d');
            if(!canvas) { console.warn('[Çark] wheel-canvas-3d bulunamadı.'); return; }
            window._winnerIndex   = -1;
            window._wheelSpinning = false;
            _drawWheel3D(canvas, window._wheelAngle);
        }

        function _drawWheel3D(canvas, angle) {
            const ctx = canvas.getContext('2d');
            const W = canvas.width, H = canvas.height;
            const cx = W/2, cy = H/2;
            const R = W/2 - 6;
            const prizes = window.WHEEL_PRIZES || [];
            const n = prizes.length;
            if(n === 0) return;
            const slice = (Math.PI * 2) / n;
            ctx.clearRect(0, 0, W, H);

            // Dış parlak halka
            const glowGrd = ctx.createRadialGradient(cx,cy,R-4,cx,cy,R+8);
            glowGrd.addColorStop(0,'rgba(234,179,8,0.0)');
            glowGrd.addColorStop(1,'rgba(234,179,8,0.35)');
            ctx.beginPath(); ctx.arc(cx,cy,R+6,0,Math.PI*2);
            ctx.fillStyle=glowGrd; ctx.fill();

            // Dilimleri çiz
            prizes.forEach((p, i) => {
                // İbre saat 12'de (üstte) → -Math.PI/2 offset
                const startA = angle + i * slice - Math.PI/2;
                const endA = startA + slice;
                const mid = startA + slice/2;

                const isWinner = (_winnerIndex === i);
                const baseColor = p.color || '#0ea5e9';

                // Dilim
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.arc(cx, cy, R, startA, endA);
                ctx.closePath();
                if(isWinner) {
                    const winGrd = ctx.createRadialGradient(
                        cx + Math.cos(mid)*R*0.5, cy + Math.sin(mid)*R*0.5, 0,
                        cx + Math.cos(mid)*R*0.5, cy + Math.sin(mid)*R*0.5, R*0.7
                    );
                    winGrd.addColorStop(0,'#fffde7');
                    winGrd.addColorStop(0.5,'#fbbf24');
                    winGrd.addColorStop(1,'#b45309');
                    ctx.fillStyle = winGrd;
                } else {
                    ctx.fillStyle = baseColor;
                }
                ctx.fill();
                // Kenarlık
                ctx.strokeStyle = isWinner ? '#fbbf24' : 'rgba(0,0,0,0.35)';
                ctx.lineWidth = isWinner ? 4 : 1.5;
                ctx.stroke();

                // Parlaklık efekti
                const shineGrd = ctx.createRadialGradient(
                    cx + Math.cos(mid)*R*0.4, cy + Math.sin(mid)*R*0.4, 0,
                    cx + Math.cos(mid)*R*0.4, cy + Math.sin(mid)*R*0.4, R*0.6
                );
                shineGrd.addColorStop(0,'rgba(255,255,255,0.20)');
                shineGrd.addColorStop(1,'rgba(0,0,0,0.0)');
                ctx.beginPath();
                ctx.moveTo(cx,cy);
                ctx.arc(cx,cy,R,startA,endA);
                ctx.closePath();
                ctx.fillStyle = shineGrd;
                ctx.fill();

                // Metin
                ctx.save();
                ctx.translate(cx + Math.cos(mid)*(R*0.64), cy + Math.sin(mid)*(R*0.64));
                ctx.rotate(mid + Math.PI/2);
                ctx.fillStyle = isWinner ? '#1c0a00' : '#ffffff';
                ctx.textAlign = 'center';
                ctx.Color = isWinner ? 'rgba(255,220,100,0.6)' : 'rgba(0,0,0,0.9)';
                ctx.Blur = 4;
                const nameParts = (p.name || '').split(' ');
                if(nameParts.length >= 2) {
                    ctx.font = `bold ${isWinner ? '10' : '9'}px sans-serif`;
                    ctx.fillText(nameParts[0], 0, -5);
                    ctx.fillText(nameParts.slice(1).join(' '), 0, 6);
                } else {
                    ctx.font = `bold ${isWinner ? '11' : '10'}px sans-serif`;
                    ctx.fillText(p.name || '', 0, 2);
                }
                ctx.restore();
            });

            // Merkez daire
            const cGrd = ctx.createRadialGradient(cx-4,cy-4,0,cx,cy,26);
            cGrd.addColorStop(0,'#71717a');
            cGrd.addColorStop(1,'#18181b');
            ctx.beginPath(); ctx.arc(cx,cy,26,0,Math.PI*2);
            ctx.fillStyle=cGrd; ctx.fill();
            ctx.strokeStyle='rgba(255,255,255,0.15)'; ctx.lineWidth=2.5; ctx.stroke();

            // Dönüş hızı görsel — çark dönerken radyal çizgiler
            if(_wheelSpinning) {
                ctx.save();
                const lineCount = 18;
                for(let li = 0; li < lineCount; li++) {
                    const a = angle + li * (Math.PI*2/lineCount);
                    const opacity = (li % 2 === 0) ? 0.10 : 0.05;
                    ctx.strokeStyle = `rgba(255,255,255,${opacity})`;
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.moveTo(cx + Math.cos(a)*28, cy + Math.sin(a)*28);
                    ctx.lineTo(cx + Math.cos(a)*R, cy + Math.sin(a)*R);
                    ctx.stroke();
                }
                ctx.restore();
            }

            // Kazanan dilim etrafında parlayan halka
            if(!_wheelSpinning && _winnerIndex >= 0) {
                ctx.save();
                const wStartA = angle + _winnerIndex * slice - Math.PI/2;
                const wEndA = wStartA + slice;
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.arc(cx, cy, R + 5, wStartA, wEndA);
                ctx.closePath();
                ctx.strokeStyle = 'rgba(251,191,36,0.85)';
                ctx.lineWidth = 5;
                ctx.Color = '#fbbf24';
                ctx.Blur = 18;
                ctx.stroke();
                ctx.restore();
            }
        }

        // Init wheel when spin modal opens


        function updateSpinInfo() {
            const el = document.getElementById('spin-inline-info');
            if(!el || !currentUser) return;
            const stats = currentUser.stats || {};
            const prem = parseInt(stats.premium_tier) || 0;
            const maxSpins = prem >= 2 ? 2 : 1;
            const today = new Date().toISOString().slice(0,10);
            const count = stats.last_spin_date === today ? (stats.spin_count || 0) : 0;
            const left = Math.max(0, maxSpins - count);
            el.textContent = left > 0 ? `${left} hak kaldı` : 'Bugün bitti';
            el.className = left > 0
                ? 'text-[10px] text-green-400 font-bold uppercase tracking-widest text-right'
                : 'text-[10px] text-sky-300 font-bold uppercase tracking-widest text-right';
        }

        async function spinWheelAction() {
            const btn = document.getElementById('spin-btn');
            if(!btn || btn.disabled || window._wheelSpinning) return;
            btn.disabled = true;
            window._wheelSpinning = true;
            btn.innerText = "DÖNÜYOR...";
            haptic([20,10,20,10,20]);

            try {
                const res = await sendAction('daily_spin', {});
                if(res.status !== 'ok') {
                    showToast(res.message || 'Hata oluştu.', 'error', 3000);
                    btn.disabled = false;
                    window._wheelSpinning = false;
                    btn.innerText = "ÇARKI ÇEVİR";
                    return;
                }

                const prizes = window.WHEEL_PRIZES || [];
                const prizeIndex = prizes.findIndex(p => p.id === res.prize_id);
                const n = prizes.length;
                if(prizeIndex < 0 || n === 0) { alert("Hata: ödül bulunamadı."); return; }

                const sliceAngle = (Math.PI * 2) / n;

                // İbre üstte (saat 12 = -Math.PI/2).
                // Kazanan dilim index=prizeIndex, merkezinin açısı: prizeIndex*sliceAngle + sliceAngle/2
                // Bunu üste getirmek için: _wheelAngle = -(prizeIndex*sliceAngle + sliceAngle/2)
                // Ama mevcut _wheelAngle'dan devam etmeli + en az 8 tam tur dönsün
                const currentNorm = ((window._wheelAngle % (Math.PI*2)) + Math.PI*2) % (Math.PI*2);
                const targetSliceCenter = prizeIndex * sliceAngle + sliceAngle / 2;
                // Hedef: çarkın açısı = -targetSliceCenter (yani o dilim tam üste gelsin)
                const targetNorm = ((-targetSliceCenter) % (Math.PI*2) + Math.PI*2) % (Math.PI*2);
                let delta = targetNorm - currentNorm;
                if(delta < 0) delta += Math.PI*2;
                // En az 8 tam tur + biraz daha
                const extraSpins = Math.PI * 2 * (8 + Math.floor(Math.random()*4));
                const finalAngle = window._wheelAngle + extraSpins + delta;

                // Tick sound
                const tickSound = document.getElementById('spin-tick-sound');

                const canvas = document.getElementById('wheel-canvas-3d');
                const start = performance.now();
                const duration = 6500;
                const startAngle = window._wheelAngle;
                const totalAngle = finalAngle - startAngle;
                let lastTickSlice = -1;

                // Çarkı dönerken parlat
                if(canvas) canvas.classList.add('wheel-spinning-canvas');

                function easeInOut(t) {
                    return t < 0.5
                        ? 4 * t * t * t
                        : 1 - Math.pow(-2 * t + 2, 3) / 2;
                }

                function animate(now) {
                    const elapsed = now - start;
                    const t = Math.min(elapsed / duration, 1);
                    const eased = easeInOut(t);
                    window._wheelAngle = startAngle + totalAngle * eased;

                    // 3D tilt — sadece orta hızda belirgin, başta ve sonda sıfır
                    const tiltEnvelope = Math.sin(t * Math.PI); // 0→1→0
                    const tiltX = Math.sin(elapsed * 0.004) * tiltEnvelope * 12;
                    if(canvas) {
                        canvas.style.transform = `rotateX(${tiltX}deg)`;
                        _drawWheel3D(canvas, window._wheelAngle);
                    }

                    // Slice sınırına göre tick sesi (gerçekçi tık-tık)
                    const tickSound = document.getElementById('spin-tick-sound');
                    const currentSlice = Math.floor(((window._wheelAngle % (Math.PI*2) + Math.PI*2) % (Math.PI*2)) / sliceAngle);
                    if(currentSlice !== lastTickSlice && t > 0.05 && t < 0.97) {
                        lastTickSlice = currentSlice;
                        if(tickSound) {
                            tickSound.currentTime = 0;
                            try { tickSound.play().catch(()=>{}); } catch(e){}
                        }
                    }

                    if(t < 1) {
                        requestAnimationFrame(animate);
                    } else {
                        if(canvas) {
                            canvas.classList.remove('wheel-spinning-canvas');
                            canvas.style.transform = '';
                        }
                        // Kazanan dilimi vurgula + kısa pulse animasyonu
                        window._winnerIndex = prizeIndex;
                        _drawWheel3D(canvas, window._wheelAngle);

                        // Kazanan için 3 kez kısa parlama
                        let pulseCount = 0;
                        const pulseInterval = setInterval(() => {
                            pulseCount++;
                            if(canvas) {
                                canvas.style.boxShadow = pulseCount % 2 === 1
                                    ? '0 0 60px rgba(251,191,36,1), 0 0 120px rgba(251,191,36,0.6)'
                                    : '0 0 35px rgba(14,165,233,0.5), 0 0 60px rgba(234,179,8,0.2)';
                            }
                            if(pulseCount >= 6) {
                                clearInterval(pulseInterval);
                                if(canvas) canvas.style.boxShadow = '';
                            }
                        }, 180);
                        window._wheelSpinning = false;
                        btn.disabled = false;
                        btn.innerText = "ÇARKI ÇEVİR";

                        // Win sound + confetti
                        const winSound = document.getElementById('spin-win-sound');
                        if(winSound) { winSound.currentTime=0; try{winSound.play().catch(()=>{});}catch(e){} }
                        haptic([100,50,100,50,200]);
                        showSpinConfetti();

                        setTimeout(async () => {
                            // Güzel sonuç banner'ı göster
                            showSpinResult(res.prize_name);
                            // loadData yerine sadece spin sayacını ve XP'yi local güncelle
                            if(currentUser && currentUser.stats) {
                                const today = new Date().toISOString().slice(0,10);
                                currentUser.stats.last_spin_date = today;
                                currentUser.stats.spin_count = (currentUser.stats.spin_count || 0) + 1;
                                localStorage.setItem("fr_user", JSON.stringify(currentUser));
                                updateProfileUI();
                                renderMissions();
                                updateSpinInfo();
                            }
                        }, 400);
                    }
                }
                requestAnimationFrame(animate);

            } catch(e) {
                console.error('[Çark] spinWheelAction hatası:', e);
                btn.disabled = false;
                window._wheelSpinning = false;
                btn.innerText = "ÇARKI ÇEVİR";
            }
        }

        function showSpinResult(prizeName) {
            // Varsa eski result div'i temizle
            const old = document.getElementById('spin-result-banner');
            if(old) old.remove();

            const banner = document.createElement('div');
            banner.id = 'spin-result-banner';
            banner.style.cssText = 'position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,0.65);';
            banner.innerHTML = `
            <div style="background:linear-gradient(135deg,#1c1c1e,#2a1500);border:2px solid #eab308;border-radius:28px;padding:36px 28px;max-width:340px;width:100%;text-align:center;box-shadow:0 0 60px rgba(234,179,8,0.5),0 0 120px rgba(234,179,8,0.2);animation:scaleIn 0.4s cubic-bezier(0.16,1,0.3,1) both;">
                <div style="font-size:56px;margin-bottom:12px;display:inline-block;animation:bounce 0.55s ease-in-out infinite alternate;">🎉</div>
                <div style="color:#fbbf24;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:0.2em;margin-bottom:6px;">Tebrikler!</div>
                <div style="color:#ffffff;font-size:32px;font-weight:900;letter-spacing:0.05em;text-shadow:0 0 20px rgba(234,179,8,0.8);">${prizeName}</div>
                <div style="color:#a1a1aa;font-size:11px;margin-top:8px;font-weight:600;">Hesabına eklendi!</div>
                <button onclick="document.getElementById('spin-result-banner').remove()" style="margin-top:24px;background:linear-gradient(135deg,#eab308,#b45309);color:#000;border:none;border-radius:14px;padding:14px 32px;font-size:15px;font-weight:900;cursor:pointer;text-transform:uppercase;letter-spacing:0.1em;width:100%;">HARIKA! ✓</button>
            </div>`;
            document.body.appendChild(banner);
            banner.addEventListener('click', (e) => { if(e.target === banner) banner.remove(); });
        }

        function showSpinConfetti() {
            const colors = ['#ff4444','#ffbb00','#44ff88','#4488ff','#ff44ff','#ffffff','#ff8800','#00ffcc'];
            const count = 70;
            for(let i = 0; i < count; i++) {
                const el = document.createElement('div');
                const color = colors[i % colors.length];
                const isRect = i % 3 !== 0;
                const size = 6 + Math.random() * 8;
                const delay = Math.random() * 0.6;
                const duration = 1.8 + Math.random() * 1.0;
                const startX = Math.random() * 100;
                if(isRect) {
                    el.style.cssText = `position:fixed;width:${size}px;height:${size * 0.45}px;border-radius:1px;background:${color};left:${startX}vw;top:-2vh;pointer-events:none;z-index:999999;animation:confettiRect ${duration}s ease-in ${delay}s forwards;`;
                } else {
                    el.style.cssText = `position:fixed;width:${size}px;height:${size}px;border-radius:50%;background:${color};left:${startX}vw;top:-2vh;pointer-events:none;z-index:999999;animation:confettiFall ${duration}s ease-in ${delay}s forwards;`;
                }
                document.body.appendChild(el);
                setTimeout(()=>el.remove(), (duration + delay + 0.2) * 1000);
            }
        }

        // Cark acilinca init et - window.onload sonrasi guvenli


        // ==============================================================
        // ŞİFRE SIFIRLAMA (FORGOT PASSWORD)
        // ==============================================================

        function openForgotPasswordModal() {
            const modal = document.getElementById("forgot-password-modal");
            if (modal) {
                document.getElementById("fp-step-1").classList.remove("hidden");
                document.getElementById("fp-step-2").classList.add("hidden");
                document.getElementById("fp-email").value = "";
                modal.classList.remove("hidden");
            }
        }

        function closeForgotPasswordModal() {
            const modal = document.getElementById("forgot-password-modal");
            if (modal) modal.classList.add("hidden");
        }

        async function requestPasswordReset() {
            const email = document.getElementById("fp-email").value.trim();
            if(!email) return alert("Lütfen kayıtlı e-posta adresinizi girin!");
            try {
                const res = await sendAction('request_reset', { email: email });
                if(res.status === 'ok') {
                    alert("Sıfırlama kodu e-postanıza gönderildi!");
                    document.getElementById("fp-step-1").classList.add("hidden");
                    document.getElementById("fp-step-2").classList.remove("hidden");
                }
            } catch(e) {}
        }

        async function submitNewPassword() {
            const email = document.getElementById("fp-email").value.trim();
            const code = document.getElementById("fp-code").value.trim();
            const newPw = document.getElementById("fp-new-password").value.trim();
            
            if(!code || !newPw) return alert("Kod ve yeni şifre boş bırakılamaz!");
            if(newPw.length < 4) return alert("Şifre en az 4 karakter olmalıdır.");
            
            try {
                await sendAction('reset_password_code', { email: email, code: code, new_password: newPw });
                
                // Kayıtlı kullanıcı varsa yeni şifreyi encode ederek güncelle
                if (localStorage.getItem("fr_remembered_username")) {
                    localStorage.setItem("fr_remembered_password", btoa(unescape(encodeURIComponent(newPw))));
                }
                const loginPassInput = document.getElementById("login-password");
                if(loginPassInput) loginPassInput.value = newPw;

                alert("Şifreniz başarıyla güncellendi! Artık yeni şifrenizle giriş yapabilirsiniz.");
                document.getElementById("forgot-password-modal").classList.add("hidden");
            } catch(e) { }
        }

    </script>

    <!-- ============================================================ -->
    <!-- STORY MODALLARI -->
    <!-- ============================================================ -->
    <div id="story-view-modal" class="hidden fixed inset-0 bg-black z-[99998] flex flex-col">
        <div class="absolute top-4 left-4 right-4 flex gap-1 z-10" id="story-progress-bars"></div>
        <button onclick="closeStoryView()" class="absolute top-10 right-4 z-20 w-10 h-10 bg-black/60 rounded-full text-white text-xl flex items-center justify-center">✕</button>
        <div id="story-view-user" class="absolute top-12 left-4 flex items-center gap-3 z-20">
            <img id="story-view-avatar" class="w-10 h-10 rounded-full border-2 border-sky-400 object-cover" src="">
            <div>
                <div id="story-view-username" class="text-white font-bold text-sm"></div>
                <div id="story-view-time" class="text-zinc-400 text-[10px]"></div>
            </div>
        </div>
        <img id="story-view-img" class="w-full h-full object-contain" src="" style="display:none;">
        <div id="story-view-text" class="flex-1 flex items-center justify-center p-8 text-center">
            <div id="story-view-text-content" class="text-white text-xl font-bold leading-relaxed"></div>
        </div>
        <div id="story-view-viewers" class="absolute bottom-6 left-0 right-0 flex flex-col items-center gap-2">
            <div class="bg-black/60  px-4 py-2 rounded-full text-zinc-400 text-xs font-bold" id="story-viewer-count"></div>
            <button id="story-delete-btn" onclick="deleteCurrentStory()" class="hidden bg-sky-700/80  px-5 py-2 rounded-full text-white text-xs font-bold border border-sky-400/50">🗑️ Story'yi Sil</button>
        </div>
    </div>

    <div id="add-story-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-zinc-700  scale-in-anim">
            <div class="flex items-center justify-between mb-5">
                <h3 class="text-3xl text-white teko-font tracking-wide">📸 Story Paylaş</h3>
                <button onclick="document.getElementById('add-story-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>
            <p class="text-[10px] text-yellow-500 font-bold uppercase tracking-widest mb-4 flex items-center gap-1"><span class="animate-pulse">⭐</span> Standart, Deluxe ve Ultra+ üyelere özel · 24 saat sonra silinir</p>
            <textarea id="story-text-input" placeholder="Ne düşünüyorsun? Nerede sürdün?" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 h-24 text-white text-sm outline-none focus:border-sky-400 transition custom-scrollbar mb-3" maxlength="200"></textarea>
            <input id="story-photo-input" type="file" accept="image/*" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-3 py-3 text-xs text-zinc-300 cursor-pointer mb-4">
            <div class="grid grid-cols-2 gap-3">
                <button onclick="document.getElementById('add-story-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm transition hover:bg-zinc-800">İptal</button>
                <button onclick="submitStory()" class="bg-gradient-to-r from-sky-700 to-sky-500 text-white py-3 rounded-xl font-bold text-sm btn-premium-hover ">PAYLAŞ</button>
            </div>
        </div>
    </div>

    <!-- YORUM MODALI -->
    <div id="comment-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4">
        <div class="glass-panel w-full max-w-md rounded-3xl border border-zinc-700  scale-in-anim max-h-[80vh] flex flex-col">
            <div class="p-5 border-b border-zinc-800 flex items-center justify-between shrink-0">
                <h3 class="text-2xl text-white teko-font tracking-wide" id="comment-modal-title">💬 Yorumlar</h3>
                <button onclick="document.getElementById('comment-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>
            <div id="comment-list" class="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar"></div>
            <div class="p-3 border-t border-zinc-800 shrink-0 flex gap-2">
                <input id="comment-input" type="text" placeholder="Yorumunu yaz..." maxlength="200" class="flex-1 bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-sky-400 transition">
                <button onclick="submitComment()" class="bg-white hover:bg-gray-200 text-black px-4 py-3 rounded-xl font-bold text-sm btn-premium-hover">Gönder</button>
            </div>
        </div>
    </div>

    <!-- SEVİYE ATLAMA KUTLAMA OVERLAYİ -->
    <div id="levelup-overlay" class="hidden fixed inset-0 pointer-events-none z-[99997] flex items-center justify-center">
        <div id="levelup-card" class="bg-gradient-to-br from-yellow-600/90 to-amber-500/90  rounded-3xl p-8 text-center border border-yellow-400/50  level-up-anim max-w-xs w-full mx-4">
            <div class="text-6xl mb-3" id="levelup-icon">🏆</div>
            <div class="text-white text-[10px] font-black uppercase tracking-[0.2em] mb-1">SEVİYE ATLAMA!</div>
            <div class="text-black font-black text-3xl teko-font tracking-wide" id="levelup-name">Şampiyon</div>
            <div class="text-black/70 text-xs mt-2 font-bold" id="levelup-desc">Tebrikler! Yeni ünvanına ulaştın.</div>
        </div>
    </div>

    <!-- ÖNCELİKLİ DESTEK MODALI -->
    <div id="support-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-zinc-700  scale-in-anim">
            <div class="flex items-center justify-between mb-5">
                <h3 class="text-2xl text-white teko-font tracking-wide">🎧 Destek</h3>
                <button onclick="document.getElementById('support-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>
            <div id="support-priority-badge" class="mb-4 text-center py-2 rounded-xl text-xs font-black uppercase tracking-widest"></div>
            <textarea id="support-message" placeholder="Sorununu veya önerini yaz..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 h-28 text-white text-sm outline-none focus:border-sky-400 transition custom-scrollbar mb-4"></textarea>
            <div class="grid grid-cols-2 gap-3">
                <button onclick="document.getElementById('support-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm">İptal</button>
                <button onclick="submitSupport()" class="bg-gradient-to-r from-sky-700 to-sky-500 text-white py-3 rounded-xl font-bold text-sm btn-premium-hover">GÖNDER</button>
            </div>
        </div>
    </div>

    <!-- TEHLİKE BİLDİR MODALI -->
    <div id="danger-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[9999] px-4">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-sky-900/50  scale-in-anim">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-2xl text-sky-300 teko-font tracking-wide">⚠️ Tehlike Bildir</h3>
                <button onclick="document.getElementById('danger-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>
            <p class="text-xs text-zinc-400 mb-4">Bu rampada bir tehlike mi var? Kapalı mı, hasar mı var? Bildirin, topluluk uyarılsın.</p>
            <div class="grid grid-cols-2 gap-2 mb-4">
                <button onclick="setDangerReason('Rampa kapalı')" class="bg-zinc-900 border border-zinc-700 hover:border-sky-500 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">🚫 Kapalı</button>
                <button onclick="setDangerReason('Hasar var / tehlikeli')" class="bg-zinc-900 border border-zinc-700 hover:border-sky-500 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">💥 Hasarlı</button>
                <button onclick="setDangerReason('Yüzey ıslak / kaygan')" class="bg-zinc-900 border border-zinc-700 hover:border-sky-500 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">💧 Kaygan</button>
                <button onclick="setDangerReason('Engel var / yol kapalı')" class="bg-zinc-900 border border-zinc-700 hover:border-sky-500 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">🚧 Engel</button>
            </div>
            <textarea id="danger-reason-input" placeholder="Detay ekle (isteğe bağlı)..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 h-20 text-white text-sm outline-none focus:border-sky-400 transition custom-scrollbar mb-4"></textarea>
            <div class="grid grid-cols-2 gap-3">
                <button onclick="document.getElementById('danger-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm">İptal</button>
                <button onclick="submitDangerReport()" class="bg-sky-800 hover:bg-sky-700 text-white py-3 rounded-xl font-bold text-sm btn-premium-hover">BİLDİR</button>
            </div>
        </div>
    </div>

    <!-- KULLANICI ŞİKAYET MODALI -->
    <div id="report-user-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[99999] px-4">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-orange-900/50  scale-in-anim">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-2xl text-orange-400 teko-font tracking-wide">&#128680; Kullanıcı Sikayet Et</h3>
                <button onclick="document.getElementById('report-user-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">&#10005;</button>
            </div>
            <p class="text-xs text-zinc-400 mb-4"><b id="report-user-target-label" class="text-orange-400"></b> adli kullaniciyi neden sikayet ediyorsunuz?</p>
            <div class="grid grid-cols-2 gap-2 mb-4">
                <button onclick="setReportReason('Taciz / Zorbalik')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Taciz</button>
                <button onclick="setReportReason('Uygunsuz Icerik')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Uygunsuz</button>
                <button onclick="setReportReason('Spam / Bot')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Spam</button>
                <button onclick="setReportReason('Sahte Hesap')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Sahte Hesap</button>
                <button onclick="setReportReason('Nefret Soylemi')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Nefret Soylemi</button>
                <button onclick="setReportReason('Diger')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Diger</button>
            </div>
            <textarea id="report-user-detail" placeholder="Ek aciklama (istege bagli)..." class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 h-16 text-white text-sm outline-none focus:border-orange-500 transition custom-scrollbar mb-4"></textarea>
            <div class="grid grid-cols-2 gap-3">
                <button onclick="document.getElementById('report-user-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm">Iptal</button>
                <button onclick="submitReportUser()" class="bg-orange-800 hover:bg-orange-700 text-white py-3 rounded-xl font-bold text-sm btn-premium-hover">SIKAYET ET</button>
            </div>
        </div>
    </div>

    <!-- MESAJ SIKAYET MODALI -->
    <div id="report-msg-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[99999] px-4">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-orange-900/50  scale-in-anim">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-2xl text-orange-400 teko-font tracking-wide">&#128680; Mesaji Sikayet Et</h3>
                <button onclick="document.getElementById('report-msg-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">&#10005;</button>
            </div>
            <div id="report-msg-preview" class="bg-black/60 border border-zinc-700 rounded-xl p-3 mb-4 text-zinc-300 text-xs italic break-words"></div>
            <div class="grid grid-cols-2 gap-2 mb-4">
                <button onclick="setMsgReportReason('Taciz / Zorbalik')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Taciz</button>
                <button onclick="setMsgReportReason('Uygunsuz Icerik')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Uygunsuz</button>
                <button onclick="setMsgReportReason('Spam / Reklam')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Spam</button>
                <button onclick="setMsgReportReason('Nefret Soylemi')" class="bg-zinc-900 border border-zinc-700 hover:border-orange-600 transition text-zinc-300 py-2.5 rounded-xl text-xs font-bold">Nefret</button>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <button onclick="document.getElementById('report-msg-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm">Iptal</button>
                <button onclick="submitReportMsg()" class="bg-orange-800 hover:bg-orange-700 text-white py-3 rounded-xl font-bold text-sm btn-premium-hover">SIKAYET ET</button>
            </div>
        </div>
    </div>

    <!-- TAM EKRAN FOTOGRAF GORUNTULEME -->
    <div id="fullscreen-img-modal" class="hidden fixed inset-0 bg-black z-[99999] flex items-center justify-center" onclick="closeFullscreenImg()">
        <button class="absolute top-4 right-4 z-10 w-10 h-10 bg-black/60 rounded-full text-white text-xl flex items-center justify-center border border-zinc-700">✕</button>
        <div class="absolute top-4 left-4 flex gap-2 z-10" id="fullscreen-nav">
            <button onclick="event.stopPropagation(); fullscreenPrev()" class="w-10 h-10 bg-black/60 rounded-full text-white text-lg flex items-center justify-center border border-zinc-700">‹</button>
            <button onclick="event.stopPropagation(); fullscreenNext()" class="w-10 h-10 bg-black/60 rounded-full text-white text-lg flex items-center justify-center border border-zinc-700">›</button>
        </div>
        <img id="fullscreen-img" src="" class="max-w-full max-h-full object-contain select-none" style="touch-action:pinch-zoom;">
        <div id="fullscreen-counter" class="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black/60 text-white text-xs px-3 py-1 rounded-full font-bold"></div>
    </div>

    <!-- REEL YÜKLEME MODALI -->
    <div id="reel-upload-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[99999] px-4 ">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-6 border border-pink-900/50  scale-in-anim">
            <div class="flex items-center justify-between mb-5">
                <h3 class="text-3xl text-white teko-font tracking-wide">🎬 REEL PAYLAŞ</h3>
                <button onclick="document.getElementById('reel-upload-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>

            <!-- Üyelik bilgisi -->
            <div id="reel-limit-info" class="bg-zinc-900/80 border border-zinc-700 rounded-xl p-3 mb-4 text-xs text-zinc-400 font-bold"></div>

            <!-- Medya seçimi -->
            <div class="grid grid-cols-2 gap-3 mb-4">
                <!-- Reel medya seçimi — Prominent Disclosure ile açılır -->
                <button id="reel-photo-btn" onclick="_showPhotoDisclosure('reel', () => document.getElementById('reel-photo-input').click())" class="flex flex-col items-center justify-center gap-2 bg-zinc-900 border-2 border-pink-600/50 rounded-xl p-4 cursor-pointer hover:bg-pink-900/20 transition">
                    <span class="text-3xl">📸</span>
                    <span class="text-xs font-black text-white uppercase tracking-widest">Fotoğraf</span>
                </button>
                <input type="file" id="reel-photo-input" accept="image/*" class="hidden" onchange="handleReelFile(this,'image')">
                <button id="reel-video-btn" onclick="_showPhotoDisclosure('reel', () => document.getElementById('reel-video-input').click())" class="flex flex-col items-center justify-center gap-2 bg-zinc-900 border-2 border-zinc-700 rounded-xl p-4 cursor-pointer hover:bg-zinc-800 transition">
                    <span class="text-3xl">🎥</span>
                    <span class="text-xs font-black text-white uppercase tracking-widest">Video</span>
                    <span class="text-[9px] text-zinc-500 font-bold">Standart+ gerekli</span>
                </button>
                <input type="file" id="reel-video-input" accept="video/*" class="hidden" onchange="handleReelFile(this,'video')">
            </div>

            <!-- Önizleme -->
            <div id="reel-preview-container" class="hidden mb-4 rounded-xl overflow-hidden bg-black border border-zinc-700 relative" style="max-height:200px">
                <img id="reel-preview-img" class="hidden w-full object-cover" style="max-height:200px">
                <video id="reel-preview-video" class="hidden w-full" style="max-height:200px" controls muted playsinline></video>
                <button onclick="clearReelFile()" class="absolute top-2 right-2 w-7 h-7 bg-black/70 rounded-full text-white text-xs flex items-center justify-center border border-zinc-600">✕</button>
                <div id="reel-compress-info" class="absolute bottom-2 left-2 bg-black/70 text-green-400 text-[9px] font-bold px-2 py-1 rounded-lg hidden">✓ Optimize edildi</div>
            </div>

            <textarea id="reel-caption" placeholder="Açıklama ekle... #downhill #freeride" class="w-full bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 h-16 text-white text-sm outline-none focus:border-pink-500 transition custom-scrollbar mb-4 font-medium resize-none"></textarea>

            <div id="reel-upload-progress" class="hidden mb-3">
                <div class="text-xs text-zinc-400 font-bold mb-1 text-center">Yükleniyor...</div>
                <div class="w-full bg-zinc-800 rounded-full h-2"><div id="reel-progress-bar" class="bg-gradient-to-r from-pink-600 to-sky-400 h-2 rounded-full transition-all" style="width:0%"></div></div>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <button onclick="document.getElementById('reel-upload-modal').classList.add('hidden')" class="bg-zinc-900 border border-zinc-700 text-zinc-400 py-3 rounded-xl font-bold text-sm">İptal</button>
                <button onclick="submitReel()" id="reel-submit-btn" class="bg-gradient-to-r from-pink-700 to-sky-500 hover:opacity-90 text-white py-3 rounded-xl font-black text-sm tracking-widest btn-premium-hover ">PAYLAŞ</button>
            </div>
        </div>
    </div>

    <!-- Reel Yorum Modali -->
    <div id="reel-comment-modal" class="hidden fixed inset-0 modal-backdrop flex items-end justify-center z-[99999]">
        <div class="glass-panel w-full max-w-md rounded-t-3xl p-5 border-t border-zinc-700 " style="max-height:70vh;display:flex;flex-direction:column;">
            <div class="flex items-center justify-between mb-4 shrink-0">
                <h3 class="text-xl text-white teko-font tracking-wide">💬 Yorumlar</h3>
                <button onclick="document.getElementById('reel-comment-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>
            <div id="reel-comments-list" class="flex-1 overflow-y-auto custom-scrollbar space-y-3 mb-4 pr-1"></div>
            <div class="flex gap-2 shrink-0">
                <input id="reel-comment-input" type="text" placeholder="Yorum yaz..." class="flex-1 bg-black/60 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-pink-500 transition font-medium">
                <button onclick="submitReelComment()" class="bg-pink-700 hover:bg-pink-600 text-white px-5 py-3 rounded-xl font-black text-sm btn-premium-hover">GÖNDER</button>
            </div>
        </div>
    </div>

    <!-- Reel Beğenenler Modali -->
    <div id="reel-likes-modal" class="hidden fixed inset-0 modal-backdrop flex items-end justify-center z-[99999]">
        <div class="glass-panel w-full max-w-md rounded-t-3xl p-5 border-t border-zinc-700 " style="max-height:60vh;display:flex;flex-direction:column;">
            <div class="flex items-center justify-between mb-4 shrink-0">
                <h3 class="text-xl text-white teko-font tracking-wide">❤️ Beğenenler</h3>
                <button onclick="document.getElementById('reel-likes-modal').classList.add('hidden')" class="w-8 h-8 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center">✕</button>
            </div>
            <div id="reel-likes-list" class="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-1"></div>
        </div>
    </div>

    <!-- Trial Bitti Modali -->
    <div id="trial-expired-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-[99999] px-4">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-7 border border-yellow-600/50  text-center scale-in-anim">
            <div class="text-6xl mb-4">🏔️</div>
            <h2 class="text-3xl text-white teko-font tracking-wide mb-2">3 Gunluk Denemen Bitti!</h2>
            <p class="text-zinc-300 text-sm mb-2 leading-relaxed">Ultra+ deneyimin nasıldı? Sınırsız AI, özel renkler, alev efekti ve çok daha fazlası seni bekliyor!</p>
            <div class="bg-black/40 rounded-2xl p-4 mb-5 border border-yellow-900/40">
                <div class="text-yellow-400 font-black text-sm uppercase tracking-widest mb-2">Ultra+ ile Neler Kazanırsın?</div>
                <div class="text-left text-xs text-zinc-300 space-y-1">
                    <div>👑 Özel isim rengi ve efekt</div>
                    <div>🤖 Sınırsız Freerider AI</div>
                    <div>🔥 Alev/Buz profil efekti</div>
                    <div>📍 Sapphire harita ikonları</div>
                    <div>📸 10 bisiklet fotoğrafı</div>
                    <div>📌 Mesaj sabitleme</div>
                </div>
            </div>
            <button onclick="document.getElementById('trial-expired-modal').classList.add('hidden'); switchTab(6);" class="w-full bg-gradient-to-r from-yellow-600 to-amber-500 hover:opacity-90 text-black py-4 rounded-xl font-black text-base tracking-widest btn-premium-hover  mb-3">👑 PLUS ALMAK İSTİYORUM!</button>
            <button onclick="document.getElementById('trial-expired-modal').classList.add('hidden')" class="w-full bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 text-zinc-400 py-3 rounded-xl font-bold text-sm transition">Daha Sonra</button>
        </div>
    </div>

    <!-- READY PLAYER ME AVATAR MODAL -->
    <div id="rpm-modal" class="hidden fixed inset-0 z-[99999] flex flex-col" style="background:#000;">
        <div class="flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-zinc-800 shrink-0">
            <div class="flex items-center gap-3">
                <span class="text-xl">🎭</span>
                <span class="text-white font-black text-sm teko-font tracking-widest">3D AVATAR OLUŞTUR</span>
            </div>
            <button onclick="closeRpmModal()" class="w-9 h-9 bg-zinc-800 rounded-full text-zinc-400 hover:text-white flex items-center justify-center text-lg border border-zinc-700">✕</button>
        </div>
        <div id="rpm-loading" class="flex flex-col items-center justify-center flex-1 gap-4">
            <div class="w-12 h-12 rounded-full border-4 border-purple-900/40 border-t-purple-500 animate-spin"></div>
            <p class="text-zinc-400 text-sm font-bold">Avatar editörü yükleniyor...</p>
        </div>
        <iframe id="rpm-iframe" class="hidden flex-1 w-full border-none" allow="camera *; microphone *"></iframe>
        <div class="px-4 py-3 bg-zinc-950 border-t border-zinc-800 shrink-0">
            <p class="text-[10px] text-zinc-500 text-center font-bold uppercase tracking-widest">Avatarını oluşturduktan sonra "Kullan" butonuna bas — otomatik kaydedilir</p>
        </div>
    </div>

    <!-- ================================================================ -->
    <!-- GOOGLE PLAY PROMINENT DISCLOSURE — MİKROFON İZNİ MODALI         -->
    <!-- Politika: getUserMedia() çağrısından ÖNCE gösterilmesi zorunlu   -->
    <!-- ================================================================ -->
    <div id="pd-mic-modal" class="hidden fixed inset-0 z-[999999] flex items-center justify-center px-4" style="background:rgba(0,0,0,0.75);">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-7 border border-sky-700/60  scale-in-anim">
            <div class="flex flex-col items-center text-center gap-4">
                <div class="w-16 h-16 rounded-2xl bg-sky-900/60 border border-sky-600/50 flex items-center justify-center text-4xl ">🎤</div>
                <div>
                    <h2 class="text-2xl text-white font-black tracking-wide mb-1">Mikrofon İzni</h2>
                    <p class="text-xs text-sky-400 font-bold uppercase tracking-widest">Sesli Mesaj Özelliği</p>
                </div>
                <div class="bg-black/50 rounded-2xl p-4 border border-zinc-700 text-left w-full space-y-2">
                    <p class="text-sm text-zinc-200 leading-relaxed">FreeriderTR, <strong class="text-white">sesli mesaj kaydedip göndermek</strong> için mikrofonuna erişmek istiyor.</p>
                    <ul class="text-xs text-zinc-400 space-y-1.5 pt-1">
                        <li class="flex items-start gap-2"><span class="text-sky-400 shrink-0 mt-0.5">✔</span><span>Ses yalnızca kayıt düğmesine bastığında alınır</span></li>
                        <li class="flex items-start gap-2"><span class="text-sky-400 shrink-0 mt-0.5">✔</span><span>Kayıt dışında mikrofon hiçbir zaman aktif olmaz</span></li>
                        <li class="flex items-start gap-2"><span class="text-sky-400 shrink-0 mt-0.5">✔</span><span>Ses verisi yalnızca mesaj olarak iletilir, başka amaçla kullanılmaz</span></li>
                        <li class="flex items-start gap-2"><span class="text-zinc-500 shrink-0 mt-0.5">ⓘ</span><span class="text-zinc-500">İzni tarayıcı ayarlarından istediğin zaman iptal edebilirsin</span></li>
                    </ul>
                </div>
                <div class="grid grid-cols-2 gap-3 w-full">
                    <button id="pd-mic-deny" class="bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 text-zinc-400 py-3 rounded-xl font-bold text-sm transition">Vazgeç</button>
                    <button id="pd-mic-allow" class="bg-gradient-to-r from-sky-700 to-sky-500 hover:opacity-90 text-white py-3 rounded-xl font-black text-sm tracking-widest ">İzin Ver</button>
                </div>
                <p class="text-[10px] text-zinc-600 leading-relaxed">"İzin Ver"e basınca tarayıcının standart izin penceresi açılır. Orada da onaylaman gerekir.</p>
            </div>
        </div>
    </div>

    <!-- ================================================================ -->
    <!-- GOOGLE PLAY PROMINENT DISCLOSURE — FOTOĞRAF / GALERİ MODALI      -->
    <!-- Politika: file input tetiklenmeden ÖNCE gösterilmesi zorunlu      -->
    <!-- ================================================================ -->
    <div id="pd-photo-modal" class="hidden fixed inset-0 z-[999999] flex items-center justify-center px-4" style="background:rgba(0,0,0,0.75);">
        <div class="glass-panel w-full max-w-sm rounded-3xl p-7 border border-pink-700/60  scale-in-anim">
            <div class="flex flex-col items-center text-center gap-4">
                <div class="w-16 h-16 rounded-2xl bg-pink-900/50 border border-pink-600/50 flex items-center justify-center text-4xl " id="pd-photo-icon">📸</div>
                <div>
                    <h2 class="text-2xl text-white font-black tracking-wide mb-1" id="pd-photo-title">Fotoğraf Erişimi</h2>
                    <p class="text-xs text-pink-400 font-bold uppercase tracking-widest" id="pd-photo-subtitle">Galeri Erişimi</p>
                </div>
                <div class="bg-black/50 rounded-2xl p-4 border border-zinc-700 text-left w-full space-y-2">
                    <p class="text-sm text-zinc-200 leading-relaxed" id="pd-photo-desc">FreeriderTR, seçtiğin fotoğrafa erişmek için galerini kullanacak.</p>
                    <ul class="text-xs text-zinc-400 space-y-1.5 pt-1" id="pd-photo-list"></ul>
                </div>
                <div class="grid grid-cols-2 gap-3 w-full">
                    <button id="pd-photo-deny" class="bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 text-zinc-400 py-3 rounded-xl font-bold text-sm transition">Vazgeç</button>
                    <button id="pd-photo-allow" class="bg-gradient-to-r from-pink-700 to-rose-500 hover:opacity-90 text-white py-3 rounded-xl font-black text-sm tracking-widest ">Galeriye Git</button>
                </div>
                <p class="text-[10px] text-zinc-600 leading-relaxed">Seçilen medya yalnızca belirtilen amaçla kullanılır ve üçüncü taraflarla paylaşılmaz.</p>
            </div>
        </div>
    </div>

    <!-- ================================================================ -->
    <!-- GOOGLE PLAY IAP — Android Satın Alma Callback'leri               -->
    <!-- ================================================================ -->
    <script>
    // Android Google Play Satın Alma Callback'leri
    function onGooglePurchaseSuccess(purchaseToken, subscriptionId) {
        fetch('/api/verify_google_purchase', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                purchaseToken: purchaseToken,
                productId: subscriptionId    // Python'ın beklediği field adı
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.status === 'ok') {
                location.reload();
            } else {
                alert("Doğrulama hatası: " + (data.message || "Hata"));
            }
        })
        .catch(err => {
            alert("Sunucuya ulaşılamadı, tekrar dene.");
        });
    }

    // YENİ: Google Play Billing Event (clever-responder webhook doğrulaması)
    window.onBillingEvent = async function(event, data) {
        let parsedData = null;
        if (data) {
            try {
                parsedData = typeof data === 'string' ? JSON.parse(data) : data;
            } catch (e) {
                parsedData = data;
            }
        }

        if (event === "billing_success") {
            const purchaseInfo = parsedData;
            
            console.log("Ödeme alındı, Python backend'inde doğrulanıyor...");

            try {
                const response = await fetch("/api/verify_google_purchase", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        purchaseToken: purchaseInfo.purchaseToken,
                        productId: purchaseInfo.productId
                    })
                });

                const result = await response.json();

                if (result.status === 'ok') {
                    alert("Tebrikler! Premium hesabınız aktif edildi.");
                    window.location.reload();
                } else {
                    alert("Ödeme doğrulanamadı: " + (result.message || "Bilinmeyen hata"));
                }
            } catch (error) {
                console.error("Doğrulama servisinde hata:", error);
            }
        } else if (event === "existing_purchases") {
            // currentUser yoksa (henüz giriş yapılmamışsa) hiçbir şey yapma
            if (!currentUser) return;
            if (Array.isArray(parsedData) && parsedData.length > 0) {
                const isPremium = (currentUser.stats && parseInt(currentUser.stats.premium_tier || 0) > 0);
                
                if (!isPremium) {
                    console.log("Aktif abonelik bulundu, Python backend ile geri yükleniyor...");
                    const activeSub = parsedData[0];
                    try {
                        const response = await fetch("/api/verify_google_purchase", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                purchaseToken: activeSub.purchaseToken,
                                productId: activeSub.productId,
                                isRestore: true
                            })
                        });
                        const result = await response.json();
                        if (result.status === 'ok') {
                            console.log("Abonelik başarıyla geri yüklendi.");
                            // KRITIK FIX: window.location.reload() YAPMA!
                            // reload() → auto-login → existing_purchases → reload() = SONSUZ DÖNGÜ
                            // Bunun yerine sadece UI'ı güncelle:
                            if (result.user) {
                                currentUser = result.user;
                                window.currentUser = currentUser;
                                localStorage.setItem("fr_user", JSON.stringify(currentUser));
                            } else if (currentUser && currentUser.stats && result.tier) {
                                currentUser.stats.premium_tier = result.tier;
                                if (result.expiry) currentUser.stats.premium_expire_date = result.expiry;
                                localStorage.setItem("fr_user", JSON.stringify(currentUser));
                            }
                            // Sayfayı yenileme, sadece UI güncelle
                            if (typeof updateProfileUI === 'function') updateProfileUI();
                        }
                    } catch (error) {
                        console.error("Geri yükleme hatası:", error);
                    }
                }
            }
        } else if (event === "billing_error") {
            alert("Ödeme işlemi başarısız: " + data);
        } else if (event === "billing_pending") {
            alert("Ödemeniz beklemede. İşlem tamamlandığında üyeliğiniz aktif edilecektir.");
        }
    };

    function onGooglePurchaseCancelled(msg) {
        console.log("Satın alma iptal edildi");
    }

    function onGooglePurchaseError(errorMessage) {
        alert("Ödeme başarısız: " + errorMessage);
    }

    function handleBuyButton(productId) {
        if (typeof window.Android !== 'undefined' && window.Android !== null && typeof window.Android.launchBilling === 'function') {
            try {
                window.Android.launchBilling(productId);
            } catch(e) {
                console.error('[IAP] launchBilling hatası:', e);
                showToast('Ödeme ekranı açılamadı. Lütfen uygulamayı güncelleyin.');
            }
        } else {
            // Web / tarayıcı → admin'e talep gönder
            _sendWebPurchaseRequest(productId);
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // 🔥 PREMIUM PROMOSYON POPUP (24 saatte 1 kez, login sonrası 30sn)
    // switchTab'dan da çağrılır (session başına max 1 kez)
    // ══════════════════════════════════════════════════════════════════
    function showPremiumPopup() {
        // Premium kullanıcılara gösterme
        if (currentUser && currentUser.stats && parseInt(currentUser.stats.premium_tier) > 0) return;
        
        // 24 saatte 1 kez kontrolü
        const lastShown = localStorage.getItem('_fr_prem_popup_ts');
        if (lastShown && (Date.now() - parseInt(lastShown)) < 86400000) return;
        
        localStorage.setItem('_fr_prem_popup_ts', Date.now().toString());
        
        const popup = document.createElement('div');
        popup.id = 'premium-promo-popup';
        popup.className = 'premium-popup-overlay';
        popup.innerHTML = `
            <div class="premium-popup-card">
                <div style="font-size:48px;margin-bottom:12px;animation:premiumGlow 2s ease-in-out infinite">🔥</div>
                <h2 style="font-size:22px;font-weight:900;margin-bottom:4px;background:linear-gradient(135deg,#eab308,#f97316,#ef4444);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;letter-spacing:1px">%50 İNDİRİM KAZANDIN!</h2>
                <p style="color:#a1a1aa;font-size:12px;margin-bottom:20px;font-weight:500">Sınırlı süreliğine Premium avantajlarını keşfet</p>
                
                <div style="text-align:left;margin-bottom:24px;padding:0 8px">
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;color:#d4d4d8;font-size:13px;font-weight:600">
                        <span style="color:#22c55e;font-size:16px">✓</span> Reklamsız deneyim
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;color:#d4d4d8;font-size:13px;font-weight:600">
                        <span style="color:#22c55e;font-size:16px">✓</span> Özel profil renkleri & rozet
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;color:#d4d4d8;font-size:13px;font-weight:600">
                        <span style="color:#22c55e;font-size:16px">✓</span> Sınırsız AI sohbet
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;color:#d4d4d8;font-size:13px;font-weight:600">
                        <span style="color:#22c55e;font-size:16px">✓</span> Video Reels paylaşımı
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;color:#d4d4d8;font-size:13px;font-weight:600">
                        <span style="color:#22c55e;font-size:16px">✓</span> Onaylı hesap rozeti
                    </div>
                </div>
                
                <button onclick="document.getElementById('premium-promo-popup').remove(); switchTab(6);" 
                    style="width:100%;padding:14px;border-radius:14px;border:none;font-weight:900;font-size:14px;text-transform:uppercase;letter-spacing:2px;cursor:pointer;
                    background:linear-gradient(135deg,#eab308,#f97316);color:#000;
                    box-shadow:0 4px 20px rgba(234,179,8,0.4);
                    transition:all 0.25s;margin-bottom:10px"
                    onmouseover="this.style.transform='translateY(-2px) scale(1.02)';this.style.boxShadow='0 8px 30px rgba(234,179,8,0.6)'"
                    onmouseout="this.style.transform='';this.style.boxShadow='0 4px 20px rgba(234,179,8,0.4)'">
                    🚀 HEMEN AL
                </button>
                <button onclick="document.getElementById('premium-promo-popup').remove()" 
                    style="width:100%;padding:12px;border-radius:14px;border:1px solid #3f3f46;background:transparent;color:#71717a;font-weight:700;font-size:12px;cursor:pointer;transition:all 0.25s;text-transform:uppercase;letter-spacing:1px"
                    onmouseover="this.style.borderColor='#52525b';this.style.color='#a1a1aa'"
                    onmouseout="this.style.borderColor='#3f3f46';this.style.color='#71717a'">
                    Daha Sonra
                </button>
            </div>
        `;
        document.body.appendChild(popup);
        
        // Overlay'e tıklayınca kapat
        popup.addEventListener('click', (e) => {
            if (e.target === popup) popup.remove();
        });
    }

    // Popup triggers removed per user request

    // --- ADMIN EXTRA FUNCTIONS ---
        async function execAdminCmd(cmdOverride) {
            const cmd = cmdOverride || document.getElementById('admin-cmd-input').value;
            if(!cmd) return;
            try {
                const res = await sendAction('admin_command', {command: cmd});
                if(res.status==='ok') { 
                    showToast(`✅ Başarılı: ${res.message}`, 'success', 4000); 
                    if(!cmdOverride && document.getElementById('admin-cmd-input')) document.getElementById('admin-cmd-input').value = ''; 
                }
                else showToast(`❌ Hata: ${res.message}`, 'error', 4000);
            } catch(e) {
                showToast(`❌ Hata: ${e.message}`, 'error');
            }
        }

        // HTML özel karakterlerini güvenli şekilde kaçıran yardımcı fonksiyon
        function escHtml(str) {
            if (!str) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        let _adminRepPage = 1;
        async function loadAdminReports(page = 1) {

            _adminRepPage = page;
            const status = document.getElementById('admin-report-status') ? document.getElementById('admin-report-status').value : 'pending';
            const severity = document.getElementById('admin-report-severity') ? document.getElementById('admin-report-severity').value : 'all';
            const list = document.getElementById('admin-reports-list');
            const pg = document.getElementById('admin-reports-pagination');
            if(!list) return;
            list.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4 animate-pulse">Yükleniyor...</div>';
            try {
                const res = await fetch(`/admin/reports?status=${status}&severity=${severity}&page=${page}&per_page=15`);
                const data = await res.json();
                if (data.status !== 'ok') { list.innerHTML = `<div class="text-sky-300 text-xs italic text-center py-4">Hata: ${data.message}</div>`; return; }
                if (!data.reports || !data.reports.length) { list.innerHTML = '<div class="text-zinc-600 text-xs italic text-center py-4">Rapor bulunamadı.</div>'; pg.innerHTML=''; return; }
                list.innerHTML = data.reports.map((r, i) => {
                    let borderClass = 'border-zinc-700';
                    if(r.severity === 'high') borderClass = 'border-red-500/50';
                    else if(r.severity === 'medium') borderClass = 'border-orange-500/50';
                    else if(r.severity === 'low') borderClass = 'border-yellow-500/50';
                    return `
                    <div class="rounded-xl p-4 border ${borderClass} admin-card-enter transition-all" style="background:rgba(0,0,0,0.45);animation-delay:${i*0.03}s">
                        <div class="flex justify-between items-center mb-2">
                            <div class="flex gap-2 items-center text-[10px] font-bold uppercase tracking-widest">
                                <span class="${r.severity==='high'?'text-red-400':(r.severity==='medium'?'text-orange-400':'text-yellow-400')}">${r.severity}</span>
                                <span class="text-zinc-500">|</span>
                                <span class="text-blue-300">${r.status}</span>
                            </div>
                            <span class="text-[9px] text-zinc-500">${new Date(r.created_at).toLocaleString('tr-TR')}</span>
                        </div>
                        <div class="text-white text-xs font-bold mb-2">👤 ${r.sender}</div>
                        <div class="bg-black/60 p-3 rounded-lg border border-zinc-800 text-zinc-300 text-xs mb-3 break-words font-medium">${escHtml(r.content)}</div>
                        ${r.status === 'pending' ? `
                        <div class="flex gap-2">
                            <button onclick="repBan('${r.sender}','${r.id}')" class="flex-1 py-2 bg-red-950/40 border border-sky-900/50 text-sky-400 text-[10px] font-bold rounded-lg hover:bg-sky-900/40 transition">🚫 Onayla & Banla</button>
                            <button onclick="repDismiss('${r.id}')" class="flex-1 py-2 bg-zinc-800 border border-zinc-700 text-zinc-300 text-[10px] font-bold rounded-lg hover:bg-zinc-700 transition">✅ Yoksay</button>
                        </div>` : ''}
                        ${r.admin_note ? `<div class="mt-2 text-[10px] text-amber-400 font-bold">💬 Not: ${escHtml(r.admin_note)}</div>` : ''}
                    </div>`;
                }).join('');
                pg.innerHTML = '';
                if (page > 1) pg.innerHTML += `<button onclick="loadAdminReports(${page-1})" class="px-3 py-1 bg-zinc-800 text-zinc-300 text-xs rounded-lg hover:bg-zinc-700">◀ Önceki</button>`;
                if (data.count === 15) pg.innerHTML += `<button onclick="loadAdminReports(${page+1})" class="px-3 py-1 bg-zinc-800 text-zinc-300 text-xs rounded-lg hover:bg-zinc-700">Sonraki ▶</button>`;
            } catch(e) {
                list.innerHTML = `<div class="text-sky-300 text-xs italic text-center py-4">Bağlantı hatası: ${e.message}</div>`;
            }
        }

        async function repBan(username, reportId) {
            if (!confirm(`⚠️ "${username}" kullanıcısını banlamak istediğinizden emin misiniz?`)) return;
            const reason = prompt('Ban gerekçesi (opsiyonel):', 'Topluluk kuralları ihlali') || 'Moderasyon ihlali';
            try {
                const data = await sendAction('admin_ban_user', { username, reason });
                if(data.status === 'ok') { showToast(`✅ ${username} banlandı.`, 'success'); loadAdminReports(_adminRepPage); }
                else showToast(`❌ Hata: ${data.message}`, 'error');
            } catch(e) {}
        }
        async function repDismiss(reportId) {
            try {
                const res = await fetch('/admin/dismiss_report', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ report_id: reportId }) });
                const data = await res.json();
                if(data.status === 'ok') { showToast(`✅ Rapor yoksayıldı.`, 'success'); loadAdminReports(_adminRepPage); }
            } catch(e) {}
        }

        async function adminResetPassword(uname) {
            if(!confirm(`⚠️ ${uname} şifresi sıfırlanacak. Onaylıyor musunuz?`)) return;
            try {
                const r = await sendAction('admin_reset_password', {username: uname});
                if(r.status==='ok') alert(`✅ Şifre sıfırlandı.
Yeni Şifre: ${r.new_password}
Email Gitti: ${r.email_sent}`);
                else showToast(`❌ Hata: ${r.message}`, 'error');
            } catch(e) {}
        }
        async function adminChangeUsername(uname) {
            const newName = prompt(`${uname} için YENİ kullanıcı adı girin:`);
            if(!newName) return;
            try {
                const r = await sendAction('admin_change_username', {old_username: uname, new_username: newName});
                if(r.status==='ok') { showToast(`✅ Değiştirildi.`, 'success'); document.getElementById('ua-username-label').textContent = '@' + newName; _uaCurrentUser = newName; }
                else showToast(`❌ Hata: ${r.message}`, 'error');
            } catch(e) {}
        }
        async function adminDeleteUser(uname) {
            if(!confirm(`🚨 DİKKAT! ${uname} hesabını tamamen silmek üzeresiniz. Bu işlem GERİ ALINAMAZ! Emin misiniz?`)) return;
            try {
                const r = await sendAction('admin_delete_user', {username: uname});
                if(r.status==='ok') { showToast(`✅ ${uname} silindi.`, 'success'); document.getElementById('user-activity-modal').classList.add('hidden'); }
                else showToast(`❌ Hata: ${r.message}`, 'error');
            } catch(e) {}
        }

        // --- END ADMIN EXTRA FUNCTIONS ---


        // --- NEW ADMIN PANEL ACTIONS ---
        async function adminCheckUserDetails() {
            const username = document.getElementById('admin-action-username').value.trim();
            if(!username) { showToast('Kullanıcı adı girin!', 'warning'); return; }
            
            const btn = event && event.target && event.target.tagName === 'BUTTON' ? event.target : document.querySelector('button[onclick="adminCheckUserDetails()"]');
            const originalText = btn.innerHTML;
            btn.innerHTML = '⏳ Aranıyor...';
            
            try {
                const res = await sendAction('admin_check_user_details', {username});
                btn.innerHTML = originalText;
                
                if(res.status === 'ok') {
                    document.getElementById('admin-action-result').classList.remove('hidden');
                    const u = res.user;
                    const p = res.premium;
                    
                    document.getElementById('aa-username').textContent = u.username;
                    document.getElementById('aa-email').textContent = u.email;
                    document.getElementById('aa-date').textContent = u.created_at.substring(0, 10);
                    document.getElementById('aa-cityxp').textContent = `${u.city} / ${u.xp} XP`;
                    document.getElementById('aa-role').textContent = u.role;
                    
                    const banEl = document.getElementById('aa-banned');
                    const banBtn = document.getElementById('aa-btn-ban');
                    if(u.is_banned) {
                        banEl.textContent = '❌ Banlı';
                        banEl.className = 'font-bold text-red-500';
                        banBtn.textContent = '✅ Unban';
                    } else {
                        banEl.textContent = '✅ Aktif';
                        banEl.className = 'font-bold text-green-500';
                        banBtn.textContent = '🚫 Banla';
                    }
                    
                    const tEl = document.getElementById('aa-tier');
                    tEl.textContent = p.tier === 3 ? 'Ultra+' : (p.tier === 2 ? 'Deluxe' : (p.tier === 1 ? 'Standart' : 'Yok'));
                    tEl.className = p.tier > 0 ? 'font-bold text-yellow-400' : 'font-bold text-zinc-500';
                    
                    document.getElementById('aa-expire').textContent = p.expire_date;
                    document.getElementById('aa-source').textContent = p.source;
                } else {
                    showToast(`Hata: ${res.message}`, 'error');
                    document.getElementById('admin-action-result').classList.add('hidden');
                }
            } catch(e) {
                btn.innerHTML = originalText;
                showToast(`Hata: ${e.message}`, 'error');
            }
        }

        async function adminActionExec(actionSuffix) {
            const username = document.getElementById('aa-username').textContent;
            if(!username) return;
            try {
                const res = await sendAction('admin_command', {command: `${username} ${actionSuffix}`});
                if(res.status === 'ok') {
                    showToast(`✅ ${res.message}`, 'success');
                    adminCheckUserDetails();
                } else {
                    showToast(`❌ Hata: ${res.message}`, 'error');
                }
            } catch(e) {}
        }
        
        async function adminActionBanToggle() {
            const username = document.getElementById('aa-username').textContent;
            if(!username) return;
            const btn = document.getElementById('aa-btn-ban');
            const isBan = btn.textContent.includes('Banla');
            
            if(isBan) {
                if(!confirm(`⚠️ ${username} kullanıcısını banlamak üzeresiniz!`)) return;
                const reason = prompt('Ban gerekçesi:');
                try {
                    const data = await sendAction('admin_ban_user', { username, reason });
                    if(data.status === 'ok') { showToast('Banlandı!', 'success'); adminCheckUserDetails(); }
                    else showToast(data.message, 'error');
                } catch(e) {}
            } else {
                try {
                    const data = await sendAction('admin_unban_user', { username });
                    if(data.status === 'ok') { showToast('Ban açıldı!', 'success'); adminCheckUserDetails(); }
                    else showToast(data.message, 'error');
                } catch(e) {}
            }
        }
        // --- END NEW ADMIN PANEL ACTIONS ---

</script>


<!-- ========================================== -->
<!-- AI HUB (YENI NESİL AI MERKEZI)             -->
<!-- ========================================== -->
<style>
  .ai-fab {
      position: fixed;
      bottom: 90px;
      right: 20px;
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0ea5e9, #8b5cf6);
      box-shadow: 0 0 20px rgba(139, 92, 246, 0.6), inset 0 0 10px rgba(255,255,255,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 50;
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      border: 2px solid rgba(255,255,255,0.2);
  }
  .ai-fab:hover {
      transform: scale(1.1) rotate(5deg);
      box-shadow: 0 0 30px rgba(139, 92, 246, 0.9);
  }
  .ai-fab svg { width: 28px; height: 28px; fill: white; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.4)); }
  .ai-overlay {
      position: fixed; inset: 0; background: rgba(5,5,10,0.95);  z-index: 999999 !important;
      display: none; flex-direction: column; opacity: 0; transition: opacity 0.3s ease;
  }
  .ai-overlay.show { display: flex !important; opacity: 1 !important; }
  .ai-header { padding: 20px; border-bottom: 1px solid rgba(139, 92, 246, 0.3); background: linear-gradient(180deg, rgba(139,92,246,0.1), transparent); display: flex; justify-content: space-between; align-items: center; }
  .ai-title { font-size: 24px; font-weight: 900; background: linear-gradient(90deg, #38bdf8, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-transform: uppercase; letter-spacing: 2px; }
  .ai-close { background: rgba(255,255,255,0.1); border-radius: 50%; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: white; font-size: 20px; font-weight: bold; }
  .ai-content { flex: 1; overflow-y: auto; padding: 20px; }
  .ai-card {
      background: linear-gradient(145deg, rgba(30,30,40,0.8), rgba(15,15,20,0.9));
      border: 1px solid rgba(139, 92, 246, 0.2);
      border-radius: 20px; padding: 24px; margin-bottom: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      transition: all 0.3s ease; cursor: pointer; position: relative; overflow: hidden;
  }
  .ai-card::before {
      content:''; position: absolute; top:0; left:0; width:100%; height:100%;
      background: radial-gradient(circle at top right, rgba(139, 92, 246, 0.2), transparent 60%); pointer-events: none;
  }
  .ai-card:hover { transform: translateY(-5px); border-color: rgba(139, 92, 246, 0.6); box-shadow: 0 15px 40px rgba(139, 92, 246, 0.2); }
  .ai-card-title { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
  .ai-card-desc { font-size: 13px; color: #a1a1aa; line-height: 1.5; }
  .ai-screen { display: none; flex-direction: column; height: 100%; }
  
  /* Input & Button Styles */
  .ai-input { width: 100%; background: rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 14px 16px; color: white; font-size: 14px; margin-bottom: 12px; outline: none; transition: border 0.3s; }
  .ai-input:focus { border-color: #8b5cf6; box-shadow: 0 0 15px rgba(139, 92, 246, 0.3); }
  .ai-btn { width: 100%; background: linear-gradient(90deg, #0ea5e9, #8b5cf6); border: none; border-radius: 12px; padding: 16px; color: white; font-weight: 900; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; cursor: pointer; box-shadow: 0 5px 20px rgba(139, 92, 246, 0.4); margin-bottom: 20px; transition: transform 0.2s; }
  .ai-btn:active { transform: scale(0.98); }
  
  /* Result Components */
  .ai-result-box { background: rgba(20,20,30,0.8); border-radius: 16px; border: 1px solid rgba(255,255,255,0.05); padding: 20px; margin-top: 10px; animation: slideUpFade 0.4s ease forwards; }
  .ai-score-ring { width: 80px; height: 80px; border-radius: 50%; border: 6px solid #8b5cf6; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 900; color: white; box-shadow: 0 0 20px rgba(139,92,246,0.5); margin: 0 auto 20px; background: rgba(0,0,0,0.5); }
  .ai-stat-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 13px; }
  .ai-stat-label { color: #a1a1aa; font-weight: 600; }
  .ai-stat-val { color: #fff; font-weight: 800; text-align: right; }
  .ai-tag { display: inline-block; padding: 4px 10px; background: rgba(139,92,246,0.2); border: 1px solid rgba(139,92,246,0.5); border-radius: 8px; font-size: 11px; font-weight: 800; color: #c4b5fd; margin: 0 6px 6px 0; text-transform: uppercase; }
  .ai-tag.green { background: rgba(34,197,94,0.2); border-color: rgba(34,197,94,0.5); color: #86efac; }
  .ai-tag.red { background: rgba(239,68,68,0.2); border-color: rgba(239,68,68,0.5); color: #fca5a5; }
  
  /* Loader */
  .ai-loader { display: none; margin: 30px auto; width: 50px; height: 50px; border: 4px solid rgba(255,255,255,0.1); border-top-color: #8b5cf6; border-radius: 50%; animation: spin 1s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  
  /* Memory Build Progress */
  .build-progress { display: flex; gap: 4px; margin-bottom: 20px; }
  .build-step { flex: 1; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; }
  .build-step.active { background: #8b5cf6; box-shadow: 0 0 10px #8b5cf6; }
</style>

<!-- Floating Button -->


<!-- Main Overlay -->
<div id="ai-hub-overlay" class="ai-overlay">
    <div class="ai-header">
        <div class="ai-title" id="ai-hub-title">AI Merkezi</div>
        <div class="ai-close" onclick="closeAIHub()" style="pointer-events: auto;">×</div>
    </div>
    
    <div class="ai-content custom-scrollbar" id="ai-main-menu">
        <p class="text-xs text-zinc-400 mb-6 font-medium">Sana özel geliştirilmiş yapay zeka analiz araçlarını keşfet. Sorularını yanıtlamaktan öte, bisikletini analiz eder ve sana özel tavsiyeler sunar.</p>
        
        <div class="ai-card" onclick="openAIScreen('analysis')" style="pointer-events: auto;">
            <div class="ai-card-title">🔍 Bisiklet Analizi</div>
            <div class="ai-card-desc">Bisikletinin veya parçalarının uyumluluğunu, kategorisini ve performansını detaylı raporla.</div>
        </div>
        
        <div class="ai-card" onclick="openAIScreen('recommend')" style="pointer-events: auto;">
            <div class="ai-card-title">🎯 Akıllı Öneri</div>
            <div class="ai-card-desc">Bütçene, tarzına ve seviyene en uygun bisiklet modelini ve geometri özelliklerini bul.</div>
        </div>
        
        <div class="ai-card" onclick="openAIScreen('build')" style="pointer-events: auto;">
            <div class="ai-card-title">🛠️ Custom Build Yap</div>
            <div class="ai-card-desc">Parça parça hayalindeki bisikleti topla. AI uyumluluğu kontrol edip ilerlemeni kaydetsin.</div>
        </div>
        
        <div class="ai-card" onclick="openAIScreen('part')" style="pointer-events: auto;">
            <div class="ai-card-title">⚙️ Parça İncelemesi</div>
            <div class="ai-card-desc">Herhangi bir parçanın sertlik, dayanıklılık ve fiyat/performans skorunu öğren.</div>
        </div>
    </div>
    
    <!-- 1. Analysis Screen -->
    <div class="ai-content custom-scrollbar ai-screen" id="ai-screen-analysis">
        <button class="text-zinc-400 mb-4 text-xs font-bold uppercase" onclick="backToAIMenu()" style="pointer-events: auto;">← Geri Dön</button>
        <input type="text" id="ai-inp-analysis" class="ai-input" placeholder="Örn: Rockrider ST540 + RockShox Judy">
        <button class="ai-btn" onclick="runAI('analysis')" style="pointer-events: auto;">Analiz Et</button>
        <div id="ai-loader-analysis" class="ai-loader"></div>
        <div id="ai-res-analysis"></div>
    </div>

    <!-- 2. Recommend Screen -->
    <div class="ai-content custom-scrollbar ai-screen" id="ai-screen-recommend">
        <button class="text-zinc-400 mb-4 text-xs font-bold uppercase" onclick="backToAIMenu()" style="pointer-events: auto;">← Geri Dön</button>
        <input type="text" id="ai-inp-rec-budget" class="ai-input" placeholder="Bütçe (Örn: 60.000 TL)">
        <input type="text" id="ai-inp-rec-style" class="ai-input" placeholder="Sürüş Tarzı (Örn: Downhill, Jump)">
        <input type="text" id="ai-inp-rec-terrain" class="ai-input" placeholder="Zemin (Örn: Kayalık, Çamur)">
        <input type="text" id="ai-inp-rec-level" class="ai-input" placeholder="Seviye (Örn: Orta)">
        <button class="ai-btn" onclick="runAI('recommend')" style="pointer-events: auto;">Bisiklet Öner</button>
        <div id="ai-loader-recommend" class="ai-loader"></div>
        <div id="ai-res-recommend"></div>
    </div>

    <!-- 3. Build Screen (16-Step Visual Builder) -->
    <div class="ai-content custom-scrollbar ai-screen" id="ai-screen-build">
        <button class="text-zinc-400 mb-4 text-xs font-bold uppercase" onclick="backToAIMenu()" style="pointer-events: auto;">← Geri Dön</button>
        
        <!-- 16-Step Progress Indicators -->
        <div class="flex gap-1 mb-4 overflow-x-auto pb-2 custom-scrollbar" id="ai-build-progress">
            <!-- JavaScript will inject 16 dots here -->
        </div>

        <!-- SVG 3D Blueprint Assembly Animation -->
        <div id="ai-bike-blueprint" class="w-full h-48 bg-black/40 rounded-xl mb-4 border border-zinc-800/80 relative overflow-hidden flex items-center justify-center perspective-[1000px] ">
            <svg viewBox="100 50 650 400" class="w-full h-full  transition-all duration-700" style="transform-style: preserve-3d;">
                
                <!-- 1: Frame -->
                <path id="svg-part-frame" d="M 230 310 L 330 260 L 510 200 L 410 340 Z M 330 260 L 410 340" fill="none" stroke="#a855f7" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" class="opacity-10 transition-all duration-700 transform translate-x-20 scale-95" style="transform-origin: center;"/>
                
                <!-- 2: Headset -->
                <ellipse id="svg-part-headset" cx="510" cy="200" rx="14" ry="8" fill="#a855f7" class="opacity-10 transition-all duration-700 transform -translate-y-10 scale-50" style="transform-origin: center; transform: rotate(-35deg);"/>
                
                <!-- 3: Fork (Dual Crown) -->
                <path id="svg-part-fork" d="M 476 150 L 510 200 L 612 350 M 506 150 L 446 150 M 495 200 L 530 180" fill="none" stroke="#a855f7" stroke-width="12" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform -translate-y-20 rotate-12" style="transform-origin: 510px 200px;"/>
                
                <!-- 4: Shock (Coil) -->
                <g id="svg-part-shock" class="opacity-10 transition-all duration-700 transform scale-50 translate-x-10" style="transform-origin: center;">
                    <path d="M 360 300 L 440 240" fill="none" stroke="#eab308" stroke-width="6" stroke-linecap="round"/>
                    <path d="M 370 292 Q 385 270 390 290 Q 405 265 410 285 Q 425 260 430 280" fill="none" stroke="#eab308" stroke-width="8" stroke-linecap="round"/>
                </g>
                
                <!-- 5: BB -->
                <circle id="svg-part-bb" cx="410" cy="340" r="14" fill="#22c55e" class="opacity-10 transition-all duration-700 transform scale-50" style="transform-origin: center;"/>
                
                <!-- 6: Crank -->
                <path id="svg-part-crank" d="M 410 340 L 440 375" fill="none" stroke="#22c55e" stroke-width="10" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform rotate-180" style="transform-origin: 410px 340px;"/>
                
                <!-- 7: Chainguide -->
                <path id="svg-part-chainguide" d="M 400 330 A 20 20 0 0 1 420 320 L 430 340 Z" fill="none" stroke="#f43f5e" stroke-width="6" class="opacity-10 transition-all duration-700 transform scale-50 -translate-y-5" style="transform-origin: center;"/>
                
                <!-- 8: Derailleur -->
                <path id="svg-part-derailleur" d="M 230 310 L 230 350 L 210 360" fill="none" stroke="#71717a" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" class="opacity-10 transition-all duration-700 transform translate-x-10" style="transform-origin: center;"/>
                
                <!-- 9: Shifter -->
                <circle id="svg-part-shifter" cx="475" cy="145" r="6" fill="#71717a" class="opacity-10 transition-all duration-700 transform -translate-y-10" style="transform-origin: center;"/>
                
                <!-- 10: Cassette -->
                <circle id="svg-part-cassette" cx="230" cy="310" r="30" fill="none" stroke="#71717a" stroke-width="10" stroke-dasharray="8 4" class="opacity-10 transition-all duration-700 transform rotate-90" style="transform-origin: center;"/>
                
                <!-- 11: Chain -->
                <path id="svg-part-chain" d="M 410 325 L 230 280 M 410 355 L 230 340" fill="none" stroke="#a1a1aa" stroke-width="4" stroke-dasharray="4 2" class="opacity-10 transition-all duration-700 transform translate-x-5" style="transform-origin: center;"/>
                
                <!-- 12: Brakes (Calipers + Levers) -->
                <g id="svg-part-brakes" class="opacity-10 transition-all duration-700 transform rotate-45" style="transform-origin: center;">
                    <rect x="582" y="310" width="15" height="25" fill="#ef4444" rx="4"/>
                    <rect x="200" y="270" width="15" height="25" fill="#ef4444" rx="4"/>
                    <path d="M 480 145 L 460 155 M 490 135 L 510 125" fill="none" stroke="#ef4444" stroke-width="4" stroke-linecap="round"/>
                </g>
                
                <!-- 13: Rotors -->
                <circle id="svg-part-rotors" cx="612" cy="350" r="50" fill="none" stroke="#9ca3af" stroke-width="3" stroke-dasharray="15 5" class="opacity-10 transition-all duration-700 transform rotate-90" style="transform-origin: 612px 350px;"/>
                <circle id="svg-part-rotors-r" cx="230" cy="310" r="50" fill="none" stroke="#9ca3af" stroke-width="3" stroke-dasharray="15 5" class="opacity-10 transition-all duration-700 transform rotate-90" style="transform-origin: 230px 310px;"/>
                
                <!-- 14: Wheels -->
                <circle id="svg-part-wheels" cx="612" cy="350" r="95" fill="none" stroke="#3b82f6" stroke-width="10" class="opacity-10 transition-all duration-1000 transform translate-y-32 scale-75" style="transform-origin: 612px 350px;"/>
                <circle id="svg-part-wheels-r" cx="230" cy="310" r="95" fill="none" stroke="#3b82f6" stroke-width="10" class="opacity-10 transition-all duration-1000 transform translate-y-32 scale-75" style="transform-origin: 230px 310px;"/>
                
                <!-- 15: Tires -->
                <circle id="svg-part-tires" cx="612" cy="350" r="110" fill="none" stroke="#52525b" stroke-width="20" stroke-dasharray="12 6" class="opacity-10 transition-all duration-700 transform scale-110" style="transform-origin: 612px 350px;"/>
                <circle id="svg-part-tires-r" cx="230" cy="310" r="110" fill="none" stroke="#52525b" stroke-width="20" stroke-dasharray="12 6" class="opacity-10 transition-all duration-700 transform scale-110" style="transform-origin: 230px 310px;"/>
                
                <!-- 16: Handlebar -->
                <path id="svg-part-handlebar" d="M 470 140 Q 485 130 500 140" fill="none" stroke="#f43f5e" stroke-width="10" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform -translate-y-10" style="transform-origin: center;"/>
                
                <!-- 17: Stem -->
                <path id="svg-part-stem" d="M 476 150 L 485 140" fill="none" stroke="#f97316" stroke-width="12" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform scale-50" style="transform-origin: center;"/>
                
                <!-- 18: Grips -->
                <path id="svg-part-grips" d="M 460 145 L 475 138 M 495 138 L 510 145" fill="none" stroke="#14b8a6" stroke-width="14" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform scale-150" style="transform-origin: center;"/>
                
                <!-- 19: Seatpost / Dropper -->
                <path id="svg-part-seatpost" d="M 330 260 L 320 230" fill="none" stroke="#f97316" stroke-width="10" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform translate-y-20" style="transform-origin: center;"/>
                
                <!-- 20: Saddle -->
                <path id="svg-part-saddle" d="M 280 235 Q 320 220 360 240" fill="none" stroke="#f97316" stroke-width="14" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform -translate-y-20" style="transform-origin: center;"/>
                
                <!-- 21: Pedals -->
                <path id="svg-part-pedals" d="M 430 375 L 450 375" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" class="opacity-10 transition-all duration-700 transform scale-50 translate-y-5" style="transform-origin: center;"/>
                
                <!-- 22: Extras -->
                <g id="svg-part-extras" class="opacity-10 transition-all duration-700 transform scale-50" style="transform-origin: center;">
                    <circle cx="150" cy="100" r="15" fill="url(#grad1)"/>
                    <text x="150" y="105" fill="#a855f7" font-size="16" font-family="sans-serif" font-weight="bold" text-anchor="middle">+</text>
                </g>
                <defs>
                    <radialGradient id="grad1" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" style="stop-color:#a855f7;stop-opacity:0.5" />
                        <stop offset="100%" style="stop-color:transparent;stop-opacity:0" />
                    </radialGradient>
                </defs>
            </svg>
            
            <style>
                .svg-installed {
                    opacity: 1 !important;
                    transform: translate3d(0,0,0) rotate(0deg) scale(1) !important;
                    filter: drop-shadow(0 0 10px rgba(168,85,247,0.8));
                }
            </style>
        </div>

        <!-- Step Header -->
        <div class="bg-black/60 border border-zinc-800 rounded-xl p-4 mb-4 relative overflow-hidden">
            <div class="absolute -right-4 -top-4 text-6xl opacity-10">🚲</div>
            <div class="text-xs text-purple-400 font-black tracking-widest uppercase mb-1" id="ai-build-step-counter">Adım 1 / 16</div>
            <div class="text-lg text-white font-bold" id="ai-build-step-title">Kadro (Frame)</div>
            <div class="text-[10px] text-zinc-500 mt-1" id="ai-build-summary-text">Garaj bomboş. Bisikleti toplamaya kadrodan başlıyoruz.</div>
        </div>

        <!-- Input Area (Only visible if not completed) -->
        <div id="ai-build-input-area">
            <input type="text" id="ai-inp-build" class="ai-input mb-3" placeholder="Marka ve model girin...">
            <div class="flex gap-2 mb-4">
                <button class="flex-[2] ai-btn bg-purple-600 hover:bg-purple-500 text-white !border-none" onclick="runAI('build')" style="pointer-events: auto;">Ekle & Kontrol Et</button>
                <button class="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-all" onclick="window.aiSkipBuildStep()" style="pointer-events: auto;">Geç ⏭</button>
                <button class="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-all" onclick="window.aiUndoBuildStep()" style="pointer-events: auto;">← Geri Al</button>
            </div>
        </div>

        <!-- Completed Area (Only visible when 16 steps are done) -->
        <div id="ai-build-complete-area" class="hidden mb-4">
            <div class="bg-green-900/20 border border-green-500/30 p-4 rounded-xl text-center mb-3">
                <div class="text-3xl mb-2">🎉</div>
                <div class="text-green-400 font-bold">Bisiklet Tamamlandı!</div>
                <div class="text-xs text-zinc-300 mt-1">Tüm parçaları girdin. Şimdi yapay zekanın bu sistemi analiz etmesini sağla.</div>
            </div>
            <div class="flex flex-col gap-2">
                <button class="w-full ai-btn bg-gradient-to-r from-blue-600 to-purple-600 !border-none" onclick="window.aiAnalyzeFullBuild()" style="pointer-events: auto;">Analiz Et & Raporla</button>
                <div class="flex gap-2">
                    <button class="flex-1 bg-zinc-800 text-zinc-300 py-2 rounded-xl text-xs font-bold" onclick="window.aiCopyBuild()" style="pointer-events: auto;">Tasarımı Kopyala</button>
                    <button class="flex-1 bg-red-900/30 text-red-400 border border-red-900/50 py-2 rounded-xl text-xs font-bold" onclick="window.aiResetBuild()" style="pointer-events: auto;">Sıfırla</button>
                </div>
            </div>
        </div>

        <div id="ai-loader-build" class="ai-loader"></div>
        <div id="ai-res-build"></div>
    </div>


    <!-- 4. Part Screen -->
    <div class="ai-content custom-scrollbar ai-screen" id="ai-screen-part">
        <button class="text-zinc-400 mb-4 text-xs font-bold uppercase" onclick="backToAIMenu()" style="pointer-events: auto;">← Geri Dön</button>
        <div id="ai-part-input-container">
            <!-- JavaScript buraya Dropdown yapısını render edecek -->
        </div>
        <div id="ai-loader-part" class="ai-loader mt-4"></div>
        <div id="ai-res-part" class="mt-4"></div>
    </div>

</div>

<script>


// ═══════════════════════════════════════════════════════════════
// FREERIDER TR — UYGULAMA TURU v5 (Inline-Style, Bulletproof)
// ═══════════════════════════════════════════════════════════════
window.AppTour = (function() {

    var TOUR_KEY = 'freerider_tour_v5_done';
    var current = 0;

    var STEPS = [
        {
            tab: 0, emoji: '🗺️', title: 'Harita',
            subtitle: "Türkiye'nin Trail & Rampa Haritası",
            desc: 'Yakınındaki tüm trail, rampa ve sürüş noktalarını harita üzerinde görürsün.',
            tips: [
                '📍 <b>Haritadaki renkli ikonlara</b> dokun → o noktanın detaylarını, fotoğraflarını ve yorumlarını görürsün.',
                '➕ <b>Sağ alt köşedeki + butonuna</b> bas → kendi keşfettiğin yeni bir noktayı topluluğa ekle.',
                '🔍 <b>Üstteki arama çubuğuna</b> şehir veya bölge yaz → harita oraya odaklanır.',
                '📏 <b>Filtre butonuna</b> bas → Trail, Rampa veya Etkinlik türlerini filtrele.'
            ]
        },
        {
            tab: 1, emoji: '💬', title: 'Chat',
            subtitle: 'Topluluk Sohbet Odaları',
            desc: "Şehrindeki veya tüm Türkiye'deki sürücülerle anlık mesajlaş.",
            tips: [
                '🏙️ <b>Şehir odalarına</b> bas → o ilin bisikletçileriyle sohbet et.',
                "🌍 <b>Genel oda</b> → tüm Türkiye'den sürücülerle tanış ve sürüş planla.",
                "📸 <b>Kamera ikonuna</b> bas → chat'e fotoğraf veya video gönder.",
                '👤 <b>Bir kullanıcı adına</b> dokun → profilini gör, takip et veya özel mesaj at.'
            ]
        },
        {
            tab: 2, emoji: '🛒', title: 'Pazar',
            subtitle: 'İkinci El Bisiklet & Parça Pazarı',
            desc: 'Kullanılmış bisiklet ve parçaları al veya sat, toplulukla takas yap.',
            tips: [
                '🔎 <b>Arama kutusuna</b> ürün adı yaz → anında ilanlar filtrelenir.',
                '💰 <b>Bir ilana</b> dokun → fiyatı, açıklamayı ve satıcı bilgisini gör.',
                '📤 <b>"İlan Ver" butonuna</b> bas → kendi bisiklet veya parçanı saniyeler içinde sat.',
                '❤️ <b>Kalp ikonuna</b> bas → beğendiğin ilanı favorilerine ekle.'
            ]
        },
        {
            tab: 5, emoji: '🎯', title: 'Görevler & Çark',
            subtitle: 'XP Kazan, Ödül Çevir',
            desc: 'Günlük görevleri tamamla, puan topla; şans çarkını çevirerek sürpriz ödüller kazan.',
            tips: [
                '✅ <b>Görev listesindeki "Tamamla" butonuna</b> bas → XP ve rozet kazan.',
                '🎡 <b>Şans Çarkına</b> bas → günlük ücretsiz çevirme hakkınla ödül kazan.',
                '🏅 <b>Rozet koleksiyonuna</b> bak → hangi başarımlara sahip olduğunu gör.',
                '📅 Görevler <b>her gün sıfırlanır</b> → her gün gir, XP biriktir!'
            ]
        },
        {
            tab: 9, emoji: '🎬', title: 'Reels',
            subtitle: 'Bisiklet Aksiyon Videoları',
            desc: 'Sürücülerin çektiği kısa aksiyon videolarını izle veya kendi anını paylaş.',
            tips: [
                '📜 <b>Ekranı yukarı/aşağı kaydır</b> → bir sonraki veya önceki videoya geç.',
                '❤️ <b>Kalp ikonuna</b> çift dokun veya bas → videoyu beğen.',
                '💬 <b>Yorum ikonuna</b> bas → video hakkında yorum yap, sürücüyle etkileş.',
                '📤 <b>Paylaş butonuna</b> bas → kendi sürüş videonunu yükle, topluluğa göster.'
            ]
        },
        {
            tab: 3, emoji: '🏆', title: 'Sıralama Tablosu',
            subtitle: 'Liderlik & XP Sıralaması',
            desc: 'Türkiye geneli ve şehir bazında XP sıralamalarında yerini gör.',
            tips: [
                '📊 <b>"Türkiye" sekmesine</b> bas → tüm sürücüler arasındaki sıranı gör.',
                '🏙️ <b>"Şehrim" sekmesine</b> bas → sadece bulunduğun ilin sıralamasını gör.',
                '👤 <b>Bir kullanıcıya</b> dokun → o kişinin profilini ve istatistiklerini incele.',
                '📈 <b>Görev tamamla ve aktif ol</b> → XP kazan, sıralamanda yüksel.'
            ]
        },
        {
            tab: 7, emoji: '👤', title: 'Profil',
            subtitle: 'Garaj, Rozetler & Ayarlar',
            desc: 'Kendi dijital garajını oluştur, rozetlerini ve istatistiklerini takip et.',
            tips: [
                '✏️ <b>"Profili Düzenle" butonuna</b> bas → fotoğrafını, biyografini ve şehrini güncelle.',
                '🚲 <b>Garaj bölümüne</b> bak → bisikletlerini ekle, sürüş tarihçeni tut.',
                '🏅 <b>Rozetlerine</b> dokun → her rozeti nasıl kazandığını öğren.',
                '⚙️ <b>Ayarlar butonuna</b> bas → bildirim, gizlilik ve tema ayarlarını yönet.'
            ],
            isLast: true
        }
    ];

    // Turu gösterecek ana overlay elementi
    var overlayEl = null;

    function removeOverlay() {
        if (overlayEl && overlayEl.parentNode) {
            overlayEl.parentNode.removeChild(overlayEl);
        }
        overlayEl = null;
    }

    function showStep(idx) {
        removeOverlay();

        var step = STEPS[idx];
        var total = STEPS.length;
        var isLast = !!step.isLast;

        // Progress dots
        var dotsHtml = '';
        for (var i = 0; i < total; i++) {
            var dotColor = i < idx ? 'rgba(168,85,247,0.6)' : (i === idx ? '#a855f7' : 'rgba(255,255,255,0.15)');
            var dotWidth = i === idx ? '36px' : '14px';
            dotsHtml += '<div style="height:4px;border-radius:2px;background:' + dotColor + ';width:' + dotWidth + ';transition:all 0.3s;' + (i === idx ? 'box-shadow:0 0 8px rgba(168,85,247,0.9);' : '') + '"></div>';
        }

        // Tips
        var tipsHtml = '';
        for (var j = 0; j < step.tips.length; j++) {
            tipsHtml += '<div style="display:flex;align-items:flex-start;gap:12px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:12px 14px;margin-bottom:10px;">' +
                '<span style="font-size:19px;flex-shrink:0;line-height:1.3;">' + step.tips[j].split(' ')[0] + '</span>' +
                '<span style="font-size:13px;color:#d4d4d8;line-height:1.55;">' + step.tips[j].substring(step.tips[j].indexOf(' ') + 1) + '</span>' +
                '</div>';
        }

        // Prev button
        var prevBtn = idx > 0
            ? '<button onclick="window.AppTour.prev()" style="flex-shrink:0;width:46px;height:52px;border-radius:13px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);color:#a1a1aa;font-size:18px;cursor:pointer;">←</button>'
            : '';

        // Next button
        var nextLabel = isLast ? '🎉 Turu Tamamla!' : 'Sıradaki →';
        var nextBg = isLast ? 'linear-gradient(135deg,#f59e0b,#ef4444)' : 'linear-gradient(135deg,#7c3aed,#a855f7)';
        var nextBtn = '<button onclick="window.AppTour.next()" style="flex:1;height:52px;border-radius:14px;background:' + nextBg + ';border:none;color:#fff;font-size:14px;font-weight:900;cursor:pointer;box-shadow:0 6px 20px rgba(168,85,247,0.45);letter-spacing:0.3px;">' + nextLabel + '</button>';

        // Build full overlay HTML
        overlayEl = document.createElement('div');
        overlayEl.id = 'apptour-overlay-v5';
        overlayEl.innerHTML =
            // Backdrop (semi-transparent, clicking it skips tour)
            '<div onclick="window.AppTour.skip()" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2147483640;"></div>' +
            // Bottom sheet
            '<div id="apptour-sheet-v5" style="' +
                'position:fixed;left:0;right:0;bottom:0;' +
                'z-index:2147483645;' +
                'background:linear-gradient(170deg,#1c1c1f 0%,#0a0a0c 100%);' +
                'border-top:1.5px solid rgba(168,85,247,0.4);' +
                'border-radius:26px 26px 0 0;' +
                'padding:20px 18px 36px;' +
                'box-shadow:0 -24px 70px rgba(0,0,0,0.85);' +
                'max-height:85vh;overflow-y:auto;' +
                'transform:translateY(100%);' +
                'transition:transform 0.4s cubic-bezier(0.34,1.56,0.64,1);' +
                'pointer-events:auto;' +
            '">' +
                // Handle bar
                '<div style="width:38px;height:4px;background:rgba(255,255,255,0.13);border-radius:2px;margin:0 auto 18px;"></div>' +
                // Badge
                '<div style="text-align:center;margin-bottom:14px;">' +
                    '<span style="display:inline-block;background:linear-gradient(90deg,rgba(168,85,247,0.22),rgba(99,102,241,0.22));border:1px solid rgba(168,85,247,0.45);border-radius:100px;padding:4px 14px;font-size:11px;font-weight:800;color:#c4b5fd;letter-spacing:1.2px;text-transform:uppercase;">Adım ' + (idx+1) + ' / ' + total + '</span>' +
                '</div>' +
                // Emoji ring
                '<div style="width:68px;height:68px;border-radius:50%;background:radial-gradient(circle,rgba(168,85,247,0.2) 0%,transparent 70%);border:2px solid rgba(168,85,247,0.5);display:flex;align-items:center;justify-content:center;font-size:34px;margin:0 auto 14px;box-shadow:0 0 28px rgba(168,85,247,0.4);">' + step.emoji + '</div>' +
                // Title
                '<div style="font-size:22px;font-weight:900;color:#fff;text-align:center;margin-bottom:4px;letter-spacing:-0.5px;">' + step.title + '</div>' +
                // Subtitle
                '<div style="font-size:11px;font-weight:700;color:#a855f7;text-align:center;margin-bottom:10px;text-transform:uppercase;letter-spacing:1.2px;">' + step.subtitle + '</div>' +
                // Desc
                '<div style="font-size:13px;color:#a1a1aa;text-align:center;line-height:1.6;margin-bottom:18px;">' + step.desc + '</div>' +
                // Progress dots
                '<div style="display:flex;gap:5px;justify-content:center;margin-bottom:18px;">' + dotsHtml + '</div>' +
                // Divider
                '<div style="height:1px;background:linear-gradient(90deg,transparent,rgba(255,255,255,0.08),transparent);margin-bottom:14px;"></div>' +
                // Tips label
                '<div style="font-size:10px;font-weight:800;color:#52525b;text-transform:uppercase;letter-spacing:2px;margin-bottom:10px;">Bu sayfada ne yapacaksın?</div>' +
                // Tips
                tipsHtml +
                // Buttons
                '<div style="display:flex;gap:10px;align-items:center;margin-top:6px;">' + prevBtn + nextBtn + '</div>' +
                // Skip
                '<button onclick="window.AppTour.skip()" style="display:block;width:100%;margin-top:12px;padding:8px;background:transparent;border:none;color:#3f3f46;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;cursor:pointer;">Turu Geç ✕</button>' +
            '</div>';

        // Set z-index on panel wrapper too
        overlayEl.style.cssText = 'position:fixed;inset:0;z-index:2147483640;pointer-events:none;';

        document.body.appendChild(overlayEl);

        // Slide up animation
        requestAnimationFrame(function() {
            requestAnimationFrame(function() {
                var sheet = document.getElementById('apptour-sheet-v5');
                if (sheet) sheet.style.transform = 'translateY(0)';
            });
        });
    }

    function goToStep(idx) {
        current = idx;
        var step = STEPS[idx];
        if (typeof switchTab === 'function') switchTab(step.tab);
        setTimeout(function() { showStep(idx); }, 500);
    }

    function hideAndRun(cb) {
        var sheet = document.getElementById('apptour-sheet-v5');
        if (sheet) {
            sheet.style.transform = 'translateY(100%)';
            setTimeout(function() {
                removeOverlay();
                if (cb) cb();
            }, 380);
        } else {
            removeOverlay();
            if (cb) cb();
        }
    }

    return {
        init: function() {
            // Önce hesaba kayıtlı DB değerini kontrol et (farklı cihazlarda da çalışsın)
            if (typeof currentUser !== 'undefined' && currentUser && currentUser.stats && currentUser.stats.onboarding_completed) {
                return; // Veritabanında tur tamamlandı kaydı varsa başlatma
            }
            var done = localStorage.getItem(TOUR_KEY);
            if (!done) {
                var self = this;
                setTimeout(function() { self.start(false); }, 2200);
            }
        },

        start: function(forceRestart) {
            if (forceRestart) localStorage.removeItem(TOUR_KEY);
            current = 0;
            removeOverlay();
            if (typeof showToast === 'function') showToast('🚀 Uygulama turu başlıyor…', 'success', 2000);
            // switchTab(0) already called by startAppTourFromSettings; also call here for init path
            if (!forceRestart && typeof switchTab === 'function') switchTab(0);
            var self = this;
            setTimeout(function() { showStep(0); }, 500);
        },

        next: function() {
            if (current >= STEPS.length - 1) {
                this.finish();
            } else {
                var self = this;
                hideAndRun(function() { goToStep(current + 1); });
            }
        },

        prev: function() {
            if (current > 0) {
                hideAndRun(function() { goToStep(current - 1); });
            }
        },

        skip: function() {
            var self = this;
            hideAndRun(function() { self._complete(); });
        },

        finish: function() {
            var self = this;
            hideAndRun(function() {
                self._complete();
                if (typeof window.confetti === 'function') {
                    window.confetti({ particleCount: 220, spread: 130, origin: { y: 0.6 },
                        colors: ['#a855f7','#38bdf8','#f59e0b','#ef4444','#ffffff'],
                        disableForReducedMotion: true, zIndex: 9999999 });
                }
                if (typeof showToast === 'function') {
                    setTimeout(function() { showToast("🎉 Tebrikler! Artık Freerider TR'yi tam olarak biliyorsun!", 'success', 4000); }, 300);
                }
            });
        },

        _complete: function() {
            localStorage.setItem(TOUR_KEY, 'true');
            if (typeof currentUser !== 'undefined' && currentUser && currentUser.stats && !currentUser.stats.onboarding_completed) {
                currentUser.stats.onboarding_completed = true;
                if (typeof sendAction === 'function') sendAction('update_user_stats', { stats: currentUser.stats });
            }
        }
    };

})();

// Geriye dönük uyumluluk
window.OnboardingManager = { startTour: function() { window.AppTour.start(true); }, init: function() { window.AppTour.init(); } };



// --- iOS PWA Install Prompt Logic ---
function closeIosPrompt() {
    document.getElementById('ios-pwa-prompt').classList.add('hidden');
    localStorage.setItem('iosPromptClosed', 'true');
}

document.addEventListener("DOMContentLoaded", () => {
    const isIos = () => {
        const userAgent = window.navigator.userAgent.toLowerCase();
        return /iphone|ipad|ipod/.test(userAgent);
    };
    const isStandalone = () => {
        return ('standalone' in window.navigator) && (window.navigator.standalone);
    };

    if (isIos() && !isStandalone()) {
        if (!localStorage.getItem('iosPromptClosed')) {
            setTimeout(() => {
                const prompt = document.getElementById('ios-pwa-prompt');
                if(prompt) {
                    prompt.classList.remove('hidden');
                    if(typeof lucide !== 'undefined') lucide.createIcons();
                }
            }, 3000);
        }
    }
});
</script>

<!-- iOS PWA Install Prompt -->
<div id="ios-pwa-prompt" class="hidden fixed bottom-5 left-1/2 -translate-x-1/2 w-[95%] max-w-sm z-[99999] slide-up-anim">
    <div class="glass-panel border border-zinc-700/80 rounded-2xl p-4  relative bg-black/80 ">
        <button onclick="closeIosPrompt()" class="absolute top-2 right-2 text-zinc-400 hover:text-white bg-black/50 w-8 h-8 rounded-full flex items-center justify-center border border-zinc-700 transition hover:scale-110">✕</button>
        <div class="flex items-start gap-4">
            <img src="https://cdn.freeridertr.com.tr/profil%20resmi/unnamed.jpg" class="w-14 h-14 rounded-xl  border border-red-900/50">
            <div class="pr-6">
                <h4 class="text-white font-bold text-base leading-tight">Uygulamayı Yükle</h4>
                <p class="text-zinc-300 text-[11px] mt-1.5 leading-relaxed">
                    Tam ekran deneyim için alttaki Paylaş <span class="inline-flex bg-zinc-800 text-blue-400 p-0.5 rounded mx-0.5 align-middle border border-zinc-700"><i data-lucide="share" class="w-3 h-3"></i></span> ikonuna dokunun ve <br><b class="text-white font-bold">"Ana Ekrana Ekle"</b> seçeneğini seçin.
                </p>
            </div>
        </div>
    </div>
</div>

<!-- ========== AI DESTEK FLOATING PANEL ========== -->
<div id="ai-support-overlay" style="
  display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6);
  z-index:99998; backdrop-filter:blur(4px); transition:opacity 0.3s;
" onclick="if(event.target===this)closeAISupportPanel()"></div>

<div id="ai-support-panel" style="
  display:none; position:fixed; bottom:20px; right:20px;
  width:360px; max-width:calc(100vw - 24px);
  height:520px; max-height:calc(100vh - 100px);
  background:#1a1a2e; border-radius:20px;
  box-shadow:0 8px 40px rgba(0,0,0,0.6);
  z-index:99999; display:none; flex-direction:column;
  font-family:inherit; overflow:hidden;
  border:1px solid rgba(255,255,255,0.08);
  animation:aiSupportSlideUp 0.35s cubic-bezier(0.34,1.56,0.64,1);
">
  <!-- Header -->
  <div style="
    background:linear-gradient(135deg,#1a73e8,#6c3fe8);
    padding:14px 16px; display:flex; align-items:center; gap:10px;
    flex-shrink:0;
  ">
    <div style="
      width:38px; height:38px; border-radius:50%;
      background:rgba(255,255,255,0.2);
      display:flex; align-items:center; justify-content:center;
      font-size:18px; flex-shrink:0;
    ">👨‍💻</div>
    <div style="flex:1;">
      <div style="color:#fff; font-weight:700; font-size:14px;">Mert — Destek Ekibi</div>
      <div style="color:rgba(255,255,255,0.75); font-size:11px; display:flex; align-items:center; gap:4px;">
        <span style="width:7px;height:7px;border-radius:50%;background:#4cff91;display:inline-block;"></span>
        Çevrimiçi
      </div>
    </div>
    <button onclick="closeAISupportPanel()" style="
      background:rgba(255,255,255,0.15); border:none; color:#fff;
      width:28px; height:28px; border-radius:50%; cursor:pointer;
      font-size:16px; display:flex; align-items:center; justify-content:center;
      transition:background 0.2s;
    " onmouseover="this.style.background='rgba(255,255,255,0.3)'" 
       onmouseout="this.style.background='rgba(255,255,255,0.15)'">✕</button>
  </div>

  <!-- Messages area -->
  <div id="ai-support-messages" style="
    flex:1; overflow-y:auto; padding:14px 12px;
    display:flex; flex-direction:column; gap:10px;
    scrollbar-width:thin; scrollbar-color:rgba(255,255,255,0.15) transparent;
  ">
    <!-- Karşılama mesajı -->
    <div class="ai-msg-bot" style="
      background:rgba(255,255,255,0.06); border-radius:14px 14px 14px 4px;
      padding:10px 13px; max-width:85%; font-size:13px; color:#e0e0e0; line-height:1.5;
    ">
      Merhaba! Ben Mert, FreeriderTR destek ekibindenim 👋<br>
      Hesap kurtarma, teknik sorunlar veya platform hakkında her konuda yardımcı olabilirim. Nasıl yardımcı olabilirim?
    </div>
  </div>

  <!-- Input area -->
  <div style="
    padding:10px 12px; border-top:1px solid rgba(255,255,255,0.08);
    display:flex; gap:8px; flex-shrink:0; background:rgba(0,0,0,0.2);
  ">
    <textarea id="ai-support-input" placeholder="Mesajınızı yazın..." style="
      flex:1; background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12);
      border-radius:12px; color:#fff; padding:9px 12px; font-size:13px;
      font-family:inherit; resize:none; outline:none; max-height:80px;
      min-height:38px; line-height:1.4;
      scrollbar-width:thin; scrollbar-color:rgba(255,255,255,0.15) transparent;
    " rows="1" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendAISupportMessage();}"
       oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,80)+'px';"
    ></textarea>
    <button id="ai-support-send-btn" onclick="sendAISupportMessage()" style="
      background:linear-gradient(135deg,#1a73e8,#6c3fe8);
      border:none; color:#fff; width:38px; height:38px;
      border-radius:12px; cursor:pointer; font-size:18px;
      display:flex; align-items:center; justify-content:center;
      flex-shrink:0; transition:opacity 0.2s; align-self:flex-end;
    ">➤</button>
  </div>
</div>


<style>
@keyframes aiSupportSlideUp {
  from { opacity:0; transform:translateY(30px) scale(0.95); }
  to   { opacity:1; transform:translateY(0) scale(1); }
}
.ai-msg-bot, .ai-msg-user { animation: aiSupportSlideUp 0.2s ease; }
</style>

<script>
// ======== AI DESTEK SİSTEMİ ========
var _aiSupportHistory = [];
var _aiSupportPending = false;
var _aiSupportIdentityVerified = false;
var _aiSupportTargetUsername = '';

function openAISupportPanel() {
  document.getElementById('ai-support-overlay').style.display = 'block';
  var panel = document.getElementById('ai-support-panel');
  panel.style.display = 'flex';
  setTimeout(function(){ document.getElementById('ai-support-input').focus(); }, 300);
}

function closeAISupportPanel() {
  document.getElementById('ai-support-overlay').style.display = 'none';
  document.getElementById('ai-support-panel').style.display = 'none';
}

function _addAIMessage(text, isUser) {
  var container = document.getElementById('ai-support-messages');
  var div = document.createElement('div');
  div.style.cssText = isUser
    ? 'background:linear-gradient(135deg,#1a73e8,#6c3fe8);border-radius:14px 14px 4px 14px;padding:10px 13px;max-width:80%;font-size:13px;color:#fff;line-height:1.5;align-self:flex-end;'
    : 'background:rgba(255,255,255,0.06);border-radius:14px 14px 14px 4px;padding:10px 13px;max-width:85%;font-size:13px;color:#e0e0e0;line-height:1.5;';
  div.innerHTML = text.split(String.fromCharCode(10)).join('<br>');
  div.className = isUser ? 'ai-msg-user' : 'ai-msg-bot';
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  return div;
}

function _addTypingIndicator() {
  var container = document.getElementById('ai-support-messages');
  var div = document.createElement('div');
  div.id = 'ai-typing';
  div.style.cssText = 'background:rgba(255,255,255,0.06);border-radius:14px 14px 14px 4px;padding:8px 16px;max-width:60px;font-size:24px;color:#fff;display:flex;align-items:center;justify-content:space-between;line-height:1;';
  div.innerHTML = '<span style="animation:aiTypeDot 1.4s infinite both;">•</span><span style="animation:aiTypeDot 1.4s infinite 0.2s both;">•</span><span style="animation:aiTypeDot 1.4s infinite 0.4s both;">•</span>';
  if (!document.getElementById('ai-type-style')) {
    var s = document.createElement('style');
    s.id = 'ai-type-style';
    s.textContent = '@keyframes aiTypeDot{0%,80%,100%{opacity:0.3}40%{opacity:1}}';
    document.head.appendChild(s);
  }
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function _removeTypingIndicator() {
  var el = document.getElementById('ai-typing');
  if (el) el.remove();
}

function sendAISupportMessage() {
  if (_aiSupportPending) return;
  var input = document.getElementById('ai-support-input');
  var msg = input.value.trim();
  if (!msg) return;
  
  input.value = '';
  input.style.height = '38px';
  _addAIMessage(msg, true);
  _aiSupportHistory.push({ role: 'user', content: msg });
  
  _aiSupportPending = true;
  document.getElementById('ai-support-send-btn').style.opacity = '0.5';
  _addTypingIndicator();
  
  var sessionId = 'guest_' + (Date.now().toString(36));
  
  fetch('/api/data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'ai_support_chat',
      data: {
        message: msg,
        history: _aiSupportHistory.slice(-10),
        session_id: sessionId
      }
    })
  })
  .then(function(r){ return r.json(); })
  .then(function(d) {
    _removeTypingIndicator();
    _aiSupportPending = false;
    document.getElementById('ai-support-send-btn').style.opacity = '1';
    
    if (d.status === 'ok') {
      var reply = d.message || '';
      _addAIMessage(reply, false);
      _aiSupportHistory.push({ role: 'assistant', content: reply });
      
      // Extra data işleme
      var extra = d.extra || {};
      if (extra.identity_verified && extra.target_username) {
        _aiSupportIdentityVerified = true;
        _aiSupportTargetUsername = extra.target_username;
        // Şifre belirleme UI'ı göster
        _showPasswordSetUI(extra.target_username);
      }
    } else {
      _addAIMessage('Şu an bir sorun yaşıyoruz, lütfen daha sonra tekrar deneyin 🙏', false);
    }
  })
  .catch(function() {
    _removeTypingIndicator();
    _aiSupportPending = false;
    document.getElementById('ai-support-send-btn').style.opacity = '1';
    _addAIMessage('Bağlantı hatası oluştu. İnternet bağlantınızı kontrol edin.', false);
  });
}

function _showPasswordSetUI(username) {
  var container = document.getElementById('ai-support-messages');
  var wrapper = document.createElement('div');
  wrapper.style.cssText = 'background:rgba(26,115,232,0.15);border:1px solid rgba(26,115,232,0.3);border-radius:14px;padding:12px;margin-top:4px;';
  var lbl = document.createElement('div');
  lbl.style.cssText = 'color:#90caf9;font-size:12px;margin-bottom:8px;font-weight:600;';
  lbl.textContent = '🔐 Yeni Şifre Belirle';
  var inp = document.createElement('input');
  inp.id = 'new-pw-input'; inp.type = 'password';
  inp.placeholder = 'Yeni şifreniz (min. 6 karakter)';
  inp.style.cssText = 'width:100%;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.15);border-radius:8px;color:#fff;padding:8px 10px;font-size:13px;outline:none;box-sizing:border-box;';
  var btn = document.createElement('button');
  btn.textContent = 'Şifreyi Kaydet';
  btn.style.cssText = 'margin-top:8px;width:100%;background:linear-gradient(135deg,#1a73e8,#6c3fe8);border:none;color:#fff;border-radius:8px;padding:8px;font-size:13px;cursor:pointer;font-family:inherit;';
  btn.onclick = function() { submitNewPassword(username); };
  wrapper.appendChild(lbl); wrapper.appendChild(inp); wrapper.appendChild(btn);
  container.appendChild(wrapper);
  container.scrollTop = container.scrollHeight;
}

function submitNewPassword(username) {
  var pw = document.getElementById('new-pw-input') ? document.getElementById('new-pw-input').value.trim() : '';
  if (!pw || pw.length < 6) {
    alert('Şifre en az 6 karakter olmalı.');
    return;
  }
  
  fetch('/api/data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'ai_support_set_password', target_username: username, new_password: pw })
  })
  .then(function(r){ return r.json(); })
  .then(function(d) {
    if (d.status === 'ok') {
      _addAIMessage('✅ Şifreniz başarıyla güncellendi! Artık yeni şifrenizle giriş yapabilirsiniz.', false);
    } else {
      _addAIMessage('⚠️ ' + (d.message || 'Bir hata oluştu.'), false);
    }
  });
}

// ============================================================
// ANDROID SWIPEREFRESH KONTROLÜ
// ============================================================
(function() {
    let allowSwipeRefresh = true;

    function checkSwipeEnabled(e) {
        if (!window.AndroidApp) return;
        
        let shouldDisable = false;
        
        // Eğer herhangi bir modal açıksa SwipeRefresh kapat (UI ile çakışmasın)
        const modals = document.querySelectorAll('.fixed.inset-0:not(.hidden)');
        if (modals.length > 0) {
            shouldDisable = true;
        } else {
            // Modal kapalı, fakat scroll edilen bir div'e dokunuluyorsa?
            let el = e.target;
            while (el && el !== document.body && el !== document) {
                const style = window.getComputedStyle(el);
                if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
                    // İç div zaten biraz aşağı kaydırılmışsa SwipeRefresh çalışmamalı!
                    if (el.scrollTop > 0) {
                        shouldDisable = true;
                        break;
                    }
                }
                el = el.parentElement;
            }
        }
        
        const newAllow = !shouldDisable;
        if (newAllow !== allowSwipeRefresh) {
            allowSwipeRefresh = newAllow;
            try {
                window.AndroidApp.setSwipeEnabled(allowSwipeRefresh);
            } catch(err) {}
        }
    }

    document.addEventListener('touchstart', checkSwipeEnabled, { passive: true });
    // Scroll esnasında div en tepeye gelirse tekrar açabilmek için
    document.addEventListener('scroll', function(e) {
        if (e.target && e.target.scrollTop === 0) {
            checkSwipeEnabled(e);
        }
    }, true);
})();
</script>

</body>
</html>
"""
